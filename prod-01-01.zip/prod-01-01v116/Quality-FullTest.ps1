<# 
Quality-FullTest.ps1  (Fixed v2)
- Correct parser overload
- Skip header check for Functions-Common.ps1 by default
- Writes JSON + Markdown to C:\CS-Toolbox-TEMP\Collected-Info
#>

[CmdletBinding()]
param(
  [string]$Root = "C:\CS-Toolbox-TEMP\prod-01-01",
  [switch]$Recurse,
  [switch]$IncludeFunctionsCommonInHeaderCheck
)

# Load shared functions first – required for Show-Header and others
# (param MUST be first, so we load immediately after it)
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    exit 1
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    exit 1
}

Ensure-ExportFolder

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Paths / helpers
$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory | Out-Null }
function Get-Timestamp { (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }
$ts = Get-Timestamp
$jsonPath = Join-Path $ExportRoot ("Quality-FullTest-Findings-{0}.json" -f $ts)
$mdPath   = Join-Path $ExportRoot ("Quality-FullTest-Report-{0}.md"    -f $ts)

function Write-Utf8NoBom {
  param([string]$Path,[string]$Content)
  $enc = [System.Text.UTF8Encoding]::new($false)
  [IO.File]::WriteAllBytes($Path, $enc.GetBytes($Content))
}

# --- Required header signature pieces
function Get-RequiredHeaderFirstLine { [string]([char]0x0023) + " Load shared functions first " + [char]0x2013 + " required for Show-Header and others" }
$HeaderFirstLine = Get-RequiredHeaderFirstLine

function Test-HasHeader {
  param([string]$Content)
  # Escape $ so we match literal "$scriptRoot"
  $joinPathPattern = "Join-Path\s+\`$scriptRoot\s+'Functions-Common\.ps1'"
  return (($Content -match [regex]::Escape($HeaderFirstLine)) -and ($Content -match $joinPathPattern))
}

# --- Collect files
if (-not (Test-Path $Root)) { throw "Root not found: $Root" }
$files = Get-ChildItem -Path $Root -Filter *.ps1 -File -Recurse:$Recurse | Sort-Object FullName

# --- Results containers
$syntaxIssues  = New-Object System.Collections.Generic.List[object]
$headerMissing = New-Object System.Collections.Generic.List[object]

# --- Scan
foreach ($fi in $files) {
  $path = $fi.FullName
  $name = $fi.Name

  # 1) Syntax check using correct overload
  try {
    $null = $t = $e = $null
    [System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$t, [ref]$e) | Out-Null
    if ($e -and $e.Count -gt 0) {
      foreach ($err in $e) {
        $syntaxIssues.Add([pscustomobject]@{
          Script  = $name
          Path    = $path
          Line    = $err.Extent.StartLineNumber
          Column  = $err.Extent.StartColumnNumber
          Message = ($err.Message -as [string])
        })
      }
    }
  } catch {
    $syntaxIssues.Add([pscustomobject]@{
      Script  = $name
      Path    = $path
      Line    = 0
      Column  = 0
      Message = "Parser threw: $($_.Exception.Message)"
    })
  }

  # 2) Header check (skip Functions-Common.ps1 unless explicitly included)
  $skipHeaderCheck = (-not $IncludeFunctionsCommonInHeaderCheck) -and ($name -ieq 'Functions-Common.ps1')
  if (-not $skipHeaderCheck) {
    try { $raw = Get-Content -Path $path -Raw -Encoding UTF8 } catch { $raw = Get-Content -Path $path -Raw }
    if (-not (Test-HasHeader -Content $raw)) {
      $headerMissing.Add([pscustomobject]@{
        Script  = $name
        Path    = $path
        Message = "Missing required header element: # Load shared functions first - required for Show-Header and others"
        FixHint = "Add the standard Functions-Common loader block at the very top (above Show-Header) exactly as specified."
      })
    }
  }
}

# --- Compose JSON
$payload = [pscustomobject]@{
  ScannedRoot = $Root
  Timestamp   = (Get-Date).ToString("s")
  Counts      = [pscustomobject]@{
    SyntaxIssues  = $syntaxIssues.Count
    HeaderMissing = $headerMissing.Count
    Placeholders  = 0
    Forbidden     = 0
  }
  SyntaxIssues  = $syntaxIssues
  HeaderMissing = $headerMissing
  Placeholders  = @()
  Forbidden     = @()
}

# --- Write JSON
$payload | ConvertTo-Json -Depth 6 | Write-Utf8NoBom -Path $jsonPath

# --- Write Markdown
$md = New-Object System.Text.StringBuilder
[void]$md.AppendLine("# CS Toolbox - Full Quality Test Report")
[void]$md.AppendLine("")
[void]$md.AppendLine("* Scanned Root: **$Root**")
[void]$md.AppendLine("* Timestamp: **$(Get-Date)**")
[void]$md.AppendLine("")
[void]$md.AppendLine("## Summary")
[void]$md.AppendLine("* Syntax issues: **$($payload.Counts.SyntaxIssues)**")
[void]$md.AppendLine("* Header missing: **$($payload.Counts.HeaderMissing)**")
[void]$md.AppendLine("* Placeholders: **0**")
[void]$md.AppendLine("* Forbidden: **0**")
[void]$md.AppendLine("")

[void]$md.AppendLine("## Syntax Issues")
if ($syntaxIssues.Count -eq 0) {
  [void]$md.AppendLine("- None")
} else {
  foreach ($s in $syntaxIssues) {
    [void]$md.AppendLine(("- **{0}** L{1}:{2} - {3}" -f $s.Script, $s.Line, $s.Column, $s.Message))
  }
}
[void]$md.AppendLine("")

[void]$md.AppendLine("## Header Missing")
if ($headerMissing.Count -eq 0) {
  [void]$md.AppendLine("- None")
} else {
  foreach ($h in $headerMissing) {
    [void]$md.AppendLine(("- **{0}** - {1}" -f $h.Script, $h.Message))
    [void]$md.AppendLine(("  - Fix: {0}" -f $h.FixHint))
  }
}
[void]$md.AppendLine("")
[void]$md.AppendLine("## Placeholders Found")
[void]$md.AppendLine("- None")
[void]$md.AppendLine("")
[void]$md.AppendLine("## Forbidden Strings")
[void]$md.AppendLine("- None")
[void]$md.AppendLine("")
[void]$md.AppendLine("## Pester Summary")
[void]$md.AppendLine("- Pester not available")

Write-Utf8NoBom -Path $mdPath -Content $md.ToString()

Write-Host "Reports written:" -ForegroundColor Cyan
Write-Host (" - {0}" -f $jsonPath)
Write-Host (" - {0}" -f $mdPath)
