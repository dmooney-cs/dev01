param(
    [Alias('DefaultLogs')]
    [switch]$DefaultLog,
    [switch]$Html,
    [switch]$ExportOnly
)

# =====================================================================
# agent-msg-correlator.ps1  (PS 5.1 compatible)
# ---------------------------------------------------------------------
# SWITCHES:
#   -DefaultLog / -DefaultLogs
#       * Uses default agent log path automatically:
#           C:\Program Files (x86)\CyberCNSAgent\logs
#       * Quiet mode (suppresses info chatter; errors always shown)
#       * Skips interactive main menu entirely
#       * Skips HTML prompt; only console summary + details
#
#   -Html
#       * Auto-creates HTML report (no "Y/N" prompt)
#       * Does NOT open the HTML file (no Start-Process)
#       * Works with or without -DefaultLog
#
#   -ExportOnly   (required for cookbook commands)
#       * Uses default agent log path automatically
#       * Quiet mode
#       * Forces HTML export (no prompt), does NOT open
#       * Exits after export (no menu/launcher hand-off)
#
# Occurrence snapshots:
#   * Shows ONLY ONE occurrence per match (MOST RECENT)
#   * Includes the exact matching line + 5 lines before/after
#   * Shown in console and included in HTML export
# =====================================================================

# -----------------------------
# Configurable Paths & URLs
# -----------------------------
$Global:MsgIndexPrimaryUrl       = 'https://raw.githubusercontent.com/dmooney-cs/prod/main/cs-message-index.csv'
$Global:MsgIndexSecondaryUrl     = ''

# Optional hash URLs (plain text SHA256). Leave $null if not used.
$Global:MsgIndexPrimaryHashUrl   = $null
$Global:MsgIndexSecondaryHashUrl = $null

# Local storage root for the message index
$Global:MsgIndexLocalRoot        = 'C:\CS-Toolbox-TEMP\prod-01-01\KnownIssues'
$Global:MsgIndexLocalFileName    = 'cs-message-index.csv'

# Default agent log root path
$Global:DefaultAgentLogRoot      = 'C:\Program Files (x86)\CyberCNSAgent\logs'

# Path to CS Toolbox Launcher (for Q in menu)
$Global:LauncherPath             = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# Quiet mode for -DefaultLog / -ExportOnly
$Global:MsgCorrelatorQuiet       = $false
if ($DefaultLog -or $ExportOnly) { $Global:MsgCorrelatorQuiet = $true }

# HTML behavior flags for -Html / -ExportOnly
$Global:MsgCorrelatorAutoHtml    = $false
$Global:MsgCorrelatorOpenHtml    = $true

if ($Html -or $ExportOnly) {
    $Global:MsgCorrelatorAutoHtml = $true
    $Global:MsgCorrelatorOpenHtml = $false
}

# Script-scope storage for CSV column names
$script:MsgIndexColumns          = @()

# -----------------------------
# Script Settings
# -----------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -----------------------------
# Helper: Logging (quiet-aware)
# -----------------------------
function Write-LogInfo {
    param([string]$Message)
    if ($Global:MsgCorrelatorQuiet) { return }
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[INFO]  $ts  $Message"
}
function Write-LogWarn {
    param([string]$Message)
    if ($Global:MsgCorrelatorQuiet) { return }
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[WARN]  $ts  $Message" -ForegroundColor Yellow
}
function Write-LogErrorLine {
    param([string]$Message)
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[ERROR] $ts  $Message" -ForegroundColor Red
}

# -----------------------------
# Helper: Ensure directory
# -----------------------------
function Ensure-Directory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-LogInfo "Creating directory: $Path"
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

# -----------------------------
# Helper: HTML escaping
# -----------------------------
function HtmlEscape {
    param([string]$s)
    if ($null -eq $s) { return '' }
    $s = $s -replace '&','&amp;'
    $s = $s -replace '<','&lt;'
    $s = $s -replace '>','&gt;'
    return $s
}

# -----------------------------
# Helper: Detect HTML masquerading as CSV
# -----------------------------
function Test-FileLooksLikeHtml {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try {
        $lines  = Get-Content -LiteralPath $Path -TotalCount 5 -ErrorAction Stop
        $joined = ($lines -join "`n").TrimStart()
        if ($joined.StartsWith("<!DOCTYPE html", [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
        if ($joined.StartsWith("<html", [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
        return $false
    }
    catch { return $false }
}

# -----------------------------
# Helper: Read file lines with caching (for context blocks)
# -----------------------------
function Get-CachedFileLines {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Cache,
        [Parameter(Mandatory = $true)][string]$Path
    )
    if ($Cache.ContainsKey($Path)) { return $Cache[$Path] }
    try { $lines = @(Get-Content -LiteralPath $Path -ErrorAction Stop) } catch { $lines = @() }
    $Cache[$Path] = $lines
    return $lines
}

# -----------------------------
# Helper: Build a context snippet (N lines before/after) for a match
# -----------------------------
function Get-LogContextSnippet {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Cache,
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][int]$LineNumber,
        [int]$Before = 5,
        [int]$After  = 5
    )

    $lines = Get-CachedFileLines -Cache $Cache -Path $Path
    if (-not $lines -or $lines.Count -eq 0) {
        return [pscustomobject]@{
            Path          = $Path
            MatchLine     = $LineNumber
            StartLine     = $LineNumber
            EndLine       = $LineNumber
            Lines         = @()
            MatchLineText = ''
        }
    }

    $total = $lines.Count
    if ($LineNumber -lt 1) { $LineNumber = 1 }
    if ($LineNumber -gt $total) { $LineNumber = $total }

    $start = $LineNumber - $Before
    if ($start -lt 1) { $start = 1 }
    $end = $LineNumber + $After
    if ($end -gt $total) { $end = $total }

    $slice = @()
    for ($i = $start; $i -le $end; $i++) {
        $slice += [pscustomobject]@{
            LineNumber = $i
            Text       = [string]$lines[$i-1]
            IsMatch    = ($i -eq $LineNumber)
        }
    }

    $matchText = [string]$lines[$LineNumber-1]

    return [pscustomobject]@{
        Path          = $Path
        MatchLine     = $LineNumber
        StartLine     = $start
        EndLine       = $end
        Lines         = $slice
        MatchLineText = $matchText
    }
}

# -----------------------------
# Helper: Download index
# -----------------------------
function Download-IndexFromSource {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$CsvUrl,
        [string]$HashUrl,
        [Parameter(Mandatory = $true)][string]$TargetPath
    )

    $attemptMax = 3
    $success    = $false

    Ensure-Directory -Path (Split-Path -Parent $TargetPath)

    for ($i = 1; $i -le $attemptMax -and -not $success; $i++) {
        Write-LogInfo "Attempt $i of $attemptMax to download index from $Label..."

        $tmpPath = "$TargetPath.download"
        if (Test-Path -LiteralPath $tmpPath) {
            Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
        }

        try {
            Invoke-WebRequest -Uri $CsvUrl -OutFile $tmpPath -UseBasicParsing -ErrorAction Stop

            if (Test-FileLooksLikeHtml -Path $tmpPath) {
                Write-LogWarn "Downloaded content from $Label appears to be HTML (not CSV). Discarding."
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                continue
            }

            $hashValue = $null
            try {
                $hashObj   = Get-FileHash -Path $tmpPath -Algorithm SHA256
                $hashValue = $hashObj.Hash
                Write-LogInfo "Downloaded index from $Label. SHA256: $hashValue"
            } catch {
                Write-LogWarn ("Failed to compute hash for download from {0}: {1}" -f $Label, $_.Exception.Message)
            }

            if ($HashUrl -and $HashUrl.Trim().Length -gt 0 -and $hashValue) {
                Write-LogInfo "Retrieving expected hash from: $HashUrl"
                try {
                    $expected = (Invoke-WebRequest -Uri $HashUrl -UseBasicParsing -ErrorAction Stop).Content.Trim()
                    Write-LogInfo "Expected SHA256: $expected"
                    if ($expected -and $expected -ne $hashValue) {
                        Write-LogWarn "Hash mismatch from $Label. Discarding downloaded file."
                        Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                        continue
                    }
                } catch {
                    Write-LogWarn "Failed to retrieve/read hash from $HashUrl : $($_.Exception.Message)"
                }
            } else {
                Write-LogInfo "No remote hash URL configured for $Label; local SHA256 shown for reference only."
            }

            if (Test-Path -LiteralPath $TargetPath) {
                Remove-Item -LiteralPath $TargetPath -Force -ErrorAction SilentlyContinue
            }
            Move-Item -Path $tmpPath -Destination $TargetPath -Force
            Write-LogInfo "Index downloaded and saved to: $TargetPath"
            $success = $true
        }
        catch {
            Write-LogWarn "Download attempt $i from $Label failed: $($_.Exception.Message)"
            if (Test-Path -LiteralPath $tmpPath) {
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
            }
        }
    }

    if (-not $success) { Write-LogWarn "All attempts to download from $Label failed." }
    return $success
}

# -----------------------------
# Helper: Index metadata
# -----------------------------
function Get-IndexMetadata {
    param([string]$LocalRoot,[string]$LocalFileName)

    Ensure-Directory -Path $LocalRoot
    $localPath = Join-Path $LocalRoot $LocalFileName

    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        if (Test-FileLooksLikeHtml -Path $localPath) {
            Write-LogWarn "Existing local index appears to be HTML (corrupted). Deleting."
            Remove-Item -LiteralPath $localPath -Force -ErrorAction SilentlyContinue
            return [pscustomobject]@{ Path=$localPath; Exists=$false; LastWriteTime=$null; AgeDays=$null }
        }

        $info   = Get-Item -LiteralPath $localPath
        $age    = (New-TimeSpan -Start $info.LastWriteTime -End (Get-Date)).TotalDays
        $ageR   = [Math]::Round([double]$age, 2)

        return [pscustomobject]@{
            Path          = $localPath
            Exists        = $true
            LastWriteTime = $info.LastWriteTime
            AgeDays       = $ageR
        }
    }

    return [pscustomobject]@{ Path=$localPath; Exists=$false; LastWriteTime=$null; AgeDays=$null }
}

# -----------------------------
# Helper: Ensure index fresh (7-day rule)
# -----------------------------
function Ensure-IndexFreshForCorrelation {
    param(
        [string]$PrimaryUrl,
        [string]$SecondaryUrl,
        [string]$PrimaryHashUrl,
        [string]$SecondaryHashUrl,
        [string]$LocalRoot,
        [string]$LocalFileName,
        [switch]$ForceRefresh
    )

    $meta = Get-IndexMetadata -LocalRoot $LocalRoot -LocalFileName $LocalFileName

    $needsDownload = $ForceRefresh.IsPresent -or (-not $meta.Exists) -or (
        $meta.AgeDays -ne $null -and $meta.AgeDays -gt 7.0
    )

    if ($meta.Exists -and -not $ForceRefresh.IsPresent -and $meta.AgeDays -ne $null -and $meta.AgeDays -le 7.0) {
        Write-LogInfo "Local index updated within last 7 days; no automatic refresh needed."
    }

    if ($needsDownload) {
        if (-not $ForceRefresh.IsPresent -and $meta.Exists) {
            Write-LogInfo ("Local index is older than 7 days (Age: {0} day(s)); refreshing from server." -f $meta.AgeDays)
        } elseif (-not $meta.Exists) {
            Write-LogInfo "No local index present; fetching from server."
        } else {
            Write-LogInfo "Force update of index requested."
        }

        $ok = $false
        if ($PrimaryUrl -and $PrimaryUrl.Trim().Length -gt 0) {
            $ok = Download-IndexFromSource -Label 'DL1' -CsvUrl $PrimaryUrl -HashUrl $PrimaryHashUrl -TargetPath (Join-Path $LocalRoot $LocalFileName)
        }
        if (-not $ok -and $SecondaryUrl -and $SecondaryUrl.Trim().Length -gt 0) {
            $ok = Download-IndexFromSource -Label 'DL2' -CsvUrl $SecondaryUrl -HashUrl $SecondaryHashUrl -TargetPath (Join-Path $LocalRoot $LocalFileName)
        }

        $meta = Get-IndexMetadata -LocalRoot $LocalRoot -LocalFileName $LocalFileName
        if (-not $meta.Exists) { throw "Unable to obtain index file from DL1 or DL2." }
    }

    return [pscustomobject]@{ Path=$meta.Path; Metadata=$meta }
}

# -----------------------------
# Helper: Extract CSV (if ZIP)
# -----------------------------
function Get-IndexCsvPath {
    param([Parameter(Mandatory = $true)][string]$IndexFilePath)

    $ext = [System.IO.Path]::GetExtension($IndexFilePath)
    if ($ext -ieq '.zip') {
        $tempDir = Join-Path ([System.IO.Path]::GetDirectoryName($IndexFilePath)) 'agent-msg-index-unzipped'
        Ensure-Directory -Path $tempDir
        Write-LogInfo "Index appears to be a ZIP. Extracting to: $tempDir"
        Get-ChildItem -LiteralPath $tempDir -File -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Expand-Archive -LiteralPath $IndexFilePath -DestinationPath $tempDir -Force

        $csv = Get-ChildItem -Path $tempDir -Filter *.csv -File -Recurse | Select-Object -First 1
        if (-not $csv) { throw "No CSV file found inside index archive: $IndexFilePath" }
        Write-LogInfo "Using CSV from archive: $($csv.FullName)"
        return $csv.FullName
    }

    Write-LogInfo "Index treated as CSV: $IndexFilePath"
    return $IndexFilePath
}

# -----------------------------
# Severity detection
# -----------------------------
$Global:LevelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'

function Get-SeverityFromLine {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return 'Unknown' }
    if ($Line -match $Global:LevelRegex) {
        $upper = $Matches[1].ToUpperInvariant()
        switch -Regex ($upper) {
            '^FAIL(ED)?$' { return 'FAIL' }
            default       { return $upper }
        }
    }
    return 'Unknown'
}
function Get-SeverityColor {
    param([string]$Severity)
    switch ($Severity) {
        'FATAL'          { return 'Red' }
        'ERROR'          { return 'Red' }
        'EXCEPTION'      { return 'Red' }
        'FAIL'           { return 'Magenta' }
        'TIMEOUT'        { return 'Magenta' }
        'UNAUTHORIZED'   { return 'DarkYellow' }
        'ACCESS DENIED'  { return 'DarkYellow' }
        'WARN'           { return 'Yellow' }
        'WARNING'        { return 'Yellow' }
        default          { return 'Cyan' }
    }
}

# -----------------------------
# Helper: Find CSV column by candidate names
# -----------------------------
function Find-CsvColName {
    param([string[]]$Props,[string[]]$Candidates)
    foreach ($cand in $Candidates) {
        $candNorm = ($cand -replace "^\uFEFF","").Trim().ToLowerInvariant()
        foreach ($p in $Props) {
            if (-not $p) { continue }
            $pNorm = ($p -replace "^\uFEFF","").Trim().ToLowerInvariant()
            if ($pNorm -eq $candNorm) { return $p }
        }
    }
    return $null
}

# -----------------------------
# Helper: normalize CSV values (BOM/quotes)
# -----------------------------
function Normalize-CsvValue {
    param([object]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace "^\uFEFF",""
    $s = $s.Trim()
    if ($s.Length -ge 2 -and $s.StartsWith('"') -and $s.EndsWith('"')) {
        $s = $s.Substring(1, $s.Length - 2)
    } else {
        if ($s.EndsWith('"')) { $s = $s.Substring(0, $s.Length - 1) }
        if ($s.StartsWith('"')) { $s = $s.Substring(1) }
    }
    return $s
}

# -----------------------------
# Multiline-safe CSV reader (PS 5.1)
# -----------------------------
function Read-CsvMultilineSafe {
    param([Parameter(Mandatory = $true)][string]$Path,[string]$Delimiter = ',')

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "CSV not found: $Path" }

    Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction Stop

    $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($Path)
    $parser.TextFieldType = 'Delimited'
    $parser.SetDelimiters($Delimiter)
    $parser.HasFieldsEnclosedInQuotes = $true
    $parser.TrimWhiteSpace = $false

    $headers = $parser.ReadFields()
    if (-not $headers -or $headers.Count -eq 0) {
        $parser.Close()
        throw "CSV has no header row: $Path"
    }

    $headers[0] = $headers[0] -replace "^\uFEFF",""
    $out = @()

    while (-not $parser.EndOfData) {
        $fields = $parser.ReadFields()
        if ($null -eq $fields) { continue }

        if ($fields.Count -lt $headers.Count) {
            $fields = $fields + (@('') * ($headers.Count - $fields.Count))
        } elseif ($fields.Count -gt $headers.Count) {
            $fields = $fields[0..($headers.Count - 1)]
        }

        $obj = [ordered]@{}
        for ($i = 0; $i -lt $headers.Count; $i++) {
            $obj[$headers[$i]] = Normalize-CsvValue -Value $fields[$i]
        }
        $out += [pscustomobject]$obj
    }

    $parser.Close()
    return $out
}

# -----------------------------
# Import Known Issues from CSV (patterns)
# -----------------------------
function Import-KnownIssuePatterns {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Index CSV not found at: $Path" }

    Write-LogInfo "Importing Known Issues from CSV: $Path"

    try { $rows = Read-CsvMultilineSafe -Path $Path -Delimiter ',' }
    catch { throw "Failed to read index CSV: $($_.Exception.Message)" }

    if (-not $rows -or @($rows).Count -eq 0) { throw "Index CSV is empty: $Path" }

    $first     = $rows[0]
    $propNames = @($first.PSObject.Properties.Name)
    $script:MsgIndexColumns = $propNames
    Write-LogInfo ("Index CSV columns: " + ($propNames -join ', '))

    $colError = Find-CsvColName -Props $propNames -Candidates @('ERROR','Error','MESSAGE','Message','Log Message','LogMessage')
    if (-not $colError) {
        Write-LogWarn "Index CSV does not have a recognizable ERROR/Message column; falling back to first non-empty property per row."
    } else {
        Write-LogInfo "Using column '$colError' as Error/Message source."
    }

    $patterns = @()
    foreach ($row in $rows) {
        $errorText = $null
        if ($colError) { $errorText = [string]$row.$colError }

        if ([string]::IsNullOrWhiteSpace($errorText)) {
            foreach ($p in $row.PSObject.Properties) {
                $s = [string]$p.Value
                if (-not [string]::IsNullOrWhiteSpace($s)) { $errorText = $s; break }
            }
        }

        if ([string]::IsNullOrWhiteSpace($errorText)) { continue }
        $errorText = $errorText.Trim()
        if ($errorText.Length -lt 5) { continue }

        $patterns += [pscustomobject]@{ CsvRow=$row; ErrorText=$errorText }
    }

    if (@($patterns).Count -eq 0) { throw "No usable error patterns could be derived from the index CSV." }

    Write-LogInfo "Prepared $(@($patterns).Count) error pattern(s) from index."
    return $patterns
}

# -----------------------------
# Parse timestamp from a log line
# -----------------------------
function Get-LogLineTimestamp {
    param([Parameter(Mandatory = $true)][string]$Line)

    $regex1 = '(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2})'
    $m1 = [regex]::Match($Line, $regex1)
    if ($m1.Success) {
        try { return [datetime]$m1.Groups[1].Value } catch { }
    }

    $regex2 = '(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*(AM|PM)?)'
    $m2 = [regex]::Match($Line, $regex2)
    if ($m2.Success) {
        try { return [datetime]$m2.Groups[1].Value } catch { }
    }

    if ($Line.Length -ge 19) {
        try { return [datetime]$Line.Substring(0, 19) } catch { }
    }

    return $null
}

# -----------------------------
# Format "X minutes/hours ago"
# -----------------------------
function Format-TimeAgo {
    param([Parameter(Mandatory = $true)][DateTime]$LastTime,[Parameter(Mandatory = $true)][DateTime]$Now)

    $span = $Now - $LastTime
    if ($span.TotalMinutes -lt 120) {
        $mins = [int][Math]::Round($span.TotalMinutes)
        if ($mins -le 1) { return "1 minute ago" }
        return "$mins minutes ago"
    }

    $hours = [int][Math]::Round($span.TotalHours)
    if ($hours -le 1) { return "1 hour ago" }
    return "$hours hours ago"
}

# -----------------------------
# Folder selection (menu option 2)
# -----------------------------
function Select-FolderPath {
    param([string]$InitialPath)
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select folder containing agent logs'
        if ($InitialPath -and (Test-Path -LiteralPath $InitialPath -PathType Container)) { $dialog.SelectedPath = $InitialPath }
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $dialog.SelectedPath) { return $dialog.SelectedPath }
    }
    catch {
        Write-LogWarn "Folder selection dialog unavailable; falling back to manual path entry. $($_.Exception.Message)"
    }
    return (Read-Host "Enter folder path to scan for agent logs")
}

# -----------------------------
# Show full CSV row (console)
# -----------------------------
function Show-CsvRowDetails {
    param([Parameter(Mandatory = $true)][psobject]$Row)
    foreach ($prop in $Row.PSObject.Properties) {
        $name  = $prop.Name
        $value = if ($null -eq $prop.Value) { '' } else { $prop.Value }
        Write-Host ("  {0}: {1}" -f $name, $value)
    }
}

# -----------------------------
# Startup Snapshot (colored)
# -----------------------------
function Show-StartupSnapshot {
    param(
        [string]$LogRoot,
        [int]$LogFileCount,
        [psobject]$IndexMeta,
        [string[]]$CsvColumns,
        [int]$PatternCount
    )

    if ($Global:MsgCorrelatorQuiet) { return }

    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host '  Agent Message Correlator - Startup Snapshot' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''

    Write-Host '[LOG SCAN]' -ForegroundColor Yellow
    Write-Host ("  Root       : {0}" -f $LogRoot) -ForegroundColor Gray
    Write-Host ("  Log Files  : {0}" -f $LogFileCount) -ForegroundColor Gray
    Write-Host ''

    Write-Host '[INDEX]' -ForegroundColor Yellow
    if ($IndexMeta -and $IndexMeta.Exists) {
        $ageTxt = if ($IndexMeta.AgeDays -ne $null) { ("{0:N2} day(s)" -f $IndexMeta.AgeDays) } else { 'n/a' }
        Write-Host ("  File       : {0}" -f $IndexMeta.Path) -ForegroundColor Gray
        Write-Host ("  Status     : Present") -ForegroundColor Green
        Write-Host ("  Last Write : {0}" -f $IndexMeta.LastWriteTime) -ForegroundColor Gray
        Write-Host ("  Age        : {0}" -f $ageTxt) -ForegroundColor Gray
    } else {
        $pathTxt = if ($IndexMeta) { $IndexMeta.Path } else { '(not set)' }
        Write-Host ("  File       : {0}" -f $pathTxt) -ForegroundColor Gray
        Write-Host ("  Status     : MISSING") -ForegroundColor Red
    }
    Write-Host ''

    Write-Host '[INDEX CONTENT]' -ForegroundColor Yellow
    $colsDisp = if ($CsvColumns -and $CsvColumns.Count -gt 0) { ($CsvColumns -join ', ') } else { '(unknown)' }
    Write-Host ("  Columns    : {0}" -f $colsDisp) -ForegroundColor Gray
    Write-Host ("  Patterns   : {0} error pattern(s) prepared" -f $PatternCount) -ForegroundColor Gray
    Write-Host ''
}

# -----------------------------
# HTML report generation
# -----------------------------
function New-AgentMsgHtmlReport {
    param(
        [Parameter(Mandatory = $true)][object[]]$Matches,
        [Parameter(Mandatory = $true)][string]$IndexPath,
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [Parameter(Mandatory = $true)][datetime]$GeneratedAt
    )

    $outRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentMsgCorrelator'
    Ensure-Directory -Path $outRoot

    $ts       = $GeneratedAt.ToString('yyyyMMdd_HHmmss')
    $fileName = "CS-AgentMsgCorrelator-$ts.html"
    $htmlPath = Join-Path $outRoot $fileName

    $logoUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
    $sb = New-Object System.Text.StringBuilder

    [void]$sb.AppendLine('<!doctype html>')
    [void]$sb.AppendLine('<html><head><meta charset="utf-8">')
    [void]$sb.AppendLine('<title>Agent Message Correlator</title>')
    [void]$sb.AppendLine('<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:20px;}
h1{text-align:center;margin:4px 0 6px;}
.logo-wrap{text-align:center;margin-bottom:6px;}
.logo{max-height:60px;display:inline-block;}
.small{color:#777;font-size:12px;}
table{border-collapse:collapse;width:100%;margin:8px 0 16px;}
th,td{border:1px solid #e0e0e0;padding:6px 8px;text-align:left;vertical-align:top;font-size:13px;}
th{background:#f5f5f5;}
.section{margin-top:18px;padding:10px 12px;border-radius:10px;border:1px solid #e0e0e0;background:#fafafa;}
.section h2{margin:0 0 8px;}
.match-block{border:1px solid #d0d0d0;border-radius:10px;padding:8px 10px;margin:10px 0;background:#ffffff;}
.match-header{font-weight:600;margin-bottom:4px;}
.badge{display:inline-block;padding:2px 6px;border-radius:10px;font-size:11px;border:1px solid #ccc;background:#f5f5f5;margin-left:6px;}
.key{font-weight:600;white-space:nowrap;}
td.keycell{width:150px;background:#fafafa;}
.sev-ERROR,.sev-FATAL,.sev-EXCEPTION{color:#b00020;}
.sev-FAIL,.sev-TIMEOUT{color:#8e24aa;}
.sev-WARN,.sev-WARNING{color:#f57c00;}
.sev-UNAUTHORIZED,.sev-ACCESSDENIED{color:#b8860b;}
</style></head><body>')

    [void]$sb.AppendLine('<div class="logo-wrap"><img src="' + $logoUrl + '" alt="ConnectSecure Logo" class="logo"></div>')
    [void]$sb.AppendLine('<h1>Agent Message Correlator</h1>')
    [void]$sb.AppendLine('<div class="small">Generated at ' + (HtmlEscape ($GeneratedAt.ToString('yyyy-MM-dd HH:mm:ss'))) +
                         ' &mdash; Log root: ' + (HtmlEscape $LogRoot) + '</div>')
    [void]$sb.AppendLine('<div class="small">Message index: ' + (HtmlEscape $IndexPath) + '</div>')

    $matchesArray = @($Matches)
    if ($matchesArray.Count -eq 0) {
        [void]$sb.AppendLine('<div class="section"><h2>No Matches</h2><p>No messages from the index were found in the agent logs.</p></div>')
    } else {
        [void]$sb.AppendLine('<div class="section">')
        [void]$sb.AppendLine('<h2>Summary of Matched Messages</h2>')
        [void]$sb.AppendLine('<table><thead><tr>' +
                             '<th>Severity</th><th>Frequency</th>' +
                             '<th>Last Seen</th><th>Last Seen (ago)</th>' +
                             '<th>Predicted Next</th><th>Avg Minutes Between</th>' +
                             '<th>Message</th></tr></thead><tbody>')

        foreach ($m in $matchesArray) {
            $sev    = [string]$m.Severity
            $sevEsc = HtmlEscape $sev
            $sevClass = 'sev-' + ($sev -replace '\s','')
            $freq  = [string]$m.Frequency

            $last  = if ($m.LastSeen)       { HtmlEscape ($m.LastSeen.ToString('yyyy-MM-dd HH:mm:ss')) } else { '' }
            $ago   = if ($m.LastSeenAgo)    { HtmlEscape ([string]$m.LastSeenAgo) } else { '' }
            $pred  = if ($m.PredictedNext)  { HtmlEscape ($m.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss')) } else { '' }

            $avg   = ''
            if ($m.AverageMinutesBetween -ne $null -and $m.AverageMinutesBetween -gt 0) {
                $avg = [Math]::Round([double]$m.AverageMinutesBetween,2).ToString()
            }

            $msgEsc = HtmlEscape ([string]$m.Message)

            [void]$sb.AppendLine('<tr>' +
                '<td class="' + $sevClass + '">' + $sevEsc + '</td>' +
                '<td>' + $freq + '</td>' +
                '<td>' + $last + '</td>' +
                '<td>' + $ago + '</td>' +
                '<td>' + $pred + '</td>' +
                '<td>' + (HtmlEscape $avg) + '</td>' +
                '<td>' + $msgEsc + '</td>' +
                '</tr>')
        }

        [void]$sb.AppendLine('</tbody></table>')
        [void]$sb.AppendLine('</div>')

        [void]$sb.AppendLine('<div class="section">')
        [void]$sb.AppendLine('<h2>Detailed Matched Messages</h2>')

        $idx = 0
        foreach ($m in $matchesArray) {
            $idx++

            $sev    = [string]$m.Severity
            $sevEsc = HtmlEscape $sev
            $sevClass = 'sev-' + ($sev -replace '\s','')

            $freq   = [string]$m.Frequency
            $last   = if ($m.LastSeen)      { $m.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' }
            $ago    = [string]$m.LastSeenAgo
            $pred   = if ($m.PredictedNext) { $m.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' }

            $avg    = 'N/A'
            if ($m.AverageMinutesBetween -ne $null -and $m.AverageMinutesBetween -gt 0) {
                $avg = [Math]::Round([double]$m.AverageMinutesBetween,2).ToString()
            }

            $msgTxt = [string]$m.Message

            [void]$sb.AppendLine('<div class="match-block">')
            [void]$sb.AppendLine('<div class="match-header">Match #' + $idx +
                                 ' <span class="badge ' + $sevClass + '">' + $sevEsc + '</span></div>')

            [void]$sb.AppendLine('<table>')
            [void]$sb.AppendLine('<tr><td class="keycell key">Frequency</td><td>' + (HtmlEscape $freq) + '</td></tr>')
            [void]$sb.AppendLine('<tr><td class="keycell key">Last Seen</td><td>' + (HtmlEscape $last) + ' (' + (HtmlEscape $ago) + ')</td></tr>')
            [void]$sb.AppendLine('<tr><td class="keycell key">Average Gap</td><td>' + (HtmlEscape $avg) + ' minute(s)</td></tr>')
            [void]$sb.AppendLine('<tr><td class="keycell key">Predicted Reoccurrence</td><td>' + (HtmlEscape $pred) + '</td></tr>')
            [void]$sb.AppendLine('<tr><td class="keycell key">Match</td><td>' + (HtmlEscape $msgTxt) + '</td></tr>')
            [void]$sb.AppendLine('</table>')

            $row = $m.CsvRow
            if ($row) {
                [void]$sb.AppendLine('<div class="small" style="margin-top:4px;margin-bottom:2px;">Matching Details:</div>')
                [void]$sb.AppendLine('<table>')
                foreach ($prop in $row.PSObject.Properties) {
                    $name  = HtmlEscape $prop.Name
                    $val   = if ($null -ne $prop.Value) { [string]$prop.Value } else { '' }

                    $valHtml = HtmlEscape $val
                    if ($val -match '^https?://') {
                        $valHtml = '<a href="' + (HtmlEscape $val) + '" target="_blank">' + (HtmlEscape $val) + '</a>'
                    }
                    [void]$sb.AppendLine('<tr><td class="keycell key">' + $name + '</td><td>' + $valHtml + '</td></tr>')
                }
                [void]$sb.AppendLine('</table>')
            }

            # Most recent occurrence only (match line +/- 5)
            $c = $m.LatestContext
            if ($c) {
                [void]$sb.AppendLine('<div class="small" style="margin-top:8px;margin-bottom:2px;">Most Recent Occurrence (match line with 5 lines before/after):</div>')
                [void]$sb.AppendLine('<div style="margin:6px 0 10px;">')
                [void]$sb.AppendLine('<div class="small"><b>Occurrence</b> &mdash; ' + (HtmlEscape ([string]$c.Path)) + ' (Line ' + (HtmlEscape ([string]$c.MatchLine)) + ')</div>')
                [void]$sb.AppendLine('<pre style="background:#0b0b0b;color:#e6e6e6;padding:8px;border-radius:10px;overflow:auto;font-size:12px;line-height:1.35;">')
                foreach ($l in @($c.Lines)) {
                    $num = ('{0,6}' -f [int]$l.LineNumber)
                    $text = [string]$l.Text
                    if ($l.IsMatch) {
                        [void]$sb.AppendLine((HtmlEscape ($num + ': >> ' + $text)))
                    } else {
                        [void]$sb.AppendLine((HtmlEscape ($num + ':    ' + $text)))
                    }
                }
                [void]$sb.AppendLine('</pre>')
                [void]$sb.AppendLine('</div>')
            }

            [void]$sb.AppendLine('</div>')
        }

        [void]$sb.AppendLine('</div>')
    }

    [void]$sb.AppendLine('</body></html>')

    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($sb.ToString())
    [System.IO.File]::WriteAllBytes($htmlPath, $bytes)

    Write-LogInfo ("HTML report written to: {0}" -f $htmlPath)

    if ($Global:MsgCorrelatorOpenHtml) {
        try { Start-Process $htmlPath } catch { Write-LogWarn "Failed to open HTML report automatically: $($_.Exception.Message)" }
    } else {
        Write-LogInfo "HTML auto-generation requested; report was not opened automatically."
    }
}

# -----------------------------
# Correlation routine
# -----------------------------
function Invoke-AgentCorrelation {
    param(
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [switch]$SkipHtmlPrompt
    )

    $now = Get-Date

    if (-not $Global:MsgCorrelatorQuiet) {
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  Agent Message Correlator' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''
        Write-LogInfo ("Local machine time: {0:u}" -f $now.ToUniversalTime())
        Write-Host ''
    }

    try {
        if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) { throw "Log root path does not exist: $LogRoot" }

        Write-LogInfo ("Enumerating *.log files under: {0}" -f $LogRoot)
        $logFiles = @(Get-ChildItem -Path $LogRoot -Filter *.log -File -Recurse -ErrorAction SilentlyContinue)
        if (-not $logFiles -or @($logFiles).Count -eq 0) { throw "No *.log files found under: $LogRoot" }
        Write-LogInfo ("Found {0} log file(s)." -f (@($logFiles).Count))

        $idxResult = Ensure-IndexFreshForCorrelation `
            -PrimaryUrl       $Global:MsgIndexPrimaryUrl `
            -SecondaryUrl     $Global:MsgIndexSecondaryUrl `
            -PrimaryHashUrl   $Global:MsgIndexPrimaryHashUrl `
            -SecondaryHashUrl $Global:MsgIndexSecondaryHashUrl `
            -LocalRoot        $Global:MsgIndexLocalRoot `
            -LocalFileName    $Global:MsgIndexLocalFileName

        $indexFile = $idxResult.Path
        $indexMeta = $idxResult.Metadata

        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host "------------------------------------------------------------"
            Write-Host "  Index Ready"
            Write-Host "------------------------------------------------------------"
        }
        Write-LogInfo ("Using index file: {0}" -f $indexFile)

        $csvPath = Get-IndexCsvPath -IndexFilePath $indexFile
        Write-LogInfo ("Importing CSV from: {0}" -f $csvPath)

        $patternEntries = @(Import-KnownIssuePatterns -Path $csvPath)

        Show-StartupSnapshot -LogRoot $LogRoot `
            -LogFileCount (@($logFiles).Count) `
            -IndexMeta $indexMeta `
            -CsvColumns $script:MsgIndexColumns `
            -PatternCount (@($patternEntries).Count)

        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host "------------------------------------------------------------"
            Write-Host "  Correlating Known Messages Against Agent Logs"
            Write-Host "------------------------------------------------------------"
        }

        $matchesSummary = @()
        $fileLineCache = @{}

        foreach ($entry in $patternEntries) {
            try {
                $pattern = $entry.ErrorText
                if ([string]::IsNullOrWhiteSpace($pattern)) { continue }

                $matches = Select-String -Path ($logFiles.FullName) -SimpleMatch -Pattern $pattern -ErrorAction SilentlyContinue
                if (-not $matches) { continue }

                $count          = @($matches).Count
                $lastSeen       = $null
                $severityCounts = @{}
                $timestamps     = New-Object 'System.Collections.Generic.List[datetime]'

                # Keep ONLY the most recent occurrence snapshot
                $latestCtx     = $null
                $latestKey     = $null

                foreach ($m in $matches) {
                    $line = $m.Line

                    $sev = Get-SeverityFromLine -Line $line
                    if (-not $severityCounts.ContainsKey($sev)) { $severityCounts[$sev] = 0 }
                    $severityCounts[$sev]++

                    $ts = Get-LogLineTimestamp -Line $line
                    if ($ts) {
                        if (-not $lastSeen -or $ts -gt $lastSeen) { $lastSeen = $ts }
                        [void]$timestamps.Add($ts)
                    }

                    # Most-recent key: timestamp if available; else file write time + line offset
                    $fileTime = $null
                    try { $fileTime = (Get-Item -LiteralPath $m.Path -ErrorAction Stop).LastWriteTime } catch { $fileTime = $null }

                    if ($ts) {
                        $key = $ts
                    } elseif ($fileTime) {
                        $key = $fileTime.AddMilliseconds([Math]::Min(999, [int]($m.LineNumber % 1000)))
                    } else {
                        $key = [datetime]::MinValue
                    }

                    if (-not $latestKey -or $key -gt $latestKey) {
                        $latestKey = $key
                        try { $latestCtx = Get-LogContextSnippet -Cache $fileLineCache -Path $m.Path -LineNumber $m.LineNumber -Before 5 -After 5 }
                        catch { $latestCtx = $null }
                    }
                }

                $avgMinutes = $null
                $predicted  = $null

                if ($timestamps.Count -ge 2) {
                    $orderedTimes = $timestamps.ToArray() | Sort-Object
                    $totalDelta   = 0.0
                    for ($i = 1; $i -lt $orderedTimes.Length; $i++) {
                        $totalDelta += ($orderedTimes[$i] - $orderedTimes[$i-1]).TotalMinutes
                    }
                    $avgMinutes = $totalDelta / [double]($orderedTimes.Length - 1)
                    if ($lastSeen -and $avgMinutes -gt 0) { $predicted = $lastSeen.AddMinutes($avgMinutes) }
                }

                $timeAgo = if ($lastSeen) { Format-TimeAgo -LastTime $lastSeen -Now $now } else { 'N/A' }

                $sevOrder = @('FATAL','ERROR','EXCEPTION','FAIL','TIMEOUT','UNAUTHORIZED','ACCESS DENIED','WARN','WARNING','Unknown')
                $primarySeverity = 'Unknown'
                foreach ($s in $sevOrder) {
                    if ($severityCounts.ContainsKey($s) -and $severityCounts[$s] -gt 0) { $primarySeverity = $s; break }
                }

                $matchesSummary += [pscustomobject]@{
                    Severity              = $primarySeverity
                    SeverityBreakdown     = $severityCounts
                    Message               = $pattern
                    CsvRow                = $entry.CsvRow
                    Frequency             = $count
                    LastSeen              = $lastSeen
                    LastSeenAgo           = $timeAgo
                    AverageMinutesBetween = $avgMinutes
                    PredictedNext         = $predicted
                    LatestContext         = $latestCtx
                }
            }
            catch {
                $patText = '<unknown>'
                try { $patText = [string]$entry.ErrorText } catch { }
                $lineNo = $null
                try { $lineNo = $_.InvocationInfo.ScriptLineNumber } catch { }
                Write-LogWarn ("Pattern processing failed" + (if($lineNo){" at line $lineNo"}else{""}) + ": " + $_.Exception.Message + " | Pattern: " + $patText)
                continue
            }
        }

        $matchesSummary = @($matchesSummary)

        if (-not $matchesSummary -or @($matchesSummary).Count -eq 0) {
            if (-not $Global:MsgCorrelatorQuiet) {
                Write-Host ''
                Write-Host "------------------------------------------------------------"
                Write-Host "  No matches from the index were found in the agent logs."
                Write-Host "------------------------------------------------------------"
            }
            return
        }

        Write-Host ''
        Write-Host '============================================================'
        Write-Host '  All Matched Messages (Any Age) with Frequency'
        Write-Host '============================================================'
        Write-Host ''

        $allSorted = $matchesSummary | Sort-Object -Property @{Expression='Frequency';Descending=$true}, @{Expression='LastSeen';Descending=$true}

        $allSorted |
            Select-Object Severity,
                Frequency,
                @{Name='LastSeen';Expression={ if ($_.LastSeen) { $_.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                @{Name='LastSeenAgo';Expression={ $_.LastSeenAgo }},
                @{Name='PredictedNext';Expression={ if ($_.PredictedNext) { $_.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                @{Name='AvgMinutesBetween';Expression={
                    if ($_.AverageMinutesBetween -ne $null -and $_.AverageMinutesBetween -gt 0) { [Math]::Round([double]$_.AverageMinutesBetween,2) } else { $null }
                }},
                @{Name='Message';Expression={ $_.Message }} |
            Format-Table -AutoSize

        Write-Host ''
        Write-Host '============================================================'
        Write-Host '  Detailed Matched Messages'
        Write-Host '============================================================'
        Write-Host ''

        $indexCounter = 0
        foreach ($item in $allSorted) {
            $indexCounter++

            $lastSeenText = if ($item.LastSeen) { $item.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' }
            $predText = if ($item.PredictedNext) { $item.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' }
            $avgText = if ($item.AverageMinutesBetween -ne $null -and $item.AverageMinutesBetween -gt 0) {
                [Math]::Round([double]$item.AverageMinutesBetween,2).ToString()
            } else { 'N/A' }

            $sevColor = Get-SeverityColor -Severity $item.Severity

            Write-Host '============================================================' -ForegroundColor DarkGray
            Write-Host ("Match #{0}" -f $indexCounter) -ForegroundColor Gray
            Write-Host ("[{0}]  Count: {1}" -f $item.Severity, $item.Frequency) -ForegroundColor $sevColor
            Write-Host ("    Last: {0} ({1})" -f $lastSeenText, $item.LastSeenAgo) -ForegroundColor $sevColor
            Write-Host ("    Average gap between events: {0} minute(s)" -f $avgText) -ForegroundColor Cyan
            Write-Host ("    Predicted Reoccurrence: {0}" -f $predText) -ForegroundColor Green
            Write-Host '============================================================' -ForegroundColor DarkGray
            Write-Host ("MATCH: {0}" -f $item.Message) -ForegroundColor Cyan
            Write-Host ''
            Write-Host 'Matching Details:' -ForegroundColor Green
            Show-CsvRowDetails -Row $item.CsvRow
            Write-Host ''

            if ($item.LatestContext) {
                Write-Host 'Most Recent Occurrence (match line with 5 lines before/after):' -ForegroundColor Yellow
                $ctx = $item.LatestContext
                Write-Host ("  File: {0}" -f $ctx.Path) -ForegroundColor Gray
                Write-Host ("  Line: {0}" -f $ctx.MatchLine) -ForegroundColor Gray
                foreach ($ln in @($ctx.Lines)) {
                    $prefix = "{0,6}: " -f $ln.LineNumber
                    if ($ln.IsMatch) {
                        Write-Host ($prefix + $ln.Text) -ForegroundColor Red
                    } else {
                        Write-Host ($prefix + $ln.Text) -ForegroundColor DarkGray
                    }
                }
                Write-Host ''
            }
        }

        Write-Host ''
        Write-Host '============================================================'
        Write-Host '  Correlation Complete'
        Write-Host '============================================================'

        if ($Global:MsgCorrelatorAutoHtml) {
            New-AgentMsgHtmlReport -Matches $allSorted -IndexPath $csvPath -LogRoot $LogRoot -GeneratedAt $now
        }
        elseif (-not $SkipHtmlPrompt.IsPresent) {
            Write-Host ''
            $ans = Read-Host "Create HTML output report? (Y/N)"
            if ($ans -and $ans.Trim().ToUpper() -eq 'Y') {
                New-AgentMsgHtmlReport -Matches $allSorted -IndexPath $csvPath -LogRoot $LogRoot -GeneratedAt $now
            }
        }
    }
    catch {
        Write-LogErrorLine "Agent Message Correlator encountered an error: $($_.Exception.Message)"
        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host 'Press Enter to return to the main menu...'
            [void][System.Console]::ReadLine()
        }
    }
}

# -----------------------------
# MAIN MENU (interactive)
# -----------------------------
function Show-MainMenu {
    while ($true) {
        Clear-Host
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  Agent Message Correlator' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''

        $meta = Get-IndexMetadata -LocalRoot $Global:MsgIndexLocalRoot -LocalFileName $Global:MsgIndexLocalFileName
        if ($meta.Exists) {
            $ageTxt = if ($meta.AgeDays -ne $null) { ("{0:N2} day(s)" -f $meta.AgeDays) } else { 'n/a' }
            Write-Host "ConnectSecure Message Index: PRESENT" -ForegroundColor Green
            Write-Host ("  Path       : {0}" -f $meta.Path) -ForegroundColor Gray
            Write-Host ("  Last Update: {0}" -f $meta.LastWriteTime) -ForegroundColor Gray
            Write-Host ("  Age        : {0}" -f $ageTxt) -ForegroundColor Gray
        } else {
            Write-Host "ConnectSecure Message Index: MISSING" -ForegroundColor Red
            Write-Host ("  Expected at: {0}" -f $meta.Path) -ForegroundColor Gray
        }

        Write-Host ''
        Write-Host ' [1] Scan Default Agent Folder' -ForegroundColor White
        Write-Host ("     - {0}" -f $Global:DefaultAgentLogRoot) -ForegroundColor DarkGray
        Write-Host ' [2] Specify Alternate Log Location' -ForegroundColor White
        Write-Host ' [3] Force update ConnectSecure Message Index' -ForegroundColor White
        Write-Host ' [Q] Quit' -ForegroundColor White
        Write-Host ''
        $choice = Read-Host 'Select an option (1/2/3/Q)'

        switch ($choice.ToUpper()) {
            '1' {
                Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$false
                Write-Host ''
                Read-Host 'Done. Press Enter to return to the main menu...'
            }
            '2' {
                $folder = Select-FolderPath -InitialPath $Global:DefaultAgentLogRoot
                if (-not $folder -or -not (Test-Path -LiteralPath $folder -PathType Container)) {
                    Write-LogWarn ("Folder not found or invalid: {0}" -f $folder)
                    Write-Host ''
                    Read-Host 'Press Enter to return to the main menu...'
                    continue
                }
                Invoke-AgentCorrelation -LogRoot $folder -SkipHtmlPrompt:$false
                Write-Host ''
                Read-Host 'Done. Press Enter to return to the main menu...'
            }
            '3' {
                Write-Host ''
                Write-Host "------------------------------------------------------------"
                Write-Host "  Force update ConnectSecure Message Index"
                Write-Host "------------------------------------------------------------"
                try {
                    $null = Ensure-IndexFreshForCorrelation `
                        -PrimaryUrl       $Global:MsgIndexPrimaryUrl `
                        -SecondaryUrl     $Global:MsgIndexSecondaryUrl `
                        -PrimaryHashUrl   $Global:MsgIndexPrimaryHashUrl `
                        -SecondaryHashUrl $Global:MsgIndexSecondaryHashUrl `
                        -LocalRoot        $Global:MsgIndexLocalRoot `
                        -LocalFileName    $Global:MsgIndexLocalFileName `
                        -ForceRefresh
                    Write-Host ''
                    Write-Host 'Index update complete.'
                }
                catch {
                    Write-LogErrorLine "Force-update failed: $($_.Exception.Message)"
                }
                Write-Host ''
                Read-Host 'Press Enter to return to the main menu...'
            }
            'Q' {
                $launcher = $Global:LauncherPath
                if ($launcher -and (Test-Path -LiteralPath $launcher -PathType Leaf)) {
                    Write-LogInfo ("Returning to CS-Toolbox-Launcher: {0}" -f $launcher)
                    try { & $launcher } catch { Write-LogErrorLine ("Failed to launch CS-Toolbox-Launcher.ps1: {0}" -f $_.Exception.Message) }
                }
                return
            }
            Default {
                Write-LogWarn 'Invalid choice.'
                Start-Sleep -Seconds 1
            }
        }
    }
}

# -----------------------------
# ENTRYPOINT
# -----------------------------
if ($ExportOnly) {
    Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$true
    exit 0
}
elseif ($DefaultLog) {
    Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$true
}
else {
    Show-MainMenu
}
