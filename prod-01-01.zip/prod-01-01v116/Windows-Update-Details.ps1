<# ==================================================================================================
  Windows-Update-Details.ps1
  ConnectSecure Technicians Toolbox

  VERSION: v3.1 – TableView + KB Column + ExportOnly Mode

  DESCRIPTION:
     Collects Windows Update history via osquery and:

       • Default: Block view (per-update blocks with details)
       • -TableView  : Compact table with KB, InstallDate, Name, ResultCode, ErrorCode, Operation, UpdateID
       • -ExportOnly : Run osquery, save JSON/CSV only, no screen output, no pause

  SWITCHES:
     -TableView     Show a compact table (KB + metadata), most recent first
     -ExportOnly    Export JSON/CSV only, no formatted display, no pause

==================================================================================================#>

param(
    [switch]$TableView,
    [switch]$ExportOnly
)

# -------------------------------------------------------------------------------------------------
# Core Settings
# -------------------------------------------------------------------------------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot    = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot    = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch   = Join-Path $ExportRoot 'OSQuery-WindowsUpdates'
$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = $ExportPatch

# -------------------------------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolders {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
}

function Get-IsAdmin {
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

function Pause-Script {
    param([string]$Message="Press any key to continue...")
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title="OSQuery - Windows Update Details")

    Clear-Host
    $isAdmin  = Get-IsAdmin
    $HostName = $env:COMPUTERNAME
    $UserName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $HostName,$UserName,($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

function Get-WindowWidth {
    try {
        $raw = $Host.UI.RawUI
        if ($raw -and $raw.BufferSize.Width -gt 0) { return $raw.BufferSize.Width }
        if ($raw -and $raw.WindowSize.Width -gt 0) { return $raw.WindowSize.Width }
        return 120
    } catch {
        return 120
    }
}

function Write-LabelLine {
    param(
        [string]$Label,
        [string]$Value,
        [int]$LabelWidth=14
    )
    $lbl = ($Label + ":").PadRight($LabelWidth)
    Write-Host ("{0} {1}" -f $lbl,$Value) -ForegroundColor Gray
}

# Convert osquery epoch seconds -> DateTime
function Convert-OsqEpochToDateTime {
    param($Value)

    if (-not $Value) { return $null }
    try {
        $epoch = [int64]$Value
        # Convert from Unix epoch seconds to local time
        return [DateTimeOffset]::FromUnixTimeSeconds($epoch).LocalDateTime
    } catch {
        return $null
    }
}

# -------------------------------------------------------------------------------------------------
# OSQuery
# -------------------------------------------------------------------------------------------------
function Initialize-OsqOutput {
    Ensure-ExportFolders
    Ensure-Directory -Path $Global:OsqOutRoot
}

function Test-OsqueryPresent {
    if (-not (Test-Path $Global:OsqBinPath)) {
        Write-Host "`nosqueryi.exe not found at $Global:OsqBinPath" -ForegroundColor Red
        Pause-Script
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [string]$Sql,
        [string]$BaseName
    )

    Initialize-OsqOutput

    $ts       = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName+"_"+$ts+".json")
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName+"_"+$ts+".csv")

    Write-Host ""
    Write-Host "Running osquery query:" -ForegroundColor Cyan
    Write-Host "  $Sql" -ForegroundColor DarkGray

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $Global:OsqBinPath
    $psi.Arguments              = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stderr -and $stderr.Trim().Length -gt 0) {
        Write-Host "osquery stderr:" -ForegroundColor Yellow
        Write-Host "  $stderr" -ForegroundColor DarkYellow
    }
    if (-not $stdout) {
        Write-Host "No output received from osquery." -ForegroundColor Red
        return @()
    }

    try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    try {
        if (@($objs).Count -gt 0) {
            $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
            Write-Host "`nSaved:" -ForegroundColor Green
            Write-Host "  JSON: $jsonPath" -ForegroundColor Green
            Write-Host "  CSV : $csvPath" -ForegroundColor Green
        }
        else {
            Write-Host "No rows returned. JSON saved: $jsonPath" -ForegroundColor DarkCyan
        }
    } catch {}

    return $objs
}

# -------------------------------------------------------------------------------------------------
# Renderer (block view, tolerant schema)
# -------------------------------------------------------------------------------------------------
function Render-UpdateBlocks {
    param(
        [Parameter(Mandatory)][object[]]$Items,
        [int]$PageSize=10
    )

    if (-not $Items -or @($Items).Count -eq 0) {
        Write-Host "No update history to display." -ForegroundColor Yellow
        return
    }

    $i          = 0
    $total      = [int]@($Items).Count
    $labelWidth = 14

    while ($i -lt $total) {
        $batchEnd = [Math]::Min($i + $PageSize, $total)

        for ($j = $i; $j -lt $batchEnd; $j++) {
            $row   = $Items[$j]
            $date  = $row.PSObject.Properties['date'].Value
            $title = $row.PSObject.Properties['title'].Value

            $op     = $row.PSObject.Properties['operation'].Value
            $result = $row.PSObject.Properties['result_code'].Value
            $err    = if ($row.PSObject.Properties.Name -contains 'error_code') { $row.error_code } else { "" }
            $url    = $row.PSObject.Properties['support_url'].Value
            $srvsel = $row.PSObject.Properties['server_selection'].Value
            $updId  = $row.PSObject.Properties['update_id'].Value
            $hres   = $row.PSObject.Properties['hresult'].Value
            $svcId  = $row.PSObject.Properties['service_id'].Value
            $appId  = $row.PSObject.Properties['client_app_id'].Value
            $desc   = $row.PSObject.Properties['description'].Value

            $dateText  = if ($date)  { $date }  else { "(no date)" }
            $titleText = if ($title) { $title } else { "(no title)" }

            $win = Get-WindowWidth
            $h   = "-- $dateText | $titleText "
            if ($h.Length -gt $win) {
                $h = $h.Substring(0,[Math]::Max(0,$win-2))+" "
            }
            $divider = $h + ("-" * [Math]::Max(0,$win - $h.Length))
            Write-Host $divider -ForegroundColor Cyan

            if ($op)     { Write-LabelLine -Label "Operation"   -Value $op     -LabelWidth $labelWidth }
            if ($result) { Write-LabelLine -Label "ResultCode"  -Value $result -LabelWidth $labelWidth }
            if ($err)    { Write-LabelLine -Label "ErrorCode"   -Value $err    -LabelWidth $labelWidth }
            if ($url)    { Write-LabelLine -Label "SupportURL"  -Value $url    -LabelWidth $labelWidth }
            if ($srvsel) { Write-LabelLine -Label "ServerSel"   -Value $srvsel -LabelWidth $labelWidth }
            if ($updId)  { Write-LabelLine -Label "UpdateID"    -Value $updId  -LabelWidth $labelWidth }
            if ($hres)   { Write-LabelLine -Label "HResult"     -Value $hres   -LabelWidth $labelWidth }
            if ($svcId)  { Write-LabelLine -Label "ServiceID"   -Value $svcId  -LabelWidth $labelWidth }
            if ($appId)  { Write-LabelLine -Label "ClientApp"   -Value $appId  -LabelWidth $labelWidth }
            if ($desc)   { Write-LabelLine -Label "Description" -Value $desc   -LabelWidth $labelWidth }
            Write-Host ""
        }

        $i = $batchEnd
        if ($i -lt $total) {
            $ans = (Read-Host "[ENTER] next 10  |   [A] show ALL   |   [Q] back").Trim()
            switch -regex ($ans) {
                '^(?i)q$' { break }
                '^(?i)a$' { $PageSize = [int]($total - $i) }
                default   { }
            }
        }
    }
}

# -------------------------------------------------------------------------------------------------
# Table view renderer (with real DateTime + KB column)
# -------------------------------------------------------------------------------------------------
function Show-TableView {
    param(
        [Parameter(Mandatory)][object[]]$Items
    )

    if (-not $Items -or @($Items).Count -eq 0) {
        Write-Host "No update history to display." -ForegroundColor Yellow
        return
    }

    $width = Get-WindowWidth
    Write-Host ""
    Write-Host "Windows Update History (Most Recent First) - Table View" -ForegroundColor Cyan
    Write-Host ("-" * [Math]::Min($width,120)) -ForegroundColor Cyan

    # Sort by converted datetime (desc) so most recent installs at the top
    $sorted = $Items | Sort-Object -Property @{
        Expression = {
            if ($_.PSObject.Properties.Name -contains 'date') {
                Convert-OsqEpochToDateTime $_.date
            } else {
                Get-Date 0
            }
        }
        Descending = $true
    }

    $sorted |
        Select-Object `
            @{Name='KB';Expression={
                $title = if ($_.PSObject.Properties.Name -contains 'title') { [string]$_.title } else { '' }
                if (-not $title) { return '' }
                $m = [regex]::Match($title,'KB\d+')
                if ($m.Success) { $m.Value } else { '' }
            }},
            @{Name='InstallDate';Expression={
                if ($_.PSObject.Properties.Name -contains 'date') {
                    $dt = Convert-OsqEpochToDateTime $_.date
                    if ($dt) { $dt.ToString('yyyy-MM-dd HH:mm') } else { '' }
                } else { '' }
            }},
            @{Name='Name';Expression={
                if ($_.PSObject.Properties.Name -contains 'title') { $_.title } else { '' }
            }},
            result_code,
            error_code,
            operation,
            update_id |
        Format-Table -AutoSize
}

# -------------------------------------------------------------------------------------------------
# Main
# -------------------------------------------------------------------------------------------------
Show-Header "OSQuery - Windows Update Details"

if (-not (Test-OsqueryPresent)) {
    return
}

$sql = @'
SELECT * FROM windows_update_history
ORDER BY date DESC;
'@

# Always run osquery / export
$objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Windows_Update_History'

# EXPORT ONLY: no display, no pause
if ($ExportOnly) {
    return
}

# Nothing to show
if (@($objs).Count -eq 0) {
    Write-Host "No update history returned by osquery." -ForegroundColor Yellow
    Pause-Script
    return
}

# Normalize schema
$preferredOrder = @(
    'date','title','operation','result_code','error_code',
    'support_url','server_selection','update_id',
    'hresult','service_id','client_app_id','description'
)

$norm = foreach ($o in $objs) {
    $props = @{}
    foreach ($k in $preferredOrder) {
        if ($o.PSObject.Properties.Name -contains $k) { $props[$k] = $o.$k }
    }
    foreach ($k in $o.PSObject.Properties.Name) {
        if (-not $props.ContainsKey($k)) { $props[$k] = $o.$k }
    }
    [PSCustomObject]$props
}

if ($TableView) {
    Show-TableView -Items $norm
    Pause-Script
}
else {
    Render-UpdateBlocks -Items $norm -PageSize 10
    Pause-Script
}
