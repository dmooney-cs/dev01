#Requires -Version 5.1
<#
  SystemInfo-A.ps1
  Menu:
    [1] Firewall Status
    [2] Microsoft Defender
    [3] Disk / SMART (best-effort)
    [Q] Quit (return to Launcher)

  Exports to:
    <ExportRoot>\SystemInfoA\<YYYYMMDD_HHMMSS>\*.csv
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region ---------- Helpers ----------
function Get-ExportRoot {
    param([string]$Tool = "SystemInfoA")

    $cstemp = "C:\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $cstemp)) {
        try { New-Item -ItemType Directory -Path $cstemp -Force | Out-Null } catch {}
    }

    $roots = @($cstemp, "C:\Temp", $env:TEMP) | Where-Object { $_ } | Select-Object -Unique
    foreach ($r in $roots) {
        try {
            if (-not (Test-Path $r)) { New-Item -ItemType Directory -Path $r -Force | Out-Null }
            $toolRoot = Join-Path $r $Tool
            if (-not (Test-Path $toolRoot)) { New-Item -ItemType Directory -Path $toolRoot -Force | Out-Null }
            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $final = Join-Path $toolRoot $stamp
            New-Item -ItemType Directory -Path $final -Force | Out-Null
            return $final
        } catch {}
    }
    throw "Unable to create an export folder in any common temp location."
}

function Show-Header {
    param([Parameter(Mandatory)] [string]$Title)
    $hostName = $env:COMPUTERNAME
    $userName = "$($env:COMPUTERNAME)\$($env:USERNAME)"
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
               ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host ""
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host ("=" * 58)
    Write-Host " Host: $hostName   User: $userName   Admin: $isAdmin"
    Write-Host ("=" * 58)
    Write-Host ""
}

function Press-AnyKey {
    param([string]$Message="Press any key to continue...")
    Write-Host ""
    Write-Host $Message -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Export-Table {
    param(
        [Object[]]$InputObject,
        [string]$Path
    )
    try {
        if ($null -eq $InputObject) {
            "No data" | Out-File -FilePath $Path -Encoding UTF8
        }
        else {
            $arr = @($InputObject)
            if ($arr.Count -eq 0) {
                "No rows returned" | Out-File -FilePath $Path -Encoding UTF8
            }
            else {
                $arr | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
            }
        }
        Write-Host "[OK]  Exported: $Path" -ForegroundColor Green
    } catch {
        Write-Host "[WARN] Failed to export $Path : $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Return-ToLauncherOrExit {
    $launcher = $env:CS_LAUNCHER_PATH
    if ($launcher -and (Test-Path $launcher)) {
        try {
            & $launcher
            return
        } catch {
            Write-Host "[WARN] Could not return to launcher ($launcher): $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    exit
}
#endregion

#region ---------- Collectors ----------
function Get-FirewallStatus {
    $rows = @()
    try {
        if (Get-Command -Name Get-NetFirewallProfile -ErrorAction SilentlyContinue) {
            $profiles = @(Get-NetFirewallProfile -All)
            foreach ($p in $profiles) {
                # safely read optional props (not all builds expose them)
                $LogAllowed   = $null; if ($p | Get-Member -Name LogAllowed   -ErrorAction SilentlyContinue) { $LogAllowed   = $p.LogAllowed }
                $LogBlocked   = $null; if ($p | Get-Member -Name LogBlocked   -ErrorAction SilentlyContinue) { $LogBlocked   = $p.LogBlocked }
                $LogFileName  = $null; if ($p | Get-Member -Name LogFileName  -ErrorAction SilentlyContinue) { $LogFileName  = $p.LogFileName }
                $NotifyOnListen = $null; if ($p | Get-Member -Name NotifyOnListen -ErrorAction SilentlyContinue) { $NotifyOnListen = $p.NotifyOnListen }
                $AllowUnicastResponse = $null; if ($p | Get-Member -Name AllowUnicastResponseToMulticast -ErrorAction SilentlyContinue) { $AllowUnicastResponse = $p.AllowUnicastResponseToMulticast }

                $rows += [pscustomobject]@{
                    Profile            = $p.Name
                    Enabled            = $p.Enabled
                    DefaultInbound     = $p.DefaultInboundAction
                    DefaultOutbound    = $p.DefaultOutboundAction
                    LogAllowed         = $LogAllowed
                    LogBlocked         = $LogBlocked
                    LogFileName        = $LogFileName
                    NotifyOnListen     = $NotifyOnListen
                    UnicastRespToMulti = $AllowUnicastResponse
                }
            }
        }
        else {
            # Fallback: parse netsh output
            $out = netsh advfirewall show allprofiles
            $cur = @{}
            foreach ($line in $out) {
                if ($line -match 'Profile Settings:\s*(.+)\s*profile') {
                    if ($cur.Count -gt 0) { $rows += [pscustomobject]$cur; $cur=@{} }
                    $cur.Profile = $Matches[1]
                } elseif ($line -match 'State\s*(\w+)') {
                    $cur.Enabled = $Matches[1]
                } elseif ($line -match 'DefaultInboundAction\s*(\w+)') {
                    $cur.DefaultInbound = $Matches[1]
                } elseif ($line -match 'DefaultOutboundAction\s*(\w+)') {
                    $cur.DefaultOutbound = $Matches[1]
                } elseif ($line -match 'Logging:\s*(.+)') {
                    $cur.Logging = $Matches[1]
                }
            }
            if ($cur.Count -gt 0) { $rows += [pscustomobject]$cur }
        }
    } catch {
        Write-Host "[ERROR] Firewall collection: $($_.Exception.Message)" -ForegroundColor Red
    }
    return $rows
}

function Get-DefenderStatus {
    $rows = @()
    try {
        $hasMp = Get-Command -Name Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($hasMp) {
            $s     = Get-MpComputerStatus
            $pref  = Get-MpPreference
            $h     = @{}
            $safeProps = @(
                'AMServiceEnabled','AntispywareEnabled','AntivirusEnabled',
                'RealTimeProtectionEnabled','NISEnabled','BehaviorMonitorEnabled',
                'OnAccessProtectionEnabled','IoavProtectionEnabled',
                'IsTamperProtected','QuickScanSignatureVersion','NISSignatureVersion',
                'AntivirusSignatureVersion','AntispywareSignatureVersion',
                'FullScanAge','QuickScanAge','SignatureUpdated','SignatureUpdatedTime'
            )

            # Only read properties that actually exist on this build
            $propNames = @()
            if ($s -and $s.PSObject -and $s.PSObject.Properties) {
                $propNames = $s.PSObject.Properties.Name
            }

            foreach ($name in $safeProps) {
                if ($propNames -contains $name) {
                    $h[$name] = $s.$name
                }
            }

            if ($propNames -contains 'AntivirusEngineVersion') {
                $h['AntivirusEngineVersion'] = $s.AntivirusEngineVersion
            }

            if ($pref) {
                $h['ExclusionPathCount']       = @($pref.ExclusionPath).Count
                $h['ExclusionProcessCount']    = @($pref.ExclusionProcess).Count
                $h['ExclusionExtensionCount']  = @($pref.ExclusionExtension).Count
            }

            $rows += [pscustomobject]$h
        }
        else {
            $rows += [pscustomobject]@{ Note = "Get-MpComputerStatus not available on this system." }
        }
    }
    catch {
        $rows += [pscustomobject]@{ Error = $_.Exception.Message }
    }
    return $rows
}

function Get-DiskSmartInfo {
    $result = [System.Collections.Generic.List[object]]::new()
    $add = {
        param($obj)
        if ($null -ne $obj) { [void]$result.Add($obj) }
    }

    # Modern storage info (if available)
    try {
        if (Get-Command -Name Get-PhysicalDisk -ErrorAction SilentlyContinue) {
            $pds = @(Get-PhysicalDisk)
            foreach ($pd in $pds) {
                & $add ([pscustomobject]@{
                    Source            = "Get-PhysicalDisk"
                    FriendlyName      = $pd.FriendlyName
                    SerialNumber      = $pd.SerialNumber
                    HealthStatus      = $pd.HealthStatus
                    OperationalStatus = ($pd.OperationalStatus -join ',')
                    MediaType         = $pd.MediaType
                    SizeGB            = if ($pd.Size) { [math]::Round($pd.Size/1GB,2) } else { $null }
                    FirmwareVersion   = $pd.FirmwareVersion
                    CanPool           = $pd.CanPool
                })
            }
        }
    } catch {
        Write-Host "[WARN] Get-PhysicalDisk failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }

    # Classic disk info
    $drives = @()
    try {
        $drives = @(Get-WmiObject -Class Win32_DiskDrive -ErrorAction Stop)
        foreach ($d in $drives) {
            # Serial via associated PhysicalMedia when possible
            $sn = $null
            try {
                $pm = Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($d.DeviceID)'} WHERE ResultClass=Win32_PhysicalMedia" -ErrorAction Stop
                $sn = $pm.SerialNumber
            } catch {}
            & $add ([pscustomobject]@{
                Source            = "Win32_DiskDrive"
                Index             = $d.Index
                Model             = $d.Model
                SerialNumber      = $sn
                SizeGB            = if ($d.Size) { [math]::Round($d.Size/1GB,2) } else { $null }
                InterfaceType     = $d.InterfaceType
                FirmwareRevision  = $d.FirmwareRevision
                MediaType         = $d.MediaType
            })
        }
    } catch {
        Write-Host "[WARN] Win32_DiskDrive failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }

    # SMART best-effort
    try {
        $ns = "root\wmi"
        $failStatus = @(Get-WmiObject -Namespace $ns -Class MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue)
        if ($failStatus.Count -gt 0) {
            foreach ($fs in $failStatus) {
                $model = $null
                if ($drives) {
                    foreach ($d in $drives) {
                        if ($fs.InstanceName -like "*$($d.Model.Replace(' ','_'))*") {
                            $model = $d.Model
                            break
                        }
                    }
                }
                & $add ([pscustomobject]@{
                    Source         = "SMART"
                    InstanceName   = $fs.InstanceName
                    PredictFailure = $fs.PredictFailure
                    Reason         = $fs.Reason
                    Model          = $model
                })
            }
        } else {
            & $add ([pscustomobject]@{
                Source = "SMART"
                Note   = "SMART WMI classes not available or driver does not expose data."
            })
        }
    } catch {
        & $add ([pscustomobject]@{
            Source = "SMART"
            Error  = "SMART query failed: $($_.Exception.Message)"
        })
    }

    return $result
}
#endregion

#region ---------- Menu Actions ----------
function Action-Firewall {
    try {
        $exportRoot = Get-ExportRoot -Tool "SystemInfoA"
        Show-Header -Title "System Info A - Firewall Status"
        $rows = Get-FirewallStatus
        if ($rows -and @($rows).Count -gt 0) {
            $rows | Format-Table -AutoSize
        } else {
            Write-Host "No data returned." -ForegroundColor Yellow
        }
        Export-Table -InputObject $rows -Path (Join-Path $exportRoot "FirewallStatus.csv")
    } catch {
        Write-Host "ERROR collecting firewall details: $($_.Exception.Message)" -ForegroundColor Red
    }
    Press-AnyKey
}

function Action-Defender {
    try {
        $exportRoot = Get-ExportRoot -Tool "SystemInfoA"
        Show-Header -Title "System Info A - Microsoft Defender"
        $rows = Get-DefenderStatus
        if ($rows -and @($rows).Count -gt 0) {
            $rows | Format-Table -AutoSize
        } else {
            Write-Host "No data returned." -ForegroundColor Yellow
        }
        Export-Table -InputObject $rows -Path (Join-Path $exportRoot "MicrosoftDefender.csv")
    } catch {
        Write-Host "ERROR collecting Defender details: $($_.Exception.Message)" -ForegroundColor Red
    }
    Press-AnyKey
}

function Action-DiskSmart {
    try {
        $exportRoot = Get-ExportRoot -Tool "SystemInfoA"
        Show-Header -Title "System Info A - Disk / SMART"
        $rows = Get-DiskSmartInfo
        if ($rows -and @($rows).Count -gt 0) {
            $rows | Format-Table -AutoSize
        } else {
            Write-Host "No disk/SMART data returned." -ForegroundColor Yellow
        }
        Export-Table -InputObject $rows -Path (Join-Path $exportRoot "Disk_SMART.csv")
    } catch {
        Write-Host "ERROR collecting disk/SMART details: $($_.Exception.Message)" -ForegroundColor Red
    }
    Press-AnyKey
}
#endregion

#region ---------- Menu Loop ----------
function Show-MainMenu {
    while ($true) {
        Show-Header -Title "System Info A"
        Write-Host " [1] Firewall Status            - Profiles, defaults, logging"
        Write-Host " [2] Microsoft Defender         - Protection state and signatures"
        Write-Host " [3] Disk / SMART               - Disks, volumes, health (best-effort)"
        Write-Host ""
        Write-Host " [Q] Quit (return to Launcher)"
        Write-Host ""
        $choice = Read-Host "Enter your choice"

        switch ($choice.ToUpperInvariant()) {
            '1' { Action-Firewall }
            '2' { Action-Defender }
            '3' { Action-DiskSmart }
            'Q' { Return-ToLauncherOrExit }
            default {
                Write-Host "Invalid selection. Please choose 1, 2, 3, or Q." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

try {
    Show-MainMenu
} catch {
    Write-Host "[FATAL] $($_.Exception.Message)" -ForegroundColor Red
    Press-AnyKey
    Return-ToLauncherOrExit
}
#endregion
