#requires -version 5.1

[CmdletBinding()]
param(
    # MODE SELECTION
    [Alias('s')]
    [switch]$Secure,

    [Alias('u')]
    [switch]$Unsecure,

    # OPTIONAL METADATA
    [Alias('c')]
    [string]$Company,

    [Alias('t')]
    [string]$Ticket,

    [string]$Cc,

    [string]$To,

    # OUTPUT CONTROLS
    [switch]$NoHtml,
    [switch]$SkipZip
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =================== Config ===================
$OutDir = 'C:\CS-Toolbox-TEMP\ZIP'
$DefaultSources = @(
  'C:\Program Files (x86)\CyberCNSAgent\logs',
  'C:\Program Files (x86)\CyberCNSAgent\results_data',
  'C:\CS-Toolbox-TEMP\Collected-Info'
)
$LogoUrl   = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$DefaultTo = 'support@connectsecure.com'

# ---- Embedded RSA Public Key (SubjectPublicKeyInfo PEM) ----
$RsaPublicPem = @'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxGmwf7MuyKnVeL3jT8K8
nwU9Tq3qfjum06H3Tt/vR2PEJLWBa0cqm2fxPIHccvWYRe++Ta3YyFtBwnPxq6qE
k+yR88eX8lxhD3Kbgxlw1ITuUuo1dH9fJ3Nu+Hp+Mr53Jj4UmsoEvSEK1/66cwNN
FeP8Ezwtcv4OpPp04ZmXFjCfYmvxP65NvmPmd9qNuwA6nJYo37TKjKk3tJ/OkJHE
6DdiD7Cmn68I0+EJUt/FqtGT427YAON6NCvT6UKjAgmYtlKOQsQBSm+mLoGbeQsn
OjowqAaf0+7/Xw5C45S4psq5UbcRmCd+HZ+N5cjfQFNQYh/57+RD9Jxhf6SW6Ytk
GQIDAQAB
-----END PUBLIC KEY-----
'@

# =================== Logging Helpers ===================
function Write-Info ($m){ Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Cyan }
function Write-Ok   ($m){ Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Green }
function Write-Warn ($m){ Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Yellow }
function Write-Err  ($m){ Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Red }

function Ensure-Folder {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function HtmlEncode {
  param([string]$s)
  if ($null -eq $s) { return '' }
  $s = $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;'
  $s = $s -replace '"','&quot;' -replace "'","&#39;"
  return $s
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N1} {1}" -f $size, $u) }
  }
  return ("{0:N1} PB" -f ($bytes / [math]::Pow(2,50)))
}

function Normalize-SourceInput([string]$srcIn){
  if ([string]::IsNullOrWhiteSpace($srcIn)) { return $null }
  $s = $srcIn -replace '["“”]', '' -replace '(\r?\n)+',';' -replace '\s+and\s+', ';' -replace '\s*,\s*', ';'
  return ($s -split '\s*;\s*' | Where-Object { $_ -and $_.Trim().Length -gt 0 })
}

# =================== ZIP Helpers ===================
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+ or ensure System.IO.Compression assemblies are present." }
  }
}

function Get-FilesFromSources {
  param([Parameter(Mandatory)][string[]]$Sources)
  $results = New-Object System.Collections.Generic.List[object]; $i = 1
  foreach ($src in $Sources) {
    if (-not (Test-Path -LiteralPath $src)) { Write-Warn "Missing source: $src"; $i++; continue }
    $root = (Resolve-Path -LiteralPath $src).Path; if (-not $root.EndsWith('\')) { $root += '\' }
    $labelBase = Split-Path -Leaf ($root.TrimEnd('\')); $label = "{0}_{1}" -f $i, $labelBase
    Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $rel = $_.FullName.Substring($root.Length).TrimStart('\','/')
      $results.Add([pscustomobject]@{
        SourceRoot=$root; Label=$label; FullName=$_.FullName; RelPath=($rel -replace '\\','/'); Length=$_.Length
      })
    }; $i++
  }
  return $results
}

function New-ZipFromItems {
  param([Parameter(Mandatory)][pscustomobject[]]$Items,[Parameter(Mandatory)][string]$ZipPath)
  Ensure-ZipAssemblies
  if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }

  $fs = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::Create,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
  try {
    $zip = New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Create,$true)
    $skipped = New-Object System.Collections.Generic.List[string]

    foreach ($it in $Items) {
      if (-not (Test-Path -LiteralPath $it.FullName)) { continue }
      $entryRel = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
      $entryName = "$($it.Label)/$entryRel"
      try {
        $entry=$zip.CreateEntry($entryName,[System.IO.Compression.CompressionLevel]::Optimal)
        $ostream=$entry.Open()
        try {
          $istream=New-Object System.IO.FileStream($it.FullName,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
          try { $istream.CopyTo($ostream) } finally { $istream.Dispose() }
        } finally { $ostream.Dispose() }
      } catch { $skipped.Add($it.FullName) }
    }

    if ($skipped.Count -gt 0) {
      $note = "The following files were locked or otherwise unreadable at capture time:`r`n`r`n" + ($skipped -join "`r`n") + "`r`n"
      $noteEntry  = $zip.CreateEntry("0_SKIPPED_locked_files.txt",[System.IO.Compression.CompressionLevel]::Optimal)
      $noteStream = $noteEntry.Open()
      try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        $bytes = $enc.GetBytes($note)
        $noteStream.Write($bytes,0,$bytes.Length)
      } finally { $noteStream.Dispose() }
    }
  } finally { if ($zip){$zip.Dispose()} ; $fs.Dispose() }
}

# =================== ASN.1 + RSA Loader (PS 5.1-safe) ===================
function PR-AssertTag { param([byte[]]$Buf,[int]$Idx,[byte]$Tag)
  if ($Buf[$Idx] -ne $Tag) { throw ("ASN.1 tag mismatch. Expected 0x{0:X2}, got 0x{1:X2}" -f $Tag, $Buf[$Idx]) }
  return ($Idx + 1)
}
function PR-ReadLen { param([byte[]]$Buf,[int]$Idx)
  $lenByte = [int]$Buf[$Idx]; $Idx++
  if ($lenByte -lt 0x80) { return @{ Len=$lenByte; Idx=$Idx } }
  $num = $lenByte - 0x80
  if ($num -lt 1 -or $num -gt 4) { throw "Unsupported length octets ($num)" }
  $val = 0
  for ($k=0; $k -lt $num; $k++){ $val = (($val -shl 8) -bor [int]$Buf[$Idx]); $Idx++ }
  return @{ Len=$val; Idx=$Idx }
}
function PR-ReadInteger { param([byte[]]$Buf,[int]$Idx)
  $Idx = PR-AssertTag -Buf $Buf -Idx $Idx -Tag 0x02
  $lr = PR-ReadLen -Buf $Buf -Idx $Idx
  $len = $lr.Len; $Idx = $lr.Idx
  $start=$Idx
  $bytes = New-Object byte[] $len
  [System.Buffer]::BlockCopy($Buf, $start, $bytes, 0, $len)
  $Idx += $len
  if ($bytes.Length -gt 1 -and $bytes[0] -eq 0x00) {
    $trim = New-Object byte[] ($bytes.Length - 1)
    [System.Array]::Copy($bytes, 1, $trim, 0, $trim.Length)
    $bytes = $trim
  }
  return @{ Val = $bytes; Idx = $Idx }
}
function PR-ParseSpki { param([byte[]]$Buf)
  $i = 0
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $spkiEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $algEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x06; $lr = PR-ReadLen -Buf $Buf -Idx $i; $i = $lr.Idx + $lr.Len
  if ($i -lt $algEnd -and $Buf[$i] -eq 0x05) { $i++; $lr = PR-ReadLen -Buf $Buf -Idx $i; if ($lr.Len -ne 0) { throw "AlgorithmIdentifier NULL has non-zero length." } ; $i = $lr.Idx }
  if ($i -ne $algEnd) { $i = $algEnd }
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x03; $lr = PR-ReadLen -Buf $Buf -Idx $i; $bitEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $unused = $Buf[$i]; if ($unused -ne 0) { throw "Unsupported BIT STRING (unused bits = $unused)" } ; $i++
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $rsaEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $mod = $r.Val; $i = $r.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $exp = $r.Val; $i = $r.Idx
  if ($i -ne $rsaEnd) { $i = $rsaEnd }
  if ($i -ne $bitEnd) { $i = $bitEnd }
  if ($i -ne $spkiEnd){ $i = $spkiEnd }
  return @{ Modulus=$mod; Exponent=$exp }
}
Remove-Item function:\Get-RsaFromPem -ErrorAction SilentlyContinue
function Get-RsaFromPem {
  param([Parameter(Mandatory)][string]$Pem)
  $clean = $Pem -replace '-----BEGIN PUBLIC KEY-----','' -replace '-----END PUBLIC KEY-----',''
  $clean = $clean -replace '\s+',''
  try { $spki = [Convert]::FromBase64String($clean) } catch { throw "Invalid PEM public key (Base64 parse failed)." }
  $parsed = PR-ParseSpki -Buf $spki
  $rsaParams = New-Object System.Security.Cryptography.RSAParameters
  $rsaParams.Modulus  = [byte[]]$parsed.Modulus
  $rsaParams.Exponent = [byte[]]$parsed.Exponent
  $rsa = [System.Security.Cryptography.RSA]::Create()
  $rsa.ImportParameters($rsaParams)
  return $rsa
}

# =================== Crypto Helpers ===================
function New-RandomBytes([int]$len){
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  $buf = New-Object byte[] $len
  $rng.GetBytes($buf)
  $rng.Dispose()
  return $buf
}
function New-BE16([int]$n){ $t = New-Object byte[] 2; $t[0] = (($n -shr 8) -band 0xFF); $t[1] = ($n -band 0xFF); return $t }
function Bytes-Cat { param([Parameter(ValueFromRemainingArguments=$true)][object[]]$Chunks)
  $total = 0; foreach($c in $Chunks){ $total += ([byte[]]$c).Length }
  $buf = New-Object byte[] $total; $off = 0
  foreach($c in $Chunks){ $arr = [byte[]]$c; [System.Array]::Copy($arr,0,$buf,$off,$arr.Length); $off += $arr.Length }
  return $buf
}
function Parse-CSBHeader([byte[]]$bytes){
  if ($bytes.Length -lt 8) { throw "CSB too small (<8 bytes)." }
  $magic = [Text.Encoding]::ASCII.GetString($bytes,0,4)
  $ver   = $bytes[4]
  $flags = $bytes[5]
  $wlen  = (([int]$bytes[6] -shl 8) -bor ([int]$bytes[7]))
  [pscustomobject]@{ Magic=$magic; Version=$ver; Flags=$flags; WrappedLen=$wlen }
}

function Protect-Zip-ToCSB {
  param(
    [Parameter(Mandatory)][string]$ZipPath,
    [Parameter(Mandatory)][string]$OutCsbPath,
    [Parameter(Mandatory)][string]$PemPublicKey
  )

  $secret = New-RandomBytes 80
  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0, $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret,32, $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret,64, $iv,     0, 16)

  $plain = [System.IO.File]::ReadAllBytes($ZipPath)
  $aes   = [System.Security.Cryptography.Aes]::Create()
  $aes.KeySize = 256; $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = $aesKey; $aes.IV = $iv
  $ms = New-Object System.IO.MemoryStream
  $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateEncryptor(), 'Write')
  $cs.Write($plain,0,$plain.Length); $cs.FlushFinalBlock(); $cs.Dispose()
  $cipher = $ms.ToArray(); $ms.Dispose(); $aes.Dispose()

  $rsa = Get-RsaFromPem -Pem $PemPublicKey
  $wrapped = $null; $flags = 0x01
  try {
    $wrapped = $rsa.Encrypt($secret,[System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
    $flags = $flags -bor 0x02
  } catch {
    try {
      $wrapped = $rsa.Encrypt($secret,[System.Security.Cryptography.RSAEncryptionPadding]::Oaep) # OAEP-SHA1
      $flags = $flags -bor 0x04
    } catch {
      $csp = $null
      try {
        $pub = $rsa.ExportParameters($false)
        $keySizeBits = $pub.Modulus.Length * 8
        $cspParams = New-Object System.Security.Cryptography.CspParameters
        $cspParams.ProviderType = 24
        $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
        $csp.PersistKeyInCsp = $false
        $csp.ImportParameters($pub)
        $wrapped = $csp.Encrypt($secret,$false)
      } finally {
        if ($csp) { try { $csp.Clear() } catch {}; try { $csp.Dispose() } catch {} }
      }
      $flags = $flags -bor 0x08
    }
  }

  $wrapped = [byte[]]$wrapped
  if ($null -eq $wrapped -or $wrapped.Length -le 0) { throw "RSA encryption produced no data (wrappedLen=0)." }
  if ($wrapped.Length -gt 65535) { throw "Wrapped key blob too large for CSB header." }

  $magic   = [byte[]]([Text.Encoding]::ASCII.GetBytes('CSB1'))
  $verB    = [byte[]]@([byte]1)
  $flagsB  = [byte[]]@([byte]$flags)
  $wlenBE  = New-BE16 $wrapped.Length
  $headerNoTag = Bytes-Cat $magic $verB $flagsB $wlenBE $wrapped

  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  $msComb = New-Object System.IO.MemoryStream
  $msComb.Write($headerNoTag,0,$headerNoTag.Length)
  $msComb.Write($cipher,0,$cipher.Length)
  $tag = $hmac.ComputeHash($msComb.ToArray())
  $msComb.Dispose(); $hmac.Dispose()

  $finalLen = $headerNoTag.Length + $cipher.Length + $tag.Length
  $bundle = New-Object byte[] $finalLen
  [Array]::Copy($headerNoTag,0,$bundle,0,$headerNoTag.Length)
  [Array]::Copy($cipher,0,$bundle,$headerNoTag.Length,$cipher.Length)
  [Array]::Copy($tag,0,$bundle,$headerNoTag.Length+$cipher.Length,$tag.Length)
  [System.IO.File]::WriteAllBytes($OutCsbPath,$bundle)

  $verify = [System.IO.File]::ReadAllBytes($OutCsbPath)
  $h = Parse-CSBHeader $verify
  if ($h.Magic -ne 'CSB1' -or $h.Version -ne 1) { throw "Header sanity check failed (magic/version)." }
  if ($h.WrappedLen -le 0) { throw "Header sanity check failed: wrappedLen parsed as 0." }

  Write-Ok ("Wrote CSB: {0}" -f $OutCsbPath)
}

# =================== Compose Helper (RESTORED STYLED UI + SAFE ENCODING) ===================
function Build-ComposeHelper {
  param(
    [Parameter(Mandatory)][pscustomobject[]]$Attachments,
    [Parameter(Mandatory)][string]$Stamp,
    [Parameter(Mandatory)][string]$LogoUrl,
    [Parameter(Mandatory)][string]$OutDir,
    [Parameter(Mandatory)][string]$ModeTag,
    [Parameter(Mandatory)][string]$ManifestPath,
    [string]$CompanyParam,
    [string]$TicketParam,
    [string]$ToParam,
    [string]$CcParam,
    [switch]$NonInteractive
  )

  if ($NonInteractive) {
    $Company = $CompanyParam
    $Tenant  = ''
    $Ticket  = $TicketParam
    $To      = if ($ToParam) { $ToParam } else { $DefaultTo }
    $Cc      = $CcParam
    $Bcc     = ''
    $Sender  = 'dmoon'
  } else {
    $Company = if ([string]::IsNullOrWhiteSpace($CompanyParam)) { Read-Host "Enter Company" } else { $CompanyParam }
    $Tenant  = Read-Host "Enter Tenant"
    $Ticket  = if ([string]::IsNullOrWhiteSpace($TicketParam)) { Read-Host "Enter Ticket (optional, press Enter to skip)" } else { $TicketParam }

    $To = if ($ToParam) { $ToParam } else {
      $tmp = Read-Host "Enter To (press Enter for default: $DefaultTo)"
      if ([string]::IsNullOrWhiteSpace($tmp)) { $DefaultTo } else { $tmp }
    }

    $Cc  = if ([string]::IsNullOrWhiteSpace($CcParam)) { Read-Host "Enter Cc (optional)" } else { $CcParam }
    $Bcc = Read-Host "Enter Bcc (optional)"
    $Sender = Read-Host "Enter your name or signature (optional)"
    if ([string]::IsNullOrWhiteSpace($Sender)) { $Sender = 'dmoon' }
  }

  $companyEsc = HtmlEncode $Company
  $tenantEsc  = HtmlEncode $Tenant
  $ticketEsc  = HtmlEncode $Ticket
  $toEsc      = HtmlEncode $To
  $ccEsc      = HtmlEncode $Cc
  $bccEsc     = HtmlEncode $Bcc
  $senderEsc  = HtmlEncode $Sender
  $logoEsc    = HtmlEncode $LogoUrl
  $modeEsc    = HtmlEncode $ModeTag
  $outEsc     = HtmlEncode $OutDir

  if ($Attachments -and $Attachments.Count -gt 0) {
    $attachLis = ($Attachments | ForEach-Object {
      '<li><code>'+(HtmlEncode $_.Name)+'</code> <span class="size">('+(HtmlEncode $_.SizeHuman)+')</span></li>'
    }) -join "`n        "
  } else {
    $attachLis = '<li><code>(No files detected in output folder at generation time)</code></li>'
  }

  $manifestEncoded = '(Manifest not available)'
  try {
    if (Test-Path -LiteralPath $ManifestPath) {
      $lines = Get-Content -LiteralPath $ManifestPath -ErrorAction Stop
      $max = 800; $take = [Math]::Min($lines.Count,$max)
      $manifestText = [string]::Join("`n",$lines[0..($take-1)])
      if ($lines.Count -gt $max) { $manifestText += "`n... (truncated; total lines: $($lines.Count))" }
      $manifestEncoded = HtmlEncode $manifestText
    } else { $manifestEncoded = HtmlEncode "(Manifest file not found at $ManifestPath)" }
  } catch { $manifestEncoded = HtmlEncode "(Manifest read error: $($_.Exception.Message))" }

  # NOTE: ASCII-only template to prevent encoding corruption ("crosses"/garbage chars)
  $HtmlTemplate = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ConnectSecure - Compose Helper</title>
<style>
  :root{--bg:#0f172a;--panel:#111827;--text:#e5e7eb;--muted:#9ca3af;--accent:#22c55e;--link:#60a5fa;--border:rgba(255,255,255,.12);--mono:Consolas,ui-monospace,Menlo,monospace}
  html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
  *,*::before,*::after{box-sizing:border-box}
  .wrap{max-width:1100px;margin:0 auto;padding:28px 22px 40px}
  header{display:flex;flex-direction:column;align-items:center;gap:10px;margin:6px 0 18px}
  .brand{font-weight:700;letter-spacing:.3px;font-size:1.05rem;color:var(--muted)}
  h1{margin:4px 0 6px;font-size:1.6rem;line-height:1.2;text-align:center}
  .subtitle{color:var(--muted);text-align:center;margin-top:2px;max-width:850px}
  .panel{background:linear-gradient(180deg,rgba(255,255,255,.02),rgba(255,255,255,0));border:1px solid var(--border);border-radius:14px;padding:16px;margin:16px 0}
  .label-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}
  .label{font-weight:700}.subcopy{color:var(--muted);font-size:.92rem;margin-top:2px}
  a{color:var(--link);text-decoration:none}a:hover{text-decoration:underline}
  .btn{display:inline-flex;align-items:center;gap:8px;background:var(--panel);border:1px solid var(--border);color:var(--text);padding:9px 12px;border-radius:10px;cursor:pointer;text-decoration:none;font-weight:700;user-select:none}
  .btn:hover{border-color:rgba(255,255,255,.25)}
  .hint{color:var(--muted);font-size:.95rem;margin-top:6px}
  .footer{margin-top:24px;color:var(--muted);font-size:.9rem;text-align:center}
  .pill{display:inline-block;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);color:#86efac;border-radius:6px;padding:2px 8px;font-size:.8rem;margin:6px 0}
  .copyfield{background:#0b1020;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:13px}
  .copyfield.singleline{white-space:nowrap;overflow:auto}.copyfield.multiline{white-space:pre-wrap;word-break:break-word;overflow:auto;line-height:1.5}
  .file-list{margin:0;padding-left:24px;list-style:disc}.file-list li{margin:.15rem 0}.file-list code{font-family:var(--mono);font-size:13px;word-break:break-all}
  .manifest{max-height:280px;overflow:auto;border:1px solid rgba(255,255,255,.1);background:#0b1020;border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:12px;line-height:1.45}
  .flash{outline:2px solid var(--accent);outline-offset:1px;transition:outline-color .2s ease}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <div style="margin-bottom:12px;text-align:center"><img src="__LOGOURL__" alt="ConnectSecure Logo" style="max-width:180px;height:auto"/></div>
      <div class="brand">ConnectSecure</div>
      <h1>Compose Email Helper <span class="pill">__STAMP__</span></h1>
      <div class="subtitle">Attach the file(s) below, then copy To/Subject/Body into your email client.</div>
    </header>

    <section class="panel">
      <div class="label-row">
        <div><div class="label">Attach these file(s) before sending</div><div class="subcopy">Open the output folder and attach the files listed below.</div></div>
        <a class="btn" href="file:///__OUTDIR__" target="_blank" rel="noopener">Open folder</a>
      </div>
      <ul class="file-list" id="attachments">__ATTACHMENTS__</ul>
      <div class="hint">If your browser blocks file links, open File Explorer and browse to: <code>__OUTDIR_RAW__</code></div>
    </section>

    <section class="panel"><div class="label-row"><div><div class="label">To</div><div class="subcopy">Copies the recipient list to your clipboard.</div></div><button class="btn" data-copy="#toField">Copy To</button></div><div class="copyfield singleline" id="toField">__TO__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Cc</div><div class="subcopy">Optional - copies Cc to your clipboard.</div></div><button class="btn" data-copy="#ccField">Copy Cc</button></div><div class="copyfield singleline" id="ccField">__CC__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Bcc</div><div class="subcopy">Optional - copies Bcc to your clipboard.</div></div><button class="btn" data-copy="#bccField">Copy Bcc</button></div><div class="copyfield singleline" id="bccField">__BCC__</div></section>

    <section class="panel"><div class="label-row"><div><div class="label">Subject</div><div class="subcopy">Copies the subject line exactly as shown.</div></div><button class="btn" data-copy="#subjectField">Copy Subject</button></div><div class="copyfield singleline" id="subjectField">ConnectSecure Support Bundle | __MODE__ | __COMPANY__ | __TENANT__ | __TICKET__</div></section>

    <section class="panel">
      <div class="label-row"><div><div class="label">Body (HTML)</div><div class="subcopy">Copies rich HTML for clients that support it.</div></div><button class="btn" data-copy-html="#bodyHtmlField">Copy HTML Body</button></div>
      <div class="copyfield multiline" id="bodyHtmlField">
<p>Hello ConnectSecure Support,</p>
<p>Please find the attached <b>__MODE__</b> support bundle for:</p>
<ul><li>Company: <b>__COMPANY__</b></li><li>Tenant: <b>__TENANT__</b></li><li>Ticket: <b>__TICKET__</b></li></ul>
<p><b>Included Manifest (snapshot)</b></p>
<details open><summary>Bundle Manifest</summary><pre class="manifest">__MANIFEST__</pre></details>
<p>Thanks,<br/>__SENDER__</p>
      </div>
      <div class="hint">Use this if your mail client supports HTML composition.</div>

      <div style="height:10px"></div>
      <div class="label-row"><div><div class="label">Body (Plain Text)</div><div class="subcopy">Copies a plain text version for all clients.</div></div><button class="btn" data-copy="#bodyTextField">Copy Text Body</button></div>
      <div class="copyfield multiline" id="bodyTextField">Hello ConnectSecure Support,

Please find the attached __MODE__ support bundle for:
- Company: __COMPANY__
- Tenant: __TENANT__
- Ticket: __TICKET__

(See HTML body for embedded manifest snapshot.)

Thanks,
__SENDER__</div>
      <div class="hint">Tip: Paste with Ctrl+V.</div>
    </section>

    <div class="footer">&copy; <span id="year"></span> ConnectSecure. All rights reserved.</div>
  </div>

<script>
(function(){
  document.getElementById('year').textContent = new Date().getFullYear();
  const flash = (el)=>{ el.classList.add('flash'); setTimeout(()=>el.classList.remove('flash'), 650); };
  async function copyText(text, el){
    try{ if(navigator.clipboard && navigator.clipboard.writeText){ await navigator.clipboard.writeText(text); flash(el); return; } }catch(_){}
    const ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(ta); flash(el);
  }
  async function copyHtml(html, el){
    if(navigator.clipboard && navigator.clipboard.write){
      try{ const blob=new Blob([html],{type:"text/html"}); const item=new ClipboardItem({"text/html":blob}); await navigator.clipboard.write([item]); flash(el); return; }catch(_){}
    }
    const box=document.createElement('div'); box.contentEditable='true'; box.style.position='fixed'; box.style.left='-9999px'; document.body.appendChild(box);
    box.innerHTML=html; const range=document.createRange(); range.selectNodeContents(box);
    const sel=window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(box); flash(el);
  }
  document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',()=>{
    const t=document.querySelector(btn.getAttribute('data-copy'));
    copyText((t.innerText||t.textContent), t);
  }));
  document.querySelectorAll('[data-copy-html]').forEach(btn=>btn.addEventListener('click',()=>{
    const t=document.querySelector(btn.getAttribute('data-copy-html'));
    copyHtml(t.innerHTML, t);
  }));
})();
</script>
</body>
</html>
'@

  $outForHref = ($outEsc -replace '\\','/')
  $Html = $HtmlTemplate.
    Replace('__STAMP__',       (HtmlEncode $Stamp)).
    Replace('__ATTACHMENTS__', $attachLis).
    Replace('__TO__',          $toEsc).
    Replace('__CC__',          $ccEsc).
    Replace('__BCC__',         $bccEsc).
    Replace('__COMPANY__',     $companyEsc).
    Replace('__TENANT__',      $tenantEsc).
    Replace('__TICKET__',      $ticketEsc).
    Replace('__SENDER__',      $senderEsc).
    Replace('__LOGOURL__',     $logoEsc).
    Replace('__MODE__',        $modeEsc).
    Replace('__OUTDIR__',      $outForHref).
    Replace('__OUTDIR_RAW__',  $outEsc).
    Replace('__MANIFEST__',    $manifestEncoded)

  $helperPath = Join-Path $OutDir ("Compose_Helper_{0}.html" -f $Stamp)

  # UTF-8 without BOM
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($helperPath, $Html, $Utf8NoBom)

  Write-Ok "Wrote Compose Helper HTML: $helperPath"
  try { Start-Process $helperPath | Out-Null } catch {}

  return [pscustomobject]@{
    HelperPath = $helperPath
    Company    = $Company
    Tenant     = $Tenant
    Ticket     = $Ticket
    To         = $To
  }
}

# =================== MAIN ===================
Ensure-Folder -Path $OutDir

if ($Secure -and $Unsecure) { Write-Err "Cannot use -s and -u together."; exit 1 }

$NonInteractive = ($Secure -or $Unsecure)

# Secure implies SkipZip; and s/u imply NoHtml (per your requirement)
if ($Secure) { $SkipZip = $true }
if ($NonInteractive) { $NoHtml = $true }

# Mode selection
if (-not $NonInteractive) {
  Write-Host ""
  Write-Host "ConnectSecure Support Bundle Generator" -ForegroundColor Cyan
  Write-Host "  [S] Secure"
  Write-Host "  [U] Unsecure"
  Write-Host "  [Q] Quit"
  $choice = (Read-Host "Choose mode (S/U/Q)").ToUpper().Trim()
  switch ($choice) {
    'S' { $Secure = $true }
    'U' { $Unsecure = $true }
    'Q' { return }
    default { Write-Err "Invalid selection."; exit 1 }
  }
  $NonInteractive = $false
}

$modeTag = if ($Secure) { 'Secure' } else { 'Unsecure' }

# Sources
if ($Secure -or $Unsecure) {
  $srcPaths = $DefaultSources
  Write-Info "Using default capture locations (non-interactive)."
} else {
  Write-Host ""
  Write-Host "Enter source roots. Press Enter to use defaults:" -ForegroundColor Yellow
  $DefaultSources | ForEach-Object -Begin { $idx=1 } -Process { Write-Host ("  {0}) {1}" -f $idx, $_); $idx++ }
  $srcIn = Read-Host "Source paths"
  [string[]]$srcPaths = Normalize-SourceInput $srcIn
  if (-not $srcPaths) { $srcPaths = $DefaultSources }
}

# Collect files
$items = Get-FilesFromSources -Sources $srcPaths
$items = $items | Where-Object { $_.FullName -notlike "$OutDir*" }
if (-not $items) { $items = @() }

# Manifest
$Stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
$manifestPath = Join-Path $OutDir ("BundleManifest_{0}.txt" -f $Stamp)
$totalBytes = ($items | Measure-Object -Property Length -Sum).Sum; if ($null -eq $totalBytes) { $totalBytes = 0 }
$header = ("{0} files, total {1}" -f $items.Count,(Get-SizeHuman ([long]$totalBytes)))
$header | Out-File -FilePath $manifestPath -Encoding UTF8

foreach ($it in $items) {
  $sz = Get-SizeHuman $it.Length
  $dispPath = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
  ("{0}`t{1}\{2}`t{3}" -f $sz,$it.Label,$dispPath,$it.FullName) | Out-File -FilePath $manifestPath -Append -Encoding UTF8
}
Write-Ok "Manifest: $manifestPath"

# Build ZIP
$zipPath = $null
$csbPath = $null

if ($items.Count -eq 0) {
  Write-Warn "No files found under the provided sources. Bundle will contain manifest only."
}

$zipPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip" -f $Stamp)
Write-Info "Building ZIP: $zipPath"
$zipItems = @([pscustomobject]@{
  Label='0_MANIFEST'; RelPath=(Split-Path -Leaf $manifestPath); FullName=$manifestPath; Length=(Get-Item $manifestPath).Length
}) + $items
New-ZipFromItems -Items $zipItems -ZipPath $zipPath
Write-Ok "ZIP created"

# Secure -> CSB
if ($Secure) {
  $csbPath = Join-Path $OutDir ("CS-SupportBundle_{0}.csb" -f $Stamp)
  Write-Info "Encrypting ZIP to CSB..."
  Protect-Zip-ToCSB -ZipPath $zipPath -OutCsbPath $csbPath -PemPublicKey $RsaPublicPem
  Write-Ok "CSB created: $csbPath"

  if ($SkipZip -and (Test-Path -LiteralPath $zipPath)) {
    Write-Info "Removing ZIP (SkipZip implied by Secure)."
    Remove-Item -LiteralPath $zipPath -Force
    $zipPath = $null
  }
}

# Compose Helper (only when HTML is enabled; interactive mode default)
if (-not $NoHtml) {
  $attachments = @()
  if ($Secure -and $csbPath -and (Test-Path $csbPath)) {
    $fi = Get-Item -LiteralPath $csbPath
    $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) }
  } elseif ($zipPath -and (Test-Path $zipPath)) {
    $fi = Get-Item -LiteralPath $zipPath
    $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) }
  }

  $finalTo = if ($To) { $To } else { $DefaultTo }
  $null = Build-ComposeHelper `
    -Attachments $attachments `
    -Stamp $Stamp `
    -LogoUrl $LogoUrl `
    -OutDir $OutDir `
    -ModeTag $modeTag `
    -ManifestPath $manifestPath `
    -CompanyParam $Company `
    -TicketParam $Ticket `
    -ToParam $finalTo `
    -CcParam $Cc `
    -NonInteractive:$false
}

Write-Ok "Done."
if ($zipPath) { Write-Info "ZIP: $zipPath" }
if ($csbPath){ Write-Info "CSB: $csbPath" }
