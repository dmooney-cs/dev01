<# =====================================================================
  ConnectSecure - CS-Toolbox-Launcher (fixed)
  - Self-contained (no dependency on Functions-Common for the menu UI)
  - Safe Invoke-Tool wrapper sets $env:CS_FROM_LAUNCHER so sub-menus can 'Q' back
  - Z: Zip + Encrypt + Compose Helper runs in same window, returns to menu
  - C: Cleanup & Self-Destruct copies to a temp location, launches NEW window, then closes this one
===================================================================== #>

# -------- Basics --------
$ErrorActionPreference = 'Stop'

function Show-Header {
  param([string]$Title = 'ConnectSecure Technicians Toolbox')
  try { Clear-Host } catch {}
  Write-Host ''
  Write-Host " $Title" -ForegroundColor Cyan
  Write-Host ('='*70)
}

function Pause([string]$Message = 'Press any key to return to the menu...') {
  Write-Host ''
  Write-Host $Message -ForegroundColor DarkGray
  [void][System.Console]::ReadKey($true)
}

# Wrapper to invoke child scripts: marks them as launched-from-launcher so their 'Q' can just return.
function Invoke-Tool {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    Write-Host "[ERROR] Missing script: $Path" -ForegroundColor Red
    Pause
    return
  }

  try {
    $env:CS_FROM_LAUNCHER = '1'
    & $Path
  } catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Pause
  } finally {
    Remove-Item Env:\CS_FROM_LAUNCHER -ErrorAction SilentlyContinue
  }
}

# Attempt to create and return the first writable folder from a list of candidates
function Get-FirstWritablePath {
  param([string[]]$Candidates)
  foreach ($dir in $Candidates) {
    try {
      if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      $test = Join-Path $dir ([System.IO.Path]::GetRandomFileName())
      New-Item -ItemType File -Path $test -Force | Out-Null
      Remove-Item -LiteralPath $test -Force -ErrorAction SilentlyContinue
      return $dir
    } catch {
      continue
    }
  }
  return $null
}

# Copy the cleanup script to a safe temp path and launch in a new window; then close this window.
function Start-CleanupSelfDestruct {
  [CmdletBinding()]
  param(
    [string]$Source = 'C:\CS-TOOLBOX-TEMP\prod-01-01\Toolbox-Cleanup-SelfDestruct.ps1'
  )
  if (-not (Test-Path -LiteralPath $Source)) {
    Write-Host "[ERROR] Cleanup script not found at $Source" -ForegroundColor Red
    Pause
    return
  }

  $destParent = Get-FirstWritablePath @('C:\temp', "$env:TEMP", "$env:ProgramData\CS-Toolbox-Temp")
  if (-not $destParent) {
    Write-Host "[ERROR] Could not find a writable temp directory." -ForegroundColor Red
    Pause
    return
  }

  $dest = Join-Path $destParent 'Toolbox-Cleanup-SelfDestruct.ps1'
  try {
    Copy-Item -LiteralPath $Source -Destination $dest -Force
  } catch {
    Write-Host "[ERROR] Failed to copy cleanup script: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    return
  }

  try {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @(
      '-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$dest`""
    ) -WindowStyle Normal
  } catch {
    Write-Host "[ERROR] Failed to launch cleanup: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    return
  }

  # Close the current launcher window
  Write-Host "[INFO] Launched cleanup in a new window. Closing this window..." -ForegroundColor Green
  Start-Sleep -Seconds 1
  exit
}

# -------- Paths to child tools --------
$Base = 'C:\CS-TOOLBOX-TEMP\prod-01-01'

$Tools = @{
  '1' = Join-Path $Base 'Osquery-Data-Collection.ps1'           # Apps, search, browser extensions
  '2' = Join-Path $Base 'Nmap-Data-Collection.ps1'              # Network scan profiles
  '3' = Join-Path $Base 'Secondary-Validation-Tools.ps1'        # Patch audit, VC++ runtimes, TLS policy, etc.
  '4' = Join-Path $Base 'Registry-Uninstall-Search.ps1'         # Keyword-based uninstall search
  '5' = Join-Path $Base 'Agent-Log-Review.ps1'                  # EVTX robust summary + correlation
  '6' = Join-Path $Base 'SystemInfo-A.ps1'                      # Pending reboot, logs, summaries
  '7' = Join-Path $Base 'SystemInfo-B.ps1'                      # System Info B suite
  '8' = Join-Path $Base 'Dependency-Validation.ps1'             # Dependency checks (placeholder)
  '9' = Join-Path $Base 'Agent-Action-Menu.ps1'                 # Agent install/reinstall/uninstall
  'Z' = Join-Path $Base 'zip-encrypt-htmltemplate.ps1'          # Zip + Encrypt + Compose Helper (HTML)
  'C' = Join-Path $Base 'Toolbox-Cleanup-SelfDestruct.ps1'      # Special handling (new window + close)
}

# -------- Menu UI --------
function Show-Menu {
  Show-Header -Title 'ConnectSecure Technicians Toolbox'

  Write-Host ' [1] OSQuery Data Collection      - Apps, search, browser extensions'
  Write-Host ' [2] Nmap Data Collection         - Local network scan profiles'
  Write-Host ' [3] Secondary Validation Tools   - Patch audit, VC++ runtimes, TLS policy, etc.'
  Write-Host ' [4] Registry Uninstall Search    - Keyword-based uninstall search'
  Write-Host ' [5] Agent Log Review             - EVTX robust summary + correlation'
  Write-Host ' [6] System Info A                - Pending Reboot Status, Logs, Summaries'
  Write-Host ' [7] System Info B                - System Info B suite'
  Write-Host ' [8] Dependency Validation        - Dependency checks'
  Write-Host ' [9] Agent Action Menu            - Agent Install/Reinstall/Uninstall'
  Write-Host ''
  Write-Host ' [Z] Zip + Encrypt + Compose Helper (HTML template)'
  Write-Host ' [C] Cleanup & Self-Destruct (launches in new window, then closes this one)'
  Write-Host ''
  Write-Host ' [Q] Quit'
  Write-Host ''
}

# -------- Main loop --------
while ($true) {
  Show-Menu
  $choice = Read-Host 'Select an option'
  if (-not $choice) { continue }
  $choice = $choice.Trim().ToUpperInvariant()

  switch ($choice) {
    'Q' {
      break
    }

    # Special case: Cleanup launches in new window & closes this one
    'C' {
      Start-CleanupSelfDestruct -Source $Tools['C']
      continue
    }

    default {
      if ($Tools.ContainsKey($choice)) {
        if ($choice -eq 'Z') {
          # Same-window execution, then we return to menu
          Invoke-Tool -Path $Tools['Z']
        } else {
          Invoke-Tool -Path $Tools[$choice]
        }
      } else {
        Write-Host "[WARN] Unknown option '$choice'." -ForegroundColor Yellow
        Pause -Message 'Press any key...'
      }
    }
  }
}
