function Show-Header {
    param(
        [string]$Title = "ConnectSecure Toolbox"
    )

    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host (" {0}" -f $Title) -ForegroundColor Yellow
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host ""
}


# --- Error-handling wrapper so menu pauses on errors ---
function Invoke-MenuAction {
    param(
        [Parameter(Mandatory)][ScriptBlock]$Action,
        [string]$Title = "Action"
    )
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Stop'
    try {
        & $Action
    } catch {
        Write-Host ""
        Write-Host ("=== ERROR in {0} ===" -f $Title) -ForegroundColor Red
        Write-Host ($_.Exception.Message) -ForegroundColor Yellow
        if ($_.ScriptStackTrace) {
            Write-Host ""
            Write-Host "Stack:" -ForegroundColor DarkYellow
            Write-Host ($_.ScriptStackTrace) -ForegroundColor DarkGray
        }
        Write-Host ""
        Read-Host "Press Enter to return to the menu"
    } finally {
        $ErrorActionPreference = $prev
    }
}

<# =====================================================================
  ConnectSecure Technicians Toolbox - Launcher
  File: CS-Toolbox-Launcher.ps1
  Updated: 2025-08-12
  Notes:
   - Uses Functions-Common.ps1 (R6) for: Show-Header, Launch-Tool,
     Ensure-ExportFolder, Zip-Results, Email-Results, Write-SessionSummary,
     Invoke-FinalCleanupAndExit, Write-Log, Pause-Script, etc.
   - Menu updated per request:
       [3] Secondary Validation Tools - Patch, TLS, VC++, Uninstall, Logs
       [4] Windows Modern App Discovery – Enumerate & search Modern/Store apps
===================================================================== #>

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

#---------------------------
# Hardcoded path map
#---------------------------
$PathMap = [ordered]@{
    "1" = 'C:\CS-Toolbox-TEMP\prod-01-01\Osquery-Data-Collection.ps1'
    "2" = 'C:\CS-Toolbox-TEMP\prod-01-01\Nmap-Data-Collection.ps1'
    "3" = 'C:\CS-Toolbox-TEMP\prod-01-01\Secondary-Collection-Tool.ps1'          # Secondary bundle
    "4" = 'C:\CS-Toolbox-TEMP\prod-01-01\Windows-Modern-App-Discovery.ps1'       # New script
    "5" = 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-AD.ps1'
    "6" = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-A.ps1'
    "7" = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-B.ps1'
    "8" = 'C:\CS-Toolbox-TEMP\prod-01-01\Tools-Utilities.ps1'
    "9" = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1'
}

function Write-Menu {
    Clear-Host
    Show-Header -Title 'ConnectSecure Technicians Toolbox'

    Write-Host ''
    Write-Host ' [1] OSQuery Data Collection      - Apps, search, browser extensions'
    Write-Host ' [2] Nmap Data Collection         - Local network scan profiles'
    Write-Host ' [3] Secondary Validation Tools   - Patch, TLS, VC++, Uninstall, Logs'
    Write-Host ' [4] Windows Modern App Discovery - Enumerate & search Modern/Store apps'
    Write-Host ' [5] Active Directory Tools       - Users, Groups, OUs, GPOs'
    Write-Host ' [6] System Info A                - Firewall, Defender, Services'
    Write-Host ' [7] System Info B                - Networking, Shares, Schedules'
    Write-Host ' [8] Machine Utilities            - Running Services and Disk Space'
    Write-Host ' [9] Agent Action Menu            - Agent Install/Reinstall/Uninstall'
    Write-Host ''
    Write-Host ' [Z] Zip + Encrypt + Compose Helper (HTML template)'
    Write-Host ' [C] Cleanup & Self-Destruct (launches in new window, then closes this one)'
    Write-Host ''
}

function Invoke-MenuAction {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Choice
    )

    switch -Regex ($Choice.Trim()) {
        '^[1-9]$' {
            $target = $PathMap[$Choice]
            if (-not (Test-Path -LiteralPath $target)) {
                Write-Host ("ERROR: Target script not found: {0}" -f $target) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
                return $false
            }

            try {
                & $target
            } catch {
                # NOTE: wrap $target to avoid "$target:" parsing
                Write-Host ("ERROR launching {0}: {1}" -f $target, $_.Exception.Message) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
            }
            return $false
        }

        '^(Z|z)$' {
            $target = 'C:\CS-Toolbox-TEMP\prod-01-01\zip-encrypt-htmltemplate.ps1'
            if (-not (Test-Path -LiteralPath $target)) {
                Write-Host ("ERROR: Target script not found: {0}" -f $target) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
                return $false
            }
            try { Unblock-File -LiteralPath $target -ErrorAction SilentlyContinue } catch {}
            try {
                & $target
            } catch {
                Write-Host ("ERROR running {0}: {1}" -f $target, $_.Exception.Message) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
            }
            return $false
        }

        '^(C|c)$' {
            Write-Host "`n[INFO] Preparing self-destruct cleanup..."
            $src = "C:\CS-TOOLBOX-TEMP\prod-01-01\Toolbox-Cleanup-SelfDestruct.ps1"
            $targets = @("C:\Temp", $env:TEMP)
            $dest = $null

            foreach ($t in $targets) {
                try {
                    if (-not (Test-Path $t)) { New-Item -ItemType Directory -Path $t -Force | Out-Null }
                    $candidate = Join-Path $t "Toolbox-Cleanup-SelfDestruct.ps1"
                    Copy-Item -Path $src -Destination $candidate -Force
                    $dest = $candidate
                    break
                } catch {
                    Write-Host ("[WARN] Could not copy to {0} : {1}" -f $t, $_.Exception.Message) -ForegroundColor Yellow
                }
            }

            if (-not $dest) {
                Write-Host "[FATAL] Could not copy script to any temp location. Aborting." -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
                return $false
            }

            try { Unblock-File -LiteralPath $dest -ErrorAction SilentlyContinue } catch {}
            Write-Host ("[INFO] Launching cleanup from {0} ..." -f $dest)
            Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$dest`"") -WindowStyle Normal

            Write-Host "[INFO] Exiting launcher..."
            exit
        }

        default {
            Write-Host 'Please choose 1-9, Z, or C.' -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $false
        }
    }
}

#----
# Main loop
#----
while ($true) {
    Write-Menu
    $key = Read-Host 'Select an option'
    if ([string]::IsNullOrWhiteSpace($key)) { continue }

    $exitNow = Invoke-MenuAction -Choice $key
    if ($exitNow) { break }
}
