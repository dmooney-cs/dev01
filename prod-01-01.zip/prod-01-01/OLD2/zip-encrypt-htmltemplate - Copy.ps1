

# === Ensure .NET Zip assemblies are available (PS 5.1-safe) ===
function Ensure-ZipAssemblies {
  try {
    [void][System.IO.Compression.ZipArchiveMode]::Create
  } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch { }
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+ or ensure System.IO.Compression assemblies are present." }
  }
}

<# ======================================================
  ConnectSecure - Menu: Secure / Unsecure / Inspect
  S: List -> ZIP (multi-root preserved) -> Encrypt -> Helper
  U: List -> ZIP (multi-root preserved) -> Helper
  L: List -> Helper
  Outputs: C:\CS-Toolbox-TEMP\ZIP
  Notes:
    - ASCII-only prompts
    - HTML template is a single-quoted here-string with token replacement
    - Fixed PS 5.1 inline-if issue and added locked-file handling
    - Loads PKCS types for CMS encryption
    - NEW: Embeds manifest snapshot in HTML email body
====================================================== #>

# ------------------- Settings -------------------
$OutDir         = 'C:\CS-Toolbox-TEMP\ZIP'
# Default roots (recursed). Press Enter at prompt to use these.
$DefaultSources = @(
  'C:\Program Files (x86)\CyberCNSAgent\logs',
  'C:\Program Files (x86)\CyberCNSAgent\results_data',
  'C:\CS-Toolbox-TEMP\Collected-Info'
)
$LogoUrl        = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$CertUrl        = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/Support-Encrypt.cer'

$DefaultTo      = 'support@connectsecure.com'
$DefaultCc      = ''
$DefaultBcc     = ''

# ------------------- Helpers -------------------
function Write-Info ($msg) { Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Cyan }
function Write-Ok   ($msg) { Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Green }
function Write-Warn ($msg) { Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Yellow }
function Write-Err  ($msg) { Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Red }

function Ensure-Folder {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function HtmlEncode {
  param([string]$s)
  if ($null -eq $s) { return '' }
  $s = $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;'
  $s = $s -replace '"','&quot;' -replace "'","&#39;"
  return $s
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N1} {1}" -f $size, $u) }
  }
  return ("{0:N1} PB" -f ($bytes / [math]::Pow(2,50)))
}

# Ensure PKCS types exist (System.Security.Cryptography.Pkcs.*). Load if needed.
function Ensure-PkcsTypes {
  try {
    [void][System.Security.Cryptography.Pkcs.ContentInfo]
    return
  } catch {
    try {
      Add-Type -AssemblyName System.Security -ErrorAction Stop
      [void][System.Security.Cryptography.Pkcs.ContentInfo]
      return
    } catch {
      try {
        [void][System.Reflection.Assembly]::Load('System.Security')
        [void][System.Security.Cryptography.Pkcs.ContentInfo]
        return
      } catch {
        throw "PKCS types not available on this host. Install .NET Framework 4.6+ (includes System.Security.Cryptography.Pkcs) or use a host with Protect-CmsMessage."
      }
    }
  }
}

# Normalize "Source paths" input: accept ; , and "and" as separators
function Normalize-SourceInput([string]$srcIn){
  if ([string]::IsNullOrWhiteSpace($srcIn)) { return $null }
  $s = $srcIn -replace '["“”]', '' -replace '(\r?\n)+',';' -replace '\s+and\s+', ';' -replace '\s*,\s*', ';'
  return ($s -split '\s*;\s*' | Where-Object { $_ -and $_.Trim().Length -gt 0 })
}

# Expand multiple sources to items with per-source labels and relpaths
function Get-FilesFromSources {
  param([Parameter(Mandatory)][string[]]$Sources)
  $results = New-Object System.Collections.Generic.List[object]
  $i = 1
  foreach ($src in $Sources) {
    if (-not (Test-Path -LiteralPath $src)) { Write-Warn "Missing source: $src"; $i++; continue }
    $root = (Resolve-Path -LiteralPath $src).Path
    if (-not $root.EndsWith('\')) { $root = $root + '\' }
    $labelBase = Split-Path -Leaf ($root.TrimEnd('\'))
    $label = "{0}_{1}" -f $i, $labelBase
    Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $full = $_.FullName
      $rel  = $full.Substring($root.Length).TrimStart('\','/')
      $results.Add([pscustomobject]@{
        SourceRoot = $root
        Label      = $label
        FullName   = $full
        RelPath    = ($rel -replace '\\','/')
        Length     = $_.Length
      })
    }
    $i++
  }
  return $results
}

# Create a zip from multi-root items; preserves "Label/RelPath" inside ZIP, tolerates locked files
function New-ZipFromItems {
  param(
    [Parameter(Mandatory)][pscustomobject[]]$Items,  # expects Label, RelPath, FullName
    [Parameter(Mandatory)][string]$ZipPath
  )

  Ensure-ZipAssemblies

  if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
  }

  $fs = [System.IO.File]::Open(
    $ZipPath,
    [System.IO.FileMode]::Create,
    [System.IO.FileAccess]::ReadWrite,
    [System.IO.FileShare]::None
  )

  try {
    $zip = New-Object System.IO.Compression.ZipArchive(
      $fs,
      [System.IO.Compression.ZipArchiveMode]::Create,
      $true
    )

    $skipped = New-Object System.Collections.Generic.List[string]

    foreach ($it in $Items) {
      if (-not (Test-Path -LiteralPath $it.FullName)) { continue }

      $entryRel = $it.RelPath
      if ([string]::IsNullOrWhiteSpace($entryRel)) {
        $entryRel = (Split-Path -Leaf $it.FullName)
      }
      $entryName = "$($it.Label)/$entryRel"

      try {
        $entry   = $zip.CreateEntry($entryName, [System.IO.Compression.CompressionLevel]::Optimal)
        $ostream = $entry.Open()
        try {
          $istream = New-Object System.IO.FileStream(
            $it.FullName,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::ReadWrite
          )
          try {
            $istream.CopyTo($ostream)
          } finally {
            $istream.Dispose()
          }
        } finally {
          $ostream.Dispose()
        }
      } catch {
        $skipped.Add($it.FullName)
      }
    }

    if ($skipped.Count -gt 0) {
      $note = "The following files were locked or otherwise unreadable at capture time:`r`n`r`n" +
              ($skipped -join "`r`n") + "`r`n"
      $noteEntry  = $zip.CreateEntry("0_SKIPPED_locked_files.txt", [System.IO.Compression.CompressionLevel]::Optimal)
      $noteStream = $noteEntry.Open()
      try {
        $enc   = New-Object System.Text.UTF8Encoding($false)
        $bytes = $enc.GetBytes($note)
        $noteStream.Write($bytes, 0, $bytes.Length)
      } finally {
        $noteStream.Dispose()
      }
    }
  } finally {
    if ($zip) { $zip.Dispose() }
    $fs.Dispose()
  }
}

# Download a certificate (DER or PEM) and return X509Certificate2 (PS 5.1-safe)
function Get-CertFromUrl {
  param([Parameter(Mandatory)][string]$Url)

  Write-Info "Downloading certificate from $Url"

  # Ensure TLS 1.2 for older hosts
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  } catch {}

  # Download raw bytes
  $wc = New-Object System.Net.WebClient
  try {
    $raw = $wc.DownloadData($Url)
  } finally {
    $wc.Dispose()
  }

  # Try PEM first (ASCII text with headers). If not, treat as DER.
  $asText = $null
  try { $asText = [System.Text.Encoding]::ASCII.GetString($raw) } catch {}

  if ($asText -and $asText -match '-----BEGIN CERTIFICATE-----') {
    $base64 = ($asText -replace '-----BEGIN CERTIFICATE-----','' -replace '-----END CERTIFICATE-----','' -replace '\s','')
    $der = [Convert]::FromBase64String($base64)
    return New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList (,([byte[]]$der))
  }

  # Sometimes the server returns base64 without PEM headers
  if ($asText -and $asText -notmatch '[^\r\n\t A-Za-z0-9+/=]') {
    try {
      $der = [Convert]::FromBase64String(($asText -replace '\s',''))
      return New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList (,([byte[]]$der))
    } catch { }
  }

  # Fallback: treat as DER bytes as-is
  return New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList (,([byte[]]$raw))
}

# Encrypt a file to CMS .p7m using recipient certificate
function Protect-CmsFile {
  param(
    [Parameter(Mandatory)][string]$InputPath,
    [Parameter(Mandatory)][System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert,
    [Parameter(Mandatory)][string]$OutPath
  )
  # Ensure the PKCS types are loaded on this host
  Ensure-PkcsTypes

  Write-Info "Encrypting to CMS (p7m)"
  $data = [System.IO.File]::ReadAllBytes($InputPath)

  # Build ContentInfo with explicit byte[]
  $contentInfo = New-Object System.Security.Cryptography.Pkcs.ContentInfo(,[byte[]]$data)

  $cms = New-Object System.Security.Cryptography.Pkcs.EnvelopedCms($contentInfo)
  $recip = New-Object System.Security.Cryptography.Pkcs.CmsRecipient($Cert)
  $cms.Encrypt($recip)
  $encoded = $cms.Encode()
  [System.IO.File]::WriteAllBytes($OutPath, $encoded)
}

# Build HTML helper (new template + logo at top + manifest embed)
function Build-ComposeHelper {
  param(
    [Parameter(Mandatory)][pscustomobject[]]$Attachments,
    [Parameter(Mandatory)][string]$Stamp,
    [Parameter(Mandatory)][string]$LogoUrl,
    [Parameter(Mandatory)][string]$OutDir,
    [Parameter(Mandatory)][string]$ModeTag,
    [Parameter(Mandatory)][string]$ManifestPath
  )

  $Company = Read-Host "Enter Company"
  $Tenant  = Read-Host "Enter Tenant"
  $Ticket  = Read-Host "Enter Ticket (optional, press Enter to skip)"
  $To      = Read-Host "Enter To (press Enter for default: $DefaultTo)"
  if ([string]::IsNullOrWhiteSpace($To)) { $To = $DefaultTo }
  $Cc      = Read-Host "Enter Cc (optional)"
  $Bcc     = Read-Host "Enter Bcc (optional)"
  $Sender  = Read-Host "Enter your name or signature (optional)"
  if ([string]::IsNullOrWhiteSpace($Sender)) { $Sender = 'dmoon' }

  # Safe encodes
  $companyEsc = HtmlEncode $Company
  $tenantEsc  = HtmlEncode $Tenant
  $ticketEsc  = HtmlEncode $Ticket
  $toEsc      = HtmlEncode $To
  $ccEsc      = HtmlEncode $Cc
  $bccEsc     = HtmlEncode $Bcc
  $senderEsc  = HtmlEncode $Sender
  $logoEsc    = HtmlEncode $LogoUrl
  $modeEsc    = HtmlEncode $ModeTag
  $outEsc     = HtmlEncode $OutDir

  # Attachment list HTML
  if ($Attachments.Count -gt 0) {
    $attachLines = @()
    foreach ($a in $Attachments) {
      $n = HtmlEncode $a.Name
      $s = $a.SizeHuman
      $attachLines += ('<li><code>' + $n + '</code> <span class="size">(' + $s + ')</span></li>')
    }
    $attachLis = ($attachLines -join "`n        ")
  } else {
    $attachLis = '<li><code>(No files detected in C:\CS-Toolbox-TEMP\ZIP at generation time)</code></li>'
  }

  # Read manifest and embed (truncate if huge)
  $manifestEncoded = '(Manifest not available)'
  try {
    if (Test-Path -LiteralPath $ManifestPath) {
      $lines = Get-Content -LiteralPath $ManifestPath -ErrorAction Stop
      $max = 800
      $take = [Math]::Min($lines.Count, $max)
      $shown = $lines[0..($take-1)]
      $manifestText = [string]::Join("`n", $shown)
      if ($lines.Count -gt $max) {
        $manifestText += "`n... (truncated; total lines: $($lines.Count))"
      }
      $manifestEncoded = HtmlEncode $manifestText
    } else {
      $manifestEncoded = HtmlEncode "(Manifest file not found at $ManifestPath)"
    }
  } catch {
    $manifestEncoded = HtmlEncode "(Manifest read error: $($_.Exception.Message))"
  }

  $HtmlTemplate = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ConnectSecure - Compose Helper</title>
<style>
  :root{
    --bg:#0f172a;--panel:#111827;--text:#e5e7eb;--muted:#9ca3af;
    --accent:#22c55e;--link:#60a5fa;--border:rgba(255,255,255,.12);
    --mono:Consolas,ui-monospace,Menlo,monospace
  }
  html,body{margin:0;padding:0;background:var(--bg);color:var(--text);
    font:16px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
  *,*::before,*::after{box-sizing:border-box}
  .wrap{max-width:1100px;margin:0 auto;padding:28px 22px 40px}
  header{display:flex;flex-direction:column;align-items:center;gap:10px;margin:6px 0 18px}
  .brand{font-weight:700;letter-spacing:.3px;font-size:1.05rem;color:var(--muted)}
  h1{margin:4px 0 6px;font-size:1.6rem;line-height:1.2;text-align:center}
  .subtitle{color:var(--muted);text-align:center;margin-top:2px;max-width:850px}

  .panel{background:linear-gradient(180deg,rgba(255,255,255,.02),rgba(255,255,255,0));
    border:1px solid var(--border);border-radius:14px;padding:16px;margin:16px 0}
  .label-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}
  .label{font-weight:700}
  .subcopy{color:var(--muted);font-size:.92rem;margin-top:2px}
  a{color:var(--link);text-decoration:none}
  a:hover{text-decoration:underline}
  .btn{display:inline-flex;align-items:center;gap:8px;background:var(--panel);
    border:1px solid var(--border);color:var(--text);padding:9px 12px;border-radius:10px;
    cursor:pointer;text-decoration:none;font-weight:700;user-select:none}
  .btn:hover{border-color:rgba(255,255,255,.25)}
  .hint{color:var(--muted);font-size:.95rem;margin-top:6px}
  .footer{margin-top:24px;color:var(--muted);font-size:.9rem;text-align:center}
  .pill{display:inline-block;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);
    color:#86efac;border-radius:6px;padding:2px 8px;font-size:.8rem;margin:6px 0}

  .copyfield{
    background:#0b1020;border:1px solid rgba(255,255,255,.08);border-radius:10px;
    padding:10px 12px;font-family:var(--mono);font-size:13px
  }
  .copyfield.singleline{white-space:nowrap;overflow:auto}
  .copyfield.multiline{
    white-space:pre-wrap;word-break:break-word;overflow:auto;line-height:1.5
  }

  .file-list{margin:0;padding-left:24px;list-style:disc}
  .file-list li{margin:.15rem 0}
  .file-list code{font-family:var(--mono);font-size:13px;word-break:break-all}
  .inner-list{margin:.25rem 0 .35rem .9rem;padding-left:18px;list-style:circle}
  .inner-list li{margin:.12rem 0}
  .size{color:var(--muted);font-size:.86rem}

  .manifest{max-height:280px;overflow:auto;border:1px solid rgba(255,255,255,.1);
    background:#0b1020;border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:12px;line-height:1.45}

  .flash{outline:2px solid var(--accent);outline-offset:1px;transition:outline-color .2s ease}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <div style="margin-bottom:12px;text-align:center">
        <img src="__LOGOURL__" alt="ConnectSecure Logo" style="max-width:180px;height:auto"/>
      </div>
      <div class="brand">ConnectSecure</div>
      <h1>Compose Email Helper <span class="pill">__STAMP__</span></h1>
      <div class="subtitle">Attach the files below, then copy To/Subject/Body into your email client.</div>
    </header>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">Attach these file(s) before sending</div>
          <div class="subcopy">Open the output folder and attach the files listed below.</div>
        </div>
        <a class="btn" href="file:///__OUTDIR__" target="_blank" rel="noopener">Open folder</a>
      </div>
      <ul class="file-list" id="attachments">
        __ATTACHMENTS__
      </ul>
      <div class="hint">If your browser blocks file links, open File Explorer and browse to: <code>__OUTDIR__</code></div>
    </section>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">To</div>
          <div class="subcopy">Copies the recipient list to your clipboard.</div>
        </div>
          <button class="btn" data-copy="#toField">Copy To</button>
      </div>
      <div class="copyfield singleline" id="toField">__TO__</div>
    </section>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">Cc</div>
          <div class="subcopy">Optional - copies Cc to your clipboard.</div>
        </div>
          <button class="btn" data-copy="#ccField">Copy Cc</button>
      </div>
      <div class="copyfield singleline" id="ccField">__CC__</div>
    </section>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">Bcc</div>
          <div class="subcopy">Optional - copies Bcc to your clipboard.</div>
        </div>
          <button class="btn" data-copy="#bccField">Copy Bcc</button>
      </div>
      <div class="copyfield singleline" id="bccField">__BCC__</div>
    </section>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">Subject</div>
          <div class="subcopy">Copies the subject line exactly as shown.</div>
        </div>
          <button class="btn" data-copy="#subjectField">Copy Subject</button>
      </div>
      <div class="copyfield singleline" id="subjectField">ConnectSecure Support Bundle | __MODE__ | __COMPANY__ | __TENANT__ | __TICKET__</div>
    </section>

    <section class="panel">
      <div class="label-row">
        <div>
          <div class="label">Body (HTML)</div>
          <div class="subcopy">Copies rich HTML for clients that support it.</div>
        </div>
          <button class="btn" data-copy-html="#bodyHtmlField">Copy HTML Body</button>
      </div>
      <div class="copyfield multiline" id="bodyHtmlField">
<p>Hello ConnectSecure Support,</p>
<p>Please find the attached <b>__MODE__</b> support bundle for:</p>
<ul>
  <li>Company: <b>__COMPANY__</b></li>
  <li>Tenant: <b>__TENANT__</b></li>
  <li>Ticket: <b>__TICKET__</b></li>
</ul>

<p><b>Included Manifest (snapshot)</b></p>
<details open>
  <summary>Bundle Manifest</summary>
  <pre class="manifest">__MANIFEST__</pre>
</details>

<p>Thanks,<br/>__SENDER__</p>
      </div>
      <div class="hint">Use this if your mail client supports HTML composition.</div>

      <div style="height:10px"></div>

      <div class="label-row">
        <div>
          <div class="label">Body (Plain Text)</div>
          <div class="subcopy">Copies a plain text version for all clients.</div>
        </div>
          <button class="btn" data-copy="#bodyTextField">Copy Text Body</button>
      </div>
      <div class="copyfield multiline" id="bodyTextField">Hello ConnectSecure Support,

Please find the attached __MODE__ support bundle for:
- Company: __COMPANY__
- Tenant: __TENANT__
- Ticket: __TICKET__

(See HTML body for embedded manifest snapshot.)

Thanks,
__SENDER__</div>
      <div class="hint">Tip: Paste with Ctrl+V (Windows) or Cmd+V (macOS).</div>
    </section>

    <div class="footer">&copy; <span id="year"></span> ConnectSecure. All rights reserved.</div>
  </div>

<script>
(function(){
  document.getElementById('year').textContent = new Date().getFullYear();
  const flash = (el)=>{ el.classList.add('flash'); setTimeout(()=>el.classList.remove('flash'), 650); };

  async function copyText(text, el){
    try{
      if(navigator.clipboard && navigator.clipboard.writeText){
        await navigator.clipboard.writeText(text); flash(el); return;
      }
    }catch(_){}
    const ta = document.createElement('textarea'); ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(ta); flash(el);
  }

  async function copyHtml(html, el){
    if(navigator.clipboard && navigator.clipboard.write){
      try{
        const type = "text/html";
        const blob = new Blob([html], {type});
        const item = new ClipboardItem({[type]: blob});
        await navigator.clipboard.write([item]); flash(el); return;
      }catch(_){}
    }
    const box = document.createElement('div');
    box.contentEditable = 'true';
    box.style.position='fixed'; box.style.left='-9999px';
    document.body.appendChild(box);
    box.innerHTML = html;
    const range = document.createRange();
    range.selectNodeContents(box);
    const sel = window.getSelection();
    sel.removeAllRanges(); sel.addRange(range);
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(box); flash(el);
  }

  document.querySelectorAll('[data-copy]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const target = document.querySelector(btn.getAttribute('data-copy'));
      const text = (target.innerText || target.textContent);
      copyText(text, target);
    });
  });
  document.querySelectorAll('[data-copy-html]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const target = document.querySelector(btn.getAttribute('data-copy-html'));
      const html = target.innerHTML;
      copyHtml(html, target);
    });
  });

  const ul = document.getElementById('attachments');
  if(ul && !ul.getAttribute('type')) ul.setAttribute('type','disc');
})();
</script>
</body>
</html>
'@

  $Html = $HtmlTemplate.
    Replace('__STAMP__',      $Stamp).
    Replace('__ATTACHMENTS__',$attachLis).
    Replace('__TO__',         $toEsc).
    Replace('__CC__',         $ccEsc).
    Replace('__BCC__',        $bccEsc).
    Replace('__COMPANY__',    $companyEsc).
    Replace('__TENANT__',     $tenantEsc).
    Replace('__TICKET__',     $ticketEsc).
    Replace('__SENDER__',     $senderEsc).
    Replace('__LOGOURL__',    $logoEsc).
    Replace('__MODE__',       $modeEsc).
    Replace('__OUTDIR__',     ($outEsc -replace '\\','/')).
    Replace('__MANIFEST__',   $manifestEncoded)

  $helperPath = Join-Path $OutDir ("Compose_Helper_{0}.html" -f $Stamp)
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($helperPath, $Html, $Utf8NoBom)
  Write-Ok "Wrote Compose Helper HTML: $helperPath"
  Start-Process $helperPath | Out-Null
}

# ------------------- Menu -------------------
$ErrorActionPreference = 'Stop'
Ensure-Folder -Path $OutDir

Write-Host ""
Write-Host "ConnectSecure Menu:" -ForegroundColor Cyan
Write-Host "  [S] Secure    - List -> Zip -> Encrypt -> Helper"
Write-Host "  [U] Unsecure  - List -> Zip -> Helper"
Write-Host "  [L] Learn - Information on Encryption"
Write-Host ""
$mode = Read-Host "Choose mode (S/U/L)"
$mode = ($mode.ToString().Trim().ToUpperInvariant())
if ($mode -notin @('S','U','L')) { Write-Err "Invalid choice. Use S, U, or L."; exit 1 }
# Learn (L): open HTML, then re-run the script and exit this run
if ($mode -eq 'L') {
    try {
        Write-Host "[INFO] Opening encryption info page (L)..." -ForegroundColor Cyan
        $htmlPath = 'C:\CS-TOOLBOX-TEMP\prod-01-01\DOC\connectsecure_encryption_info_final.html'
        if (Test-Path $htmlPath) { Start-Process $htmlPath } else { Write-Warning "HTML not found at $htmlPath" }
    } catch {
        Write-Warning ("Failed to open HTML: {0}" -f $_.Exception.Message)
    }
    Read-Host "Press Enter to return to the menu" | Out-Null
    & 'C:\CS-TOOLBOX-TEMP\prod-01-01\zip-encrypt-htmltemplate.ps1'
    exit
}
 $modeTag = if ($mode -eq 'S') { 'Secure' } elseif ($mode -eq 'U') { 'Unsecure' } else { 'Learn' }

Write-Host ""
Write-Host "Enter source roots. Press Enter to use defaults:" -ForegroundColor Yellow
$DefaultSources | ForEach-Object -Begin { $idx=1 } -Process { Write-Host ("  {0}) {1}" -f $idx, $_); $idx++ }
Write-Host "You can also paste a semicolon-, comma-, or 'and'-separated list."
$srcIn = Read-Host "Source paths"
[string[]]$srcPaths = Normalize-SourceInput $srcIn
if (-not $srcPaths) { $srcPaths = $DefaultSources }

# Expand all files across all sources (avoid including OutDir)
$items = Get-FilesFromSources -Sources $srcPaths
$items = $items | Where-Object { $_.FullName -notlike "$OutDir*" }

if ($items.Count -eq 0) { Write-Warn "No files found under the provided sources." }

# Write manifest regardless of mode
$Stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
$manifestPath = Join-Path $OutDir ("BundleManifest_{0}.txt" -f $Stamp)

$totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
if ($null -eq $totalBytes) { $totalBytes = 0 }
$header = ("{0} files, total {1}" -f $items.Count, (Get-SizeHuman ([long]$totalBytes)))
$header | Out-File -FilePath $manifestPath -Encoding UTF8

# Manifest lines: size, label\relpath, full path
foreach ($it in $items) {
  $sz = Get-SizeHuman $it.Length
  $dispPath = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
  ("{0}`t{1}\{2}`t{3}" -f $sz, $it.Label, $dispPath, $it.FullName) | Out-File -FilePath $manifestPath -Append -Encoding UTF8
}
Write-Ok "Manifest: $manifestPath"

$zipPath = $null
$p7mPath = $null

switch ($mode) {
  
  
  
  'L' {
    try {
        Write-Host "[INFO] Opening encryption info page (L)..." -ForegroundColor Cyan
        $htmlPath = 'C:\CS-TOOLBOX-TEMP\prod-01-01\DOC\connectsecure_encryption_info_final.html'
        if (Test-Path $htmlPath) { Start-Process $htmlPath } else { Write-Warning "HTML not found at $htmlPath" }
    } catch {
        Write-Warning ("Failed to open HTML: {0}" -f $_.Exception.Message)
    }
    Read-Host "Press Enter to return to the menu" | Out-Null
    & 'C:\CS-TOOLBOX-TEMP\prod-01-01\zip-encrypt-htmltemplate.ps1'
    exit
}



  'U' {
    if ($items.Count -eq 0) { Write-Warn "Nothing to zip." }
    else {
      $zipPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip" -f $Stamp)
      Write-Info "Building zip (unsecure): $zipPath"
      $zipItems = @([pscustomobject]@{
        Label    = '0_MANIFEST'
        RelPath  = (Split-Path -Leaf $manifestPath)
        FullName = $manifestPath
        Length   = (Get-Item $manifestPath).Length
      }) + $items
      New-ZipFromItems -Items $zipItems -ZipPath $zipPath
      Write-Ok "ZIP created"
    }
  }
  'S' {
    if ($items.Count -eq 0) { Write-Warn "Nothing to zip/encrypt." }
    else {
      $zipPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip" -f $Stamp)
      Write-Info "Building zip (secure path): $zipPath"
      $zipItems = @([pscustomobject]@{
        Label    = '0_MANIFEST'
        RelPath  = (Split-Path -Leaf $manifestPath)
        FullName = $manifestPath
        Length   = (Get-Item $manifestPath).Length
      }) + $items
      New-ZipFromItems -Items $zipItems -ZipPath $zipPath
      Write-Ok "ZIP created"

      if ([string]::IsNullOrWhiteSpace($CertUrl)) { throw "Secure mode requires CertUrl to be set." }
      $cert = Get-CertFromUrl -Url $CertUrl
      $p7mPath = Join-Path $OutDir ("CS-SupportBundle_{0}.p7m" -f $Stamp)
      Protect-CmsFile -InputPath $zipPath -Cert $cert -OutPath $p7mPath
      Write-Ok "Encrypted: $p7mPath"
    }
  }
}

# Build attachment objects for the helper
$attachments = @()
$attachments += [pscustomobject]@{
  Name      = (Split-Path -Leaf $manifestPath)
  SizeHuman = (Get-SizeHuman (Get-Item $manifestPath).Length)
}
if ($zipPath) {
  $fi = Get-Item -LiteralPath $zipPath
  $attachments += [pscustomobject]@{ Name = $fi.Name; SizeHuman = (Get-SizeHuman $fi.Length) }
}
if ($p7mPath) {
  $fi = Get-Item -LiteralPath $p7mPath
  $attachments += [pscustomobject]@{ Name = $fi.Name; SizeHuman = (Get-SizeHuman $fi.Length) }
}

# Compose helper with embedded manifest
Build-ComposeHelper -Attachments $attachments -Stamp $Stamp -LogoUrl $LogoUrl -OutDir $OutDir -ModeTag $modeTag -ManifestPath $manifestPath

Write-Ok "Done."
if ($zipPath) { Write-Info "ZIP: $zipPath" }
if ($p7mPath) { Write-Info "P7M: $p7mPath" }