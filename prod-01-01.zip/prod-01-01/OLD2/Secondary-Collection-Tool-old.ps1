﻿# =================================================================================================
# Secondary-Collection-Tool.ps1  (Fully Inlined)
# - No external function file required
# - Exports -> C:\CS-Toolbox-TEMP\Collected-Info\*
# - Menu: [1] Patch Audit, [2] VC++ Runtimes, [3] TLS/SSL Policy, [4] Uninstall Search
#         [5] Agent Log Review, [6] Dependency Validation, [7] User Profile App Sweep, [Q] Quit
# =================================================================================================
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

# -------------------------------------------------------------------------------------------------
# Helpers (fully inlined)
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    try {
        Write-Host ""
        Write-Host "Press any key to continue..." -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title = "Secondary Validation Tools")
    Clear-Host
    $isAdmin = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

function Launch-Tool {
    param(
        [Parameter(Mandatory)][string]$Target
    )
    try {
        if (-not (Test-Path -LiteralPath $Target)) {
            Write-Host "❌ Target not found: $Target" -ForegroundColor Red
            Pause-Script
            return
        }
        # Run in the same window/session:
        & $Target
    } catch {
        Write-Host "❌ Error launching $Target : $($_.Exception.Message)" -ForegroundColor Red
        Pause-Script
    }
}

function Return-ToLauncher {
    try {
        $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
        if (Test-Path -LiteralPath $launcher) {
            & $launcher
        } else {
            Write-Host "Launcher not found at $launcher. Exiting script..." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "Failed to return to launcher: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# -------------------------------------------------------------------------------------------------
# [1] Windows Patch Audit (WMI)
# -------------------------------------------------------------------------------------------------
function Run-WMIPatchAudit {
    param([switch]$PauseAfter)

    Show-Header "Windows Patch Audit (WMI)"
    Ensure-ExportFolder

    Write-Host "Querying installed updates via WMI/CIM (Win32_QuickFixEngineering)..." -ForegroundColor Cyan
    try {
        $qfes = Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop
    } catch {
        $qfes = Get-WmiObject -Class Win32_QuickFixEngineering -ErrorAction SilentlyContinue
    }

    $rows = $qfes | Sort-Object -Property InstalledOn -Descending | Select-Object `
        PSComputerName, Description, HotFixID, InstalledOn, InstalledBy, Caption

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $csv   = Join-Path $ExportPatch ("PatchAudit_WMI_{0}.csv" -f $stamp)
    $rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Host ""
    Write-Host ("Found {0} updates. CSV saved to:" -f ($rows | Measure-Object | Select-Object -ExpandProperty Count)) -ForegroundColor Green
    Write-Host "  $csv" -ForegroundColor Yellow

    if ($PauseAfter) { Pause-Script }
}

# -------------------------------------------------------------------------------------------------
# [2] VC++ Runtime Validation (Fully Inlined)
#  - Scans registry uninstall hives for Microsoft Visual C++ redistributables
#  - Exports structured CSV to Collected-Info
# -------------------------------------------------------------------------------------------------
function Run-VcppValidation {
    param([switch]$PauseAfter)

    Show-Header "VC++ Runtime Validation"
    Ensure-ExportFolder

    $hives = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    function Get-VcYearFromName {
        param([string]$name)
        if ($name -match '2005') { return '2005' }
        if ($name -match '2008') { return '2008' }
        if ($name -match '2010') { return '2010' }
        if ($name -match '2012') { return '2012' }
        if ($name -match '2013') { return '2013' }
        if ($name -match '2015|2017|2019|2022') { return '2015-2022' }
        return 'Unknown'
    }

    function Get-ArchFromName {
        param([string]$name)
        if ($name -match 'x64|64') { return 'x64' }
        if ($name -match 'x86|32') { return 'x86' }
        return 'Unknown'
    }

    $items = New-Object System.Collections.Generic.List[psobject]

    foreach ($root in $hives) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                $name = $p.DisplayName
                if ([string]::IsNullOrWhiteSpace($name)) { return }
                if ($name -notmatch 'Visual C\+\+|VC\+\+|Microsoft Visual C') { return }

                $ver  = $p.DisplayVersion
                $arch = Get-ArchFromName -name $name
                $year = Get-VcYearFromName -name $name

                $items.Add([pscustomobject]@{
                    DisplayName     = $name
                    DisplayVersion  = $ver
                    Architecture    = $arch
                    Year            = $year
                    Publisher       = $p.Publisher
                    InstallDate     = $p.InstallDate
                    UninstallString = $p.UninstallString
                    KeyName         = $_.PSChildName
                    RegistryHive    = $root
                })
            } catch { }
        }
    }

    $items = $items | Sort-Object Year, Architecture, DisplayVersion, DisplayName

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $csv   = Join-Path $ExportRoot ("VCpp-Runtime_Inventory_{0}.csv" -f $stamp)
    $items | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Host ""
    Write-Host ("VC++ runtimes found: {0}. CSV saved to:" -f $items.Count) -ForegroundColor Green
    Write-Host "  $csv" -ForegroundColor Yellow

    if ($PauseAfter) { Pause-Script }
}

# -------------------------------------------------------------------------------------------------
# [3] TLS/SSL Policy Audit (Local Host)
# -------------------------------------------------------------------------------------------------
function Run-TlsPolicyAudit {
    param([switch]$PauseAfter)

    Show-Header "TLS/SSL Policy Audit (Local Host)"
    Ensure-ExportFolder

    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
    $protoList = @('TLS 1.0','TLS 1.1','TLS 1.2','TLS 1.3')
    $sides = @('Client','Server')

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($p in $protoList) {
        foreach ($side in $sides) {
            $path = Join-Path (Join-Path $base $p) $side
            $enabled = $null
            $disabledByDefault = $null
            $exists = Test-Path $path

            if ($exists) {
                $props = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
                $enabled = $props.Enabled
                $disabledByDefault = $props.DisabledByDefault
            }

            $status =
                if ($exists -and $enabled -eq 0) { 'Disabled (Enabled=0)' }
                elseif ($exists -and $disabledByDefault -eq 1) { 'DisabledByDefault=1' }
                else { 'Default/Enabled' }

            $items.Add([pscustomobject]@{
                Protocol = $p
                Role     = $side
                Path     = $path
                Enabled  = $enabled
                DisabledByDefault = $disabledByDefault
                Status   = $status
            })
        }
    }

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $csv   = Join-Path $ExportTLS ("TLS-Policy_{0}.csv" -f $stamp)
    $items | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Host ""
    Write-Host "TLS/SSL protocol status written to:" -ForegroundColor Green
    Write-Host "  $csv" -ForegroundColor Yellow

    if ($PauseAfter) { Pause-Script }
}

# -------------------------------------------------------------------------------------------------
# [4] Search Registry Uninstall Strings
# -------------------------------------------------------------------------------------------------
function Invoke-RegistryUninstallSearch {
    Show-Header "Search Registry Uninstall Strings"

    $pattern = Read-Host "Enter search text (wildcards OK; plain text becomes *text*)"
    if ([string]::IsNullOrWhiteSpace($pattern)) {
        Write-Host "No input provided. Returning to menu..." -ForegroundColor Yellow
        Pause-Script
        return
    }
    if ($pattern -notlike '*?*' -and $pattern -notlike '*`**') {
        $pattern = "*$pattern*"
    }

    Ensure-ExportFolder

    $hives = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($hive in $hives) {
        if (-not (Test-Path $hive)) { continue }
        Get-ChildItem -Path $hive -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                $name      = $p.DisplayName
                $publisher = $p.Publisher
                $uninst    = $p.UninstallString
                if ($name -and $name -like $pattern -or ($publisher -and $publisher -like $pattern)) {
                    $rows.Add([pscustomobject]@{
                        Hive            = $hive
                        DisplayName     = $name
                        Publisher       = $publisher
                        DisplayVersion  = $p.DisplayVersion
                        InstallDate     = $p.InstallDate
                        UninstallString = $uninst
                        QuietUninstall  = $p.QuietUninstallString
                        KeyName         = $_.PSChildName
                    })
                }
            } catch { }
        }
    }

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    if ($rows.Count -gt 0) {
        $csv = Join-Path $ExportReg ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, ($pattern -replace '[^\w\*\-]','_'))
        $rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        Write-Host ""
        Write-Host ("Found {0} matching uninstall entries. CSV saved to:" -f $rows.Count) -ForegroundColor Green
        Write-Host "  $csv" -ForegroundColor Yellow
    } else {
        $json = Join-Path $ExportReg ("Registry-UninstallSearch_{0}_{1}.json" -f $stamp, ($pattern -replace '[^\w\*\-]','_'))
        @{"Pattern"=$pattern; "Found"=0; "Note"="No matches"} | ConvertTo-Json | Set-Content -Path $json -Encoding UTF8
        Write-Host ""
        Write-Host "No matches. Wrote note to:" -ForegroundColor Yellow
        Write-Host "  $json" -ForegroundColor Yellow
    }

    Pause-Script
}

# -------------------------------------------------------------------------------------------------
# MENU LOOP (fully inlined, balanced)
# -------------------------------------------------------------------------------------------------
do {
    Show-Header "Secondary Validation Tools"

    Write-Host " [1] Patch Audit (WMI)         - Installed updates" -ForegroundColor White
    Write-Host " [2] VC++ Runtimes             - Installed redistributables" -ForegroundColor White
    Write-Host " [3] TLS/SSL Policy            - Local registry policy check" -ForegroundColor White
    Write-Host " [4] Uninstall Search          - Registry uninstall entries" -ForegroundColor White
    Write-Host " [5] Agent Log Review          - Agent + Windows logs" -ForegroundColor White
    Write-Host " [6] Dependency Validation     - DepWalker + VC++ refs" -ForegroundColor White
    Write-Host " [7] User Profile App Sweep    - Per-user apps & uninstall" -ForegroundColor White
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""

    $choice = Read-Host "Enter your choice"

    switch -Regex ($choice) {
        '^(1)$' { Run-WMIPatchAudit -PauseAfter; continue }
        '^(2)$' { Run-VcppValidation -PauseAfter; continue }
        '^(3)$' { Run-TlsPolicyAudit -PauseAfter; continue }
        '^(4)$' { Invoke-RegistryUninstallSearch; continue }

        '^(5)$' {
            $scriptPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Log-Review.ps1'
            if (-not (Test-Path -LiteralPath $scriptPath)) {
                Write-Host "Agent-Log-Review script not found at $scriptPath" -ForegroundColor Yellow
                Pause-Script
                continue
            }
            Write-Host "Launching Agent Log Review..." -ForegroundColor Cyan
            try {
                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName = 'powershell.exe'
                $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`""
                $psi.UseShellExecute = $false
                $proc = [System.Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            } catch {
                Write-Host ("Failed to launch: {0}" -f $_.Exception.Message) -ForegroundColor Red
                Pause-Script
            }
            continue
        }
        '^(6)$' {
            $target = Join-Path $scriptRoot 'Dependency-Validation-Tools.ps1'
            Launch-Tool -Target $target
            continue
        }
        '^(7)$' {
            $target = Join-Path $scriptRoot 'Windows-UserProfile-AppSweep.ps1'
            Launch-Tool -Target $target
            continue
        }

        '^(q|Q)$' { Return-ToLauncher; break }
        default   { Write-Host "Invalid selection. Please choose 1-7 or Q." -ForegroundColor Yellow; Pause-Script }
    }
} while ($true)
