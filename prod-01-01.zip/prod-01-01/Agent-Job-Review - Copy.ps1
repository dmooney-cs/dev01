﻿<# =====================================================================
 Agent-Job-Review.ps1  (Menu + HTML Job Run Report with Quick Mode + Grouped Views)

 Key behavior:

 - Menu:
     1) Scan default log folder
     2) Choose another folder (GUI folder picker)
     Q) Quit

 - HTML report:
     • Job Summary - Individual Jobs
         - All jobs NOT in a grouping
         - Sorted by most recent warning/failure (Last Issue), newest first
     • Job Summary - Group Jobs
         - ProcessPendingRecords grouped by AssetId
         - task FULLSCAN jobs (single grouped row)
         - adscan VerifyCreds grouped by IP
       Jobs in any grouping are omitted from the Individual Jobs summary.
       Each group table is sorted by most recent warn/fail (Last Issue).

 - For each job:
     • Only:
         - Last successful run (if present)
         - All warning/failure runs
           - Only the most recent failure has full log output;
             older failures are summarized with details omitted.
       Extra successes are counted but not shown.

 - Special handling:
     • These are treated as informational (ignored in failure detection):
       "CyberCNSAgent service failed: An instance of the service is already running."
       "Error in opening eventlog The RPC server is unavailable.  Continuing without event log"

 - Quick Mode for large logs (> 3 MB):
     • Only last ~3 MB of lines analyzed, banner in HTML explaining this.
     • Console offers a full-dataset re-run after quick report (interactive only).

 - Output filename (if not specified):
     • Default path: C:\CS-Toolbox-TEMP\Collected-Info\Agent-Jobs
     • Single log:  Job-Analysis-<agentid>-<date>-<time>.html
     • -AllLogs:    Job-Analysis-<LogFileName>-<date>-<time>.html

 - Switches:
     • -AllLogs          → process all *.log in folder (default agent log folder if none given)
     • -NoOpen / -NoPopup → don’t launch browser
     • -Silent           → suppress console/menu/progress output; implies NoOpen

===================================================================== #>

#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$LogPath,
    [string]$OutputHtml,

    # -NoOpen is the real switch; -NoPopup is an alias for compatibility
    [Alias('NoPopup')]
    [switch]$NoOpen,

    # Process ALL *.log files in a folder non-interactively
    [switch]$AllLogs,

    # Suppress all console/menu/progress chatter; implies NoOpen
    [switch]$Silent
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms | Out-Null

# ---------------- Standard paths ----------------
$script:Silent = $Silent

$DefaultLogFolder = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$DefaultLogFile   = Join-Path $DefaultLogFolder 'cybercns.log'

$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPath = Join-Path $ExportRoot 'Agent-Jobs'

# Ensure export root exists when we’ll be writing anything
if (-not (Test-Path -LiteralPath $ExportPath)) {
    New-Item -ItemType Directory -Path $ExportPath -Force | Out-Null
}

# ---------------- Silent-aware wrappers ----------------
function Write-HostSafe {
    param([string]$Message)
    if (-not $script:Silent) { Write-Host $Message }
}
function Write-WarningSafe {
    param([string]$Message)
    if (-not $script:Silent) { Write-Warning $Message }
}
function Write-ProgressSafe {
    param(
        [string]$Activity,
        [string]$Status,
        [int]$PercentComplete
    )
    if (-not $script:Silent) {
        Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete
    }
}

# ---------------- Helpers ----------------

function Html-Encode {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    [System.Net.WebUtility]::HtmlEncode($Text)
}

function New-JobAnchorId {
    param([Parameter(Mandatory)][string]$JobName)
    $slug = ($JobName -replace '[^a-zA-Z0-9]+','-').ToLower().Trim('-')
    if (-not $slug) { $slug = 'job' }
    "job-$slug"
}

function Get-CountSafe {
    param($Value)
    if ($null -eq $Value) { return 0 }
    if ($Value -is [System.Array] -or $Value -is [System.Collections.ICollection]) {
        return $Value.Count
    }
    1
}

function Highlight-StatusText {
    param([string]$HtmlLine)
    if ([string]::IsNullOrEmpty($HtmlLine)) { return $HtmlLine }

    $HtmlLine = [regex]::Replace(
        $HtmlLine,
        '(?i)\b(error|failed|failure|exception|panic)\b',
        { '<span class="hl-failure">' + $args[0].Value + '</span>' }
    )

    $HtmlLine = [regex]::Replace(
        $HtmlLine,
        '(?i)\bwarn(ing)?\b',
        { '<span class="hl-warning">' + $args[0].Value + '</span>' }
    )

    $HtmlLine
}

function Get-TrimmedLinesForRun {
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Lines,
        [int]$MaxLines
    )

    if ($null -eq $Lines) { return @() }

    $arr   = @($Lines)
    $total = Get-CountSafe $arr
    if ($total -eq 0 -or $total -le $MaxLines -or $MaxLines -le 0) {
        return $arr
    }

    $headCount = [int]([math]::Round($MaxLines * 0.7))
    if ($headCount -lt 1) { $headCount = 1 }
    if ($headCount -gt ($MaxLines - 1)) { $headCount = $MaxLines - 1 }
    $tailCount = $MaxLines - $headCount
    if ($tailCount -lt 1) { $tailCount = 1 }

    $trimmed = New-Object 'System.Collections.Generic.List[string]'
    for ($i = 0; $i -lt $headCount; $i++) {
        $trimmed.Add([string]$arr[$i])
    }

    $removed = $total - ($headCount + $tailCount)
    if ($removed -lt 0) { $removed = 0 }

    $trimmed.Add((
        "----- OUTPUT TRIMMED: showing first {0} lines and last {1} of {2} total lines -----" -f `
            $headCount, $tailCount, $total
    ))

    for ($i = $total - $tailCount; $i -lt $total; $i++) {
        $trimmed.Add([string]$arr[$i])
    }

    $trimmed
}

function Parse-PPJobName {
    param([string]$JobName)

    $assetId = $null
    $suffix  = $null

    if ($JobName -match '^ProcessPendingRecords with assetid:\s*(?<assetid>\S+)\s+and\s+(?<suffix>.+)$') {
        $assetId = $matches['assetid']
        $suffix  = $matches['suffix']
    }

    [PSCustomObject]@{
        AssetId = $assetId
        Suffix  = $suffix
    }
}

function Parse-FullScanJobName {
    param([string]$JobName)

    $jobId = $null
    if ($JobName -match '^task FULLSCAN with jobId\s+(?<jobid>[0-9a-fA-F-]+)$') {
        $jobId = $matches['jobid']
    }

    [PSCustomObject]@{
        JobId = $jobId
    }
}

function Parse-AdScanJobName {
    param([string]$JobName)

    $ip     = $null
    $verify = $null

    if ($JobName -match '^adscan for :\s*(?<ip>\S+)\s+inputParams\.VerifyCreds\s+(?<verify>\S+)$') {
        $ip     = $matches['ip']
        $verify = $matches['verify']
    }

    [PSCustomObject]@{
        Ip          = $ip
        VerifyCreds = $verify
    }
}

function Format-TimeSpanShort {
    param([TimeSpan]$Span)
    if (-not $Span) { return '' }

    $parts = @()
    if ($Span.Days -ne 0)    { $parts += ("{0}d" -f $Span.Days) }
    if ($Span.Hours -ne 0)   { $parts += ("{0}h" -f $Span.Hours) }
    if ($Span.Minutes -ne 0) { $parts += ("{0}m" -f $Span.Minutes) }
    if ($Span.Seconds -ne 0 -and (Get-CountSafe $parts) -lt 2) { $parts += ("{0}s" -f $Span.Seconds) }

    if ((Get-CountSafe $parts) -eq 0) { '0s' } else { $parts -join ' ' }
}

# Find the first "issue" line (Error/Failure/Exception/Panic or Warning) in a set of lines,
# skipping known benign messages. Returns PSCustomObject { Index; Line } or $null.
function Find-PrimaryIssueLine {
    param(
        [Parameter(Mandatory)][string[]]$Lines
    )

    for ($i = 0; $i -lt $Lines.Count; $i++) {
        $line = $Lines[$i]

        if ($line -match 'CyberCNSAgent service failed: An instance of the service is already running\.') {
            continue
        }
        if ($line -match 'Error in opening eventlog The RPC server is unavailable\.  Continuing without event log') {
            continue
        }

        if ($line -match '(?i)\b(error|failed|failure|exception|panic)\b' -or
            $line -match '(?i)\bwarn(ing)?\b') {
            return [PSCustomObject]@{
                Index = $i
                Line  = $line
            }
        }
    }

    return $null
}

# ---------------- Menu & log selection ----------------

function Select-LogFile {
    while ($true) {
        Clear-Host
        Write-Host "============================================================"
        Write-Host "  Agent Job Review"
        Write-Host "============================================================"
        Write-Host "  1) Scan default log folder"
        Write-Host "     ($DefaultLogFolder)"
        Write-Host ""
        Write-Host "  2) Choose another folder (GUI folder picker)"
        Write-Host ""
        Write-Host "  Q) Quit"
        Write-Host "============================================================"
        $choice = Read-Host "Select an option (1/2/Q)"

        $folder = $null

        switch ($choice.ToUpper()) {
            '1' {
                $defaultFolder = $DefaultLogFolder
                if (-not (Test-Path -LiteralPath $defaultFolder)) {
                    Write-Warning "Default folder not found: $defaultFolder"
                    Read-Host "Press Enter to return to the menu..."
                    continue
                }
                $folder = $defaultFolder
            }
            '2' {
                $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
                $dialog.Description = "Select folder containing log files"
                $dialog.ShowNewFolderButton = $false

                $result = $dialog.ShowDialog()
                if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
                    Write-Host "No folder selected. Returning to menu..."
                    Start-Sleep -Seconds 1
                    continue
                }
                $folder = $dialog.SelectedPath
            }
            'Q' { return $null }
            default {
                Write-Host "Invalid selection. Please enter 1, 2, or Q." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
                continue
            }
        }

        $logs = @(Get-ChildItem -LiteralPath $folder -Filter '*.log' -File -ErrorAction SilentlyContinue |
                  Sort-Object Name)

        if (-not $logs -or (Get-CountSafe $logs) -eq 0) {
            Write-Warning "No .log files found in: $folder"
            Read-Host "Press Enter to return to the menu..."
            continue
        }

        Clear-Host
        Write-Host "============================================================"
        Write-Host "  Log files in: $folder"
        Write-Host "============================================================"
        $index = 1
        foreach ($log in $logs) {
            Write-Host ("  {0}) {1}" -f $index, $log.Name)
            $index++
        }
        Write-Host "============================================================"
        $sel = Read-Host "Select a log file by number (or Q to cancel)"

        if ($sel.ToUpper() -eq 'Q') { continue }

        [int]$selIndex = 0
        if (-not [int]::TryParse($sel, [ref]$selIndex)) {
            Write-Host "Invalid selection. Must be a number or Q." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            continue
        }

        $logCount = Get-CountSafe $logs
        if ($selIndex -lt 1 -or $selIndex -gt $logCount) {
            Write-Host "Selection out of range." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            continue
        }

        return $logs[$selIndex - 1].FullName
    }
}

# ---------------- Core parsing functions ----------------

function Parse-LogLine {
    param(
        [string]$Line,
        [int]$Index
    )

    $pattern = '^(?<ts>\d{4}/\d{2}\/\d{2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+\[(?<msg>.*)\]\s*$'

    $time     = $null
    $rawTime  = $null
    $message  = $Line.Trim()
    if ($Line -match $pattern) {
        $rawTime = $matches['ts']
        try {
            $time = [datetime]::ParseExact($rawTime, 'yyyy/MM/dd HH:mm:ss', $null)
        } catch { $time = $null }
        $message = $matches['msg'].Trim()
    }

    [PSCustomObject]@{
        Index   = $Index
        Time    = $time
        RawTime = $rawTime
        Message = $message
        RawLine = $Line
    }
}

function Get-JobBoundary {
    param($Entry)

    $msg = $Entry.Message
    $startJob = $null
    $endJob   = $null

    if ($msg -match '^(?<job>.+?)\s+(Scan\s+)?Started$') {
        $startJob = $matches['job']
    }
    elseif ($msg -match '^Starting\s+(?<job>.+)$') {
        $startJob = $matches['job']
    }

    if ($msg -match '^(?<job>.+?)\s+(Scan\s+)?Completed$') {
        $endJob = $matches['job']
    }
    elseif ($msg -imatch '^(?<job>.+?)\s+completed\b') {
        $endJob = $matches['job']
    }

    [PSCustomObject]@{
        StartJobName = $startJob
        EndJobName   = $endJob
    }
}

# Updated classification with benign messages stripped first
function Classify-RunStatus {
    param([string]$Text)

    if ($null -eq $Text) { return 'Success' }

    $cleanText = $Text

    # Ignore benign "already running" service failure
    $cleanText = $cleanText -replace 'CyberCNSAgent service failed: An instance of the service is already running\.', ''

    # Ignore benign RPC/eventlog message
    $cleanText = $cleanText -replace 'Error in opening eventlog The RPC server is unavailable\.  Continuing without event log', ''

    if ($cleanText -match '(?i)\b(error|failed|failure|exception|panic)\b') {
        'Failure'
    }
    elseif ($cleanText -match '(?i)\bwarn(ing)?\b') {
        'Warning'
    }
    else {
        'Success'
    }
}

# ---------------- Main analyzer ----------------

function Analyze-LogFile {
    param(
        [Parameter(Mandatory)][string]$LogPath,
        [string]$OutputHtml,
        [switch]$NoOpen,
        [switch]$FullDataset
    )

    Write-HostSafe ""
    Write-HostSafe "------------------------------------------------------------"
    Write-HostSafe "  Analyze-LogFile starting..."
    Write-HostSafe "------------------------------------------------------------"

    if (-not (Test-Path -LiteralPath $LogPath)) {
        Write-Error "Log file not found: $LogPath"
        return
    }

    $logDir      = Split-Path -Parent $LogPath
    $agentId     = Split-Path -Leaf $logDir
    $agentIdSafe = ($agentId -replace '[^a-zA-Z0-9\-]+','-').Trim('-')
    if (-not $agentIdSafe) { $agentIdSafe = 'Agent' }

    $nowForName = Get-Date
    $runDate    = $nowForName.ToString('yyyyMMdd')
    $runTime    = $nowForName.ToString('HHmmss')

    if (-not $OutputHtml) {
        # Default to standard Collected-Info path
        $baseName   = "Job-Analysis-{0}-{1}-{2}.html" -f $agentIdSafe, $runDate, $runTime
        $OutputHtml = Join-Path $ExportPath $baseName
    }

    $fileInfo   = Get-Item -LiteralPath $LogPath
    $fileSizeMB = [math]::Round($fileInfo.Length / 1MB, 2)

    Write-HostSafe ("[INFO] Log: {0}" -f $LogPath)
    Write-HostSafe ("[INFO] AgentId (from folder): {0}" -f $agentIdSafe)
    Write-HostSafe ("[INFO] File size: {0} MB" -f $fileSizeMB)
    Write-HostSafe ("[INFO] Output HTML: {0}" -f $OutputHtml)

    # ---------- Quick-mode selection ----------
    Write-HostSafe ""
    Write-HostSafe "[PHASE 0] Reading all lines (for quick-mode decision)..."
    $allLines   = @(Get-Content -LiteralPath $LogPath)
    $totalLines = Get-CountSafe $allLines
    Write-HostSafe ("[PHASE 0] Total lines in file: {0}" -f $totalLines)

    $usingQuick     = $false
    $linesUsed      = $totalLines
    $percentOfLines = 100.0
    $rawLines       = $null

    if (-not $FullDataset -and $fileSizeMB -gt 3.0 -and $totalLines -gt 0) {
        $fraction = 3.0 / $fileSizeMB
        if ($fraction -gt 1.0) { $fraction = 1.0 }
        $linesUsed = [int]([math]::Ceiling($totalLines * $fraction))
        if ($linesUsed -lt 1) { $linesUsed = 1 }

        if ($linesUsed -lt $totalLines) {
            $usingQuick     = $true
            $startIndex     = $totalLines - $linesUsed
            $percentOfLines = [math]::Round(100.0 * $linesUsed / $totalLines, 1)

            Write-HostSafe ("[PHASE 0] Quick mode: using last {0} lines (~{1}% of file, ~3 MB of data)" -f $linesUsed, $percentOfLines)

            $rawLines = $allLines[$startIndex..($totalLines - 1)]
        }
        else {
            Write-HostSafe "[PHASE 0] File just over threshold; using all lines."
            $rawLines = $allLines
        }
    }
    else {
        Write-HostSafe "[PHASE 0] Not in quick mode (file <= 3MB or FullDataset requested)."
        $rawLines = $allLines
    }

    $allLines = $null

    $selectedTotal = Get-CountSafe $rawLines
    Write-HostSafe ("[PHASE 0] Lines selected for analysis: {0}" -f $selectedTotal)

    # ---------- Build runs ----------
    Write-HostSafe ""
    Write-HostSafe "[PHASE 1] Parsing lines and building job runs..."
    $openJobs = @{}    # jobName -> current run
    $jobRuns  = @{}    # jobName -> List[run]

    for ($i = 0; $i -lt $selectedTotal; $i++) {
        if ($selectedTotal -gt 0 -and ($i % 2000 -eq 0)) {
            $pct = [int](($i * 100.0) / $selectedTotal)
            Write-ProgressSafe -Activity "Phase 1: Parsing & building runs" -Status "$pct% ($i of $selectedTotal lines)" -PercentComplete $pct
        }
        if ($i -gt 0 -and ($i % 5000 -eq 0)) {
            Write-HostSafe ("[PHASE 1] Parsed {0}/{1} lines..." -f $i, $selectedTotal)
        }

        $line  = $rawLines[$i]
        $entry = Parse-LogLine -Line $line -Index $i
        $boundary = Get-JobBoundary -Entry $entry

        foreach ($run in $openJobs.Values) {
            $run.Lines.Add($entry.RawLine)
        }

        if ($boundary.StartJobName) {
            $jobName = $boundary.StartJobName.Trim()

            if (-not $jobRuns.ContainsKey($jobName)) {
                $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]'
            }

            $run = [PSCustomObject]@{
                JobName   = $jobName
                StartTime = $entry.Time
                EndTime   = $null
                Lines     = New-Object 'System.Collections.Generic.List[string]'
                Status    = $null
                Duration  = $null
            }

            $run.Lines.Add($entry.RawLine)

            if ($openJobs.ContainsKey($jobName)) {
                $jobRuns[$jobName].Add($openJobs[$jobName])
            }

            $openJobs[$jobName] = $run
        }

        if ($boundary.EndJobName) {
            $jobName = $boundary.EndJobName.Trim()

            if ($openJobs.ContainsKey($jobName)) {
                $run = $openJobs[$jobName]
                $run.EndTime = $entry.Time
                $jobRuns[$jobName].Add($run)
                $null = $openJobs.Remove($jobName)
            }
            else {
                if (-not $jobRuns.ContainsKey($jobName)) {
                    $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]'
                }

                $run = [PSCustomObject]@{
                    JobName   = $jobName
                    StartTime = $entry.Time
                    EndTime   = $entry.Time
                    Lines     = (New-Object 'System.Collections.Generic.List[string]')
                    Status    = $null
                    Duration  = $null
                }
                $run.Lines.Add($entry.RawLine)
                $jobRuns[$jobName].Add($run)
            }
        }
    }

    Write-ProgressSafe -Activity "Phase 1: Parsing & building runs" -Status "Done" -PercentComplete 100
    Write-HostSafe ("[PHASE 1] Completed parsing {0} lines." -f $selectedTotal)

    if ($openJobs.Count -gt 0) {
        Write-HostSafe ("[PHASE 1] Closing {0} open job(s) at end of file..." -f $openJobs.Count)
    }
    foreach ($kvp in $openJobs.GetEnumerator()) {
        $jobName = $kvp.Key
        $run     = $kvp.Value
        if (-not $jobRuns.ContainsKey($jobName)) {
            $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]'
        }
        $jobRuns[$jobName].Add($run)
    }

    $rawLines = $null

    $jobCount = $jobRuns.Keys.Count
    Write-HostSafe ("[PHASE 1] Total distinct jobs detected: {0}" -f $jobCount)

    # ---------- Summaries ----------
    Write-HostSafe ""
    Write-HostSafe "[PHASE 2] Building per-job summaries (counts, intervals, last run)..."
    $jobSummaries = @()
    $jobIndex = 0

    foreach ($jobName in $jobRuns.Keys | Sort-Object) {
        $jobIndex++
        $runs = @($jobRuns[$jobName] | Sort-Object StartTime)

        foreach ($run in $runs) {
            $text = ($run.Lines -join "`n")
            $run.Status = Classify-RunStatus -Text $text
            if ($run.StartTime -and $run.EndTime) {
                $run.Duration = $run.EndTime - $run.StartTime
            }
        }

        $totalRuns   = Get-CountSafe $runs
        $successRuns = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Success' }))
        $warningRuns = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Warning' }))
        $failedRuns  = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Failure' }))

        if ($jobIndex % 25 -eq 0 -or $jobIndex -eq 1 -or $jobIndex -eq $jobCount) {
            Write-HostSafe ("[PHASE 2] Job {0}/{1}: {2} (Total runs: {3})" -f $jobIndex, $jobCount, $jobName, $totalRuns)
        }

        $runsWithTime = @($runs | Where-Object { $_.StartTime } | Sort-Object StartTime)
        $intervalsMinutes = @()
        for ($i = 1; $i -lt (Get-CountSafe $runsWithTime); $i++) {
            $delta = $runsWithTime[$i].StartTime - $runsWithTime[$i - 1].StartTime
            if ($delta.TotalMinutes -gt 0) {
                $intervalsMinutes += $delta.TotalMinutes
            }
        }

        $avgInterval     = $null
        $predictedNext   = $null
        $avgIntervalText = 'N/A'
        $nextRunText     = 'N/A'

        if ((Get-CountSafe $intervalsMinutes) -gt 0) {
            $avgMinutes      = ($intervalsMinutes | Measure-Object -Average).Average
            $avgInterval     = [TimeSpan]::FromMinutes($avgMinutes)
            $avgIntervalText = Format-TimeSpanShort -Span $avgInterval

            if ((Get-CountSafe $runsWithTime) -gt 0) {
                $lastStart     = $runsWithTime[(Get-CountSafe $runsWithTime) - 1].StartTime
                $predictedNext = $lastStart + $avgInterval
                $nextRunText   = $predictedNext.ToString('yyyy-MM-dd HH:mm:ss')
            }
        }

        $lastRun = $runs | Sort-Object StartTime -Descending | Select-Object -First 1

        $jobSummaries += [PSCustomObject]@{
            JobName            = $jobName
            TotalRuns          = $totalRuns
            SuccessCount       = $successRuns
            WarningCount       = $warningRuns
            FailureCount       = $failedRuns
            AvgInterval        = $avgInterval
            AvgIntervalText    = $avgIntervalText
            PredictedNextRun   = $predictedNext
            PredictedNextText  = $nextRunText
            LastRun            = $lastRun
            Runs               = $runs
        }
    }

    Write-HostSafe "[PHASE 2] Completed job summaries."

    # Default IsGrouped flag
    foreach ($job in $jobSummaries) {
        if (-not $job.PSObject.Properties['IsGrouped']) {
            $job | Add-Member -NotePropertyName IsGrouped -NotePropertyValue $false -Force
        }
    }

    # ---------- Mark grouped jobs ----------
    # 1) ProcessPendingRecords with assetid: <id> and <suffix> (group by AssetId)
    $ppJobs = @($jobSummaries | Where-Object { $_.JobName -like 'ProcessPendingRecords with assetid:*' })

    foreach ($job in $ppJobs) {
        $parsed = Parse-PPJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['AssetId']) {
            $job | Add-Member -NotePropertyName AssetId -NotePropertyValue $parsed.AssetId -Force
        } else { $job.AssetId = $parsed.AssetId }

        if (-not $job.PSObject.Properties['PPTypeSuffix']) {
            $job | Add-Member -NotePropertyName PPTypeSuffix -NotePropertyValue $parsed.Suffix -Force
        } else { $job.PPTypeSuffix = $parsed.Suffix }

        $job.IsGrouped = $true
    }

    $ppGroups = @(
        $ppJobs |
        Where-Object { $_.AssetId -and $_.AssetId -ne '' } |
        Group-Object -Property AssetId
    )

    # 2) task FULLSCAN with jobId <guid> (single group)
    $fsJobs = @($jobSummaries | Where-Object { $_.JobName -like 'task FULLSCAN with jobId*' })

    foreach ($job in $fsJobs) {
        $parsed = Parse-FullScanJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['FullScanJobId']) {
            $job | Add-Member -NotePropertyName FullScanJobId -NotePropertyValue $parsed.JobId -Force
        } else { $job.FullScanJobId = $parsed.JobId }
        $job.IsGrouped = $true
    }

    # 3) adscan for : <ip> inputParams.VerifyCreds <true|false> (group by IP)
    $adsJobs = @($jobSummaries | Where-Object { $_.JobName -like 'adscan for :*inputParams.VerifyCreds*' })

    foreach ($job in $adsJobs) {
        $parsed = Parse-AdScanJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['AdIp']) {
            $job | Add-Member -NotePropertyName AdIp -NotePropertyValue $parsed.Ip -Force
        } else { $job.AdIp = $parsed.Ip }

        if (-not $job.PSObject.Properties['AdVerifyCreds']) {
            $job | Add-Member -NotePropertyName AdVerifyCreds -NotePropertyValue $parsed.VerifyCreds -Force
        } else { $job.AdVerifyCreds = $parsed.VerifyCreds }

        $job.IsGrouped = $true
    }

    $adGroups = @(
        $adsJobs |
        Where-Object { $_.AdIp -and $_.AdIp -ne '' } |
        Group-Object -Property AdIp
    )

    # ---------- Select runs to include & anchors ----------
    Write-HostSafe ""
    Write-HostSafe "[PHASE 3] Selecting runs to include (last success + all warnings/failures) and assigning anchors..."
    foreach ($job in $jobSummaries) {
        $allRuns = @($job.Runs | Sort-Object StartTime)

        $successDesc     = @($allRuns | Where-Object { $_.Status -eq 'Success' } | Sort-Object StartTime -Descending)
        $successIncluded = @($successDesc | Select-Object -First 1)
        $wfRuns          = @($allRuns | Where-Object { $_.Status -ne 'Success' })

        $includedRuns   = @($successIncluded + $wfRuns | Sort-Object StartTime)
        $hiddenCount    = (Get-CountSafe $successDesc) - (Get-CountSafe $successIncluded)
        if ($hiddenCount -lt 0) { $hiddenCount = 0 }

        $jobAnchorBase = New-JobAnchorId -JobName $job.JobName

        $idx = 0
        foreach ($run in $includedRuns) {
            $anchorId = "{0}-run-{1}" -f $jobAnchorBase, $idx
            if ($run.PSObject.Properties['AnchorId']) {
                $run.AnchorId = $anchorId
            } else {
                $run | Add-Member -NotePropertyName AnchorId -NotePropertyValue $anchorId -Force
            }
            $idx++
        }

        $failureCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Failure' } | Sort-Object StartTime -Descending)
        $warningCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Warning' } | Sort-Object StartTime -Descending)
        $successCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Success' } | Sort-Object StartTime -Descending)

        $failureHref = if ((Get-CountSafe $failureCandidates) -gt 0) { "#$($failureCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }
        $warningHref = if ((Get-CountSafe $warningCandidates) -gt 0) { "#$($warningCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }
        $successHref = if ((Get-CountSafe $successCandidates) -gt 0) { "#$($successCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }

        $lastRun = $job.LastRun
        $lastHref = "#$jobAnchorBase"
        if ($null -ne $lastRun -and ($includedRuns -contains $lastRun)) {
            if (-not $lastRun.PSObject.Properties['AnchorId']) {
                $lastRun | Add-Member -NotePropertyName AnchorId -NotePropertyValue ("{0}-run-last" -f $jobAnchorBase) -Force
            }
            $lastHref = "#$($lastRun.AnchorId)"
        }

        # ---- compute last issue (warning OR failure) and anchor ----
        $issueRuns = @($includedRuns | Where-Object { $_.Status -ne 'Success' -and $_.StartTime })
        $lastIssueTime = $null
        $lastIssueText = 'N/A'
        $issueHref     = "#$jobAnchorBase"

        if ((Get-CountSafe $issueRuns) -gt 0) {
            $latestIssue = $issueRuns | Sort-Object StartTime -Descending | Select-Object -First 1
            $lastIssueTime = $latestIssue.StartTime
            $lastIssueText = $lastIssueTime.ToString('yyyy-MM-dd HH:mm:ss')
            if ($latestIssue.PSObject.Properties['AnchorId']) {
                $issueHref = "#$($latestIssue.AnchorId)"
            }
        }

        $job | Add-Member -NotePropertyName IncludedRuns       -NotePropertyValue $includedRuns -Force
        $job | Add-Member -NotePropertyName HiddenSuccessCount -NotePropertyValue $hiddenCount -Force
        $job | Add-Member -NotePropertyName JobAnchorHref      -NotePropertyValue ("#$jobAnchorBase") -Force
        $job | Add-Member -NotePropertyName FailureAnchorHref  -NotePropertyValue $failureHref -Force
        $job | Add-Member -NotePropertyName WarningAnchorHref  -NotePropertyValue $warningHref -Force
        $job | Add-Member -NotePropertyName SuccessAnchorHref  -NotePropertyValue $successHref -Force
        $job | Add-Member -NotePropertyName LastRunAnchorHref  -NotePropertyValue $lastHref -Force

        if (-not $job.PSObject.Properties['LastIssueTime']) {
            $job | Add-Member -NotePropertyName LastIssueTime -NotePropertyValue $lastIssueTime -Force
        } else { $job.LastIssueTime = $lastIssueTime }

        if (-not $job.PSObject.Properties['LastIssueText']) {
            $job | Add-Member -NotePropertyName LastIssueText -NotePropertyValue $lastIssueText -Force
        } else { $job.LastIssueText = $lastIssueText }

        if (-not $job.PSObject.Properties['IssueAnchorHref']) {
            $job | Add-Member -NotePropertyName IssueAnchorHref -NotePropertyValue $issueHref -Force
        } else { $job.IssueAnchorHref = $issueHref }
    }
    Write-HostSafe "[PHASE 3] Anchor assignment completed."

    # ---------------- Build HTML ----------------
    Write-HostSafe ""
    Write-HostSafe "[PHASE 4] Building HTML report..."

    $now = Get-Date

    $htmlFolder = Split-Path -Parent $OutputHtml
    if (-not $htmlFolder) { $htmlFolder = (Get-Location).Path }

    # Hard-coded logo URL (top center)
    $logoUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'

    Write-HostSafe "[PHASE 4.1] Building HTML header and CSS..."

    $css = @'
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  margin: 20px;
  background-color: #0f172a;
  color: #e5e7eb;
}
h1, h2, h3 {
  color: #38bdf8;
}
.logo-wrap {
  margin-bottom: 10px;
  text-align: center;
}
.logo {
  max-height: 60px;
  display: inline-block;
}
table {
  border-collapse: collapse;
  width: 100%;
  margin-bottom: 1.5rem;
}
th, td {
  border: 1px solid #334155;
  padding: 6px 10px;
  text-align: left;
  font-size: 13px;
}
th {
  background-color: #1e293b;
}
tr:nth-child(even) td {
  background-color: #020617;
}
.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
}
.badge-success {
  background-color: #022c22;
  color: #4ade80;
}
.badge-warning {
  background-color: #451a03;
  color: #fbbf24;
}
.badge-failure {
  background-color: #450a0a;
  color: #f87171;
}
pre {
  background-color: #020617;
  padding: 10px;
  border-radius: 6px;
  overflow-x: auto;
  font-size: 12px;
}
details {
  margin-bottom: 8px;
}
details > summary {
  cursor: pointer;
  padding: 4px 8px;
  background-color: #020617;
  border-radius: 4px;
  font-size: 13px;
}
summary::-webkit-details-marker {
  display: none;
}
.summary-row {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  font-size: 13px;
}
.summary-row span {
  white-space: nowrap;
}
.small {
  font-size: 11px;
  color: #9ca3af;
}
code {
  background-color: #020617;
  padding: 2px 4px;
  border-radius: 4px;
}
a {
  color: #38bdf8;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
.quick-banner {
  margin: 8px 0 16px 0;
  padding: 8px 12px;
  border-radius: 6px;
  background-color: #451a03;
  color: #fde68a;
  font-size: 12px;
}
.hl-failure {
  background-color: #7f1d1d;
  color: #fee2e2;
  font-weight: 600;
}
.hl-warning {
  background-color: #854d0e;
  color: #fef3c7;
  font-weight: 600;
}
@media (prefers-color-scheme: light) {
  body { background-color: #ffffff; color: #111827; }
  th { background-color: #f9fafb; }
  tr:nth-child(even) td { background-color: #f9fafb; }
  pre { background-color: #111827; color: #e5e7eb; }
  details > summary { background-color: #f3f4f6; }
  code { background-color: #f3f4f6; }
  .quick-banner {
    background-color: #f97316;
    color: #111827;
  }
  .hl-failure {
    background-color: #fecaca;
    color: #7f1d1d;
  }
  .hl-warning {
    background-color: #fef3c7;
    color: #854d0e;
  }
}
'@

    $html = New-Object System.Text.StringBuilder

    $null = $html.AppendLine('<!DOCTYPE html>')
    $null = $html.AppendLine('<html><head><meta charset="utf-8" />')
    $null = $html.AppendLine('<title>Agent Job Analysis Report</title>')
    $null = $html.AppendLine('<style>')
    $null = $html.AppendLine($css)
    $null = $html.AppendLine('</style>')
    $null = $html.AppendLine('<script>')
    $null = $html.AppendLine('function collapseAllDetails(){var ds=document.querySelectorAll("details[open]");for(var i=0;i<ds.length;i++){ds[i].removeAttribute("open");}}')
    $null = $html.AppendLine('</script>')
    $null = $html.AppendLine('</head><body>')

    if ($logoUrl) {
        $null = $html.AppendLine("<div class=""logo-wrap""><img src=""$logoUrl"" alt=""ConnectSecure Logo"" class=""logo"" /></div>")
    }

    $null = $html.AppendLine('<h1>Agent Job Analysis Report</h1>')
    $null = $html.AppendLine('<button onclick="collapseAllDetails()" style="margin-bottom:10px;">Collapse All</button>')
    $null = $html.AppendLine("<p class=""small"">Generated: $($now.ToString('yyyy-MM-dd HH:mm:ss'))<br />Log file: <code>$(Html-Encode $LogPath)</code><br />File size: $fileSizeMB MB<br />AgentId: <code>$(Html-Encode $agentIdSafe)</code></p>")

    if ($usingQuick) {
        $null = $html.AppendLine("<div class=""quick-banner""><strong>Quick mode:</strong> This report analyzed only the most recent ~3 MB of the log (about $percentOfLines% of lines). For a full report, rerun without CLI switches and accept the full-dataset prompt.</div>")
    }

    $null = $html.AppendLine('<p class="small">Note: For large runs, log output may be truncated for compactness. A marker line indicates when output has been trimmed. For each job, only the most recent failure run is shown with log output; additional failures are summarized without code context. Known benign messages (service already running, RPC eventlog unavailable) do not count as failures.</p>')

    # Individual jobs list (exclude grouped jobs)
    $individualJobs = @($jobSummaries | Where-Object { -not $_.IsGrouped })

    # Sort by most recent issue (warning/failure) then JobName
    $individualJobs = $individualJobs | Sort-Object `
        @{ Expression = { $_.LastIssueTime }; Descending = $true }, `
        @{ Expression = { $_.JobName };       Descending = $false }

    $indCount = Get-CountSafe $individualJobs

    # Summary table - Individual Jobs
    Write-HostSafe "[PHASE 4.2] Building Job Summary - Individual Jobs..."
    $null = $html.AppendLine('<h2>Job Summary - Individual Jobs</h2>')
    $null = $html.AppendLine('<table>')
    $null = $html.AppendLine('<tr><th>Job</th><th>Total Runs</th><th>Success</th><th>Warnings</th><th>Failures</th><th>Last Issue (Warn/Fail)</th><th>Avg Interval</th><th>Predicted Next Run</th><th>Last Run Start</th><th>Last Status</th></tr>')

    $indIndex = 0
    foreach ($job in $individualJobs) {
        $indIndex++
        if ($indIndex % 25 -eq 0 -or $indIndex -eq 1 -or $indIndex -eq $indCount) {
            Write-HostSafe ("[PHASE 4.2] Summary row {0}/{1}: {2}" -f $indIndex, $indCount, $job.JobName)
        }

        $last = $job.LastRun

        $statusBadgeClass = 'badge'
        switch ($last.Status) {
            'Success' { $statusBadgeClass += ' badge-success' }
            'Warning' { $statusBadgeClass += ' badge-warning' }
            'Failure' { $statusBadgeClass += ' badge-failure' }
        }

        $lastStartText = if ($last.StartTime) { $last.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }
        $lastStatusHtml = "<a href=""$($job.LastRunAnchorHref)""><span class=""$statusBadgeClass"">$($last.Status)</span></a>"

        $jobLink        = "<a href=""$($job.JobAnchorHref)"">$(Html-Encode $job.JobName)</a>"
        $totalLink      = "<a href=""$($job.JobAnchorHref)"">$($job.TotalRuns)</a>"
        $successLink    = "<a href=""$($job.SuccessAnchorHref)"">$($job.SuccessCount)</a>"
        $warningLink    = "<a href=""$($job.WarningAnchorHref)"">$($job.WarningCount)</a>"
        $failureLink    = "<a href=""$($job.FailureAnchorHref)"">$($job.FailureCount)</a>"
        $avgIntLink     = "<a href=""$($job.JobAnchorHref)"">$(Html-Encode $job.AvgIntervalText)</a>"
        $nextRunLink    = "<a href=""$($job.JobAnchorHref)"">$(Html-Encode $job.PredictedNextText)</a>"
        $lastStartLink  = "<a href=""$($job.LastRunAnchorHref)"">$(Html-Encode $lastStartText)</a>"

        $issueText = $job.LastIssueText
        $issueLink = if ($job.LastIssueTime) {
            "<a href=""$($job.IssueAnchorHref)"">$(Html-Encode $issueText)</a>"
        } else {
            Html-Encode $issueText
        }

        $null = $html.AppendLine('<tr>' +
            "<td>$jobLink</td>" +
            "<td>$totalLink</td>" +
            "<td>$successLink</td>" +
            "<td>$warningLink</td>" +
            "<td>$failureLink</td>" +
            "<td>$issueLink</td>" +
            "<td>$avgIntLink</td>" +
            "<td>$nextRunLink</td>" +
            "<td>$lastStartLink</td>" +
            "<td>$lastStatusHtml</td>" +
            '</tr>')
    }
    $null = $html.AppendLine('</table>')

    # ---------------- Grouped summaries (if you add them, they slot here) ----------------

    # ---------------- Details per job (ALL jobs, grouped + individual) ----------------

    Write-HostSafe "[PHASE 4.3] Building per-job detail sections..."

    $detailJobs  = $jobSummaries
    $detailCount = Get-CountSafe $detailJobs

    $detailIndex = 0

    $maxSuccessLinesPerRun = 300
    $maxWarningLinesPerRun = 800
    $maxFailureLinesPerRun = 1000

    foreach ($job in $detailJobs | Sort-Object JobName) {
        $detailIndex++
        $includedRuns = @($job.IncludedRuns)
        $runCount     = Get-CountSafe $includedRuns

        $pctJobs = if ($detailCount -gt 0) { [int](($detailIndex * 100.0) / $detailCount) } else { 0 }

        $jobLabel = $job.JobName
        if ($jobLabel.Length -gt 60) {
            $jobLabel = $jobLabel.Substring(0,57) + '...'
        }

        Write-ProgressSafe -Activity "Phase 4: Building job details" -Status ("Job {0}/{1}: {2}" -f $detailIndex, $detailCount, $jobLabel) -PercentComplete $pctJobs

        $jobNameHtml = Html-Encode $job.JobName
        $anchorId    = New-JobAnchorId -JobName $job.JobName

        $null = $html.AppendLine("<h2 id=""$anchorId"">Job: $jobNameHtml</h2>")

        $null = $html.AppendLine('<div class="summary-row">')
        $null = $html.AppendLine("<span><strong>Total Runs:</strong> $($job.TotalRuns)</span>")
        $null = $html.AppendLine("<span><strong>Success:</strong> $($job.SuccessCount)</span>")
        $null = $html.AppendLine("<span><strong>Warnings:</strong> $($job.WarningCount)</span>")
        $null = $html.AppendLine("<span><strong>Failures:</strong> $($job.FailureCount)</span>")
        $null = $html.AppendLine("<span><strong>Avg Interval:</strong> $(Html-Encode $job.AvgIntervalText)</span>")
        $null = $html.AppendLine("<span><strong>Predicted Next Run:</strong> $(Html-Encode $job.PredictedNextText)</span>")
        $null = $html.AppendLine('</div>')

        if ($runCount -eq 0) {
            $null = $html.AppendLine('<p>No runs included for this job.</p>')
            continue
        }

        $hiddenSuccessCount = $job.HiddenSuccessCount
        if ($hiddenSuccessCount -gt 0) {
            $null = $html.AppendLine("<p class=""small"">$hiddenSuccessCount older successful run(s) omitted from details.</p>")
        }

        $failureRuns = @($includedRuns | Where-Object { $_.Status -eq 'Failure' } | Sort-Object StartTime -Descending)
        $repFailure  = $null
        $extraFailureRuns = @()

        $failCount = Get-CountSafe $failureRuns
        if ($failCount -gt 0) {
            $repFailure = $failureRuns[0]
            if ($failCount -gt 1) {
                $extraFailureRuns = $failureRuns[1..($failCount - 1)]
            }
        }

        if ($failCount -gt 1) {
            $null = $html.AppendLine("<p class=""small""><strong>Note:</strong> This job has $failCount failure run(s). Only the most recent failure run is shown with log output. $((Get-CountSafe $extraFailureRuns)) additional failure run(s) are listed below with details omitted.</p>")
        }

        $lastRun = $job.LastRun
        if ($includedRuns -contains $lastRun) {
            $startText = if ($lastRun.StartTime) { $lastRun.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Unknown' }
            $endText   = if ($lastRun.EndTime)   { $lastRun.EndTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Open-ended' }
            $durText   = if ($lastRun.Duration)  { Format-TimeSpanShort -Span $lastRun.Duration } else { 'N/A' }

            $badgeClass = 'badge'
            switch ($lastRun.Status) {
                'Success' { $badgeClass += ' badge-success' }
                'Warning' { $badgeClass += ' badge-warning' }
                'Failure' { $badgeClass += ' badge-failure' }
            }
            $statusBadge = "<span class=""$badgeClass"">$($lastRun.Status)</span>"

            $anchorAttrLast = if ($lastRun.PSObject.Properties['AnchorId']) { " id=""$($lastRun.AnchorId)""" } else { '' }

            $null = $html.AppendLine("<h3$anchorAttrLast>Last Included Run</h3>")
            $null = $html.AppendLine("<p class=""small""><strong>Start:</strong> $startText &nbsp; | &nbsp; <strong>End:</strong> $endText &nbsp; | &nbsp; <strong>Duration:</strong> $durText &nbsp; | &nbsp; <strong>Status:</strong> $statusBadge</p>")
        }

        $null = $html.AppendLine('<h3>Included Runs (most recent first)</h3>')

        foreach ($run in ($includedRuns | Sort-Object StartTime -Descending)) {
            $startText = if ($run.StartTime) { $run.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Unknown' }
            $endText   = if ($run.EndTime)   { $run.EndTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Open-ended' }
            $durText   = if ($run.Duration)  { Format-TimeSpanShort -Span $run.Duration } else { 'N/A' }

            $badgeClass = 'badge'
            switch ($run.Status) {
                'Success' { $badgeClass += ' badge-success' }
                'Warning' { $badgeClass += ' badge-warning' }
                'Failure' { $badgeClass += ' badge-failure' }
            }

            $summaryText = "Run starting $startText (Status: $($run.Status), Duration: $durText)"
            $summaryHtml = Html-Encode $summaryText
            $statusBadge = "<span class=""$badgeClass"">$($run.Status)</span>"

            if ($includedRuns -contains $lastRun -and $run -eq $lastRun) {
                $anchorAttr = ''
            }
            else {
                $anchorAttr = if ($run.PSObject.Properties['AnchorId']) { " id=""$($run.AnchorId)""" } else { '' }
            }

            $null = $html.AppendLine("<details$anchorAttr>")
            $null = $html.AppendLine("<summary>$summaryHtml &nbsp; $statusBadge</summary>")

            $null = $html.AppendLine("<p class=""small""><strong>Start:</strong> $startText &nbsp; | &nbsp; <strong>End:</strong> $endText &nbsp; | &nbsp; <strong>Duration:</strong> $durText</p>")

            # --------- Primary issue line anchor and link (defensively normalized) ---------
            $linesToUse = $run.Lines
            $lineCount  = Get-CountSafe $linesToUse

            if ($lineCount -gt 0) {
                # Normalize: cast to string, drop null/empty
                $normalizedLines = @(
                    $linesToUse |
                    ForEach-Object {
                        if ($_ -ne $null) { [string]$_ }
                    } |
                    Where-Object { $_ -ne '' }
                )

                $linesToUse = $normalizedLines
                $lineCount  = $normalizedLines.Count

                if ($lineCount -gt 0) {
                    $maxLines = switch ($run.Status) {
                        'Success' { $maxSuccessLinesPerRun }
                        'Warning' { $maxWarningLinesPerRun }
                        'Failure' { $maxFailureLinesPerRun }
                        default   { $maxSuccessLinesPerRun }
                    }
                    if ($maxLines -gt 0) {
                        $linesToUse = Get-TrimmedLinesForRun -Lines $linesToUse -MaxLines $maxLines
                        $lineCount  = Get-CountSafe $linesToUse
                    }
                }
            }

            $linesArray = @($linesToUse)
            $primaryIssue = if ($lineCount -gt 0) {
                Find-PrimaryIssueLine -Lines $linesArray
            } else {
                $null
            }

            if ($primaryIssue) {
                $issueLineNumber = $primaryIssue.Index + 1
                $issueSnippet    = $primaryIssue.Line
                if ($issueSnippet.Length -gt 120) {
                    $issueSnippet = $issueSnippet.Substring(0,117) + '...'
                }
                $issueSnippetHtml = Html-Encode $issueSnippet

                $issueAnchorId = if ($run.PSObject.Properties['AnchorId']) {
                    "$($run.AnchorId)-issue"
                } else {
                    "run-issue-$issueLineNumber"
                }

                $null = $html.AppendLine("<p class=""small"">Primary issue line: <a href=""#$issueAnchorId"">line $issueLineNumber</a> &mdash; <code>$issueSnippetHtml</code></p>")
            }

            # If this is an "extra" failure run, omit log details to keep file small
            if ($run.Status -eq 'Failure' -and ($extraFailureRuns -contains $run)) {
                $null = $html.AppendLine('<p class="small">Additional failure run; log details omitted to keep this report compact. See the representative failure run above for full context.</p>')
                $null = $html.AppendLine('</details>')
                continue
            }

            if ($lineCount -gt 0) {
                $sb = New-Object System.Text.StringBuilder

                for ($i = 0; $i -lt $lineCount; $i++) {
                    $line = $linesArray[$i]
                    $encoded = Html-Encode $line
                    $encoded = Highlight-StatusText $encoded

                    if ($primaryIssue -and $i -eq $primaryIssue.Index) {
                        $issueAnchorId = if ($run.PSObject.Properties['AnchorId']) {
                            "$($run.AnchorId)-issue"
                        } else {
                            "run-issue-$($i+1)"
                        }
                        $null = $sb.Append("<a id=""$issueAnchorId""></a>")
                    }

                    $null = $sb.Append($encoded)
                    if ($i -lt $lineCount - 1) {
                        $null = $sb.Append("`n")
                    }
                }

                $escapedLines = $sb.ToString()
                $null = $html.AppendLine("<pre>$escapedLines</pre>")
            }
            else {
                # Explicit note when a run has no usable output lines
                $null = $html.AppendLine('<p class="small">No log output captured for this run (all lines were empty or trimmed).</p>')
            }

            $null = $html.AppendLine('</details>')
        }
    }

    Write-ProgressSafe -Activity "Phase 4: Building job details" -Status "Done" -PercentComplete 100
    Write-HostSafe "[PHASE 4.3] Completed per-job detail sections."

    $null = $html.AppendLine('</body></html>')

    Write-HostSafe "[PHASE 4.4] HTML content built. Writing to disk..."
    $dir = Split-Path -Parent $OutputHtml
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    [IO.File]::WriteAllText($OutputHtml, $html.ToString(), [Text.Encoding]::UTF8)

    Write-HostSafe ("[DONE] Report written to: {0}" -f $OutputHtml)

    if (-not $NoOpen) {
        Write-HostSafe "[DONE] Launching HTML in default browser..."
        Start-Process $OutputHtml | Out-Null
    }

    [PSCustomObject]@{
        OutputHtml     = $OutputHtml
        QuickModeUsed  = $usingQuick
        FileSizeMB     = $fileSizeMB
        PercentOfLines = $percentOfLines
    }
}

# ---------------- Entry point / switch handling ----------------

# Effective NoOpen: either -NoOpen or -Silent implies "don’t open"
$effectiveNoOpen = $NoOpen -or $Silent

# 1) -AllLogs: non-interactive, process all *.log in a folder
if ($AllLogs) {
    Write-HostSafe "============================================================"
    Write-HostSafe "  Agent Job Review - ALL LOGS MODE"
    Write-HostSafe "============================================================"

    $folder = $null

    if ($LogPath) {
        if (Test-Path -LiteralPath $LogPath -PathType Container) {
            $folder = $LogPath
        }
        elseif (Test-Path -LiteralPath $LogPath -PathType Leaf) {
            $folder = Split-Path -Parent $LogPath
        }
        else {
            Write-WarningSafe "LogPath '$LogPath' not found, falling back to default log folder: $DefaultLogFolder"
            $folder = $DefaultLogFolder
        }
    }
    else {
        $folder = $DefaultLogFolder
    }

    if (-not (Test-Path -LiteralPath $folder)) {
        Write-Error "Log folder not found: $folder"
        return
    }

    $logs = @(Get-ChildItem -LiteralPath $folder -Filter '*.log' -File -ErrorAction SilentlyContinue |
              Sort-Object Name)

    if (-not $logs -or (Get-CountSafe $logs) -eq 0) {
        Write-Error "No .log files found in: $folder"
        return
    }

    Write-HostSafe ("[INFO] Processing {0} log file(s) in: {1}" -f (Get-CountSafe $logs), $folder)

    foreach ($lf in $logs) {
        Write-HostSafe ""
        Write-HostSafe "============================================================"
        Write-HostSafe ("  Processing log: {0}" -f $lf.FullName)
        Write-HostSafe "============================================================"

        $baseName   = [IO.Path]::GetFileNameWithoutExtension($lf.Name)
        $safeBase   = ($baseName -replace '[^a-zA-Z0-9\-]+','-').Trim('-')
        if (-not $safeBase) { $safeBase = 'log' }
        $stamp      = (Get-Date).ToString('yyyyMMdd-HHmmss')
        $outName    = "Job-Analysis-{0}-{1}.html" -f $safeBase, $stamp
        $outPath    = Join-Path $ExportPath $outName

        Analyze-LogFile -LogPath $lf.FullName -OutputHtml $outPath -NoOpen:$true | Out-Null
    }

    Write-HostSafe ""
    Write-HostSafe "[DONE] All logs processed (no browser popups in -AllLogs mode)."
    return
}

# 2) Single-log modes (menu or direct)

if (-not $LogPath) {
    if ($effectiveNoOpen -and (Test-Path -LiteralPath $DefaultLogFile)) {
        # Non-interactive default when no path given and NoOpen/Silent is set
        $LogPath = $DefaultLogFile
        Write-HostSafe ("[INFO] No LogPath specified; using default log: {0}" -f $LogPath)
    }
    else {
        # Interactive menu selection
        $LogPath = Select-LogFile
        if (-not $LogPath) {
            Write-HostSafe "No log selected. Exiting."
            return
        }
    }
}

$result = Analyze-LogFile -LogPath $LogPath -OutputHtml $OutputHtml -NoOpen:$effectiveNoOpen

# Enforce 3MB limit for CLI/non-interactive usage:
# Only offer full-dataset rerun when NO CLI switches that imply non-interactive usage are present.
if ($result -and $result.QuickModeUsed -and -not $effectiveNoOpen -and -not $AllLogs -and -not $Silent) {
    Write-Host ""
    Write-Host ("[SUMMARY] Quick mode analyzed ~3 MB (~{0}% of lines) of a {1} MB log." -f $result.PercentOfLines, $result.FileSizeMB)
    $choice = Read-Host "Run full-dataset analysis now? (Y/N)"
    if ($choice.ToUpper() -eq 'Y') {
        Write-Host ""
        Write-Host "[FULL] Running full-dataset analysis..."
        Analyze-LogFile -LogPath $LogPath -NoOpen:$effectiveNoOpen -FullDataset
    }
}
