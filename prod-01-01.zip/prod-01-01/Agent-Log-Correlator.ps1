<# ====================================================
  Agent-Log-Correlator.ps1  (v1.7.2)
  - ASCII only; PS 5.1 compatible
  - Fix: avoid automatic $Host collision
  - Fix: PatternCountLast24 increments correct entry (no ++ on hashtable)
  - Fix: exclude Agent-Log-Correlator-Diagnostics_*.log from analysis
  - Strict Y/N gate; progress + ETA every 15s
  - Summary: cybercns log count, secondary count, total MB, total lines, total severity, time range
  - CS Servers pivot: Total + Type columns; sortable
  - 3rd-party pivot: patch logs only; Total column; sortable; collapsed "App Family" groups
  - Common Severity Messages: split into Regular / Utilities / Patch / Other; per-file examples; per-file Last 24h counts
  - Version Review: excludes Unknown; includes Hostname + IP
  - Last Scan Review: excludes rows where Agent ID is the log file name or not numeric
====================================================== #>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$PSDefaultParameterValues['*:ErrorAction'] = 'Stop'
$Global:AGL_LastHtmlPath = $null

trap {
  $ex = $_.Exception
  Write-Host ''
  Write-Host '============= Agent-Log-Correlator ERROR =============' -ForegroundColor Red
  Write-Host ('Type   : {0}' -f ($ex.GetType().FullName)) -ForegroundColor Red
  Write-Host ('Message: {0}' -f $ex.Message) -ForegroundColor Red
  if ($_.InvocationInfo) {
    Write-Host ('Script : {0}' -f $_.InvocationInfo.ScriptName) -ForegroundColor Red
    Write-Host ('Line   : {0}' -f $_.InvocationInfo.ScriptLineNumber) -ForegroundColor Red
    Write-Host ('Column : {0}' -f $_.InvocationInfo.OffsetInLine) -ForegroundColor Red
    Write-Host '---- Position ----' -ForegroundColor Red
    Write-Host $_.InvocationInfo.PositionMessage -ForegroundColor Red
  }
  if ($_.ScriptStackTrace) {
    Write-Host '---- Script Stack Trace ----' -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor Red
  }
  if ($ex.InnerException) {
    Write-Host '---- Inner Exception ----' -ForegroundColor Red
    Write-Host ($ex.InnerException | Format-List * -Force | Out-String) -ForegroundColor Red
  }
  try {
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = if ($Global:AGL_LastHtmlPath) { Split-Path -Parent $Global:AGL_LastHtmlPath } else { Get-Location }
    $logPath = Join-Path $base ("Agent-Log-Correlator-Diagnostics_{0}.log" -f $ts)
    $diag = @()
    $diag += "[{0}] ERROR" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $diag += "Message: {0}" -f $ex.Message
    if ($_.InvocationInfo) {
      $diag += "Script : {0}" -f $_.InvocationInfo.ScriptName
      $diag += "Line   : {0}" -f $_.InvocationInfo.ScriptLineNumber
      $diag += "Column : {0}" -f $_.InvocationInfo.OffsetInLine
      $diag += "Position:"
      $diag += $_.InvocationInfo.PositionMessage
    }
    if ($_.ScriptStackTrace) { $diag += "ScriptStackTrace:`n$($_.ScriptStackTrace)" }
    if ($ex.InnerException) { $diag += "InnerException:`n$($ex.InnerException | Format-List * -Force | Out-String)" }
    Set-Content -LiteralPath $logPath -Value ($diag -join [Environment]::NewLine) -Encoding UTF8 -Force
    Write-Host ("Diagnostics written to: {0}" -f $logPath) -ForegroundColor Yellow
  } catch {}
  Write-Host ''
  Write-Host 'Press Enter to return to the correlator menu...' -ForegroundColor Gray
  Read-Host | Out-Null
  continue
}

try { $null = [System.Web.HttpUtility]::HtmlEncode('x') } catch { try { Add-Type -AssemblyName System.Web -ErrorAction SilentlyContinue } catch {} }

# ---- Tunables ----
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$FoldUrlToHost          = $true
$MaxExamplesPerPattern  = 8
$ContextBefore          = 2
$ContextAfter           = 2
$LargeFileContextMB     = 25
$MaxCommonMessages      = 300
$ProgressRefreshSec     = 15
$WeightAnalyze          = 80   # percent weights for overall progress
$WeightAggregate        = 15
$WeightRender           = 5

$script:StartTime = $null
$script:LastTick  = Get-Date

function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan }
function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green }
function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow }
function Write-Err  { param([string]$Msg) Write-Host ("[ERR]   {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Red }

function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path -PathType Container)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } }

function New-Eta { param([int]$Done,[int]$Total)
  if ($Done -le 0) { return 'estimating...' }
  $elapsed = (Get-Date) - $script:StartTime
  $perItem = [TimeSpan]::FromTicks([int64]([double]$elapsed.Ticks / [Math]::Max(1,$Done)))
  $remain  = [TimeSpan]::FromTicks($perItem.Ticks * [Math]::Max(0, $Total - $Done))
  return $remain.ToString("hh\:mm\:ss")
}

function Should-Tick { $now = Get-Date; if (($now - $script:LastTick).TotalSeconds -ge $ProgressRefreshSec) { $script:LastTick = $now; return $true } return $false }

function Show-ProgressBars {
  param([string]$PhaseLabel,[int]$PhasePercent,[int]$OverallPercent,[string]$Status)
  if ($PhasePercent -lt 0) { $PhasePercent = 0 } elseif ($PhasePercent -gt 100) { $PhasePercent = 100 }
  if ($OverallPercent -lt 0) { $OverallPercent = 0 } elseif ($OverallPercent -gt 100) { $OverallPercent = 100 }
  Write-Progress -Id 1 -Activity ("Agent Log Correlator - {0}" -f $PhaseLabel) -Status $Status -PercentComplete $PhasePercent
  Write-Progress -Id 0 -Activity "Overall" -Status ("{0}% complete" -f $OverallPercent) -PercentComplete $OverallPercent
}

function Read-FileLines { param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return @() }
  try { return [System.IO.File]::ReadLines($Path) } catch { try { return Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue } catch { return @() } }
}

function Get-RelativePath { param([Parameter(Mandatory)][string]$Base,[Parameter(Mandatory)][string]$Full)
  try {
    $baseUri = (Resolve-Path -LiteralPath $Base -ErrorAction Stop).ProviderPath
    $fullUri = (Resolve-Path -LiteralPath $Full -ErrorAction Stop).ProviderPath
    $u1 = [System.Uri]("file://" + ($baseUri -replace '\','/').TrimEnd('/') + '/')
    $u2 = [System.Uri]("file://" + ($fullUri -replace '\','/'))
    $rel = $u1.MakeRelativeUri($u2).ToString()
    return [System.Uri]::UnescapeDataString($rel) -replace '/','\'
  } catch { return (Split-Path -Leaf $Full) }
}

function TryParse-LineDateTime { param([string]$Line,[datetime]$FallbackDate)
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?'); if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?'); if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }
  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?'); if ($m.Success -and $FallbackDate) {
    try { $h=[int]$m.Groups[1].Value.Substring(0,2); $mi=[int]$m.Groups[1].Value.Substring(3,2); $s=[int]$m.Groups[1].Value.Substring(6,2); return ($FallbackDate.Date.AddHours($h).AddMinutes($mi).AddSeconds($s)) } catch {}
  }
  return $null
}

function Normalize-LineForPattern { param([string]$Line)
  if ($null -eq $Line) { return '' }
  $norm = $Line
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
  if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
  $norm = $norm -replace '(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)','{IP}'
  $norm = $norm -replace '\b\d+\b','{N}'
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()
  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

function Test-IsCsHost { param([Parameter(Mandatory)][string]$HostName)
  $h = $HostName.ToLowerInvariant()
  foreach ($root in @('myconnectsecure.com','mycybercns.com')) { if ($h -eq $root -or $h -like ('*.'+$root)) { return $true } }
  return $false
}

function Get-LogTypeFromName { param([string]$FileName)
  $n = ($FileName | Split-Path -Leaf).ToLowerInvariant()
  if ($n -match 'patch') { return 'Patch' }
  if ($n -match 'util|utility|utilities|monitor') { return 'Utilities' }
  if ($n -match '^cybercns.*\.log$') { return 'Regular' }
  if ($n -match 'cybercns') { return 'Regular' }
  return 'Other'
}

function Get-HttpOrHttpsUrlCountsFromLog { param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}; if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath; if (@($lines).Count -eq 0) { return $counts }
  $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
  foreach ($ln in $lines) {
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value; if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }; $counts[$u]++
    }
  }
  return $counts
}

function Get-CsServersFromLog { param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}; if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath; if (@($lines).Count -eq 0) { return $counts }
  $urlRegex     = [regex]'https?://[^\s"''\]\)<>]+'
  $hostRegexNet = [regex]'(?i)\b([a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:myconnectsecure\.com|mycybercns\.com))\b'
  foreach ($ln in $lines) {
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value; if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      $urlHost = $null
      try { $urlHost = ([Uri]$u).Host } catch { $hm = [regex]::Match($u,'^https?://([^/:?#]+)'); if ($hm.Success) { $urlHost = $hm.Groups[1].Value } }
      if ($urlHost -and (Test-IsCsHost -HostName $urlHost)) { if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }; $counts[$u]++ }
    }
    $h = $hostRegexNet.Match([string]$ln); if ($h.Success) { $hostOnly = $h.Groups[1].Value; if (-not $counts.ContainsKey($hostOnly)) { $counts[$hostOnly] = 0 }; $counts[$hostOnly]++ }
  }
  return $counts
}

function Analyze-LogFile { param([Parameter(Mandatory)][string]$FilePath)
  $result = [ordered]@{
    FilePath=$FilePath; FileName=[IO.Path]::GetFileName($FilePath); RelPath=$null; LogType='Other';
    AgentID=$null; AgentVersion=$null; HostName=$null; IP=$null;
    SeverityTotal=0; CountsByLevel=@{}; CsUrlCounts=@{}; ThirdPartyUrlCounts=@{};
    CommonPatterns=@{}; PatternExamples=@{}; ExampleByPattern=@{};
    PatternCountLast24=@{}; LastScanByType=@{}; FirstTimestamp=$null; LastTimestamp=$null; LineCount=0; FileBytes=0L
  }

  $result.LogType = Get-LogTypeFromName -FileName $result.FileName

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false; if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }
  $lines = Read-FileLines -Path $FilePath; $lines = @($lines); $result.LineCount = $lines.Count
  if ($file) { $result.FileBytes = $file.Length }
  if ($lines.Count -eq 0) { return $result }
  $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }

  foreach ($ln in $lines) {
    if ($null -eq $result.AgentID      -and $ln -match '\[Agent ID\s*:-\s*([^\]]+)\]')             { $result.AgentID      = $Matches[1].Trim() }
    if ($null -eq $result.AgentVersion -and $ln -match '\[Agent version\s*:-\s*([^\]]+)\]')        { $result.AgentVersion = $Matches[1].Trim() }
    if ($null -eq $result.HostName     -and $ln -match '\[(?:Host(?:\s*Name)?|Hostname)\s*:-\s*([^\]]+)\]') { $result.HostName = $Matches[1].Trim() }
    if ($null -eq $result.IP           -and $ln -match '\[(?:IP|IP Address)\s*:-\s*([^\]]+)\]')    { $result.IP = $Matches[1].Trim() }

    if ($null -eq $result.AgentID      -and $ln -match '(?i)\bAgent\s*ID\s*[:=]\s*([A-Za-z0-9\-\{\}]+)')   { $result.AgentID      = $Matches[1].Trim() }
    if ($null -eq $result.AgentVersion -and $ln -match '(?i)\bAgent\s*Version\s*[:=]\s*([0-9][0-9A-Za-z\.\-_]+)') { $result.AgentVersion = $Matches[1].Trim() }
    if ($null -eq $result.HostName     -and $ln -match '(?i)\bHost(?:\s*Name)?\s*[:=]\s*([A-Za-z0-9\.\-]+)') { $result.HostName = $Matches[1].Trim() }
    if ($null -eq $result.IP           -and $ln -match '(?i)\bIP(?:\s*Address)?\s*[:=]\s*(([0-9]{1,3}\.){3}[0-9]{1,3})') { $result.IP = $Matches[1].Trim() }

    $dt0 = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate
    if ($dt0) {
      if (-not $result.FirstTimestamp) { $result.FirstTimestamp = $dt0 }
      if (-not $result.LastTimestamp -or $dt0 -gt $result.LastTimestamp) { $result.LastTimestamp = $dt0 }
    }
  }
  if ([string]::IsNullOrWhiteSpace($result.AgentID)) {
    $p = Split-Path -Parent $FilePath
    $name = Split-Path -Leaf $p
    if ($name -match '^[0-9A-Fa-f\-]{6,36}$') { $result.AgentID = $name }
  }
  if ([string]::IsNullOrWhiteSpace($result.AgentID)) { $result.AgentID = $result.FileName }
  if ([string]::IsNullOrWhiteSpace($result.HostName)) { $result.HostName = '(unknown)' }
  if ([string]::IsNullOrWhiteSpace($result.IP)) { $result.IP = '' }
  $fileAnchor = $result.LastTimestamp

  # URLs
  $result.CsUrlCounts = Get-CsServersFromLog -LogPath $FilePath
  $urlCounts = Get-HttpOrHttpsUrlCountsFromLog -LogPath $FilePath
  foreach ($kv in $urlCounts.GetEnumerator()) {
    $u = [string]$kv.Key; $uHost = $null
    try { $uHost = ([Uri]$u).Host } catch { $hm = [regex]::Match($u,'^https?://([^/:?#]+)'); if ($hm.Success) { $uHost=$hm.Groups[1].Value } }
    if ($uHost -and (Test-IsCsHost -HostName $uHost)) { continue }
    if (-not $result.ThirdPartyUrlCounts.ContainsKey($u)) { $result.ThirdPartyUrlCounts[$u] = 0 }
    $result.ThirdPartyUrlCounts[$u] += [int]$kv.Value
  }

  # Severity + patterns
  $contexts = @{}; $exampleCap = if ($limitCtx) { [Math]::Min($MaxExamplesPerPattern,3) } else { $MaxExamplesPerPattern }
  for ($i=0; $i -lt $lines.Count; $i++) {
    $line = [string]$lines[$i]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }
      $dtLine = TryParse-LineDateTime -Line $line -FallbackDate $result.LastTimestamp
      $norm = Normalize-LineForPattern -Line $line

      if (-not $result.CommonPatterns.ContainsKey($norm)) { $result.CommonPatterns[$norm] = 0 }
      $result.CommonPatterns[$norm]++

      if ($fileAnchor -and $dtLine) {
        $delta = ($fileAnchor - $dtLine).TotalHours
        if ($delta -le 24 -and $delta -ge 0) {
          if (-not $result.PatternCountLast24.ContainsKey($norm)) { $result.PatternCountLast24[$norm] = 0 }
          # FIX: increment the entry, not the hashtable itself
          $result.PatternCountLast24[$norm]++
        }
      }

      if (-not $result.ExampleByPattern.ContainsKey($norm)) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($n -eq $null -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx=($lines[$start..$end] -join "`n")
        $result.ExampleByPattern[$norm] = [ordered]@{
          Timestamp = if ($dtLine) { $dtLine } else { $null }
          ContextHtml = "<pre>" + [System.Web.HttpUtility]::HtmlEncode($ctx) + "</pre>"
          RawLine = $line
        }
      }

      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }
      if (@($contexts[$norm]).Count -lt $exampleCap) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($n -eq $null -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx=($lines[$start..$end] -join "`n")
        $contexts[$norm] += ("<pre>" + [System.Web.HttpUtility]::HtmlEncode($ctx) + "</pre>")
      }
    }

    foreach ($st in @(
      @{ Name='Vulnerability'; Pattern='(?i)\bVuln(?:erability)?\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Vuln(?:erability)?' },
      @{ Name='Patch';         Pattern='(?i)\bPatch\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Patch' },
      @{ Name='Compliance';    Pattern='(?i)\bCompliance\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Compliance' },
      @{ Name='Software';      Pattern='(?i)\bSoftware\b.*\bScan\b|(?i)\bInventory\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Software' },
      @{ Name='Discovery';     Pattern='(?i)\bDiscovery\b.*\bScan\b' },
      @{ Name='OS/Config';     Pattern='(?i)\bOS\b.*\bScan\b|(?i)\bConfiguration\b.*\bScan\b' },
      @{ Name='AV/Malware';    Pattern='(?i)\bAV\b.*\bScan\b|(?i)\bMalware\b.*\bScan\b' }
    )) {
      if ($line -match $st.Pattern) {
        $dt2 = TryParse-LineDateTime -Line $line -FallbackDate $fallbackDate
        if ($dt2) {
          $name=[string]$st.Name
          if (-not $result.LastScanByType.ContainsKey($name)) { $result.LastScanByType[$name] = $dt2 }
          elseif ($dt2 -gt $result.LastScanByType[$name]) { $result.LastScanByType[$name] = $dt2 }
        }
      }
    }
  }

  $result.CountsByLevel = $countsByLevel
  $result.SeverityTotal = ($countsByLevel.GetEnumerator() | Measure-Object -Property Value -Sum).Sum
  $result.PatternExamples = $contexts
  return $result
}

function Get-AppFamilyKey { param([string]$Url)
  if ([string]::IsNullOrWhiteSpace($Url)) { return 'Other' }
  $appHost = ''
  $path = ''
  try {
    $u = [Uri]$Url
    $appHost = $u.Host.ToLowerInvariant()
    $path = $u.AbsolutePath.Trim('/')
  } catch {
    $m = [regex]::Match($Url,'^https?://([^/]+)(/(.*))?')
    if ($m.Success) {
      $appHost = $m.Groups[1].Value.ToLowerInvariant()
      $path = ($m.Groups[3].Value + '') -replace '^\s+|\s+$',''
    }
  }
  $firstSeg = if ($path) { $path.Split('/')[0].ToLowerInvariant() } else { '' }

  if ($appHost -like '*enterprisedb.com*' -or $path -match '(?i)\bpostgresql\b') { return 'PostgreSQL' }
  if ($appHost -like '*microsoft.com*' -or $appHost -like '*windowsupdate.com*') { return 'Microsoft' }
  if ($appHost -like '*adobe.com*' -or $appHost -like '*macromedia.com*') { return 'Adobe' }
  if ($appHost -like '*googleapis.com*' -or $appHost -like '*google.com*') { return 'Google' }
  if ($appHost -like '*oracle.com*' -or $path -match '(?i)\bjava\b') { return 'Oracle/Java' }
  if ($appHost -like '*github.com*' -or $appHost -like '*githubusercontent.com*') { return 'GitHub' }
  if ($firstSeg) { return ($appHost + '/' + $firstSeg) }
  if ($appHost) { return $appHost }
  return 'Other'
}

function Correlate-AgentLogs { param([Parameter(Mandatory)][string]$Root,[string]$OutHtmlPath)
  try {
    $rootAbs = (Resolve-Path -LiteralPath $Root).ProviderPath
    $allFiles = Get-ChildItem -Path $rootAbs -Recurse -File

    # Exclude our own diagnostics logs from analysis
    $logFilesOnly = @(
      $allFiles | Where-Object {
        $_.Extension -ieq '.log' -and
        $_.Name -notlike 'Agent-Log-Correlator-Diagnostics_*.log'
      }
    )
    $cybercnsLogFiles = @($logFilesOnly | Where-Object { $_.Name -match '(?i)^cybercns.*\.log$' })
    $secondaryCount   = [Math]::Max(0, $logFilesOnly.Count - $cybercnsLogFiles.Count)

    $total            = $logFilesOnly.Count; $processed = 0
    $fileAnalyses = New-Object System.Collections.Generic.List[object]
    $overallFirst = $null; $overallLast = $null; $overallSeverity = 0
    $totalLines = 0; $totalBytes = 0L
    $script:StartTime = Get-Date; $script:LastTick = (Get-Date).AddSeconds(-$ProgressRefreshSec)

    Write-Info ("Analyzing {0} *.log files under ""{1}"" ..." -f $logFilesOnly.Count, $rootAbs)
    Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent 0 -OverallPercent 0 -Status ("0/{0} reviewed" -f $total)

    foreach ($f in $logFilesOnly) {
      try {
        $fa = [pscustomobject](Analyze-LogFile -FilePath $f.FullName)
        $fa.RelPath = Get-RelativePath -Base $rootAbs -Full $f.FullName
        [void]$fileAnalyses.Add($fa)

        if ($fa.FirstTimestamp) { if (-not $overallFirst -or $fa.FirstTimestamp -lt $overallFirst) { $overallFirst = $fa.FirstTimestamp } }
        if ($fa.LastTimestamp)  { if (-not $overallLast  -or $fa.LastTimestamp  -gt $overallLast)  { $overallLast  = $fa.LastTimestamp } }
        $overallSeverity += [int]$fa.SeverityTotal
        $totalLines += [int]$fa.LineCount
        $totalBytes += [long]$fa.FileBytes
      } catch {
        Write-Warn ("Failed to analyze {0}: {1}" -f $f.FullName, $_.Exception.Message)
      } finally {
        $processed++; $pctPhase=[int]([double]$processed/[Math]::Max(1,$total)*100); $pctOverall=[int](($WeightAnalyze*$pctPhase)/100)
        if (Should-Tick) {
          $eta=New-Eta -Done $processed -Total $total
          $status=("{0}/{1} reviewed - {2}% - ETA {3}" -f $processed,$total,$pctPhase,$eta)
          Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent $pctPhase -OverallPercent $pctOverall -Status $status
          Write-Info $status
        }
      }
    }
    Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent 100 -OverallPercent $WeightAnalyze -Status ("{0}/{1} reviewed - 100%" -f $processed,$total)

    $totalMB = if ($totalBytes -gt 0) { [Math]::Round($totalBytes/1MB,2) } else { 0 }

    Write-Host ''
    Write-OK ("Distinct cybercns*.log files : {0}" -f $cybercnsLogFiles.Count)
    Write-OK ("Number of secondary log files: {0}" -f $secondaryCount)
    Write-OK ("Total size of logs analyzed (MB): {0}" -f $totalMB)
    Write-OK ("Total number of lines analyzed  : {0}" -f $totalLines)
    Write-OK ("Total severity messages (all logs): {0}" -f $overallSeverity)
    if ($overallFirst -and $overallLast) {
      Write-Info ("Time range across logs: {0} -> {1}" -f ($overallFirst.ToString('yyyy-MM-dd HH:mm')), ($overallLast.ToString('yyyy-MM-dd HH:mm')))
    }
    Write-Host ''

    # Strict Y/N only
    while ($true) {
      $answer = Read-Host "Proceed with correlation and HTML export? (Y/N)"
      if ($answer -match '^(?i)[yn]$') { break }
      Write-Host 'Invalid input' -ForegroundColor Yellow
    }
    if ($answer -notmatch '^(?i)y$') { Write-Warn 'Aborted by user.'; return }

    if (-not $OutHtmlPath) { $OutHtmlPath = Join-Path $rootAbs 'Agent-Log-Correlator-Report.html' }
    $Global:AGL_LastHtmlPath = $OutHtmlPath
    $outDir = Split-Path -Parent $OutHtmlPath; Ensure-Folder $outDir

    # ====== Aggregations ======
    Show-ProgressBars -PhaseLabel "Phase 2/3 - Aggregate" -PhasePercent 10 -OverallPercent ($WeightAnalyze + 2) -Status "Preparing aggregates"

    $allAgentIDs = @(
      $fileAnalyses | ForEach-Object {
        $aid = $_.AgentID
        if ($aid -and $aid -match '^\d+$' -and $aid -ne $_.FileName) { $aid }
      } | Sort-Object -Unique
    )

    $severityByFile = $fileAnalyses | ForEach-Object {
      [pscustomobject]@{
        File = $_.RelPath; AgentID = $_.AgentID; Host=$_.HostName; Type=$_.LogType; TotalSeverity = $_.SeverityTotal
      }
    } | Sort-Object -Property TotalSeverity -Descending

    $hostByAgentCounts = @{}; foreach ($fa in $fileAnalyses) {
      $aid=[string]$fa.AgentID; $h=[string]$fa.HostName
      if (-not $hostByAgentCounts.ContainsKey($aid)) { $hostByAgentCounts[$aid]=@{} }
      if (-not $hostByAgentCounts[$aid].ContainsKey($h)) { $hostByAgentCounts[$aid][$h]=0 }
      $hostByAgentCounts[$aid][$h]++
    }
    $primaryHostByAgent = @{}
    foreach ($aid in $hostByAgentCounts.Keys) {
      $kv = $hostByAgentCounts[$aid].GetEnumerator() | Sort-Object -Property Value -Descending | Select-Object -First 1
      $primaryHostByAgent[$aid] = if ($kv) { $kv.Key } else { '(unknown)' }
    }

    $relToAid=@{}; $relToHost=@{}; $relToType=@{}; $relToFA=@{}
    foreach ($fa in $fileAnalyses) {
      $relToAid[$fa.RelPath]=$fa.AgentID
      $relToHost[$fa.RelPath]=$fa.HostName
      $relToType[$fa.RelPath]=$fa.LogType
      $relToFA[$fa.RelPath]=$fa
    }

    # CS servers pivot: URL x AgentID, plus Type rollups and totals
    $csPivot = @{}; $csUrlTypeTotals=@{}; $csUrlTotals=@{}
    foreach ($fa in $fileAnalyses) {
      foreach ($kv in $fa.CsUrlCounts.GetEnumerator()) {
        $url=[string]$kv.Key; $cnt=[int]$kv.Value
        $aid=$fa.AgentID
        if (-not $csPivot.ContainsKey($url)) { $csPivot[$url]=@{} }
        if (-not $csPivot[$url].ContainsKey($aid)) { $csPivot[$url][$aid]=0 }
        $csPivot[$url][$aid]+=$cnt
        if (-not $csUrlTotals.ContainsKey($url)) { $csUrlTotals[$url]=0 }
        $csUrlTotals[$url]+=$cnt
        $typ=$fa.LogType
        if (-not $csUrlTypeTotals.ContainsKey($url)) { $csUrlTypeTotals[$url]=@{} }
        if (-not $csUrlTypeTotals[$url].ContainsKey($typ)) { $csUrlTypeTotals[$url][$typ]=0 }
        $csUrlTypeTotals[$url][$typ]+=$cnt
      }
    }
    $csUrlsSorted = @($csUrlTotals.GetEnumerator() | Sort-Object -Property Value -Descending | ForEach-Object { $_.Key })

    # 3rd-party pivot: patch logs only
    $thirdPivot = @{}; $thirdTotals=@{}
    foreach ($fa in $fileAnalyses) {
      if ($fa.FileName -notmatch '(?i)patch') { continue }
      foreach ($kv in $fa.ThirdPartyUrlCounts.GetEnumerator()) {
        $url=[string]$kv.Key; $cnt=[int]$kv.Value
        if (-not $thirdPivot.ContainsKey($url)) { $thirdPivot[$url]=@{} }
        if (-not $thirdPivot[$url].ContainsKey($fa.RelPath)) { $thirdPivot[$url][$fa.RelPath]=0 }
        $thirdPivot[$url][$fa.RelPath]+=$cnt
        if (-not $thirdTotals.ContainsKey($url)) { $thirdTotals[$url]=0 }
        $thirdTotals[$url]+=$cnt
      }
    }
    $thirdUrlsSorted = @($thirdTotals.GetEnumerator() | Sort-Object -Property Value -Descending | ForEach-Object { $_.Key })

    # Build a stable, unique, sorted array of file paths that appear in the third-party pivot
    $thirdFiles = @()
    foreach ($url in $thirdPivot.Keys) {
      foreach ($fp in $thirdPivot[$url].Keys) {
        $thirdFiles += ,([string]$fp)
      }
    }
    $thirdFiles = @($thirdFiles | Sort-Object -Unique)

    # Collapsed app families
    $thirdCollapsed = @{}
    foreach ($url in $thirdTotals.Keys) {
      $fam = Get-AppFamilyKey -Url $url
      if (-not $thirdCollapsed.ContainsKey($fam)) { $thirdCollapsed[$fam]=@{} }
      $thirdCollapsed[$fam][$url] = $thirdTotals[$url]
    }
    $thirdCollapsedSorted = @($thirdCollapsed.Keys | Sort-Object { ($thirdCollapsed[$_].GetEnumerator() | Measure-Object -Property Value -Sum).Sum } -Descending)

    # Common messages: global and by type
    $globalPatterns=@{}; $perFilePatternCounts=@{}; $examplesPerPattern=@{}; $last24ByPattern=@{}
    $byTypePatterns = @{ 'Regular'=@{}; 'Utilities'=@{}; 'Patch'=@{}; 'Other'=@{} }
    $byTypePerFile = @{ 'Regular'=@{}; 'Utilities'=@{}; 'Patch'=@{}; 'Other'=@{} }

    foreach ($fa in $fileAnalyses) {
      foreach ($kv in $fa.CommonPatterns.GetEnumerator()) {
        $norm=[string]$kv.Key; $ct=[int]$kv.Value
        if (-not $globalPatterns.ContainsKey($norm)) { $globalPatterns[$norm]=0 }
        $globalPatterns[$norm]+=$ct
        if (-not $perFilePatternCounts.ContainsKey($norm)) { $perFilePatternCounts[$norm]=@{} }
        if (-not $perFilePatternCounts[$norm].ContainsKey($fa.RelPath)) { $perFilePatternCounts[$norm][$fa.RelPath]=0 }
        $perFilePatternCounts[$norm][$fa.RelPath]+=$ct

        $t=$fa.LogType
        if (-not $byTypePatterns[$t].ContainsKey($norm)) { $byTypePatterns[$t][$norm]=0 }
        $byTypePatterns[$t][$norm]+=$ct
        if (-not $byTypePerFile[$t].ContainsKey($norm)) { $byTypePerFile[$t][$norm]=@{} }
        if (-not $byTypePerFile[$t][$norm].ContainsKey($fa.RelPath)) { $byTypePerFile[$t][$norm][$fa.RelPath]=0 }
        $byTypePerFile[$t][$norm][$fa.RelPath]+=$ct
      }
      foreach ($kv2 in $fa.PatternCountLast24.GetEnumerator()) {
        $norm=[string]$kv2.Key; $ct24=[int]$kv2.Value
        if (-not $last24ByPattern.ContainsKey($norm)) { $last24ByPattern[$norm]=0 }
        $last24ByPattern[$norm]+=$ct24
      }
      foreach ($ekv in $fa.ExampleByPattern.GetEnumerator()) {
        $norm=[string]$ekv.Key
        if (-not $examplesPerPattern.ContainsKey($norm)) { $examplesPerPattern[$norm]=@{} }
        $examplesPerPattern[$norm][$fa.RelPath] = $ekv.Value
      }
    }
    $sortedPatterns = $globalPatterns.GetEnumerator() | Sort-Object -Property Value -Descending
    if ($MaxCommonMessages -gt 0) { $sortedPatterns = $sortedPatterns | Select-Object -First $MaxCommonMessages }

    # Version review
    $versionByAgent=@{}; $hostByAgent=@{}; $ipByAgent=@{}
    foreach ($fa in $fileAnalyses) {
      if ($fa.AgentID -match '^\d+$' -and ($fa.AgentID -ne $fa.FileName)) {
        $ver = if ($fa.AgentVersion) { $fa.AgentVersion } else { 'Unknown' }
        if ($ver -ne 'Unknown') { $versionByAgent[$fa.AgentID]=$ver }
        if (-not $hostByAgent.ContainsKey($fa.AgentID) -and $fa.HostName) { $hostByAgent[$fa.AgentID]=$fa.HostName }
        if (-not $ipByAgent.ContainsKey($fa.AgentID) -and $fa.IP) { $ipByAgent[$fa.AgentID]=$fa.IP }
      }
    }
    $versionCounts=@{}; foreach ($aid in $versionByAgent.Keys) { $v=$versionByAgent[$aid]; if (-not $versionCounts.ContainsKey($v)) { $versionCounts[$v]=0 }; $versionCounts[$v]++ }
    $verCountsSorted = $versionCounts.GetEnumerator() | Sort-Object -Property Name
    $verLabelsJson = (@($verCountsSorted | ForEach-Object { $_.Key }) | ConvertTo-Json -Compress)
    $verDataJson   = (@($verCountsSorted | ForEach-Object { $_.Value }) | ConvertTo-Json -Compress)
    $versionByAgentRows = ($versionByAgent.Keys | Sort-Object | ForEach-Object {
      $aid=$_; $ver=$versionByAgent[$aid]; $hn=($hostByAgent[$aid]+''); $ip=($ipByAgent[$aid]+'')
      '<tr><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($aid)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($ver)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($hn)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($ip)+'</td></tr>'
    }) -join "`n"

    # Last scan matrix + chart (agent ids filtered)
    $scanTypes = @('Vulnerability','Patch','Compliance','Software','Discovery','OS/Config','AV/Malware')
    $lastScanByAgentType=@{}; foreach ($fa in $fileAnalyses) {
      if ($fa.AgentID -match '^\d+$' -and ($fa.AgentID -ne $fa.FileName)) {
        if (-not $lastScanByAgentType.ContainsKey($fa.AgentID)) { $lastScanByAgentType[$fa.AgentID]=@{} }
        foreach ($kv in $fa.LastScanByType.GetEnumerator()) {
          $t=[string]$kv.Key; $dt=[datetime]$kv.Value
          if (-not $lastScanByAgentType[$fa.AgentID].ContainsKey($t)) { $lastScanByAgentType[$fa.AgentID][$t]=$dt } elseif ($dt -gt $lastScanByAgentType[$fa.AgentID][$t]) { $lastScanByAgentType[$fa.AgentID][$t]=$dt }
        }
      }
    }
    $scanHeader = '<tr><th>Agent ID</th>' + (($scanTypes | ForEach-Object { '<th>'+[System.Web.HttpUtility]::HtmlEncode($_)+'</th>' }) -join '') + '</tr>'
    $scanRows = @(); $agentsJson = (@($allAgentIDs) | ConvertTo-Json -Compress)
    foreach ($aid in $allAgentIDs) {
      $cells = @('<td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($aid)+'</td>')
      foreach ($t in $scanTypes) {
        $dt = $null; if ($lastScanByAgentType.ContainsKey($aid) -and $lastScanByAgentType[$aid].ContainsKey($t)) { $dt = $lastScanByAgentType[$aid][$t] }
        $cellVal = if ($dt) { $dt.ToString('yyyy-MM-dd HH:mm') } else { '<span class="small">-</span>' }
        $cells += ('<td>' + $cellVal + '</td>')
      }
      $scanRows += ('<tr>'+($cells -join '')+'</tr>')
    }
    $scanTable = '<table class="sticky sortable" id="scanTable"><thead>'+ $scanHeader +'</thead><tbody>'+ ($scanRows -join "`n") +'</tbody></table>'
    $scanDatasets = @()
    foreach ($t in $scanTypes) {
      $vals = @()
      foreach ($aid in $allAgentIDs) {
        $dt = $null; if ($lastScanByAgentType.ContainsKey($aid) -and $lastScanByAgentType[$aid].ContainsKey($t)) { $dt = $lastScanByAgentType[$aid][$t] }
        if ($dt) { try { $epochMs = [Int64]([DateTimeOffset]$dt).ToUnixTimeMilliseconds() } catch { $epochMs = [Int64]([double](Get-Date $dt -UFormat %s) * 1000) }; $vals += $epochMs } else { $vals += $null }
      }
      $scanDatasets += [pscustomobject]@{ label=$t; data=$vals }
    }
    $scanDatasetsJson = ($scanDatasets | ConvertTo-Json -Compress)

    # ====== HTML ======
    Show-ProgressBars -PhaseLabel "Phase 3/3 - Render HTML" -PhasePercent 20 -OverallPercent ($WeightAnalyze + $WeightAggregate + 1) -Status "Building HTML"

    $style = @"
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;cursor:pointer;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:10px;margin:6px 0 10px;}
.kicker h3{margin:0 0 6px 0;}
.badge{display:inline-block;padding:2px 6px;border:1px solid #aaa;border-radius:8px;font-size:12px;color:#555;background:#fafafa;margin-left:6px;}
.summary{background:#fff7e6;border:1px solid #ffd699;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.summary h2{margin:6px 0 8px 0;}
.summary table{width:auto;border-collapse:separate;border-spacing:0 4px;}
.summary td{border:none;padding:2px 10px 2px 0;}
.key{color:#555;font-weight:600;white-space:nowrap;}
.val{color:#000;}
.src{color:#888;font-size:12px;}
.mono{font-family:Consolas,Menlo,monospace;}
.exhdr{font-weight:600;margin:6px 0 2px;}
.sticky thead th{position:sticky;top:0;z-index:2;}
.section{margin:18px 0 22px;}
.chart-wrap{width:100%;max-width:1100px;margin:12px auto;}
.sort-ind::after{content:"";margin-left:6px;}
th.sort-asc::after{content:"  ^";}
th.sort-desc::after{content:"  v";}
</style>
"@

    $sevHeader = '<tr><th>File</th><th>Agent ID</th><th>Host</th><th>Type</th><th style="text-align:right">Total Severity</th></tr>'
    $sevRows = ($severityByFile | ForEach-Object {
      '<tr><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($_.File)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($_.AgentID)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($_.Host)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode($_.Type)+'</td><td data-num="'+$_.TotalSeverity+'" style="text-align:right">'+$_.TotalSeverity+'</td></tr>'
    }) -join "`n"

    $csHeader = '<tr><th data-num="1">Total</th><th>Type</th><th>URL / Host</th>' + (($allAgentIDs | ForEach-Object {
      $h = if ($primaryHostByAgent.ContainsKey($_)) { $primaryHostByAgent[$_] } else { '(unknown)' }
      '<th class="mono" title="Primary host: '+[System.Web.HttpUtility]::HtmlEncode($h)+'">'+[System.Web.HttpUtility]::HtmlEncode($_)+'</th>'
    }) -join '') + '</tr>'

    $csRows = @()
    foreach ($url in $csUrlsSorted) {
      $tot = [int]$csUrlTotals[$url]
      $typestr = ''
      if ($csUrlTypeTotals.ContainsKey($url)) {
        $kv = $csUrlTypeTotals[$url].GetEnumerator() | Sort-Object -Property Value -Descending
        $typestr = (($kv | ForEach-Object { $_.Key + ':' + $_.Value }) -join ', ')
      }
      $cells=@()
      foreach ($aid in $allAgentIDs) {
        $v = if ($csPivot[$url].ContainsKey($aid)) { [int]$csPivot[$url][$aid] } else { 0 }
        $cells += ('<td data-num="'+$v+'" style="text-align:right">'+$v+'</td>')
      }
      $csRows += ('<tr><td data-num="'+$tot+'" style="text-align:right"><strong>'+ $tot +'</strong></td><td>'+[System.Web.HttpUtility]::HtmlEncode($typestr)+'</td><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($url)+'</td>'+($cells -join '')+'</tr>')
    }
    $csTable = '<table class="sticky sortable" id="csTable"><thead>'+ $csHeader +'</thead><tbody>'+ ($csRows -join "`n") +'</tbody></table>'

    $thirdHeader = '<tr><th data-num="1">Total</th><th>URL</th>' + (@($thirdFiles | ForEach-Object {
      $aid = if ($relToAid.ContainsKey($_)) { $relToAid[$_] } else { '' }
      $hn  = if ($relToHost.ContainsKey($_)) { $relToHost[$_] } else { '' }
      '<th><div class="mono">'+[System.Web.HttpUtility]::HtmlEncode($_)+'</div><div class="small">'+[System.Web.HttpUtility]::HtmlEncode(($aid+' / '+$hn))+'</div></th>'
    }) -join '') + '</tr>'

    $thirdRows = @()
    foreach ($url in $thirdUrlsSorted) {
      $tot = [int]$thirdTotals[$url]
      $cells=@()
      foreach ($fp in $thirdFiles) {
        $v = if ($thirdPivot[$url].ContainsKey($fp)) { [int]$thirdPivot[$url][$fp] } else { 0 }
        $cells += ('<td data-num="'+$v+'" style="text-align:right">'+$v+'</td>')
      }
      $thirdRows += ('<tr><td data-num="'+$tot+'" style="text-align:right"><strong>'+ $tot +'</strong></td><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($url)+'</td>'+($cells -join '')+'</tr>')
    }
    $thirdTable = if (@($thirdFiles).Count -gt 0) {
      '<table class="sticky sortable" id="thirdTable"><thead>'+ $thirdHeader +'</thead><tbody>'+ ($thirdRows -join "`n") +'</tbody></table>'
    } else {
      '<div class="kicker">No patch logs with 3rd-party URLs were found.</div>'
    }

    # Collapsed families
    $thirdCollapsedHtml = @()
    foreach ($fam in $thirdCollapsedSorted) {
      $map = $thirdCollapsed[$fam]
      $famTotal = ($map.GetEnumerator() | Measure-Object -Property Value -Sum).Sum
      $rows = ($map.GetEnumerator() | Sort-Object -Property Value -Descending | ForEach-Object {
        '<tr><td style="text-align:right" data-num="'+$_.Value+'">'+$_.Value+'</td><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($_.Key)+'</td></tr>'
      }) -join "`n"
      $thirdCollapsedHtml += @"
<details>
  <summary>$famTotal x - $fam</summary>
  <table class="sticky sortable"><thead><tr><th data-num="1">Total</th><th>URL</th></tr></thead><tbody>
  $rows
  </tbody></table>
</details>
"@
    }
    $thirdCollapsedBlock = ($thirdCollapsedHtml -join "`n")

    function Build-CommonSectionHtml {
      param([string]$SectionName,[hashtable]$patterns,[hashtable]$perFileMap)
      $htmlParts=@()
      $ordered = $patterns.GetEnumerator() | Sort-Object -Property Value -Descending
      foreach ($kv in $ordered) {
        $norm=[string]$kv.Key
        $count=[int]$kv.Value
        $count24 = if ($last24ByPattern.ContainsKey($norm)) { [int]$last24ByPattern[$norm] } else { 0 }

        $per = if ($perFileMap.ContainsKey($norm)) { $perFileMap[$norm] } else { @{} }
        $perSorted = $per.GetEnumerator() | Sort-Object -Property Value -Descending
        $perRows = ($perSorted | ForEach-Object {
          $f = [string]$_.Key
          $aid = if ($relToAid.ContainsKey($f)) { $relToAid[$f] } else { '' }
          $hn  = if ($relToHost.ContainsKey($f)) { $relToHost[$f] } else { '' }
          $fa  = if ($relToFA.ContainsKey($f)) { $relToFA[$f] } else { $null }
          $cnt24 = 0; if ($fa -and $fa.PatternCountLast24.ContainsKey($norm)) { $cnt24 = [int]$fa.PatternCountLast24[$norm] }
          '<tr><td class="mono">'+[System.Web.HttpUtility]::HtmlEncode($f)+'</td><td>'+[System.Web.HttpUtility]::HtmlEncode(($aid+' | '+$hn))+'</td><td data-num="'+$_.Value+'" style="text-align:right">'+$_.Value+'</td><td data-num="'+$cnt24+'" style="text-align:right">'+$cnt24+'</td></tr>'
        }) -join "`n"

        $examplesBlocks = @()
        $orderedFiles = @($perSorted | ForEach-Object { $_.Key })
        if ($orderedFiles.Count -eq 0 -and $examplesPerPattern.ContainsKey($norm)) { $orderedFiles = @($examplesPerPattern[$norm].Keys) }

        if ($examplesPerPattern.ContainsKey($norm)) {
          $exMap = $examplesPerPattern[$norm]
          foreach ($f in $orderedFiles) {
            if (-not $exMap.ContainsKey($f)) { continue }
            $ex = $exMap[$f]
            $ts = if ($ex.Timestamp) { ([datetime]$ex.Timestamp).ToString('yyyy-MM-dd HH:mm') } else { '-' }
            $aid = if ($relToAid.ContainsKey($f)) { $relToAid[$f] } else { '' }
            $hn  = if ($relToHost.ContainsKey($f)) { $relToHost[$f] } else { '' }
            $examplesBlocks += ('<div class="ex"><div class="exhdr"><span class="mono">['+ $ts + ']</span> ' + [System.Web.HttpUtility]::HtmlEncode($f) + ' - ' + [System.Web.HttpUtility]::HtmlEncode(($aid+' | '+$hn)) + '</div>' + $ex.ContextHtml + '</div>')
          }
        }

        $htmlParts += @"
<details>
  <summary>$count x (Last 24h: $count24) - <span class="mono">$( [System.Web.HttpUtility]::HtmlEncode($norm) )</span></summary>
  <div class="kicker"><strong>By file</strong></div>
  <table class="sticky sortable"><thead><tr><th>File</th><th>ID | Host</th><th data-num="1" style="text-align:right">Count</th><th data-num="1" style="text-align:right">Last 24h</th></tr></thead><tbody>
    $perRows
  </tbody></table>
  <div class="kicker"><strong>Examples (one per file)</strong></div>
  $($examplesBlocks -join "`n")
</details>
"@
      }
      if ($htmlParts.Count -eq 0) { return '<div class="small">No messages found for this section.</div>' }
      return ($htmlParts -join "`n")
    }

    $commonRegularHtml   = Build-CommonSectionHtml -SectionName 'Regular'   -patterns $byTypePatterns['Regular']   -perFileMap $byTypePerFile['Regular']
    $commonUtilitiesHtml = Build-CommonSectionHtml -SectionName 'Utilities' -patterns $byTypePatterns['Utilities'] -perFileMap $byTypePerFile['Utilities']
    $commonPatchHtml     = Build-CommonSectionHtml -SectionName 'Patch'     -patterns $byTypePatterns['Patch']     -perFileMap $byTypePerFile['Patch']
    $commonOtherHtml     = Build-CommonSectionHtml -SectionName 'Other'     -patterns $byTypePatterns['Other']     -perFileMap $byTypePerFile['Other']

    $timeRange = 'n/a'
    if ($overallFirst -and $overallLast) { $timeRange = $overallFirst.ToString('yyyy-MM-dd HH:mm') + ' -> ' + $overallLast.ToString('yyyy-MM-dd HH:mm') }

    $summaryTable = @"
<table>
<tr><td class="key">Root</td><td class="val mono">$([System.Web.HttpUtility]::HtmlEncode($rootAbs))</td></tr>
<tr><td class="key">cybercns*.log files</td><td class="val">$($cybercnsLogFiles.Count)</td></tr>
<tr><td class="key">Number of secondary log files</td><td class="val">$([Math]::Max(0,$logFilesOnly.Count - $cybercnsLogFiles.Count))</td></tr>
<tr><td class="key">Total size analyzed (MB)</td><td class="val">$totalMB</td></tr>
<tr><td class="key">Total lines analyzed</td><td class="val">$totalLines</td></tr>
<tr><td class="key">Total severity (all logs)</td><td class="val">$overallSeverity</td></tr>
<tr><td class="key">Time range</td><td class="val">$timeRange</td></tr>
</table>
"@

    $versionHeader = '<tr><th>Agent ID</th><th>Version</th><th>Hostname</th><th>IP</th></tr>'

    $html = @"
<!doctype html>
<html><head><meta charset="utf-8"><title>ConnectSecure - Agent Log Correlator</title>
$style
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// basic table sort (click header). numeric if cell or header has data-num attr; else text.
(function(){
  function getCellVal(td){var v=td.getAttribute('data-num'); if(v!==null) return parseFloat(v)||0; return (td.textContent||'').toLowerCase();}
  function sortTable(tbl, idx, asc){
    var tbody = tbl.tBodies[0]; var rows=[].slice.call(tbody.querySelectorAll('tr'));
    rows.sort(function(a,b){
      var A=getCellVal(a.children[idx]||document.createElement('td'));
      var B=getCellVal(b.children[idx]||document.createElement('td'));
      if(typeof A==='number' && typeof B==='number'){return asc?(A-B):(B-A);}
      return asc? String(A).localeCompare(String(B)) : String(B).localeCompare(String(A));
    });
    rows.forEach(function(r){tbody.appendChild(r);});
  }
  document.addEventListener('click',function(e){
    var th=e.target.closest('th'); if(!th) return;
    var table=th.closest('table'); if(!table || !table.classList.contains('sortable')) return;
    var idx=[].slice.call(th.parentNode.children).indexOf(th);
    var asc = !(th.classList.contains('sort-asc'));
    [].forEach.call(th.parentNode.children,function(h){h.classList.remove('sort-asc','sort-desc');});
    th.classList.add(asc?'sort-asc':'sort-desc');
    sortTable(table, idx, asc);
  });
})();
</script>
</head><body>
<div class="logo-wrap"><img src="$LogoUrl" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Agent Log Correlator</h1>
<div class="summary"><h2>Summary</h2>$summaryTable</div>

<div class="section"><h2>Severity by Log File <span class="badge">highest -> lowest</span></h2>
<table class="sticky sortable"><thead>$sevHeader</thead><tbody>
$sevRows
</tbody></table></div>

<div class="section"><h2>ConnectSecure Servers - URL x Agent ID</h2>$csTable</div>

<div class="section"><h2>3rd-Party Updates - URL x File <span class="badge">patch logs only</span></h2>$thirdTable
<div class="kicker"><h3>3rd Party Application Collapsed</h3>$thirdCollapsedBlock</div>
</div>

<div class="section"><h2>Common Severity Messages - Regular Logs</h2>$commonRegularHtml</div>
<div class="section"><h2>Common Severity Messages - Utilities Logs</h2>$commonUtilitiesHtml</div>
<div class="section"><h2>Common Severity Messages - Patch Logs</h2>$commonPatchHtml</div>
<div class="section"><h2>Common Severity Messages - Other Logs</h2>$commonOtherHtml</div>

<div class="section"><h2>Agent Version Review</h2>
<table class="sticky sortable"><thead>$versionHeader</thead><tbody>$versionByAgentRows</tbody></table>
<div class="chart-wrap"><canvas id="versionChart"></canvas></div></div>

<div class="section"><h2>Last Scan Review</h2>$scanTable
<div class="chart-wrap"><canvas id="scanChart"></canvas></div>
<div class="small">Note: chart Y-axis shows date (epoch). Hover for tooltip.</div></div>

<script>
(function(){var c=document.getElementById('versionChart').getContext('2d');
new Chart(c,{type:'bar',data:{labels:$verLabelsJson,datasets:[{label:'Agents per Version',data:$verDataJson}]},
options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{ticks:{autoSkip:false,maxRotation:60,minRotation:0}},y:{beginAtZero:true,precision:0}}}})})();
(function(){var c=document.getElementById('scanChart').getContext('2d');
new Chart(c,{type:'line',data:{labels:$agentsJson,datasets:$scanDatasetsJson},
options:{responsive:true,interaction:{mode:'nearest',intersect:false},parsing:{xAxisKey:undefined,yAxisKey:undefined},
scales:{x:{ticks:{autoSkip:false,maxRotation:60,minRotation:0}},y:{beginAtZero:false,ticks:{callback:function(v){var d=new Date(v);if(isNaN(d))return'';return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}},title:{display:true,text:'Last scan date'}}}})})();
</script>
</body></html>
"@

    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html)
    [System.IO.File]::WriteAllBytes($OutHtmlPath, $bytes) | Out-Null

    Show-ProgressBars -PhaseLabel "Phase 3/3 - Render HTML" -PhasePercent 100 -OverallPercent 100 -Status "Done"

    Write-Host ''
    if (Test-Path -LiteralPath $OutHtmlPath) {
      $size = (Get-Item -LiteralPath $OutHtmlPath).Length
      Write-OK ("HTML exported to: ""{0}"" ({1} bytes)" -f $OutHtmlPath, $size)
    } else {
      Write-Err ("HTML file not found at: {0}" -f $OutHtmlPath)
    }

    $opened = $false
    foreach ($method in 1..4) {
      try {
        if ($method -eq 1) { Start-Process -FilePath $OutHtmlPath -Verb Open -ErrorAction Stop | Out-Null }
        elseif ($method -eq 2) { Start-Process -FilePath "cmd.exe" -ArgumentList @('/c','start','','"'+$OutHtmlPath+'"') -WindowStyle Hidden -ErrorAction Stop | Out-Null }
        elseif ($method -eq 3) { Start-Process -FilePath "explorer.exe" -ArgumentList @('"' + $OutHtmlPath + '"') -ErrorAction Stop | Out-Null }
        else { Invoke-Item -Path $OutHtmlPath -ErrorAction Stop }
        $opened = $true
        Write-Info ("Opened report using method {0}" -f $method)
        break
      } catch { Write-Warn ("Open method {0} failed: {1}" -f $method, $_.Exception.Message); Start-Sleep -Milliseconds 300 }
    }
    if (-not $opened) { Write-Warn "Could not auto-open the report. Open it manually using the path above." }

    while ($true) {
      $resp = Read-Host 'Type "open" to open again, "path" to print the report path, or press Enter to return to the menu'
      if ([string]::IsNullOrWhiteSpace($resp)) { break }
      if ($resp -match '^(?i)open$') { try { Invoke-Item -Path $OutHtmlPath -ErrorAction Stop } catch { Write-Warn ("Open failed: {0}" -f $_.Exception.Message) }; continue }
      if ($resp -match '^(?i)path$') { Write-Host $OutHtmlPath; continue }
      Write-Warn 'Unknown command. Type "open", "path", or press Enter.'
    }
  }
  catch {
    $er = $_
    $ex = $er.Exception
    Write-Host ''
    Write-Host '============= Correlator caught an error =============' -ForegroundColor Red
    Write-Host ('Type   : {0}' -f ($ex.GetType().FullName)) -ForegroundColor Red
    Write-Host ('Message: {0}' -f $ex.Message) -ForegroundColor Red
    if ($er.InvocationInfo) {
      Write-Host ('Script : {0}' -f $er.InvocationInfo.ScriptName) -ForegroundColor Red
      Write-Host ('Line   : {0}' -f $er.InvocationInfo.ScriptLineNumber) -ForegroundColor Red
      Write-Host ('Column : {0}' -f $er.InvocationInfo.OffsetInLine) -ForegroundColor Red
      Write-Host '---- Position ----' -ForegroundColor Red
      Write-Host $er.InvocationInfo.PositionMessage -ForegroundColor Red
    }
    if ($er.ScriptStackTrace) {
      Write-Host '---- Script Stack Trace ----' -ForegroundColor Red
      Write-Host $er.ScriptStackTrace -ForegroundColor Red
    }
    try {
      $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
      $base = if ($Global:AGL_LastHtmlPath) { Split-Path -Parent $Global:AGL_LastHtmlPath } else { Get-Location }
      $logPath = Join-Path $base ("Agent-Log-Correlator-Diagnostics_{0}.log" -f $ts)
      $diag = @()
      $diag += "[{0}] ERROR" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
      $diag += "Message: {0}" -f $ex.Message
      if ($er.InvocationInfo) {
        $diag += "Script : {0}" -f $er.InvocationInfo.ScriptName
        $diag += "Line   : {0}" -f $er.InvocationInfo.ScriptLineNumber
        $diag += "Column : {0}" -f $er.InvocationInfo.OffsetInLine
        $diag += "Position:"
        $diag += $er.InvocationInfo.PositionMessage
      }
      if ($er.ScriptStackTrace) { $diag += "ScriptStackTrace:`n$($er.ScriptStackTrace)" }
      if ($ex.InnerException) { $diag += "InnerException:`n$($ex.InnerException | Format-List * -Force | Out-String)" }
      Set-Content -LiteralPath $logPath -Value ($diag -join [Environment]::NewLine) -Encoding UTF8 -Force
      Write-Host ("Diagnostics written to: {0}" -f $logPath) -ForegroundColor Yellow
    } catch {}
    Write-Host ''
    Write-Host 'Press Enter to return to the correlator menu...' -ForegroundColor Gray
    Read-Host | Out-Null
  }
  finally {
    Write-Progress -Id 1 -Completed -Activity "Agent Log Correlator"
    Write-Progress -Id 0 -Completed -Activity "Overall"
  }
}

function Start-AgentLogCorrelator {
  while ($true) {
    Clear-Host
    Write-Host '==============================================' -ForegroundColor DarkCyan
    Write-Host ' ConnectSecure - Agent Log Correlator' -ForegroundColor DarkCyan
    Write-Host '==============================================' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '1) Analyze a target directory'
    Write-Host 'Q) Quit'
    Write-Host ''
    $choice = Read-Host 'Choose an option'
    switch ($choice) {
      '1' {
        $root = Read-Host 'Enter the full path to the directory to analyze'
        if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) { Write-Warn 'Invalid path. Press Enter to continue.'; Read-Host | Out-Null; continue }
        $out = Read-Host 'Optional: enter a full path for the HTML report (or leave blank to save in the root)'
        try { Correlate-AgentLogs -Root $root -OutHtmlPath $out } catch { Write-Err ("Correlation failed: {0}" -f $_.Exception.Message); Write-Host 'Press Enter to return to the menu...'; Read-Host | Out-Null }
      }
      'Q' { return }
      'q' { return }
      Default { Write-Warn 'Invalid choice.'; Start-Sleep -Milliseconds 900 }
    }
  }
}

Start-AgentLogCorrelator
