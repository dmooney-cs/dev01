<# ====================================================
  Agent-Log-Correlator.ps1  (v1.9h)
  - ASCII only; PS 5.1 compatible
  - Avoids automatic $Host collision
  - Excludes Agent-Log-Correlator-Diagnostics_*.log from analysis
  - Deduplicate .log files by (Name + Size); skip duplicates
  - Strict Y/N gate for correlation prompt (interactive only)
  - Progress with ETA every 15 seconds (interactive only)
  - Summary:
      * Number of cybercns*.log
      * Number of secondary log files
      * Duplicate log files skipped
      * Total MB, total lines, total severity, time range
  - Agent inference:
      * If any file in a folder has a real AgentID/Host/IP,
        assume all files in that folder belong to that same agent.
  - Severity view:
      * Aggregated by AgentID (Total Severity)
      * Each row has collapsible table of that agent's logs (file, type, severity)
  - CS Servers pivot:
      * COLLAPSED BY PARENT URL (scheme+host)
      * Parent row shows total hits per Agent ID
      * Child URLs listed inside details under each parent
  - 3rd-party pivot (patch logs only):
      * COLLAPSED BY PARENT URL (scheme+host)
      * Parent row shows total hits per File
      * Child URLs listed inside details under each parent
      * Collapsed "App Family" with totals and drilldown retained
  - Common Severity Messages:
      * Regular logs split into:
          - "Common" (patterns seen in >= 2 Regular log files)
          - "Outliers" (patterns seen in exactly 1 Regular log file with high count)
      * Utilities, Patch, Other logs normal sections
      * Per-file totals and Last 24h counts
      * One example block per file, with timestamps
      * SUMMARY INCLUDES: count of log files containing each pattern
  - Version Review:
      * Excludes Unknown versions
      * Includes Hostname and IP
  - Last Scan Review:
      * Excludes rows where AgentID equals log filename, and not a number

  NEW SWITCHES (same behavior pattern as agent-msg-correlator):
    -DefaultLog / -DefaultLogs
        * Uses default agent log path automatically:
            C:\Program Files (x86)\CyberCNSAgent\logs
        * Quiet + Silent (no chatter/progress/menus)
        * Skips interactive menu entirely
        * Forces HTML export (no prompt), does NOT auto-open

    -Html
        * Forces HTML export (no prompt)
        * Does NOT auto-open

    -ExportOnly
        * Uses default agent log path automatically
        * Quiet + Silent
        * Forces HTML export (no prompt), does NOT auto-open
        * Exits after export (no menu)

    -LogPath <path>
        * Quiet + Silent
        * Forces HTML export (no prompt), does NOT auto-open
        * Skips menu

====================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [Alias('DefaultLogs')]
    [switch]$DefaultLog,
    [switch]$Html,
    [switch]$ExportOnly,
    [string]$LogPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$PSDefaultParameterValues['*:ErrorAction'] = 'Stop'

# -----------------------------
# Defaults / global flags
# -----------------------------
$Global:AGL_DefaultAgentLogRoot = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$Global:AGL_CollectedOutRoot    = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'

$Global:AGL_Quiet     = $false
$Global:AGL_Silent    = $false
$Global:AGL_AutoHtml  = $false
$Global:AGL_OpenHtml  = $true
$Global:AGL_LastHtmlPath = $null

# Match "same changes" behavior:
if ($DefaultLog -or $ExportOnly -or ($LogPath -and $LogPath.Trim().Length -gt 0)) {
    $Global:AGL_Quiet  = $true
    $Global:AGL_Silent = $true
    $ProgressPreference = 'SilentlyContinue'
}
if ($Html -or $ExportOnly -or $DefaultLog -or ($LogPath -and $LogPath.Trim().Length -gt 0)) {
    $Global:AGL_AutoHtml = $true
    $Global:AGL_OpenHtml = $false
}

trap {
    $ex = $_.Exception
    if (-not $Global:AGL_Silent) {
        Write-Host ''
        Write-Host '============= Agent-Log-Correlator ERROR =============' -ForegroundColor Red
        Write-Host ('Type   : {0}' -f ($ex.GetType().FullName)) -ForegroundColor Red
        Write-Host ('Message: {0}' -f $ex.Message) -ForegroundColor Red
        if ($_.InvocationInfo) {
            Write-Host ('Script : {0}' -f $_.InvocationInfo.ScriptName) -ForegroundColor Red
            Write-Host ('Line   : {0}' -f $_.InvocationInfo.ScriptLineNumber) -ForegroundColor Red
            Write-Host ('Column : {0}' -f $_.InvocationInfo.OffsetInLine) -ForegroundColor Red
            Write-Host '---- Position ----' -ForegroundColor Red
            Write-Host $_.InvocationInfo.PositionMessage -ForegroundColor Red
        }
        if ($_.ScriptStackTrace) {
            Write-Host '---- Script Stack Trace ----' -ForegroundColor Red
            Write-Host $_.ScriptStackTrace -ForegroundColor Red
        }
        if ($ex.InnerException) {
            Write-Host '---- Inner Exception ----' -ForegroundColor Red
            Write-Host ($ex.InnerException | Format-List * -Force | Out-String) -ForegroundColor Red
        }
    }

    try {
        $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
        $base = if ($Global:AGL_LastHtmlPath) { Split-Path -Parent $Global:AGL_LastHtmlPath } else { Get-Location }
        $logPathDiag = Join-Path $base ("Agent-Log-Correlator-Diagnostics_{0}.log" -f $ts)
        $diag = @()
        $diag += "[{0}] ERROR" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        $diag += "Message: {0}" -f $ex.Message
        if ($_.InvocationInfo) {
            $diag += "Script : {0}" -f $_.InvocationInfo.ScriptName
            $diag += "Line   : {0}" -f $_.InvocationInfo.ScriptLineNumber
            $diag += "Column : {0}" -f $_.InvocationInfo.OffsetInLine
            $diag += "Position:"
            $diag += $_.InvocationInfo.PositionMessage
        }
        if ($_.ScriptStackTrace) { $diag += "ScriptStackTrace:`n$($_.ScriptStackTrace)" }
        if ($ex.InnerException)  { $diag += "InnerException:`n$($ex.InnerException | Format-List * -Force | Out-String)" }
        Set-Content -LiteralPath $logPathDiag -Value ($diag -join [Environment]::NewLine) -Encoding UTF8 -Force
        if (-not $Global:AGL_Silent) {
            Write-Host ("Diagnostics written to: {0}" -f $logPathDiag) -ForegroundColor Yellow
            Write-Host ''
            Write-Host 'Press Enter after selection to return to the correlator menu...' -ForegroundColor Gray
            Read-Host | Out-Null
        }
    } catch {}

    continue
}

try {
    $null = [System.Web.HttpUtility]::HtmlEncode('x')
} catch {
    try { Add-Type -AssemblyName System.Web -ErrorAction SilentlyContinue } catch {}
}

# ---- Tunables ----
$LogoUrl               = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$FoldUrlToHost         = $true
$MaxExamplesPerPattern = 8
$ContextBefore         = 2
$ContextAfter          = 2
$LargeFileContextMB    = 25
$MaxCommonMessages     = 300
$ProgressRefreshSec    = 15
$WeightAnalyze         = 80
$WeightAggregate       = 15
$WeightRender          = 5
$OutlierMinCount       = 25

$script:StartTime = $null
$script:LastTick  = Get-Date

function Write-Info { param([string]$Msg) if ($Global:AGL_Quiet) { return } Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan }
function Write-OK   { param([string]$Msg) if ($Global:AGL_Silent) { return } Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green }
function Write-Warn { param([string]$Msg) if ($Global:AGL_Quiet) { return } Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow }
function Write-Err  { param([string]$Msg) if ($Global:AGL_Silent) { return } Write-Host ("[ERR]   {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Red }

function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
    }
}

function New-Eta {
    param([int]$Done,[int]$Total)
    if ($Done -le 0 -or -not $script:StartTime) { return 'estimating...' }
    $elapsed = (Get-Date) - $script:StartTime
    $perItem = [TimeSpan]::FromTicks([int64]([double]$elapsed.Ticks / [Math]::Max(1,$Done)))
    $remain  = [TimeSpan]::FromTicks($perItem.Ticks * [Math]::Max(0, $Total - $Done))
    return $remain.ToString("hh\:mm\:ss")
}

function Should-Tick {
    $now = Get-Date
    if (($now - $script:LastTick).TotalSeconds -ge $ProgressRefreshSec) {
        $script:LastTick = $now
        return $true
    }
    return $false
}

function Show-ProgressBars {
    param(
        [string]$PhaseLabel,
        [int]$PhasePercent,
        [int]$OverallPercent,
        [string]$Status
    )
    if ($Global:AGL_Silent) { return }
    if ($PhasePercent   -lt 0)   { $PhasePercent   = 0 }
    if ($PhasePercent   -gt 100) { $PhasePercent   = 100 }
    if ($OverallPercent -lt 0)   { $OverallPercent = 0 }
    if ($OverallPercent -gt 100) { $OverallPercent = 100 }
    Write-Progress -Id 1 -Activity ("Agent Log Correlator - {0}" -f $PhaseLabel) -Status $Status -PercentComplete $PhasePercent
    Write-Progress -Id 0 -Activity "Overall" -Status ("{0}% complete" -f $OverallPercent) -PercentComplete $OverallPercent
}

function Read-FileLines {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return @() }
    try     { return [System.IO.File]::ReadLines($Path) }
    catch   { try { return Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue } catch { return @() } }
}

function Get-RelativePath {
    param(
        [Parameter(Mandatory)][string]$Base,
        [Parameter(Mandatory)][string]$Full
    )
    try {
        $baseUri = (Resolve-Path -LiteralPath $Base -ErrorAction Stop).ProviderPath
        $fullUri = (Resolve-Path -LiteralPath $Full -ErrorAction Stop).ProviderPath
        $u1 = [System.Uri]("file://" + ($baseUri -replace '\','/').TrimEnd('/') + '/')
        $u2 = [System.Uri]("file://" + ($fullUri -replace '\','/'))
        $rel = $u1.MakeRelativeUri($u2).ToString()
        return [System.Uri]::UnescapeDataString($rel) -replace '/','\'
    } catch {
        return (Split-Path -Leaf $Full)
    }
}

function TryParse-LineDateTime {
    param(
        [string]$Line,
        [datetime]$FallbackDate
    )
    if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

    $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
    if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

    $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
    if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

    $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
    if ($m.Success -and $FallbackDate) {
        try {
            $h  = [int]$m.Groups[1].Value.Substring(0,2)
            $mi = [int]$m.Groups[1].Value.Substring(3,2)
            $s  = [int]$m.Groups[1].Value.Substring(6,2)
            return ($FallbackDate.Date.AddHours($h).AddMinutes($mi).AddSeconds($s))
        } catch {}
    }
    return $null
}

function Normalize-LineForPattern {
    param([string]$Line)
    if ($null -eq $Line) { return '' }
    $norm = $Line
    $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
    $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
    if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
    $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
    $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
    $norm = $norm -replace '(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)','{IP}'
    $norm = $norm -replace '\b\d+\b','{N}'
    $norm = $norm -replace '\s+',' '
    $norm = $norm.Trim()
    if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
    return $norm
}

function Test-IsCsHost {
    param([Parameter(Mandatory)][string]$HostName)
    $h = $HostName.ToLowerInvariant()
    foreach ($root in @('myconnectsecure.com','mycybercns.com')) {
        if ($h -eq $root -or $h -like ('*.'+$root)) { return $true }
    }
    return $false
}

function Get-LogTypeFromName {
    param([string]$FileName)
    $n = ($FileName | Split-Path -Leaf).ToLowerInvariant()
    if ($n -match 'patch')                          { return 'Patch' }
    if ($n -match 'util|utility|utilities|monitor') { return 'Utilities' }
    if ($n -match '^cybercns.*\.log$')              { return 'Regular' }
    if ($n -match 'cybercns')                       { return 'Regular' }
    return 'Other'
}

function Get-HttpOrHttpsUrlCountsFromLog {
    param([Parameter(Mandatory)][string]$LogPath)
    $counts = @{}
    if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
    $lines = Read-FileLines -Path $LogPath
    if (@($lines).Count -eq 0) { return $counts }
    $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
    foreach ($ln in $lines) {
        foreach ($m in $urlRegex.Matches([string]$ln)) {
            $u = [string]$m.Value
            if ([string]::IsNullOrWhiteSpace($u)) { continue }
            while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
            if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
            $counts[$u]++
        }
    }
    return $counts
}

function Get-CsServersFromLog {
    param([Parameter(Mandatory)][string]$LogPath)
    $counts = @{}
    if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
    $lines = Read-FileLines -Path $LogPath
    if (@($lines).Count -eq 0) { return $counts }
    $urlRegex     = [regex]'https?://[^\s"''\]\)<>]+'
    $hostRegexNet = [regex]'(?i)\b([a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:myconnectsecure\.com|mycybercns\.com))\b'
    foreach ($ln in $lines) {
        foreach ($m in $urlRegex.Matches([string]$ln)) {
            $u = [string]$m.Value
            if ([string]::IsNullOrWhiteSpace($u)) { continue }
            while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
            $urlHost = $null
            try { $urlHost = ([Uri]$u).Host }
            catch {
                $hm = [regex]::Match($u,'^https?://([^/:?#]+)')
                if ($hm.Success) { $urlHost = $hm.Groups[1].Value }
            }
            if ($urlHost -and (Test-IsCsHost -HostName $urlHost)) {
                if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
                $counts[$u]++
            }
        }
        $h = $hostRegexNet.Match([string]$ln)
        if ($h.Success) {
            $hostOnly = $h.Groups[1].Value
            if (-not $counts.ContainsKey($hostOnly)) { $counts[$hostOnly] = 0 }
            $counts[$hostOnly]++
        }
    }
    return $counts
}

# -----------------------------
# (UNCHANGED) Analyze-LogFile and all other functions...
# -----------------------------
# NOTE: Everything below this point is unchanged EXCEPT for prompt text that now includes:
#       "press Enter after selection" where interactive input is expected.
#       No logic or existing behavior has been removed.

function Analyze-LogFile {
    param([Parameter(Mandatory)][string]$FilePath)

    $result = [ordered]@{
        FilePath            = $FilePath
        FileName            = [IO.Path]::GetFileName($FilePath)
        RelPath             = $null
        LogType             = 'Other'
        AgentID             = $null
        AgentVersion        = $null
        HostName            = $null
        IP                  = $null
        SeverityTotal       = 0
        CountsByLevel       = @{}
        CsUrlCounts         = @{}
        ThirdPartyUrlCounts = @{}
        CommonPatterns      = @{}
        PatternExamples     = @{}
        ExampleByPattern    = @{}
        PatternCountLast24  = @{}
        LastScanByType      = @{}
        FirstTimestamp      = $null
        LastTimestamp       = $null
        LineCount           = 0
        FileBytes           = 0L
    }

    $result.LogType = Get-LogTypeFromName -FileName $result.FileName

    $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
    $countsByLevel = @{
        ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0
    }

    $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
    $limitCtx = $false
    if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

    $lines = Read-FileLines -Path $FilePath
    $lines = @($lines)
    $result.LineCount = $lines.Count
    if ($file) { $result.FileBytes = $file.Length }
    if ($lines.Count -eq 0) { return $result }

    $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }

    foreach ($ln in $lines) {
        if ($null -eq $result.AgentID      -and $ln -match '\[Agent ID\s*:-\s*([^\]]+)\]')                             { $result.AgentID      = $Matches[1].Trim() }
        if ($null -eq $result.AgentVersion -and $ln -match '\[Agent version\s*:-\s*([^\]]+)\]')                        { $result.AgentVersion = $Matches[1].Trim() }
        if ($null -eq $result.HostName     -and $ln -match '\[(?:Host(?:\s*Name)?|Hostname)\s*:-\s*([^\]]+)\]')        { $result.HostName     = $Matches[1].Trim() }
        if ($null -eq $result.IP           -and $ln -match '\[(?:IP|IP Address)\s*:-\s*([^\]]+)\]')                    { $result.IP           = $Matches[1].Trim() }

        if ($null -eq $result.AgentID      -and $ln -match '(?i)\bAgent\s*ID\s*[:=]\s*([A-Za-z0-9\-\{\}]+)')           { $result.AgentID      = $Matches[1].Trim() }
        if ($null -eq $result.AgentVersion -and $ln -match '(?i)\bAgent\s*Version\s*[:=]\s*([0-9][0-9A-Za-z\.\-_]+)') { $result.AgentVersion = $Matches[1].Trim() }
        if ($null -eq $result.HostName     -and $ln -match '(?i)\bHost(?:\s*Name)?\s*[:=]\s*([A-Za-z0-9\.\-]+)')       { $result.HostName     = $Matches[1].Trim() }
        if ($null -eq $result.IP           -and $ln -match '(?i)\bIP(?:\s*Address)?\s*[:=]\s*(([0-9]{1,3}\.){3}[0-9]{1,3})') { $result.IP = $Matches[1].Trim() }

        $dt0 = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate
        if ($dt0) {
            if (-not $result.FirstTimestamp) { $result.FirstTimestamp = $dt0 }
            if (-not $result.LastTimestamp  -or $dt0 -gt $result.LastTimestamp) { $result.LastTimestamp = $dt0 }
        }
    }

    if ([string]::IsNullOrWhiteSpace($result.AgentID)) {
        $p    = Split-Path -Parent $FilePath
        $name = Split-Path -Leaf $p
        if ($name -match '^[0-9A-Fa-f\-]{6,36}$') { $result.AgentID = $name }
    }
    if ([string]::IsNullOrWhiteSpace($result.AgentID))  { $result.AgentID  = $result.FileName }
    if ([string]::IsNullOrWhiteSpace($result.HostName)) { $result.HostName = '(unknown)' }
    if ([string]::IsNullOrWhiteSpace($result.IP))       { $result.IP       = '' }

    $fileAnchor = $result.LastTimestamp

    $result.CsUrlCounts = Get-CsServersFromLog -LogPath $FilePath
    $urlCounts          = Get-HttpOrHttpsUrlCountsFromLog -LogPath $FilePath
    foreach ($kv in $urlCounts.GetEnumerator()) {
        $u = [string]$kv.Key
        $uHost = $null
        try { $uHost = ([Uri]$u).Host }
        catch {
            $hm = [regex]::Match($u,'^https?://([^/:?#]+)')
            if ($hm.Success) { $uHost=$hm.Groups[1].Value }
        }
        if ($uHost -and (Test-IsCsHost -HostName $uHost)) { continue }
        if (-not $result.ThirdPartyUrlCounts.ContainsKey($u)) { $result.ThirdPartyUrlCounts[$u] = 0 }
        $result.ThirdPartyUrlCounts[$u] += [int]$kv.Value
    }

    $contexts   = @{}
    $exampleCap = if ($limitCtx) { [Math]::Min($MaxExamplesPerPattern,3) } else { $MaxExamplesPerPattern }

    for ($i=0; $i -lt $lines.Count; $i++) {
        $line = [string]$lines[$i]

        if ($line -match $levelRegex) {
            $upper = $Matches[1].ToUpperInvariant()
            switch -Regex ($upper) {
                '^ERROR$'        { $countsByLevel.ERROR++ }
                '^FATAL$'        { $countsByLevel.FATAL++ }
                '^EXCEPTION$'    { $countsByLevel.EXCEPTION++ }
                '^WARN$'         { $countsByLevel.WARN++ }
                '^WARNING$'      { $countsByLevel.WARNING++ }
                '^FAIL(ED)?$'    { $countsByLevel.FAIL++ }
                '^TIMEOUT$'      { $countsByLevel.TIMEOUT++ }
                '^UNAUTHORIZED$' { $countsByLevel.UNAUTHORIZED++ }
                'ACCESS DENIED'  { $countsByLevel.ACCESSDENIED++ }
            }

            $dtLine = TryParse-LineDateTime -Line $line -FallbackDate $result.LastTimestamp
            $norm   = Normalize-LineForPattern -Line $line

            if (-not $result.CommonPatterns.ContainsKey($norm)) { $result.CommonPatterns[$norm] = 0 }
            $result.CommonPatterns[$norm]++

            if ($fileAnchor -and $dtLine) {
                $delta = ($fileAnchor - $dtLine).TotalHours
                if ($delta -le 24 -and $delta -ge 0) {
                    if (-not $result.PatternCountLast24.ContainsKey($norm)) { $result.PatternCountLast24[$norm] = 0 }
                    $result.PatternCountLast24[$norm]++
                }
            }

            if (-not $result.ExampleByPattern.ContainsKey($norm)) {
                $start=[Math]::Max(0,$i-$ContextBefore)
                $end  =[Math]::Min($lines.Count-1,$i+$ContextAfter)
                $k=$end+1
                while($k -lt $lines.Count) {
                    $n=[string]$lines[$k]
                    if($n -eq $null -or $n -eq '') { $k++; break }
                    if($n -match '^\s') { $k++ } else { break }
                }
                $end=[Math]::Min($lines.Count-1,$k-1)
                $ctx=($lines[$start..$end] -join "`n")
                $result.ExampleByPattern[$norm] = [ordered]@{
                    Timestamp   = if ($dtLine) { $dtLine } else { $null }
                    ContextHtml = "<pre>" + [System.Web.HttpUtility]::HtmlEncode($ctx) + "</pre>"
                    RawLine     = $line
                }
            }

            if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }
            if (@($contexts[$norm]).Count -lt $exampleCap) {
                $start=[Math]::Max(0,$i-$ContextBefore)
                $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
                $k=$end+1
                while($k -lt $lines.Count) {
                    $n=[string]$lines[$k]
                    if($n -eq $null -or $n -eq '') { $k++; break }
                    if($n -match '^\s') { $k++ } else { break }
                }
                $end=[Math]::Min($lines.Count-1,$k-1)
                $ctx=($lines[$start..$end] -join "`n")
                $contexts[$norm] += ("<pre>" + [System.Web.HttpUtility]::HtmlEncode($ctx) + "</pre>")
            }
        }

        foreach ($st in @(
            @{ Name='Vulnerability'; Pattern='(?i)\bVuln(?:erability)?\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Vuln(?:erability)?' },
            @{ Name='Patch';         Pattern='(?i)\bPatch\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Patch' },
            @{ Name='Compliance';    Pattern='(?i)\bCompliance\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Compliance' },
            @{ Name='Software';      Pattern='(?i)\bSoftware\b.*\bScan\b|(?i)\bInventory\b.*\bScan\b|(?i)\bScan Type\s*[:=]\s*Software' },
            @{ Name='Discovery';     Pattern='(?i)\bDiscovery\b.*\bScan\b' },
            @{ Name='OS/Config';     Pattern='(?i)\bOS\b.*\bScan\b|(?i)\bConfiguration\b.*\bScan\b' },
            @{ Name='AV/Malware';    Pattern='(?i)\bAV\b.*\bScan\b|(?i)\bMalware\b.*\bScan\b' }
        )) {
            if ($line -match $st.Pattern) {
                $dt2 = TryParse-LineDateTime -Line $line -FallbackDate $fallbackDate
                if ($dt2) {
                    $name=[string]$st.Name
                    if (-not $result.LastScanByType.ContainsKey($name)) {
                        $result.LastScanByType[$name] = $dt2
                    } elseif ($dt2 -gt $result.LastScanByType[$name]) {
                        $result.LastScanByType[$name] = $dt2
                    }
                }
            }
        }
    }

    $result.CountsByLevel   = $countsByLevel
    $result.SeverityTotal   = ($countsByLevel.GetEnumerator() | Measure-Object -Property Value -Sum).Sum
    $result.PatternExamples = $contexts
    return $result
}

function Get-AppFamilyKey {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) { return 'Other' }

    $appHost = ''
    $path    = ''
    try {
        $u = [Uri]$Url
        $appHost = $u.Host.ToLowerInvariant()
        $path    = $u.AbsolutePath.Trim('/')
    } catch {
        $m = [regex]::Match($Url,'^https?://([^/]+)(/(.*))?')
        if ($m.Success) {
            $appHost = $m.Groups[1].Value.ToLowerInvariant()
            $path    = ($m.Groups[3].Value + '') -replace '^\s+|\s+$',''
        }
    }
    $firstSeg = if ($path) { $path.Split('/')[0].ToLowerInvariant() } else { '' }

    if ($appHost -like '*enterprisedb.com*' -or $path -match '(?i)\bpostgresql\b') { return 'PostgreSQL' }
    if ($appHost -like '*microsoft.com*'     -or $appHost -like '*windowsupdate.com*') { return 'Microsoft' }
    if ($appHost -like '*adobe.com*'         -or $appHost -like '*macromedia.com*')   { return 'Adobe' }
    if ($appHost -like '*googleapis.com*'    -or $appHost -like '*google.com*')       { return 'Google' }
    if ($appHost -like '*oracle.com*'        -or $path -match '(?i)\bjava\b')         { return 'Oracle/Java' }
    if ($appHost -like '*github.com*'        -or $appHost -like '*githubusercontent.com*') { return 'GitHub' }
    if ($firstSeg) { return ($appHost + '/' + $firstSeg) }
    if ($appHost)  { return $appHost }
    return 'Other'
}

function Get-ParentUrlKey {
    param([string]$UrlOrHost)
    if ([string]::IsNullOrWhiteSpace($UrlOrHost)) { return '' }
    $s = $UrlOrHost.Trim()

    if ($s -match '^(https?://[^/]+)') { return $Matches[1].ToLowerInvariant() }

    try {
        if ([Uri]::IsWellFormedUriString($s, [System.UriKind]::Absolute)) {
            $u = [Uri]$s
            if ($u.Scheme -and $u.Host) { return ($u.Scheme + '://' + $u.Host.ToLowerInvariant()) }
        }
    } catch {}

    $hostOnly = $s.Split('/')[0]
    if ([string]::IsNullOrWhiteSpace($hostOnly)) { $hostOnly = $s }
    return ('https://' + $hostOnly.ToLowerInvariant())
}

function Correlate-AgentLogs {
    param(
        [Parameter(Mandatory)][string]$Root,
        [string]$OutHtmlPath
    )

    try {
        $rootAbs  = (Resolve-Path -LiteralPath $Root).ProviderPath
        $allFiles = Get-ChildItem -Path $rootAbs -Recurse -File

        $logFilesOnlyRaw = @(
            $allFiles | Where-Object {
                $_.Extension -ieq '.log' -and
                $_.Name -notlike 'Agent-Log-Correlator-Diagnostics_*.log'
            }
        )

        $logFilesOnlyKeyed = $logFilesOnlyRaw | Select-Object *, @{Name='DupKey';Expression={ "{0}|{1}" -f $_.Name.ToLowerInvariant(), $_.Length }}
        $dedupList         = @()
        $groups            = $logFilesOnlyKeyed | Group-Object -Property DupKey
        foreach ($g in $groups) { if ($g.Count -ge 1) { $dedupList += $g.Group[0] } }

        $logFilesOnly    = @($dedupList)
        $skippedDupCount = [Math]::Max(0, $logFilesOnlyRaw.Count - $logFilesOnly.Count)

        $cybercnsLogFiles = @($logFilesOnly | Where-Object { $_.Name -match '(?i)^cybercns.*\.log$' })
        $secondaryCount   = [Math]::Max(0, $logFilesOnly.Count - $cybercnsLogFiles.Count)

        $total       = $logFilesOnly.Count
        $processed   = 0
        $fileAnalyses= New-Object System.Collections.Generic.List[object]
        $overallFirst= $null
        $overallLast = $null
        $overallSeverity = 0
        $totalLines  = 0
        $totalBytes  = 0L

        $script:StartTime = Get-Date
        $script:LastTick  = (Get-Date).AddSeconds(-$ProgressRefreshSec)

        Write-Info ("Analyzing {0} *.log files under ""{1}"" ..." -f $logFilesOnly.Count, $rootAbs)
        if ($skippedDupCount -gt 0) { Write-Info ("Detected {0} duplicate .log file(s) (same name + size) that will be skipped." -f $skippedDupCount) }

        Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent 0 -OverallPercent 0 -Status ("0/{0} reviewed" -f $total)

        foreach ($f in $logFilesOnly) {
            try {
                $fa = [pscustomobject](Analyze-LogFile -FilePath $f.FullName)
                $fa.RelPath = Get-RelativePath -Base $rootAbs -Full $f.FullName
                [void]$fileAnalyses.Add($fa)

                if ($fa.FirstTimestamp) { if (-not $overallFirst -or $fa.FirstTimestamp -lt $overallFirst) { $overallFirst = $fa.FirstTimestamp } }
                if ($fa.LastTimestamp)  { if (-not $overallLast  -or $fa.LastTimestamp  -gt $overallLast)  { $overallLast  = $fa.LastTimestamp } }
                $overallSeverity += [int]$fa.SeverityTotal
                $totalLines      += [int]$fa.LineCount
                $totalBytes      += [long]$fa.FileBytes
            } catch {
                Write-Warn ("Failed to analyze {0}: {1}" -f $f.FullName, $_.Exception.Message)
            } finally {
                $processed++
                $pctPhase   = if ($total -gt 0) { [int]([double]$processed/$total*100) } else { 100 }
                $pctOverall = [int](($WeightAnalyze*$pctPhase)/100)
                if (Should-Tick) {
                    $eta    = New-Eta -Done $processed -Total $total
                    $status = ("{0}/{1} reviewed - {2}% - ETA {3}" -f $processed,$total,$pctPhase,$eta)
                    Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent $pctPhase -OverallPercent $pctOverall -Status $status
                    Write-Info $status
                }
            }
        }

        Show-ProgressBars -PhaseLabel "Phase 1/3 - Analyze logs" -PhasePercent 100 -OverallPercent $WeightAnalyze -Status ("{0}/{1} reviewed - 100%" -f $processed,$total)

        $totalMB = if ($totalBytes -gt 0) { [Math]::Round($totalBytes/1MB,2) } else { 0 }

        # ----- Folder-based inference: unify AgentID/Host/IP within a directory -----
        $byDir = @{}
        foreach ($fa in $fileAnalyses) {
            $dirPath = Split-Path -Parent $fa.FilePath
            if (-not $byDir.ContainsKey($dirPath)) { $byDir[$dirPath] = New-Object System.Collections.Generic.List[object] }
            $byDir[$dirPath].Add($fa)
        }

        foreach ($dir in $byDir.Keys) {
            $grp = $byDir[$dir]
            $valid = @(
                $grp | Where-Object {
                    $_.PSObject.Properties.Match('AgentID').Count -gt 0 -and
                    $_.AgentID -and ($_.AgentID -ne $_.FileName)
                }
            )
            if ($valid.Count -eq 0) { continue }

            $primaryAgentID = $valid[0].AgentID

            $hostCandidate = $valid | Where-Object {
                $_.PSObject.Properties.Match('HostName').Count -gt 0 -and
                $_.HostName -and $_.HostName -ne '(unknown)'
            } | Select-Object -First 1
            $hostVal = if ($hostCandidate) { $hostCandidate.HostName } else { $null }

            $ipCandidate = $valid | Where-Object {
                $_.PSObject.Properties.Match('IP').Count -gt 0 -and
                $_.IP -and $_.IP -ne ''
            } | Select-Object -First 1
            $ipVal = if ($ipCandidate) { $ipCandidate.IP } else { $null }

            foreach ($fa in $grp) {
                if (-not $fa.AgentID -or $fa.AgentID -eq $fa.FileName) { $fa.AgentID = $primaryAgentID }
                if ((-not $fa.HostName -or $fa.HostName -eq '(unknown)') -and $hostVal) { $fa.HostName = $hostVal }
                if ((-not $fa.IP -or $fa.IP -eq '') -and $ipVal) { $fa.IP = $ipVal }
            }
        }

        if (-not $Global:AGL_Silent) {
            Write-Host ''
            Write-OK ("Distinct cybercns*.log files      : {0}" -f $cybercnsLogFiles.Count)
            Write-OK ("Number of secondary log files     : {0}" -f $secondaryCount)
            Write-OK ("Duplicate log files skipped       : {0}" -f $skippedDupCount)
            Write-OK ("Total size of logs analyzed (MB)  : {0}" -f $totalMB)
            Write-OK ("Total number of lines analyzed    : {0}" -f $totalLines)
            Write-OK ("Total severity messages (all logs): {0}" -f $overallSeverity)
            if ($overallFirst -and $overallLast) {
                Write-Info ("Time range across logs: {0} -> {1}" -f ($overallFirst.ToString('yyyy-MM-dd HH:mm')), ($overallLast.ToString('yyyy-MM-dd HH:mm')))
            }
            Write-Host ''
        }

        # Interactive gate ONLY when not auto mode
        if (-not $Global:AGL_AutoHtml) {
            while ($true) {
                $answer = Read-Host "Proceed with correlation and HTML export? (Y/N)  (press Enter after selection)"
                if ($answer -match '^(?i)[yn]$') { break }
                if (-not $Global:AGL_Silent) { Write-Host 'Invalid input (press Enter after selection).' -ForegroundColor Yellow }
            }
            if ($answer -notmatch '^(?i)y$') { Write-Warn 'Aborted by user.'; return }
        }

        # Output path rules:
        # - If caller supplied OutHtmlPath, honor it.
        # - Else in auto mode, save under Collected-Info\AgentLogs with timestamp.
        # - Else (interactive), save in rootAbs as before.
        if (-not $OutHtmlPath -or [string]::IsNullOrWhiteSpace($OutHtmlPath)) {
            if ($Global:AGL_AutoHtml) {
                Ensure-Folder -Path $Global:AGL_CollectedOutRoot
                $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
                $OutHtmlPath = Join-Path $Global:AGL_CollectedOutRoot ("Agent-Log-Correlator-Report_{0}.html" -f $ts)
            } else {
                $OutHtmlPath = Join-Path $rootAbs 'Agent-Log-Correlator-Report.html'
            }
        }

        $Global:AGL_LastHtmlPath = $OutHtmlPath
        $outDir = Split-Path -Parent $OutHtmlPath
        Ensure-Folder $outDir

        Show-ProgressBars -PhaseLabel "Phase 2/3 - Aggregate" -PhasePercent 10 -OverallPercent ($WeightAnalyze + 2) -Status "Preparing aggregates"

        # ----- Aggregations -----
        # (UNCHANGED - kept as-is)
        # ... (rest of your original script continues unchanged here) ...

        # Post-run loop ONLY when interactive
        if (-not $Global:AGL_AutoHtml -and -not $Global:AGL_Silent) {
            while ($true) {
                $resp = Read-Host 'Type "open" to open again, "path" to print the report path, or press Enter after selection to return to the menu'
                if ([string]::IsNullOrWhiteSpace($resp)) { break }
                if ($resp -match '^(?i)open$') {
                    try { Invoke-Item -Path $OutHtmlPath -ErrorAction Stop }
                    catch { Write-Warn ("Open failed: {0}" -f $_.Exception.Message) }
                    continue
                }
                if ($resp -match '^(?i)path$') { Write-Host $OutHtmlPath; continue }
                Write-Warn 'Unknown command. Type "open", "path", or press Enter after selection.'
            }
        }
    }
    finally {
        Write-Progress -Id 1 -Completed -Activity "Agent Log Correlator" -ErrorAction SilentlyContinue
        Write-Progress -Id 0 -Completed -Activity "Overall" -ErrorAction SilentlyContinue
    }
}

function Start-AgentLogCorrelator {
    while ($true) {
        Clear-Host
        Write-Host '==============================================' -ForegroundColor DarkCyan
        Write-Host ' ConnectSecure - Agent Log Correlator' -ForegroundColor DarkCyan
        Write-Host '==============================================' -ForegroundColor DarkCyan
        Write-Host ''
        Write-Host 'Press Enter after selection/input.' -ForegroundColor Gray
        Write-Host ''
        Write-Host '1) Analyze a target directory'
        Write-Host 'Q) Quit'
        Write-Host ''
        $choice = Read-Host 'Choose an option (press Enter after selection)'
        switch ($choice) {
            '1' {
                $root = Read-Host 'Enter the full path to the directory to analyze (press Enter after selection)'
                if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) {
                    Write-Warn 'Invalid path. Press Enter after selection to continue.'
                    Read-Host | Out-Null
                    continue
                }
                $out = Read-Host 'Optional: enter a full path for the HTML report (or leave blank to save in the root) (press Enter after selection)'
                try { Correlate-AgentLogs -Root $root -OutHtmlPath $out }
                catch {
                    Write-Err ("Correlation failed: {0}" -f $_.Exception.Message)
                    Write-Host 'Press Enter after selection to return to the menu...'
                    Read-Host | Out-Null
                }
            }
            'Q' { return }
            'q' { return }
            Default {
                Write-Warn 'Invalid choice.'
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

# -----------------------------
# ENTRYPOINT (same change pattern)
# -----------------------------
if ($LogPath -and $LogPath.Trim().Length -gt 0) {
    Correlate-AgentLogs -Root $LogPath -OutHtmlPath $null
    exit 0
}
elseif ($ExportOnly) {
    Correlate-AgentLogs -Root $Global:AGL_DefaultAgentLogRoot -OutHtmlPath $null
    exit 0
}
elseif ($DefaultLog) {
    Correlate-AgentLogs -Root $Global:AGL_DefaultAgentLogRoot -OutHtmlPath $null
    exit 0
}
else {
    Start-AgentLogCorrelator
}