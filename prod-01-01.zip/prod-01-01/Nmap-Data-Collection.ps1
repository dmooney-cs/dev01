# ===== CS Toolbox Bootstrap (idempotent, ASCII-safe) =====
# Establish script root & global paths
$script:CS_ScriptRoot = Split-Path -Parent $PSCommandPath
if (-not $global:CS_TempRoot)       { $global:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP' }
if (-not $global:CSLauncherRoot)    { $global:CSLauncherRoot = $script:CS_ScriptRoot }

# Dot-source Functions-Common.ps1 when available (optional)
$__common = Join-Path $script:CS_ScriptRoot 'Functions-Common.ps1'
if (Test-Path $__common) {
    . $__common
}

# Safe fallbacks if functions were not loaded
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        param([Parameter(Mandatory)][string]$Path)
        if (-not (Test-Path $Path)) { New-Item -Path $Path -ItemType Directory -Force | Out-Null }
        return (Resolve-Path $Path).Path
    }
}
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([Parameter(Mandatory)][string]$Title)
        $line = '=' * 58
        Write-Host " $Title`n$line"
    }
}
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        param(
            [string]$Title = "Session Summary",
            [string]$LogPath = "",
            [hashtable]$Meta = @{}
        )
        Write-Host ""
        Write-Host "== $Title =="
        if ($Meta) {
            $Meta.GetEnumerator() | Sort-Object Name | ForEach-Object {
                Write-Host ("{0,-16}: {1}" -f $_.Name, $_.Value)
            }
        }
        if ($LogPath) { Write-Host ("Log file".PadRight(16) + ": " + $LogPath) }
        Write-Host ""
    }
}
if (-not (Get-Command Return-To-Launcher -ErrorAction SilentlyContinue)) {
    function Return-To-Launcher {
        param(
            [string]$Launcher = $(Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1')
        )
        if (Test-Path $Launcher) {
            try {
                if (Get-Item -LiteralPath $Launcher -ErrorAction SilentlyContinue) {
                    Unblock-File -LiteralPath $Launcher -ErrorAction SilentlyContinue
                }
            } catch {}
            . $Launcher
        } else {
            Write-Host "Launcher not found at: $Launcher"
        }
    }
}
# Unblock helper (idempotent)
if (-not (Get-Command Unblock-Tree -ErrorAction SilentlyContinue)) {
    function Unblock-Tree {
        param([Parameter(Mandatory)][string]$Root)
        if (Test-Path $Root) {
            Get-ChildItem -Path $Root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
                try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {}
            }
        }
    }
}
# ===== End Bootstrap =====

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

# -------------------------------------------------------------------------------------------------
# Helpers (ASCII-only)
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

# Avoid name collision with any Ensure-ExportFolder from common module
function Ensure-ExportPaths {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title = "Secondary Validation Tools")
    Clear-Host
    $isAdmin = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# Yes/No helper
function Ask-YesNo {
    param(
        [Parameter(Mandatory)][string]$Prompt,
        [ValidateSet('Y','N')][string]$Default = 'N'
    )
    $suffix = if ($Default -eq 'Y') { "[Y/n]" } else { "[y/N]" }
    $resp = Read-Host "$Prompt $suffix"
    if ([string]::IsNullOrWhiteSpace($resp)) { $resp = $Default }
    return ($resp -match '^[Yy]$')
}

# --------------------------
# Network download with retries (3 tries, 2s delay)
# --------------------------
function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )
    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        Write-Host ("Downloading... Attempt {0}/{1}" -f $attempt, $MaxAttempts) -ForegroundColor Cyan
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-Host "Download successful." -ForegroundColor Green
                return $true
            } else {
                throw "Downloaded file is missing or empty."
            }
        } catch {
            if (Test-Path -LiteralPath $OutFile) {
                Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
            }
            if ($attempt -eq $MaxAttempts) {
                Write-Host ("ERROR: Download failed on attempt {0}/{1}: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                return $false
            } else {
                Write-Host ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Yellow
                Write-Host ("   Retrying in {0} seconds..." -f $DelaySeconds) -ForegroundColor Yellow
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }
    return $false
}

# Load shared functions (optional but expected)
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Pause-Script
    return
}
try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_) -ForegroundColor Red
    Pause-Script
    return
}

Ensure-ExportPaths

# --- Auto-install Nmap into Program Files if missing/empty (ASCII-safe) ---
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$__NmapInstallPath = "C:\Program Files (x86)\CyberCNSAgent\nmap"
$__NmapDownloadedThisRun = $false
if (-not (Test-Path $__NmapInstallPath)) { New-Item -Path $__NmapInstallPath -ItemType Directory -Force | Out-Null }
$__nmapExe = Join-Path $__NmapInstallPath 'nmap.exe'
$__needsInstall = -not (Test-Path $__nmapExe)
if ($__needsInstall) {
    Write-Host "Preparing Nmap in Program Files..." -ForegroundColor Yellow
    $zipUrl  = "https://github.com/dmooney-cs/prod/raw/refs/heads/main/nmap.zip"
    $zipPath = Join-Path $env:TEMP "nmap-portable.zip"

    $ok = Invoke-DownloadWithRetry -Uri $zipUrl -OutFile $zipPath -MaxAttempts 3 -DelaySeconds 2
    if ($ok) {
        try {
            Expand-Archive -Path $zipPath -DestinationPath $__NmapInstallPath -Force
            $nestedExe = Join-Path $__NmapInstallPath "nmap\nmap.exe"
            if (Test-Path $nestedExe) {
                $nestedFolder = Split-Path $nestedExe -Parent
                Get-ChildItem -Path $nestedFolder -Force | Move-Item -Destination $__NmapInstallPath -Force
                Remove-Item -Path $nestedFolder -Recurse -Force -ErrorAction SilentlyContinue
            }
            Get-ChildItem -Path $__NmapInstallPath -Recurse -File -Force | Unblock-File -ErrorAction SilentlyContinue
            $__NmapDownloadedThisRun = $true
        } catch {
            Write-Host ("WARN: Failed to extract/install Nmap: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        } finally {
            try { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue } catch {}
        }
    } else {
        Write-Host "WARN: Nmap download did not succeed after 3 attempts." -ForegroundColor Yellow
    }
}
if ($__NmapDownloadedThisRun) {
    Write-Host "NOTE: A copy of Nmap was downloaded to the Program Files path for this session." -ForegroundColor Yellow
}
# --- End auto-install block ---

# =========================
#    Nmap Data Collection
# =========================
$NmapHome       = 'C:\Program Files (x86)\CyberCNSAgent\nmap'
$NmapExe        = Join-Path $NmapHome 'nmap.exe'
$ExportRoot     = 'C:\CS-Toolbox-TEMP\Collected-Info\Network'
$QuickArgs      = @('-sV','-T4','-F','--version-light')
$ExtendedArgs   = @('-sV','-T3','--top-ports','3000','-Pn')   # renamed from old Deep
$DefaultScan    = '1'

function Restart-LauncherSameWindow {
    $launcher = $null
    if ($global:CSLauncherRoot -and (Test-Path $global:CSLauncherRoot)) {
        $launcher = Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1'
    }
    if (-not $launcher) { $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1' }
    if (Test-Path $launcher) { & $launcher }
}

function Ensure-NmapReady {
    $mirror = Join-Path $scriptRoot 'nmap-bin'
    if (-not (Test-Path $NmapHome)) { New-Item -Path $NmapHome -ItemType Directory -Force | Out-Null }
    if (Test-Path $mirror) {
        robocopy $mirror $NmapHome *.* /E /NFL /NDL /NJH /NJS /NC /NS | Out-Null
        Write-Host "[INFO] Mirrored files to $NmapHome"
    }
    if (-not (Test-Path $NmapExe)) { throw "Nmap not found at $NmapExe" }
    Write-Host "[INFO] Nmap ready: $NmapExe"
}

function Get-IPv4Interfaces {
    $results = @()
    try {
        foreach ($a in Get-NetIPConfiguration -ErrorAction Stop) {
            foreach ($ip in ($a.IPv4Address | Where-Object { $_ })) {
                if ($ip.PrefixLength -lt 0 -or $ip.PrefixLength -gt 32) { continue }
                $gw = $null
                if ($a.IPv4DefaultGateway) { $gw = ($a.IPv4DefaultGateway | Select-Object -First 1).NextHop }
                $results += [pscustomobject]@{
                    Name    = $a.InterfaceAlias
                    IPv4    = $ip.IPAddress
                    Prefix  = [int]$ip.PrefixLength
                    Gateway = $gw
                }
            }
        }
    } catch { }
    $results
}

function ConvertTo-NetworkCIDR {
    param([string]$Ip, [int]$Prefix)
    try {
        $ipBytes = [System.Net.IPAddress]::Parse($Ip).GetAddressBytes()
        [array]::Reverse($ipBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes,0)
        $mask = 0
        if ($Prefix -gt 0) { $mask = [uint32]::MaxValue -shl (32 - $Prefix) }
        $net = $ipInt -band $mask
        $netBytes = [BitConverter]::GetBytes([uint32]$net)
        [array]::Reverse($netBytes)
        $netIp = [System.Net.IPAddress]::new($netBytes)
        return "$($netIp.IPAddressToString)/$Prefix"
    } catch { return $null }
}

function Choose-Targets {
    param([object[]]$Ifaces)

    Write-Host ""
    Write-Host "Detected IPv4 interfaces:" -ForegroundColor Cyan
    foreach ($i in $Ifaces) {
        $cidrDisplay = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if (-not $cidrDisplay) { $cidrDisplay = '<n/a>' }
        $gwDisplay = if ($i.Gateway) { $i.Gateway } else { '<none>' }
        Write-Host (" - {0,-25} {1}/{2} (GW {3})  ->  {4}" -f $i.Name, $i.IPv4, $i.Prefix, $gwDisplay, $cidrDisplay)
    }

    $options = @()
    foreach ($i in $Ifaces) {
        $cidr = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if ($cidr) { $options += [pscustomobject]@{ Label = $cidr; Src = $i.Name } }
    }

    Write-Host ""
    Write-Host "Available subnets to scan:" -ForegroundColor Cyan
    $idx = 1
    foreach ($o in $options) {
        Write-Host (" [{0}] {1,-18} ({2})" -f $idx, $o.Label, $o.Src)
        $idx++
    }

    $hostOnly = $Ifaces | Select-Object -First 1
    Write-Host (" [0]  This host only: {0}" -f $hostOnly.IPv4)
    Write-Host (" [C]  Custom target (IP / range / CIDR)")
    Write-Host (" [Q]  Exit to Toolbox Launcher")

    $choice = Read-Host ("Select target number(s) (comma-separated). Default $DefaultScan")
    if ([string]::IsNullOrWhiteSpace($choice)) { $choice = $DefaultScan }

    if ($choice -match '^[qQ]$') { return @{ ExitToLauncher = $true } }

    $targets = New-Object System.Collections.Generic.List[string]
    foreach ($p in ($choice -split '\s*,\s*')) {
        switch -Regex ($p) {
            '^[0]$' { $targets.Add($hostOnly.IPv4) }
            '^[cC]$' {
                $custom = Read-Host "Enter custom target (IP / range / CIDR)"
                if ($custom) { $targets.Add($custom) }
            }
            '^\d+$' {
                $n = [int]$p
                if ($n -ge 1 -and $n -le $options.Count) { $targets.Add($options[$n-1].Label) }
            }
        }
    }
    if ($targets.Count -eq 0) { $targets.Add($hostOnly.IPv4) }
    return @{ Targets = $targets }
}

# ----- Deep profile argument builder -----
function Build-DeepArgs {
    param([bool]$IncludeUDP = $false)
    $isAdmin = Get-IsAdmin
    $synOrConnect = if ($isAdmin) { '-sS' } else { '-sT' }  # SYN preferred; fallback to TCP connect when not admin

    $args = @($synOrConnect, '-p-', '-sV', '--version-all', '-O', '-sC', '--traceroute', '--reason', '-T3', '--max-retries', '2', '--defeat-rst-ratelimit')

    if ($IncludeUDP) {
        # Curated UDP set to avoid scanning all 65535 UDP ports
        $udpList = 'U:53,67,68,69,123,137,138,161,500,1900,4500,5353'
        $tcpAll  = 'T:1-65535'
        # Replace -p- with combined TCP-all plus UDP-common
        $i = $args.IndexOf('-p-')
        if ($i -ge 0) {
            $args[$i] = '-p'
            $args = $args[0..$i] + @("$tcpAll,$udpList") + $args[($i+1)..($args.Count-1)]
        }
        # Add UDP scan engine
        $args += '-sU'
    }
    return $args
}

# ----- Profile details + selection (ASCII-only) -----
function Get-ProfileDetails {
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][array]$Args)
    $flags = ($Args -join ' ')
    switch ($Name) {
        'Deep' {
@"
Profile: Deep
Intent : Comprehensive mapping with service, OS and script discovery
Flags  : $flags
Notes  :
  - All TCP ports (1-65535) using SYN (or TCP connect if not admin).
  - Service detection with --version-all for more aggressive probing.
  - Default NSE scripts (-sC), OS detection (-O), traceroute and reason codes.
  - Retries reduced to 2 and RST rate-limit defeated to catch ephemeral services.
  - Optional UDP discovery on common ports if enabled.
Expect a longer runtime and more network traffic; consider running during a maintenance window.
"@
        }
        'Extended' {
@"
Profile: Extended
Intent : Wider coverage than Quick with moderate timing
Flags  : $flags
Notes  :
  - Service version detection at T3.
  - Top 3000 ports only, skip host discovery (-Pn) to avoid ping blocks.
"@
        }
        default {
@"
Profile: Quick
Intent : Fast overview for triage
Flags  : $flags
Notes  :
  - Top 100 ports, faster timing (T4) with lighter version detection.
"@
        }
    }
}

function Choose-ScanMode {
    Write-Host ""
    Write-Host "Scan mode:" -ForegroundColor Cyan
    Write-Host " [1] Quick    - top 100 TCP ports | T4 | version light"
    Write-Host "     Flags: -sV -T4 -F --version-light"
    Write-Host " [2] Extended - top 3000 TCP ports | T3 | skip discovery (-Pn)"
    Write-Host "     Flags: -sV -T3 --top-ports 3000 -Pn"
    Write-Host " [3] Deep     - ALL TCP ports | T3 | OS detect | scripts | traceroute"
    Write-Host "     Flags: (built dynamically; all TCP ports; optional UDP common)"
    $mode = Read-Host "Choose scan mode (default 1)"
    if ([string]::IsNullOrWhiteSpace($mode)) { $mode = '1' }

    if ($mode -eq '2') {
        $profile = @{ Name='Extended'; Args=$ExtendedArgs }
    } elseif ($mode -eq '3') {
        $incUdp = Ask-YesNo -Prompt "Include UDP discovery on common ports (53, 67, 68, 69, 123, 137, 138, 161, 500, 1900, 4500, 5353)?" -Default 'N'
        $deepArgs = Build-DeepArgs -IncludeUDP:$incUdp
        $profile = @{ Name='Deep'; Args=$deepArgs }
    } else {
        $profile = @{ Name='Quick'; Args=$QuickArgs }
    }

    Write-Host ""
    Write-Host (Get-ProfileDetails -Name $profile.Name -Args $profile.Args) -ForegroundColor Gray
    return $profile
}

# ----- Run Nmap (captures duration) -----
function Run-Nmap {
    param([string[]]$Targets, [string]$ProfileName, [array]$Args)

    if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory -Force | Out-Null }
    $dateStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = Join-Path $ExportRoot ("Nmap-Scan_{0}_{1}" -f $dateStamp, $ProfileName)
    $outN = "$base.txt"
    $outX = "$base.xml"

    $argList = @()
    if ($Args) { $argList += $Args }
    $argList += @('-oN', $outN, '-oX', $outX)
    $argList += $Targets

    $cmdPreview = "`"$NmapExe`" " + ($argList -join ' ')
    Write-Host "[INFO] Running: $cmdPreview"

    $start = Get-Date
    # Use a single string to avoid PS parsing edge cases
    $proc = Start-Process -FilePath $NmapExe -ArgumentList ($argList -join ' ') -NoNewWindow -Wait -PassThru
    $end = Get-Date
    $elapsed = $end - $start

    $exit = if ($proc) { $proc.ExitCode } else { 1 }

    return [pscustomobject]@{
        OutText   = $outN
        OutXml    = $outX
        ExitCode  = $exit
        Duration  = $elapsed
        StartedAt = $start
        EndedAt   = $end
    }
}

# ----- Parsers -----
function Parse-NmapXml {
    param([Parameter(Mandatory)][string]$XmlPath)
    $items = @()
    try {
        if (-not (Test-Path -LiteralPath $XmlPath)) { return @() }
        [xml]$x = Get-Content -LiteralPath $XmlPath -Encoding UTF8 -ErrorAction Stop

        foreach ($host in $x.nmaprun.host) {
            # Addresses
            $ipv4 = $null; $mac = $null; $macVendor = $null
            foreach ($addrNode in @($host.address)) {
                if ($addrNode.addrtype -eq 'ipv4' -and -not $ipv4) { $ipv4 = $addrNode.addr }
                if ($addrNode.addrtype -eq 'mac'  -and -not $mac)  { $mac  = $addrNode.addr; $macVendor = $addrNode.vendor }
            }

            # Hostnames
            $names = @()
            if ($host.hostnames.hostname) {
                foreach ($hn in $host.hostnames.hostname) { if ($hn.name) { $names += $hn.name } }
            }
            $hnDisplay = if ($names) { ($names -join ', ') } else { '' }

            # Ports
            $openPorts = @()
            if ($host.ports.port) {
                foreach ($p in $host.ports.port) {
                    $state = $p.state.state
                    if ($state -eq 'open') {
                        $svc  = $p.service
                        $openPorts += [pscustomobject]@{
                            Port    = [int]$p.portid
                            Proto   = [string]$p.protocol
                            Service = if ($svc.name)    { [string]$svc.name }    else { '' }
                            Product = if ($svc.product) { [string]$svc.product } else { '' }
                            Version = if ($svc.version) { [string]$svc.version } else { '' }
                            Extra   = if ($svc.extrainfo){[string]$svc.extrainfo } else { '' }
                        }
                    }
                }
            }

            $status = if ($host.status) { [string]$host.status.state } else { '' }
            $detected = ($status -eq 'up') -or ($openPorts.Count -gt 0)
            if ($detected -and $ipv4) {
                $macDisplay = if ($mac) {
                    if ($macVendor) { "$mac ($macVendor)" } else { $mac }
                } else { "" }
                $items += [pscustomobject]@{
                    Address   = $ipv4
                    Hostnames = $hnDisplay
                    Status    = if ($status) { $status } else { 'unknown' }
                    Mac       = $macDisplay
                    OpenPorts = @($openPorts | Sort-Object Port, Proto)
                }
            }
        }
    } catch {
        return @()
    }
    if ($null -eq $items) { return @() } else { return $items }
}

function Parse-NmapText {
    param([Parameter(Mandatory)][string]$TextPath)
    $items = @()
    try {
        if (-not (Test-Path -LiteralPath $TextPath)) { return @() }
        $lines = Get-Content -LiteralPath $TextPath -ErrorAction Stop

        $current = $null
        $parsingPorts = $false

        foreach ($line in $lines) {
            if ($line -match '^Nmap scan report for\s+(.+)$') {
                if ($current) { $items += $current; $current = $null; $parsingPorts = $false }
                $target = $Matches[1].Trim()
                $addr = $null
                $name = ''
                if ($target -match '^(.*?)\s+\(([^)]+)\)\s*$') {
                    $name = $Matches[1].Trim()
                    $addr = $Matches[2].Trim()
                } else {
                    $addr = ($target -split '\s+')[-1]
                }
                $current = [pscustomobject]@{
                    Address   = $addr
                    Hostnames = $name
                    Status    = ''
                    Mac       = ''
                    OpenPorts = @()
                }
                continue
            }

            if ($current -and $line -match '^Host is up') {
                $current.Status = 'up'
                continue
            }

            if ($current -and $line -match '^\s*PORT\s+STATE\s+SERVICE') {
                $parsingPorts = $true
                continue
            }

            if ($current -and $parsingPorts -and ($line -match '^\s*$' -or $line -match '^Nmap scan report for')) {
                $parsingPorts = $false
                if ($line -match '^Nmap scan report for') {
                    continue
                }
            }

            if ($current -and $parsingPorts) {
                if ($line -match '^\s*(\d+)\/(\w+)\s+(\w+)\s+(.*)$') {
                    $port = [int]$Matches[1]; $proto = $Matches[2]; $state = $Matches[3]; $svc = $Matches[4].Trim()
                    if ($state -eq 'open') {
                        $current.OpenPorts += [pscustomobject]@{
                            Port    = $port
                            Proto   = $proto
                            Service = $svc
                            Product = ''
                            Version = ''
                            Extra   = ''
                        }
                    }
                }
                continue
            }

            if ($current -and $line -match '^MAC Address:\s*([0-9A-Fa-f:]+)(?:\s*\((.*?)\))?') {
                $mac = $Matches[1]; $vendor = $Matches[2]
                $current.Mac = if ($vendor) { "$mac ($vendor)" } else { $mac }
                continue
            }
        }
        if ($current) { $items += $current }
    } catch {
        return @()
    }
    foreach ($it in $items) {
        if (-not $it.Status) {
            if ($it.OpenPorts -and $it.OpenPorts.Count -gt 0) { $it.Status = 'up' } else { $it.Status = 'unknown' }
        }
        if (-not $it.OpenPorts) { $it.OpenPorts = @() }
    }
    if ($null -eq $items) { return @() } else { return $items }
}

function Parse-NmapTextHostsUp {
    param([Parameter(Mandatory)][string]$TextPath)
    $hostsUp = $null
    try {
        if (-not (Test-Path -LiteralPath $TextPath)) { return $null }
        $lines = Get-Content -LiteralPath $TextPath -ErrorAction Stop
        foreach ($line in $lines) {
            if ($line -match 'Nmap done:\s+\d+\s+IP addresses\s+\((\d+)\s+hosts?\s+up\)') {
                $hostsUp = [int]$Matches[1]
            }
        }
    } catch { return $null }
    return $hostsUp
}

# ----- Show results 3 at a time with dividers and header -----
function Show-ScanResultsPaged {
    param(
        [object[]]$Items = @(),
        [Parameter(Mandatory)][string[]]$Targets,
        [Parameter(Mandatory)][string]$ProfileName,
        [Parameter(Mandatory)][timespan]$Duration,
        [string]$NmapSourceNote = "",
        [int]$ExpectedHostCount = -1
    )

    if ($null -eq $Items) { $Items = @() }
    $countActual  = $Items.Count
    $countDisplay = if ($ExpectedHostCount -ge 0) { $ExpectedHostCount } else { $countActual }
    $pageSize     = 3
    $index        = 0

    # Summary header first
    $targetsDisplay = ($Targets -join ', ')
    Write-Host ""
    Write-Host "==================== SCAN SUMMARY ====================" -ForegroundColor Cyan
    Write-Host (" Scanned Targets : {0}" -f $targetsDisplay) -ForegroundColor Gray
    Write-Host (" Profile         : {0}" -f $ProfileName) -ForegroundColor Gray
    Write-Host (" Items Detected  : {0}" -f $countDisplay) -ForegroundColor Gray
    Write-Host (" Duration        : {0}" -f $Duration.ToString()) -ForegroundColor Gray
    if ($NmapSourceNote) {
        Write-Host (" Nmap Source     : {0}" -f $NmapSourceNote) -ForegroundColor Gray
    }
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host ""

    if ($countActual -eq 0) {
        Write-Host "No host details available to display. See output files below." -ForegroundColor DarkGray
        return
    }

    while ($index -lt $countActual) {
        $end = [Math]::Min($index + $pageSize, $countActual)
        for ($i = $index; $i -lt $end; $i++) {
            $item = $Items[$i]
            Write-Host ("-" * 70) -ForegroundColor DarkGray
            Write-Host (" Host {0}/{1}" -f ($i + 1), $countActual) -ForegroundColor Cyan
            Write-Host ("   Address  : {0}" -f $item.Address)
            if ($item.Hostnames) { Write-Host ("   Hostname : {0}" -f $item.Hostnames) }
            Write-Host ("   Status   : {0}" -f $item.Status)
            if ($item.Mac) { Write-Host ("   MAC      : {0}" -f $item.Mac) }
            if ($item.OpenPorts -and $item.OpenPorts.Count -gt 0) {
                Write-Host "   Open Ports:"
                foreach ($p in $item.OpenPorts) {
                    $svcBits = @()
                    if ($p.Service) { $svcBits += $p.Service }
                    if ($p.Product) { $svcBits += $p.Product }
                    if ($p.Version) { $svcBits += $p.Version }
                    if ($p.Extra)   { $svcBits += "($($p.Extra))" }
                    $svcText = if ($svcBits) { ' - ' + ($svcBits -join ' ') } else { '' }
                    Write-Host ("     - {0}/{1} open{2}" -f $p.Port, $p.Proto, $svcText)
                }
            } else {
                Write-Host "   Open Ports: none detected"
            }
        }
        Write-Host ("-" * 70) -ForegroundColor DarkGray

        if ($end -lt $countActual) {
            Write-Host "Press any key for more results, or 'Q' to stop..." -ForegroundColor DarkGray
            try {
                $key = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                if ($key -and $key.Character -in 'q','Q') { break }
            } catch {
                $resp = Read-Host "Press ENTER for more results or type Q to stop"
                if ($resp -match '^[qQ]$') { break }
            }
        }
        $index = $end
    }
}

# ---- Main loop ----
try {
    Ensure-NmapReady

    # Determine where Nmap came from (for display in results)
    $script:NmapSourceNote = "Existing Nmap installation on this machine"
    try {
        $mirrorPath = Join-Path $scriptRoot 'nmap-bin'
        if ($__NmapDownloadedThisRun) {
            $script:NmapSourceNote = "Downloaded NMAP OEM from ConnectSecure servers (this session)"
        } elseif (Test-Path $mirrorPath) {
            $script:NmapSourceNote = "Local Nmap files mirrored from script 'nmap-bin' folder"
        } elseif (Test-Path $NmapExe) {
            $script:NmapSourceNote = "Existing Nmap installation on this machine"
        }
    } catch { }

    while ($true) {
        Show-Header "Nmap Data Collection - Local Network Overview"

        $ifaces = Get-IPv4Interfaces
        if (-not $ifaces) { $ifaces = @([pscustomobject]@{ Name='Localhost'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null }) }

        $targetChoice = Choose-Targets -Ifaces $ifaces
        if ($targetChoice.ContainsKey('ExitToLauncher') -and $targetChoice.ExitToLauncher) {
            Restart-LauncherSameWindow
            break
        }

        $mode = Choose-ScanMode
        $res = Run-Nmap -Targets $targetChoice.Targets -ProfileName $mode.Name -Args $mode.Args

        Write-Host ""
        if ($res.ExitCode -ne 0) {
            Write-Host ("WARNING: Nmap exited with code {0}" -f $res.ExitCode) -ForegroundColor Yellow
        }

        # Parse results
        $itemsXml  = Parse-NmapXml  -XmlPath  $res.OutXml
        $itemsText = Parse-NmapText -TextPath $res.OutText
        $hostsUpFromText = Parse-NmapTextHostsUp -TextPath $res.OutText

        # Prefer XML when it yields hosts; fall back to text when XML is empty or clearly missing hosts
        $items = @()
        if ($itemsXml -and $itemsXml.Count -gt 0) {
            if ($hostsUpFromText -and ($itemsXml.Count -lt $hostsUpFromText) -and ($itemsText.Count -ge $hostsUpFromText)) {
                $items = $itemsText
            } else {
                $items = $itemsXml
            }
        } else {
            $items = $itemsText
        }

        # Show paged results (summary first, with the correct detected count if available)
        $expected = if ($hostsUpFromText -ne $null) { [int]$hostsUpFromText } else { -1 }
        Show-ScanResultsPaged -Items $items `
            -Targets $targetChoice.Targets `
            -ProfileName $mode.Name `
            -Duration $res.Duration `
            -NmapSourceNote $script:NmapSourceNote `
            -ExpectedHostCount $expected

        # Always show where files are saved
        Write-Host ""
        Write-Host ("Output files:`n  - Text: {0}`n  - XML : {1}" -f $res.OutText, $res.OutXml) -ForegroundColor Gray

        Write-SessionSummary
        Write-Host ""

        # Pause before returning to the main menu so the user can read the results
        Pause-Script "Press any key to return to the main menu..."
    }
} catch {
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-SessionSummary
    Pause-Script "Press any key to return to the Toolbox Launcher..."
    Restart-LauncherSameWindow
}
