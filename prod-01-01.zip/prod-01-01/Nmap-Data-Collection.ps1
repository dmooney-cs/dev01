#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

<# =====================================================================
 Nmap-Data-Collection.ps1  (Two-phase + REAL progress + no UDP)

 FIXES INCLUDED (based on your errors):
  - Never references $Host/$host (read-only automatic var).
  - No dependency on external Functions-Common.ps1 (prevents $NoOpen / Show-Header prompts).
  - No "??" operator (PS 5.1 safe).
  - Filters EMPTY args so Nmap doesn't print the help/usage page.
  - Output filenames always unique (timestamp + random) to avoid "file in use".
  - Phase 1 + Phase 2 both show which IP is being tested.
  - Phase 2 shows REAL Nmap progress every 5 seconds using --stats-every 5s.
  - Hard per-target timeouts so a single target can't hang forever.
  - Results shown on-screen from XML (with TXT fallback).

 OUTPUT:
   C:\CS-Toolbox-TEMP\Collected-Info\Network\

 NOTES:
  - Deep mode is TCP-only (no UDP prompts, per your request).
  - ExportOnly/Silent: runs default subnet (first iface) + Quick.
===================================================================== #>

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "Ensure-Directory called with empty path." }
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Get-IsAdmin {
    try {
        $id  = [Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    if ($Silent -or $ExportOnly) { return }
    Write-Host ""
    Write-Host $Message -ForegroundColor DarkGray
    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { $null = Read-Host "Press ENTER" }
}

function Prompt-Selection {
    param(
        [Parameter(Mandatory)][string]$PromptLabel,
        [string]$DefaultValue = $null
    )
    if ($Silent -or $ExportOnly) { return $DefaultValue }
    $p = if ($DefaultValue) { "{0} (default {1}; press Enter after selection)" -f $PromptLabel, $DefaultValue }
         else { "{0} (press Enter after selection)" -f $PromptLabel }
    $val = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($val) -and $DefaultValue) { $val = $DefaultValue }
    return $val
}

function Write-SessionSummarySafe {
    if ($Silent -or $ExportOnly) { return }
    Write-Host ""
    Write-Host "== Session Summary =="
    Write-Host ""
}

function New-RunId {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $rand  = Get-Random -Minimum 1000 -Maximum 9999
    $ms    = (Get-Date).Millisecond
    return "{0}_{1:000}_{2}" -f $stamp, $ms, $rand
}

function Show-LocalHeader {
    param([string]$Title = "Nmap Data Collection - Local Network Overview")
    if ($Silent -or $ExportOnly) { return }
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host (" Nmap Data Collection - Local Network Overview") -ForegroundColor Cyan
    Write-Host ("==========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ("==========================================================") -ForegroundColor Cyan
    Write-Host ""
}

# Read a text file while another process is writing it (shared read/write)
function Get-FileTextShared {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return "" }
    $fs = $null
    $sr = $null
    try {
        $fs = New-Object System.IO.FileStream($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $sr = New-Object System.IO.StreamReader($fs, [Text.Encoding]::UTF8, $true)
        return $sr.ReadToEnd()
    } catch {
        return ""
    } finally {
        if ($sr) { try { $sr.Dispose() } catch {} }
        if ($fs) { try { $fs.Dispose() } catch {} }
    }
}

function Restart-LauncherSameWindow {
    if ($Silent -or $ExportOnly) { return }
    $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
    if (Test-Path -LiteralPath $launcher) { & $launcher }
}

# -----------------------------
# Nmap path
# -----------------------------
$NmapExe = 'C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe'
if (-not (Test-Path -LiteralPath $NmapExe)) {
    throw "Nmap not found at: $NmapExe"
}

$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Network'
Ensure-Directory -Path $ExportRoot

# -----------------------------
# Interface detection + targets
# -----------------------------
function Get-IPv4Interfaces {
    $results = @()
    try {
        foreach ($a in Get-NetIPConfiguration -ErrorAction Stop) {
            foreach ($ip in ($a.IPv4Address | Where-Object { $_ })) {
                $gw = $null
                if ($a.IPv4DefaultGateway) { $gw = ($a.IPv4DefaultGateway | Select-Object -First 1).NextHop }
                $results += [pscustomobject]@{
                    Name    = $a.InterfaceAlias
                    IPv4    = $ip.IPAddress
                    Prefix  = [int]$ip.PrefixLength
                    Gateway = $gw
                }
            }
        }
    } catch {}
    return @($results)
}

function ConvertTo-NetworkCIDR {
    param([string]$Ip, [int]$Prefix)
    try {
        $ipBytes = [System.Net.IPAddress]::Parse($Ip).GetAddressBytes()
        [array]::Reverse($ipBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes, 0)

        $mask = 0
        if ($Prefix -gt 0) { $mask = [uint32]::MaxValue -shl (32 - $Prefix) }

        $net = $ipInt -band $mask
        $netBytes = [BitConverter]::GetBytes([uint32]$net)
        [array]::Reverse($netBytes)
        $netIp = [System.Net.IPAddress]::new($netBytes)

        return "{0}/{1}" -f $netIp.IPAddressToString, $Prefix
    } catch { return $null }
}

function Choose-Targets {
    param([object[]]$Ifaces)

    $Ifaces = @($Ifaces)
    if ($Ifaces.Count -eq 0) { return @{ Targets = @('127.0.0.1') } }

    if (-not ($Silent -or $ExportOnly)) {
        Write-Host ""
        Write-Host "Detected IPv4 interfaces:" -ForegroundColor Cyan
        foreach ($i in $Ifaces) {
            $cidr = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
            $gw   = if ($i.Gateway) { $i.Gateway } else { '<none>' }
            $cidrDisp = if ($cidr) { $cidr } else { '<n/a>' }
            Write-Host (" - {0,-25} {1}/{2} (GW {3})  ->  {4}" -f $i.Name, $i.IPv4, $i.Prefix, $gw, $cidrDisp)
        }
    }

    $options = @()
    foreach ($i in $Ifaces) {
        $cidr = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if ($cidr) { $options += [pscustomobject]@{ Label = $cidr; Src = $i.Name } }
    }

    $firstIface = $Ifaces | Select-Object -First 1

    if (-not ($Silent -or $ExportOnly)) {
        Write-Host ""
        Write-Host "Available subnets to scan:" -ForegroundColor Cyan
        $idx = 1
        foreach ($o in $options) {
            Write-Host (" [{0}] {1,-18} ({2})" -f $idx, $o.Label, $o.Src)
            $idx++
        }
        Write-Host (" [0]  This host only: {0}" -f $firstIface.IPv4)
        Write-Host (" [C]  Custom target (IP / range / CIDR)")
        Write-Host (" [Q]  Exit to Toolbox Launcher")
    }

    $choice = Prompt-Selection "Select target number(s) (comma-separated)" "1"
    if ($choice -match '^[qQ]$') { return @{ ExitToLauncher = $true } }

    $targets = New-Object System.Collections.Generic.List[string]
    foreach ($p in ($choice -split '\s*,\s*')) {
        switch -Regex ($p) {
            '^[0]$' { $targets.Add($firstIface.IPv4) }
            '^[cC]$' {
                $custom = Prompt-Selection "Enter custom target (IP / range / CIDR)"
                if ($custom) { $targets.Add($custom) }
            }
            '^\d+$' {
                $n = [int]$p
                if ($n -ge 1 -and $n -le $options.Count) { $targets.Add($options[$n-1].Label) }
            }
        }
    }

    if ($targets.Count -eq 0) { $targets.Add($firstIface.IPv4) }
    return @{ Targets = @($targets) }
}

# -----------------------------
# Profiles (TCP only)
# -----------------------------
$QuickArgs    = @('-sV','-T4','-F','--version-light')
$ExtendedArgs = @('-sV','-T3','--top-ports','3000','--version-light')

function Build-DeepArgs {
    $scanType = if (Get-IsAdmin) { '-sS' } else { '-sT' }
    return @(
        $scanType,
        '-p-',
        '-sV','--version-all',
        '-O','-sC',
        '--traceroute','--reason',
        '-T3'
    )
}

function Choose-ScanMode {
    if (-not ($Silent -or $ExportOnly)) {
        Write-Host ""
        Write-Host "Scan mode:" -ForegroundColor Cyan
        Write-Host " [1] Quick    - top 100 TCP ports | T4 | version light"
        Write-Host " [2] Extended - top 3000 TCP ports | T3 | version light"
        Write-Host " [3] Deep     - ALL TCP ports | T3 | OS detect | scripts | traceroute (TCP only)"
        Write-Host ""
    }

    $mode = Prompt-Selection "Choose scan mode" "1"

    if ($mode -eq '2') { return @{ Name='Extended'; Args=$ExtendedArgs } }
    if ($mode -eq '3') { return @{ Name='Deep';     Args=(Build-DeepArgs) } }
    return @{ Name='Quick'; Args=$QuickArgs }
}

# -----------------------------
# Nmap runner (real-time progress)
# -----------------------------
function Start-NmapWithProgress {
    param(
        [Parameter(Mandatory)][string[]]$Args,
        [Parameter(Mandatory)][string]$OutText,
        [Parameter(Mandatory)][string]$OutXml,
        [int]$StatsEverySeconds = 5,
        [int]$PollMs = 500
    )

    # Remove empty args (prevents Nmap "Usage" output / weird parsing)
    $clean = @()
    foreach ($a in @($Args)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$a)) { $clean += [string]$a }
    }

    # Always write to files
    $clean += @('--stats-every', ("{0}s" -f $StatsEverySeconds), '-oN', $OutText, '-oX', $OutXml)

    # Redirect stdout/stderr to temp so we can "tail" progress without locking
    $tmpId = New-RunId
    $stdoutPath = Join-Path $ExportRoot ("_nmap_stdout_{0}.log" -f $tmpId)
    $stderrPath = Join-Path $ExportRoot ("_nmap_stderr_{0}.log" -f $tmpId)

    $argString = ($clean -join ' ')

    $start = Get-Date
    $p = Start-Process -FilePath $NmapExe -ArgumentList $argString -NoNewWindow -PassThru `
        -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath

    $lastPrint = Get-Date
    $lastStatsLine = ""

    while (-not $p.HasExited) {
        Start-Sleep -Milliseconds $PollMs

        if ($Silent -or $ExportOnly) { continue }

        $now = Get-Date
        if (($now - $lastPrint).TotalSeconds -ge $StatsEverySeconds) {
            $lastPrint = $now

            $txt = (Get-FileTextShared -Path $stdoutPath) + "`n" + (Get-FileTextShared -Path $stderrPath)
            if ($txt) {
                # Find most recent "Stats:" line
                $lines = $txt -split "`r?`n"
                for ($i = $lines.Length - 1; $i -ge 0; $i--) {
                    if ($lines[$i] -match '^\s*Stats:\s+') {
                        $lastStatsLine = $lines[$i].Trim()
                        break
                    }
                }
            }

            if ($lastStatsLine) {
                Write-Host ("[NMAP] {0}" -f $lastStatsLine) -ForegroundColor DarkGray
            } else {
                $elapsed = (Get-Date) - $start
                Write-Host ("[INFO] Running... Elapsed={0}" -f $elapsed.ToString()) -ForegroundColor DarkGray
            }
        }
    }

    $p.WaitForExit()

    $end = Get-Date
    $exit = $p.ExitCode

    # Best-effort cleanup of temp logs
    try { Remove-Item -LiteralPath $stdoutPath -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $stderrPath -Force -ErrorAction SilentlyContinue } catch {}

    return [pscustomobject]@{
        ExitCode  = [int]$exit
        Duration  = ($end - $start)
        StartedAt = $start
        EndedAt   = $end
    }
}

# -----------------------------
# Phase 1 discovery
# -----------------------------
function Get-UpTargetsFromDiscoveryText {
    param([Parameter(Mandatory)][string]$TextPath)

    $up = New-Object System.Collections.Generic.List[string]
    if (-not (Test-Path -LiteralPath $TextPath)) { return @() }

    # Read shared (in case AV or slow flush still has it open)
    $raw = Get-FileTextShared -Path $TextPath
    if (-not $raw) { return @() }

    $lines = $raw -split "`r?`n"
    for ($i = 0; $i -lt $lines.Length; $i++) {
        $line = $lines[$i]
        if ($line -match '^Nmap scan report for\s+(.+)$') {
            $t = $Matches[1].Trim()
            $ip = $null
            if ($t -match '\((\d{1,3}(?:\.\d{1,3}){3})\)') { $ip = $Matches[1] }
            elseif ($t -match '^(\d{1,3}(?:\.\d{1,3}){3})$') { $ip = $Matches[1] }

            $maxLook = [Math]::Min($i + 6, $lines.Length - 1)
            for ($j = $i + 1; $j -le $maxLook; $j++) {
                if ($lines[$j] -match '^Host is up') {
                    if ($ip) { $up.Add($ip) }
                    break
                }
            }
        }
    }

    return @($up | Sort-Object -Unique)
}

function Run-NmapDiscovery {
    param([string[]]$Targets)

    $rid  = New-RunId
    $outN = Join-Path $ExportRoot ("Nmap-Discovery_{0}.txt" -f $rid)
    $outX = Join-Path $ExportRoot ("Nmap-Discovery_{0}.xml" -f $rid)

    $args = @('-sn','-n','-T4','--max-retries','1','--host-timeout','10s') + @($Targets)

    if (-not ($Silent -or $ExportOnly)) {
        Write-Host ("[INFO] Phase 1 (Discovery) Running: `"{0}`" {1} -oN {2} -oX {3}" -f $NmapExe, ($args -join ' '), $outN, $outX) -ForegroundColor Gray
    }

    $run = Start-NmapWithProgress -Args $args -OutText $outN -OutXml $outX -StatsEverySeconds 5 -PollMs 250

    $upTargets = Get-UpTargetsFromDiscoveryText -TextPath $outN

    return [pscustomobject]@{
        OutText  = $outN
        OutXml   = $outX
        ExitCode = $run.ExitCode
        Duration = $run.Duration
        UpHosts  = @($upTargets)
    }
}

# -----------------------------
# Phase 2 per-target scan (hard timeouts)
# -----------------------------
function New-EmptyNmapRunXml {
    $doc = New-Object System.Xml.XmlDocument
    $decl = $doc.CreateXmlDeclaration("1.0","UTF-8",$null)
    $null = $doc.AppendChild($decl)
    $root = $doc.CreateElement("nmaprun")
    $null = $doc.AppendChild($root)
    return $doc
}

function Merge-NmapHostNodes {
    param(
        [Parameter(Mandatory)][string[]]$XmlFiles,
        [Parameter(Mandatory)][string]$OutXml
    )

    $doc  = New-EmptyNmapRunXml
    $root = $doc.DocumentElement

    foreach ($xf in $XmlFiles) {
        if (-not (Test-Path -LiteralPath $xf)) { continue }
        try {
            $src = New-Object System.Xml.XmlDocument
            $src.Load($xf)
            $nodes = $src.SelectNodes("//host")
            if ($nodes) {
                foreach ($n in $nodes) {
                    $import = $doc.ImportNode($n, $true)
                    $null = $root.AppendChild($import)
                }
            }
        } catch {}
    }

    try { $doc.Save($OutXml) } catch {}
}

function Run-NmapScanPhase2_PerTarget {
    param(
        [Parameter(Mandatory)][string[]]$TargetsUp,
        [Parameter(Mandatory)][string]$ProfileName,
        [Parameter(Mandatory)][array]$ProfileArgs
    )

    $rid = New-RunId
    $scanTxt = Join-Path $ExportRoot ("Nmap-Scan_{0}_{1}.txt" -f $rid, $ProfileName)
    $scanXml = Join-Path $ExportRoot ("Nmap-Scan_{0}_{1}.xml" -f $rid, $ProfileName)

    $phase2Folder = Join-Path $ExportRoot ("Phase2_{0}_{1}" -f $rid, $ProfileName)
    Ensure-Directory -Path $phase2Folder

    # Speed + safety (prevents "stuck forever")
    $common = @('-Pn','-n','--max-retries','1','--defeat-rst-ratelimit')

    # Per-target timeout tuned by profile
    $hostTimeout = '45s'
    $rttInit     = '200ms'
    $rttMax      = '1s'
    if ($ProfileName -eq 'Extended') { $hostTimeout = '90s' }
    if ($ProfileName -eq 'Deep')     { $hostTimeout = '180s'; $rttInit='300ms'; $rttMax='2s' }

    $timing = @('--host-timeout', $hostTimeout, '--initial-rtt-timeout', $rttInit, '--max-rtt-timeout', $rttMax)

    $TargetsUp = @($TargetsUp)
    $total = $TargetsUp.Count

    $xmlParts = New-Object System.Collections.Generic.List[string]
    $txtParts = New-Object System.Collections.Generic.List[string]

    $startAll = Get-Date

    for ($i = 0; $i -lt $total; $i++) {
        $targetIp = $TargetsUp[$i]
        $idx1 = $i + 1
        $pct  = [int]([Math]::Round(($idx1 / [double]$total) * 100, 0))

        if (-not ($Silent -or $ExportOnly)) {
            Write-Host ""
            Write-Host ("[INFO] Phase 2: Scanning {0}/{1} ({2}%) -> {3}" -f $idx1, $total, $pct, $targetIp) -ForegroundColor Cyan
        }

        $safeIp = ($targetIp -replace '[^\d\.]','_')
        $hostBase = Join-Path $phase2Folder ("Target_{0:000}_{1}" -f $idx1, $safeIp)
        $partTxt  = "$hostBase.txt"
        $partXml  = "$hostBase.xml"

        $args = @()
        $args += @($ProfileArgs)
        $args += @($common)
        $args += @($timing)
        $args += @($targetIp)

        $run = Start-NmapWithProgress -Args $args -OutText $partTxt -OutXml $partXml -StatsEverySeconds 5 -PollMs 250

        if (Test-Path -LiteralPath $partXml) { $xmlParts.Add($partXml) }
        if (Test-Path -LiteralPath $partTxt) { $txtParts.Add($partTxt) }

        if (-not ($Silent -or $ExportOnly)) {
            $elapsed = (Get-Date) - $startAll
            Write-Host ("[INFO] Target done. ExitCode={0}  TargetDuration={1}  TotalElapsed={2}" -f $run.ExitCode, $run.Duration.ToString(), $elapsed.ToString()) -ForegroundColor Gray
        }
    }

    # Merge TXT
    try {
        if ($txtParts.Count -gt 0) {
            if (Test-Path -LiteralPath $scanTxt) { Remove-Item -LiteralPath $scanTxt -Force -ErrorAction SilentlyContinue }
            foreach ($p in $txtParts) {
                try {
                    Add-Content -LiteralPath $scanTxt -Value ("#" * 78)
                    Add-Content -LiteralPath $scanTxt -Value ("# SOURCE: {0}" -f $p)
                    Add-Content -LiteralPath $scanTxt -Value ("#" * 78)
                    (Get-FileTextShared -Path $p) | Add-Content -LiteralPath $scanTxt
                    Add-Content -LiteralPath $scanTxt -Value ""
                } catch {}
            }
        }
    } catch {}

    # Merge XML host nodes
    Merge-NmapHostNodes -XmlFiles @($xmlParts.ToArray()) -OutXml $scanXml

    $endAll = Get-Date
    return [pscustomobject]@{
        OutText   = $scanTxt
        OutXml    = $scanXml
        Phase2Dir = $phase2Folder
        ExitCode  = 0
        Duration  = ($endAll - $startAll)
        StartedAt = $startAll
        EndedAt   = $endAll
    }
}

# -----------------------------
# Parse results (XML then TXT fallback)
# -----------------------------
function Parse-NmapXml {
    param([Parameter(Mandatory)][string]$XmlPath)

    $out = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path -LiteralPath $XmlPath)) { return @() }

    try {
        [xml]$x = Get-Content -LiteralPath $XmlPath -Encoding UTF8 -ErrorAction Stop
        $nodes = $x.SelectNodes('//host')
        if (-not $nodes) { return @() }

        foreach ($h in $nodes) {
            $addr4 = $h.SelectSingleNode("address[@addrtype='ipv4']")
            if (-not $addr4) { continue }
            $ipv4 = $addr4.addr
            if (-not $ipv4) { continue }

            $statusNode = $h.SelectSingleNode('status')
            $status = if ($statusNode -and $statusNode.state) { $statusNode.state } else { 'unknown' }

            $macDisplay = ""
            $addrMac = $h.SelectSingleNode("address[@addrtype='mac']")
            if ($addrMac -and $addrMac.addr) {
                $mac = $addrMac.addr
                $vendor = $addrMac.vendor
                $macDisplay = if ($vendor) { "$mac ($vendor)" } else { $mac }
            }

            $names = @()
            $hnodes = $h.SelectNodes('hostnames/hostname')
            if ($hnodes) {
                foreach ($hn in $hnodes) { if ($hn.name) { $names += $hn.name } }
            }
            $hnDisplay = if ($names.Count -gt 0) { $names -join ', ' } else { '' }

            $openPorts = @()
            $pNodes = $h.SelectNodes("ports/port[state/@state='open']")
            if ($pNodes) {
                foreach ($p in $pNodes) {
                    $proto = $p.protocol
                    $portId = $p.portid
                    if (-not $portId) { continue }

                    $svcNode = $p.SelectSingleNode('service')
                    $svcName = ''; $product = ''; $version = ''; $extra = ''
                    if ($svcNode) {
                        if ($svcNode.name)      { $svcName = $svcNode.name }
                        if ($svcNode.product)   { $product = $svcNode.product }
                        if ($svcNode.version)   { $version = $svcNode.version }
                        if ($svcNode.extrainfo) { $extra   = $svcNode.extrainfo }
                    }

                    $openPorts += [pscustomobject]@{
                        Port    = [int]$portId
                        Proto   = [string]$proto
                        Service = [string]$svcName
                        Product = [string]$product
                        Version = [string]$version
                        Extra   = [string]$extra
                    }
                }
            }

            # Keep host if up OR has open ports
            if ($status -eq 'up' -or $openPorts.Count -gt 0) {
                $out.Add([pscustomobject]@{
                    Address   = $ipv4
                    Hostnames = $hnDisplay
                    Status    = $status
                    Mac       = $macDisplay
                    OpenPorts = @($openPorts | Sort-Object Port, Proto)
                })
            }
        }
    } catch { return @() }

    return @($out.ToArray())
}

function Parse-NmapText {
    param([Parameter(Mandatory)][string]$TextPath)

    if (-not (Test-Path -LiteralPath $TextPath)) { return @() }
    $raw = Get-FileTextShared -Path $TextPath
    if (-not $raw) { return @() }

    $lines = $raw -split "`r?`n"
    $items = @()
    $current = $null
    $parsingPorts = $false

    foreach ($line in $lines) {
        if ($line -match '^Nmap scan report for\s+(.+)$') {
            if ($current) { $items += $current }
            $target = $Matches[1].Trim()
            $addr = $null
            $name = ''

            if ($target -match '^(.*?)\s+\(([^)]+)\)\s*$') {
                $name = $Matches[1].Trim()
                $addr = $Matches[2].Trim()
            } else {
                $addr = ($target -split '\s+')[-1]
            }

            $current = [pscustomobject]@{
                Address   = $addr
                Hostnames = $name
                Status    = ''
                Mac       = ''
                OpenPorts = @()
            }
            $parsingPorts = $false
            continue
        }

        if ($current -and $line -match '^Host is up') { $current.Status = 'up'; continue }
        if ($current -and $line -match '^\s*PORT\s+STATE\s+SERVICE') { $parsingPorts = $true; continue }
        if ($current -and $parsingPorts -and ($line -match '^\s*$')) { $parsingPorts = $false; continue }

        if ($current -and $parsingPorts) {
            if ($line -match '^\s*(\d+)\/(\w+)\s+(\w+)\s+(.*)$') {
                $port = [int]$Matches[1]; $proto = $Matches[2]; $state = $Matches[3]; $svc = $Matches[4].Trim()
                if ($state -eq 'open') {
                    $current.OpenPorts += [pscustomobject]@{
                        Port    = $port
                        Proto   = $proto
                        Service = $svc
                        Product = ''
                        Version = ''
                        Extra   = ''
                    }
                }
            }
            continue
        }

        if ($current -and $line -match '^MAC Address:\s*([0-9A-Fa-f:]+)(?:\s*\((.*?)\))?') {
            $m = $Matches[1]; $v = $Matches[2]
            $current.Mac = if ($v) { "$m ($v)" } else { $m }
            continue
        }
    }

    if ($current) { $items += $current }

    foreach ($it in $items) {
        if (-not $it.Status) {
            if ($it.OpenPorts -and @($it.OpenPorts).Count -gt 0) { $it.Status = 'up' } else { $it.Status = 'unknown' }
        }
        if (-not $it.OpenPorts) { $it.OpenPorts = @() }
    }

    return @($items)
}

function Show-ScanResultsPaged {
    param(
        [object[]]$Items = @(),
        [Parameter(Mandatory)][string[]]$Targets,
        [Parameter(Mandatory)][string]$ProfileName,
        [Parameter(Mandatory)][timespan]$Duration
    )

    if ($Silent -or $ExportOnly) { return }

    $Items = @($Items)
    $countActual = $Items.Count

    Write-Host ""
    Write-Host "==================== SCAN SUMMARY ====================" -ForegroundColor Cyan
    Write-Host (" Scanned Targets : {0}" -f ($Targets -join ', ')) -ForegroundColor Gray
    Write-Host (" Profile         : {0}" -f $ProfileName) -ForegroundColor Gray
    Write-Host (" Items Detected  : {0}" -f $countActual) -ForegroundColor Gray
    Write-Host (" Duration        : {0}" -f $Duration.ToString()) -ForegroundColor Gray
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host ""

    if ($countActual -eq 0) {
        Write-Host "No host details available to display. See output files below." -ForegroundColor DarkGray
        return
    }

    $pageSize = 3
    $index = 0

    while ($index -lt $countActual) {
        $end = [Math]::Min($index + $pageSize, $countActual)
        for ($i = $index; $i -lt $end; $i++) {
            $item = $Items[$i]
            Write-Host ("-" * 70) -ForegroundColor DarkGray
            Write-Host (" Target {0}/{1}" -f ($i + 1), $countActual) -ForegroundColor Cyan
            Write-Host ("   Address  : {0}" -f $item.Address)
            if ($item.Hostnames) { Write-Host ("   Hostname : {0}" -f $item.Hostnames) }
            Write-Host ("   Status   : {0}" -f $item.Status)
            if ($item.Mac) { Write-Host ("   MAC      : {0}" -f $item.Mac) }

            $ports = @($item.OpenPorts)
            if ($ports.Count -gt 0) {
                Write-Host "   Open Ports:"
                foreach ($p in $ports) {
                    $svcBits = @()
                    if ($p.Service) { $svcBits += $p.Service }
                    if ($p.Product) { $svcBits += $p.Product }
                    if ($p.Version) { $svcBits += $p.Version }
                    if ($p.Extra)   { $svcBits += "($($p.Extra))" }
                    $svcText = if ($svcBits.Count -gt 0) { ' - ' + ($svcBits -join ' ') } else { '' }
                    Write-Host ("     - {0}/{1} open{2}" -f $p.Port, $p.Proto, $svcText)
                }
            } else {
                Write-Host "   Open Ports: none detected"
            }
        }

        Write-Host ("-" * 70) -ForegroundColor DarkGray

        if ($end -lt $countActual) {
            Write-Host "Press any key for more results, or type Q then press Enter to stop." -ForegroundColor DarkGray
            try {
                $key = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                if ($key -and $key.Character -in 'q','Q') { break }
            } catch {
                $resp = Read-Host "Press Enter for more results or type Q to stop"
                if ($resp -match '^[qQ]$') { break }
            }
        }

        $index = $end
    }
}

# -----------------------------
# MAIN
# -----------------------------
try {
    if (-not ($Silent -or $ExportOnly)) {
        Write-Host "[INFO] Nmap ready: $NmapExe" -ForegroundColor Gray
    }

    # Silent/ExportOnly: auto run (first iface CIDR, Quick)
    if ($Silent -or $ExportOnly) {
        $ifaces = Get-IPv4Interfaces
        if (-not $ifaces -or @($ifaces).Count -eq 0) {
            $ifaces = @([pscustomobject]@{ Name='Localhost'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null })
        }

        $firstIface = @($ifaces) | Select-Object -First 1
        $cidr = ConvertTo-NetworkCIDR -Ip $firstIface.IPv4 -Prefix $firstIface.Prefix
        if (-not $cidr) { $cidr = $firstIface.IPv4 }

        $mode = @{ Name='Quick'; Args=$QuickArgs }

        $disc = Run-NmapDiscovery -Targets @($cidr)
        $up   = @($disc.UpHosts)
        if (-not $up -or $up.Count -eq 0) { $up = @($firstIface.IPv4) }

        $null = Run-NmapScanPhase2_PerTarget -TargetsUp @($up) -ProfileName $mode.Name -ProfileArgs @($mode.Args)
        return
    }

    while ($true) {
        Show-LocalHeader "Nmap Data Collection - Local Network Overview"

        $ifaces = Get-IPv4Interfaces
        if (-not $ifaces -or @($ifaces).Count -eq 0) {
            $ifaces = @([pscustomobject]@{ Name='Localhost'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null })
        }

        $targetChoice = Choose-Targets -Ifaces @($ifaces)
        if (($targetChoice -is [hashtable]) -and $targetChoice.ContainsKey('ExitToLauncher') -and $targetChoice.ExitToLauncher) {
            Restart-LauncherSameWindow
            break
        }

        $mode = Choose-ScanMode

        # Display profile flags (so you can confirm they are NOT blank)
        Write-Host ""
        Write-Host ("Profile: {0}" -f $mode.Name) -ForegroundColor Gray
        Write-Host ("Flags  : {0}" -f ($mode.Args -join ' ')) -ForegroundColor Gray
        Write-Host "Notes  :" -ForegroundColor Gray
        Write-Host "  - TWO-PHASE: discovery (-sn) then scan ONLY hosts up" -ForegroundColor Gray
        Write-Host "  - Phase 2 runs per-target (you always see which IP is being tested)" -ForegroundColor Gray
        Write-Host "  - Phase 2 shows REAL Nmap progress (%/ETC/elapsed) every 5s" -ForegroundColor Gray
        Write-Host "  - Hard timeouts prevent 'stuck forever' targets" -ForegroundColor Gray
        Write-Host ""

        $disc = Run-NmapDiscovery -Targets @($targetChoice.Targets)

        Write-Host ""
        Write-Host ("[INFO] Phase 1 complete. Discovery duration: {0}" -f $disc.Duration.ToString()) -ForegroundColor Gray
        Write-Host ("[INFO] Targets up found: {0}" -f (@($disc.UpHosts).Count)) -ForegroundColor Gray
        if ($disc.ExitCode -ne 0) {
            Write-Host ("WARNING: Discovery phase exited with code {0}" -f $disc.ExitCode) -ForegroundColor Yellow
        }

        $targetsUp = @($disc.UpHosts)
        if (-not $targetsUp -or $targetsUp.Count -eq 0) {
            Write-Host "No targets were detected as up in discovery phase. Nothing to scan." -ForegroundColor Yellow
            Write-Host ("Discovery output:`n  - Text: {0}`n  - XML : {1}" -f $disc.OutText, $disc.OutXml) -ForegroundColor Gray
            Pause-Script "Press any key to return to the main menu..."
            continue
        }

        Write-Host ""
        Write-Host "Targets that will be scanned in Phase 2:" -ForegroundColor Cyan
        $targetsUp | ForEach-Object { Write-Host (" - {0}" -f $_) -ForegroundColor Gray }
        Write-Host ""

        $scan = Run-NmapScanPhase2_PerTarget -TargetsUp @($targetsUp) -ProfileName $mode.Name -ProfileArgs @($mode.Args)

        Write-Host ""
        Write-Host ("[INFO] Phase 2 complete. Scan duration: {0}" -f $scan.Duration.ToString()) -ForegroundColor Gray

        $items = @(Parse-NmapXml -XmlPath $scan.OutXml)
        if ($items.Count -eq 0) {
            $items = @(Parse-NmapText -TextPath $scan.OutText)
        }

        Show-ScanResultsPaged -Items @($items) -Targets @($targetChoice.Targets) -ProfileName $mode.Name -Duration ($disc.Duration + $scan.Duration)

        Write-Host ""
        Write-Host "Output files:" -ForegroundColor Gray
        Write-Host ("  - Discovery Text: {0}" -f $disc.OutText) -ForegroundColor Gray
        Write-Host ("  - Discovery XML : {0}" -f $disc.OutXml) -ForegroundColor Gray
        Write-Host ("  - Scan Text     : {0}" -f $scan.OutText) -ForegroundColor Gray
        Write-Host ("  - Scan XML      : {0}" -f $scan.OutXml) -ForegroundColor Gray
        Write-Host ("  - Phase 2 per-target folder: {0}" -f $scan.Phase2Dir) -ForegroundColor Gray

        Write-SessionSummarySafe
        Pause-Script "Press any key to return to the Toolbox Launcher..."
        Restart-LauncherSameWindow
        break
    }
} catch {
    Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-SessionSummarySafe
    Pause-Script "Press any key to return to the Toolbox Launcher..."
    Restart-LauncherSameWindow
}
```
