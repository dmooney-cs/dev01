#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ===== CS Toolbox Bootstrap (idempotent, ASCII-safe) =====
$script:CS_ScriptRoot = Split-Path -Parent $PSCommandPath
if (-not $global:CS_TempRoot)    { $global:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP' }
if (-not $global:CSLauncherRoot) { $global:CSLauncherRoot = $script:CS_ScriptRoot }

$__common = Join-Path $script:CS_ScriptRoot 'Functions-Common.ps1'
if (Test-Path $__common) { . $__common }

if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        param([Parameter(Mandatory)][string]$Path)
        if (-not (Test-Path $Path)) { New-Item -Path $Path -ItemType Directory -Force | Out-Null }
        return (Resolve-Path $Path).Path
    }
}
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        param([string]$Title = "Session Summary",[string]$LogPath = "",[hashtable]$Meta = @{})
        if ($Silent -or $ExportOnly) { return }
        Write-Host ""
        Write-Host "== $Title =="
        if ($Meta) {
            $Meta.GetEnumerator() | Sort-Object Name | ForEach-Object {
                Write-Host ("{0,-16}: {1}" -f $_.Name, $_.Value)
            }
        }
        if ($LogPath) { Write-Host ("Log file".PadRight(16) + ": " + $LogPath) }
        Write-Host ""
    }
}
if (-not (Get-Command Return-To-Launcher -ErrorAction SilentlyContinue)) {
    function Return-To-Launcher {
        param([string]$Launcher = $(Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1'))
        if (Test-Path $Launcher) { try { Unblock-File -LiteralPath $Launcher -ErrorAction SilentlyContinue } catch {}; . $Launcher }
        else { Write-Host "Launcher not found at: $Launcher" }
    }
}
if (-not (Get-Command Unblock-Tree -ErrorAction SilentlyContinue)) {
    function Unblock-Tree {
        param([Parameter(Mandatory)][string]$Root)
        if (Test-Path $Root) {
            Get-ChildItem -Path $Root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
                try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {}
            }
        }
    }
}
# ===== End Bootstrap =====

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}
function Ensure-ExportPaths {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}
function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}
function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    if ($Silent -or $ExportOnly) { return }
    try { Write-Host ""; Write-Host $Message -ForegroundColor DarkGray; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
    catch { $null = Read-Host "Press ENTER to continue" }
}
function Show-Header {
    param([string]$Title = "Secondary Validation Tools")
    if ($Silent -or $ExportOnly) { return }
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"
    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}
function Ask-YesNo {
    param([Parameter(Mandatory)][string]$Prompt,[ValidateSet('Y','N')][string]$Default='N')
    if ($Silent -or $ExportOnly) { return ($Default -eq 'Y') }
    $suffix = if ($Default -eq 'Y') { "[Y/n]" } else { "[y/N]" }
    $resp = Read-Host ("{0} {1} (press Enter after selection)" -f $Prompt, $suffix)
    if ([string]::IsNullOrWhiteSpace($resp)) { $resp = $Default }
    return ($resp -match '^[Yy]$')
}
function Prompt-Selection {
    param([Parameter(Mandatory)][string]$PromptLabel,[string]$DefaultValue=$null)
    if ($Silent -or $ExportOnly) { return $DefaultValue }
    $p = if ($DefaultValue) { "{0} (default {1}; press Enter after selection)" -f $PromptLabel, $DefaultValue }
         else { "{0} (press Enter after selection)" -f $PromptLabel }
    $val = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($val) -and $DefaultValue) { $val = $DefaultValue }
    return $val
}

function Invoke-DownloadWithRetry {
    param([Parameter(Mandatory)][string]$Uri,[Parameter(Mandatory)][string]$OutFile,[int]$MaxAttempts=3,[int]$DelaySeconds=2)
    if (Test-Path -LiteralPath $OutFile) { Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        if (-not ($Silent -or $ExportOnly)) { Write-Host ("Downloading... Attempt {0}/{1}" -f $attempt,$MaxAttempts) -ForegroundColor Cyan }
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                if (-not ($Silent -or $ExportOnly)) { Write-Host "Download successful." -ForegroundColor Green }
                return $true
            }
            throw "Downloaded file is missing or empty."
        } catch {
            if (Test-Path -LiteralPath $OutFile) { Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
            if ($attempt -eq $MaxAttempts) {
                if (-not ($Silent -or $ExportOnly)) { Write-Host ("ERROR: Download failed: {0}" -f $_.Exception.Message) -ForegroundColor Red }
                return $false
            }
            if (-not ($Silent -or $ExportOnly)) {
                Write-Host ("Attempt {0}/{1} failed: {2}" -f $attempt,$MaxAttempts,$_.Exception.Message) -ForegroundColor Yellow
                Write-Host ("   Retrying in {0} seconds..." -f $DelaySeconds) -ForegroundColor Yellow
            }
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $false
}

$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Pause-Script
    return
}
try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_) -ForegroundColor Red
    Pause-Script
    return
}

Ensure-ExportPaths

try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$__NmapInstallPath = "C:\Program Files (x86)\CyberCNSAgent\nmap"
$__NmapDownloadedThisRun = $false
if (-not (Test-Path $__NmapInstallPath)) { New-Item -Path $__NmapInstallPath -ItemType Directory -Force | Out-Null }
$__nmapExe = Join-Path $__NmapInstallPath 'nmap.exe'
$__needsInstall = -not (Test-Path $__nmapExe)
if ($__needsInstall) {
    if (-not ($Silent -or $ExportOnly)) { Write-Host "Preparing Nmap in Program Files..." -ForegroundColor Yellow }
    $zipUrl  = "https://github.com/dmooney-cs/prod/raw/refs/heads/main/nmap.zip"
    $zipPath = Join-Path $env:TEMP "nmap-portable.zip"
    $ok = Invoke-DownloadWithRetry -Uri $zipUrl -OutFile $zipPath -MaxAttempts 3 -DelaySeconds 2
    if ($ok) {
        try {
            Expand-Archive -Path $zipPath -DestinationPath $__NmapInstallPath -Force
            $nestedExe = Join-Path $__NmapInstallPath "nmap\nmap.exe"
            if (Test-Path $nestedExe) {
                $nestedFolder = Split-Path $nestedExe -Parent
                Get-ChildItem -Path $nestedFolder -Force | Move-Item -Destination $__NmapInstallPath -Force
                Remove-Item -Path $nestedFolder -Recurse -Force -ErrorAction SilentlyContinue
            }
            Get-ChildItem -Path $__NmapInstallPath -Recurse -File -Force | Unblock-File -ErrorAction SilentlyContinue
            $__NmapDownloadedThisRun = $true
        } finally {
            try { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}

$NmapHome   = 'C:\Program Files (x86)\CyberCNSAgent\nmap'
$NmapExe    = Join-Path $NmapHome 'nmap.exe'
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Network'

$QuickArgs    = @('-sV','-T4','-F','--version-light')
$ExtendedArgs = @('-sV','-T3','--top-ports','3000','-Pn')
$DefaultScan  = '1'

$Phase2TimeoutTuning = @('--max-retries','2','--host-timeout','45s','--initial-rtt-timeout','100ms','--max-rtt-timeout','800ms')

function Restart-LauncherSameWindow {
    $launcher = $null
    if ($global:CSLauncherRoot -and (Test-Path $global:CSLauncherRoot)) { $launcher = Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1' }
    if (-not $launcher) { $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1' }
    if (Test-Path $launcher) { & $launcher }
}
function Ensure-NmapReady {
    $mirror = Join-Path $scriptRoot 'nmap-bin'
    if (-not (Test-Path $NmapHome)) { New-Item -Path $NmapHome -ItemType Directory -Force | Out-Null }
    if (Test-Path $mirror) { robocopy $mirror $NmapHome *.* /E /NFL /NDL /NJH /NJS /NC /NS | Out-Null }
    if (-not (Test-Path $NmapExe)) { throw "Nmap not found at $NmapExe" }
}
function Get-IPv4Interfaces {
    $results = @()
    try {
        foreach ($a in Get-NetIPConfiguration -ErrorAction Stop) {
            foreach ($ip in ($a.IPv4Address | Where-Object { $_ })) {
                if ($ip.PrefixLength -lt 0 -or $ip.PrefixLength -gt 32) { continue }
                $gw = $null
                if ($a.IPv4DefaultGateway) { $gw = ($a.IPv4DefaultGateway | Select-Object -First 1).NextHop }
                $results += [pscustomobject]@{ Name=$a.InterfaceAlias; IPv4=$ip.IPAddress; Prefix=[int]$ip.PrefixLength; Gateway=$gw }
            }
        }
    } catch { }
    $results
}
function ConvertTo-NetworkCIDR {
    param([string]$Ip,[int]$Prefix)
    try {
        $ipBytes = [System.Net.IPAddress]::Parse($Ip).GetAddressBytes()
        [array]::Reverse($ipBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes,0)
        $mask = 0
        if ($Prefix -gt 0) { $mask = [uint32]::MaxValue -shl (32 - $Prefix) }
        $net = $ipInt -band $mask
        $netBytes = [BitConverter]::GetBytes([uint32]$net)
        [array]::Reverse($netBytes)
        $netIp = [System.Net.IPAddress]::new($netBytes)
        return "$($netIp.IPAddressToString)/$Prefix"
    } catch { return $null }
}

function Choose-Targets {
    param([object[]]$Ifaces)

    Write-Host ""
    Write-Host "Detected IPv4 interfaces:" -ForegroundColor Cyan
    foreach ($i in $Ifaces) {
        $cidrDisplay = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if (-not $cidrDisplay) { $cidrDisplay = '<n/a>' }
        $gwDisplay = if ($i.Gateway) { $i.Gateway } else { '<none>' }
        Write-Host (" - {0,-25} {1}/{2} (GW {3})  ->  {4}" -f $i.Name, $i.IPv4, $i.Prefix, $gwDisplay, $cidrDisplay)
    }

    $options = @()
    foreach ($i in $Ifaces) {
        $cidr = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if ($cidr) { $options += [pscustomobject]@{ Label=$cidr; Src=$i.Name } }
    }

    Write-Host ""
    Write-Host "Available subnets to scan:" -ForegroundColor Cyan
    $idx = 1
    foreach ($o in $options) { Write-Host (" [{0}] {1,-18} ({2})" -f $idx, $o.Label, $o.Src); $idx++ }

    $hostOnly = $Ifaces | Select-Object -First 1
    Write-Host (" [0]  This host only: {0}" -f $hostOnly.IPv4)
    Write-Host (" [C]  Custom target (IP / range / CIDR)")
    Write-Host (" [Q]  Exit to Toolbox Launcher")

    $choice = Prompt-Selection ("Select target number(s) (comma-separated)") $DefaultScan
    if ($choice -match '^[qQ]$') { return @{ ExitToLauncher=$true } }

    $targets = New-Object System.Collections.Generic.List[string]
    foreach ($p in ($choice -split '\s*,\s*')) {
        switch -Regex ($p) {
            '^[0]$' { $targets.Add($hostOnly.IPv4) }
            '^[cC]$' { $custom = Prompt-Selection "Enter custom target (IP / range / CIDR)"; if ($custom) { $targets.Add($custom) } }
            '^\d+$' { $n = [int]$p; if ($n -ge 1 -and $n -le $options.Count) { $targets.Add($options[$n-1].Label) } }
        }
    }
    if ($targets.Count -eq 0) { $targets.Add($hostOnly.IPv4) }
    return @{ Targets=$targets }
}

function Build-DeepArgs {
    param([bool]$IncludeUDP = $false)
    $isAdmin = Get-IsAdmin
    $synOrConnect = if ($isAdmin) { '-sS' } else { '-sT' }
    $args = @($synOrConnect,'-p-','-sV','--version-all','-O','-sC','--traceroute','--reason','-T3','--max-retries','2','--defeat-rst-ratelimit')
    if ($IncludeUDP) {
        $udpList = 'U:53,67,68,69,123,137,138,161,500,1900,4500,5353'
        $tcpAll  = 'T:1-65535'
        $i = $args.IndexOf('-p-')
        if ($i -ge 0) {
            $args[$i] = '-p'
            $args = $args[0..$i] + @("$tcpAll,$udpList") + $args[($i+1)..($args.Count-1)]
        }
        $args += '-sU'
    }
    return $args
}
function Get-ProfileDetails {
    param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][array]$Args)
    $flags = ($Args -join ' ')
@"
Profile: $Name
Flags  : $flags
Notes  :
  - TWO-PHASE:
      Phase 1: Discovery sweep (-sn) finds hosts up
      Phase 2: Port scan ONLY those hosts (still checks ports)
  - Timeouts/retries reduced in Phase 2 to prevent hour-long /24 scans.
"@
}
function Choose-ScanMode {
    Write-Host ""
    Write-Host "Scan mode:" -ForegroundColor Cyan
    Write-Host " [1] Quick    - top 100 TCP ports | T4 | version light"
    Write-Host " [2] Extended - top 3000 TCP ports | T3"
    Write-Host " [3] Deep     - ALL TCP ports | T3 | OS detect | scripts | traceroute"

    $mode = Prompt-Selection "Choose scan mode" "1"
    if ($mode -eq '2')      { $profile = @{ Name='Extended'; Args=$ExtendedArgs } }
    elseif ($mode -eq '3')  {
        $incUdp = Ask-YesNo -Prompt "Include UDP discovery on common ports (53, 67, 68, 69, 123, 137, 138, 161, 500, 1900, 4500, 5353)?" -Default 'N'
        $profile = @{ Name='Deep'; Args=(Build-DeepArgs -IncludeUDP:$incUdp) }
    } else { $profile = @{ Name='Quick'; Args=$QuickArgs } }

    Write-Host ""
    Write-Host (Get-ProfileDetails -Name $profile.Name -Args $profile.Args) -ForegroundColor Gray
    return $profile
}

function Invoke-NmapProcess {
    param([Parameter(Mandatory)][array]$ArgList,[string]$StdOutPath,[string]$StdErrPath)
    $start = Get-Date
    $proc = Start-Process -FilePath $NmapExe -ArgumentList ($ArgList -join ' ') -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $StdOutPath -RedirectStandardError $StdErrPath
    $end = Get-Date
    $elapsed = $end - $start
    $exit = if ($proc) { $proc.ExitCode } else { 1 }
    return [pscustomobject]@{ ExitCode=$exit; Duration=$elapsed; StartedAt=$start; EndedAt=$end }
}

function Get-UpHostsFromDiscoveryOutputs {
    param([string]$XmlPath,[string]$TextPath)
    $up = New-Object System.Collections.Generic.List[string]
    try {
        if (Test-Path -LiteralPath $XmlPath) {
            [xml]$x = Get-Content -LiteralPath $XmlPath -Encoding UTF8 -ErrorAction Stop
            foreach ($host in @($x.nmaprun.host)) {
                $state = $null
                try { $state = [string]$host.status.state } catch { $state = $null }
                if ($state -ne 'up') { continue }
                $ipv4 = $null
                foreach ($addrNode in @($host.address)) {
                    if ($addrNode.addrtype -eq 'ipv4' -and $addrNode.addr) { $ipv4 = [string]$addrNode.addr; break }
                }
                if ($ipv4) { $up.Add($ipv4) }
            }
        }
    } catch { }

    if ($up.Count -eq 0) {
        try {
            if (Test-Path -LiteralPath $TextPath) {
                foreach ($line in (Get-Content -LiteralPath $TextPath -ErrorAction Stop)) {
                    if ($line -match '^Nmap scan report for\s+(.+)$') {
                        $t = $Matches[1].Trim()
                        $ip = $null
                        if ($t -match '\((\d{1,3}(\.\d{1,3}){3})\)') { $ip = $Matches[1] }
                        elseif ($t -match '(\d{1,3}(\.\d{1,3}){3})') { $ip = $Matches[1] }
                        if ($ip) { $up.Add($ip) }
                    }
                }
            }
        } catch { }
    }
    return @($up | Sort-Object -Unique)
}

function Run-NmapDiscovery {
    param([string[]]$Targets)
    if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory -Force | Out-Null }
    $dateStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = Join-Path $ExportRoot ("Nmap-Discovery_{0}" -f $dateStamp)
    $outN = "$base.txt"
    $outX = "$base.xml"
    $runOut = "$base.runlog.txt"
    $runErr = "$base.errlog.txt"

    $argList = @('-sn','-n','-T4','--max-retries','1','--host-timeout','10s','-oN',$outN,'-oX',$outX) + $Targets

    $run = Invoke-NmapProcess -ArgList $argList -StdOutPath $runOut -StdErrPath $runErr
    $upHosts = Get-UpHostsFromDiscoveryOutputs -XmlPath $outX -TextPath $outN

    return [pscustomobject]@{ OutText=$outN; OutXml=$outX; ExitCode=$run.ExitCode; Duration=$run.Duration; UpHosts=$upHosts; RunLog=$runOut; ErrLog=$runErr }
}

function Run-NmapScanPhase2 {
    param([Parameter(Mandatory)][string[]]$TargetsUp,[Parameter(Mandatory)][string]$ProfileName,[Parameter(Mandatory)][array]$Args)
    if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory -Force | Out-Null }
    $dateStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = Join-Path $ExportRoot ("Nmap-Scan_{0}_{1}" -f $dateStamp, $ProfileName)
    $outN = "$base.txt"
    $outX = "$base.xml"
    $runOut = "$base.runlog.txt"
    $runErr = "$base.errlog.txt"

    $argList = @()
    if ($Args) { $argList += $Args }
    if (-not ($argList -contains '-Pn')) { $argList += '-Pn' }
    if (-not ($argList -contains '-n'))  { $argList += '-n' }
    $argList += $Phase2TimeoutTuning
    $argList += @('-oN',$outN,'-oX',$outX)
    $argList += $TargetsUp

    $run = Invoke-NmapProcess -ArgList $argList -StdOutPath $runOut -StdErrPath $runErr
    return [pscustomobject]@{ OutText=$outN; OutXml=$outX; ExitCode=$run.ExitCode; Duration=$run.Duration; StartedAt=$run.StartedAt; EndedAt=$run.EndedAt; RunLog=$runOut; ErrLog=$runErr }
}

function Parse-NmapXml {
    param([Parameter(Mandatory)][string]$XmlPath)
    $items = @()
    try {
        if (-not (Test-Path -LiteralPath $XmlPath)) { return @() }
        [xml]$x = Get-Content -LiteralPath $XmlPath -Encoding UTF8 -ErrorAction Stop
        foreach ($host in $x.nmaprun.host) {
            $ipv4 = $null; $mac = $null; $macVendor = $null
            foreach ($addrNode in @($host.address)) {
                if ($addrNode.addrtype -eq 'ipv4' -and -not $ipv4) { $ipv4 = $addrNode.addr }
                if ($addrNode.addrtype -eq 'mac'  -and -not $mac)  { $mac  = $addrNode.addr; $macVendor = $addrNode.vendor }
            }
            $names = @()
            if ($host.hostnames.hostname) { foreach ($hn in $host.hostnames.hostname) { if ($hn.name) { $names += $hn.name } } }
            $hnDisplay = if ($names) { ($names -join ', ') } else { '' }

            $openPorts = @()
            if ($host.ports.port) {
                foreach ($p in $host.ports.port) {
                    if ($p.state.state -eq 'open') {
                        $svc  = $p.service
                        $openPorts += [pscustomobject]@{
                            Port    = [int]$p.portid
                            Proto   = [string]$p.protocol
                            Service = if ($svc.name)     { [string]$svc.name }     else { '' }
                            Product = if ($svc.product)  { [string]$svc.product }  else { '' }
                            Version = if ($svc.version)  { [string]$svc.version }  else { '' }
                            Extra   = if ($svc.extrainfo){ [string]$svc.extrainfo } else { '' }
                        }
                    }
                }
            }
            $status = if ($host.status) { [string]$host.status.state } else { '' }
            $detected = ($status -eq 'up') -or ($openPorts.Count -gt 0)
            if ($detected -and $ipv4) {
                $macDisplay = if ($mac) { if ($macVendor) { "$mac ($macVendor)" } else { $mac } } else { "" }
                $items += [pscustomobject]@{ Address=$ipv4; Hostnames=$hnDisplay; Status=(if ($status){$status}else{'unknown'}); Mac=$macDisplay; OpenPorts=@($openPorts | Sort-Object Port, Proto) }
            }
        }
    } catch { return @() }
    return @($items)
}
function Parse-NmapText {
    param([Parameter(Mandatory)][string]$TextPath)
    $items = @()
    try {
        if (-not (Test-Path -LiteralPath $TextPath)) { return @() }
        $lines = Get-Content -LiteralPath $TextPath -ErrorAction Stop
        $current = $null
        $parsingPorts = $false
        foreach ($line in $lines) {
            if ($line -match '^Nmap scan report for\s+(.+)$') {
                if ($current) { $items += $current; $current = $null; $parsingPorts = $false }
                $target = $Matches[1].Trim()
                $addr = $null; $name = ''
                if ($target -match '^(.*?)\s+\(([^)]+)\)\s*$') { $name = $Matches[1].Trim(); $addr = $Matches[2].Trim() }
                else { $addr = ($target -split '\s+')[-1] }
                $current = [pscustomobject]@{ Address=$addr; Hostnames=$name; Status=''; Mac=''; OpenPorts=@() }
                continue
            }
            if ($current -and $line -match '^Host is up') { $current.Status='up'; continue }
            if ($current -and $line -match '^\s*PORT\s+STATE\s+SERVICE') { $parsingPorts=$true; continue }
            if ($current -and $parsingPorts -and ($line -match '^\s*$' -or $line -match '^Nmap scan report for')) {
                $parsingPorts=$false
                if ($line -match '^Nmap scan report for') { continue }
            }
            if ($current -and $parsingPorts) {
                if ($line -match '^\s*(\d+)\/(\w+)\s+(\w+)\s+(.*)$') {
                    $port=[int]$Matches[1]; $proto=$Matches[2]; $state=$Matches[3]; $svc=$Matches[4].Trim()
                    if ($state -eq 'open') { $current.OpenPorts += [pscustomobject]@{ Port=$port; Proto=$proto; Service=$svc; Product=''; Version=''; Extra='' } }
                }
                continue
            }
            if ($current -and $line -match '^MAC Address:\s*([0-9A-Fa-f:]+)(?:\s*\((.*?)\))?') {
                $mac=$Matches[1]; $vendor=$Matches[2]
                $current.Mac = if ($vendor) { "$mac ($vendor)" } else { $mac }
                continue
            }
        }
        if ($current) { $items += $current }
    } catch { return @() }
    foreach ($it in $items) {
        if (-not $it.Status) { if ($it.OpenPorts -and $it.OpenPorts.Count -gt 0) { $it.Status='up' } else { $it.Status='unknown' } }
        if (-not $it.OpenPorts) { $it.OpenPorts=@() }
    }
    return @($items)
}
function Parse-NmapTextHostsUp {
    param([Parameter(Mandatory)][string]$TextPath)
    $hostsUp = $null
    try {
        if (-not (Test-Path -LiteralPath $TextPath)) { return $null }
        foreach ($line in (Get-Content -LiteralPath $TextPath -ErrorAction Stop)) {
            if ($line -match 'Nmap done:\s+\d+\s+IP addresses\s+\((\d+)\s+hosts?\s+up\)') { $hostsUp = [int]$Matches[1] }
        }
    } catch { return $null }
    return $hostsUp
}

function Show-ScanResultsPaged {
    param([object[]]$Items=@(),[Parameter(Mandatory)][string[]]$Targets,[Parameter(Mandatory)][string]$ProfileName,[Parameter(Mandatory)][timespan]$Duration,[string]$NmapSourceNote="",[int]$ExpectedHostCount=-1)
    if ($Silent -or $ExportOnly) { return }
    if ($null -eq $Items) { $Items=@() }
    $countActual=$Items.Count
    $countDisplay= if ($ExpectedHostCount -ge 0) { $ExpectedHostCount } else { $countActual }
    $pageSize=3; $index=0
    $targetsDisplay = ($Targets -join ', ')
    Write-Host ""
    Write-Host "==================== SCAN SUMMARY ====================" -ForegroundColor Cyan
    Write-Host (" Scanned Targets : {0}" -f $targetsDisplay) -ForegroundColor Gray
    Write-Host (" Profile         : {0}" -f $ProfileName) -ForegroundColor Gray
    Write-Host (" Items Detected  : {0}" -f $countDisplay) -ForegroundColor Gray
    Write-Host (" Duration        : {0}" -f $Duration.ToString()) -ForegroundColor Gray
    if ($NmapSourceNote) { Write-Host (" Nmap Source     : {0}" -f $NmapSourceNote) -ForegroundColor Gray }
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host ""
    if ($countActual -eq 0) { Write-Host "No host details available to display. See output files below." -ForegroundColor DarkGray; return }

    while ($index -lt $countActual) {
        $end = [Math]::Min($index + $pageSize, $countActual)
        for ($i=$index; $i -lt $end; $i++) {
            $item=$Items[$i]
            Write-Host ("-"*70) -ForegroundColor DarkGray
            Write-Host (" Host {0}/{1}" -f ($i+1),$countActual) -ForegroundColor Cyan
            Write-Host ("   Address  : {0}" -f $item.Address)
            if ($item.Hostnames) { Write-Host ("   Hostname : {0}" -f $item.Hostnames) }
            Write-Host ("   Status   : {0}" -f $item.Status)
            if ($item.Mac) { Write-Host ("   MAC      : {0}" -f $item.Mac) }
            if ($item.OpenPorts -and $item.OpenPorts.Count -gt 0) {
                Write-Host "   Open Ports:"
                foreach ($p in $item.OpenPorts) {
                    $svcBits=@(); if ($p.Service){$svcBits+=$p.Service}; if ($p.Product){$svcBits+=$p.Product}; if ($p.Version){$svcBits+=$p.Version}; if ($p.Extra){$svcBits+="($($p.Extra))"}
                    $svcText = if ($svcBits) { ' - ' + ($svcBits -join ' ') } else { '' }
                    Write-Host ("     - {0}/{1} open{2}" -f $p.Port,$p.Proto,$svcText)
                }
            } else { Write-Host "   Open Ports: none detected" }
        }
        Write-Host ("-"*70) -ForegroundColor DarkGray
        if ($end -lt $countActual) {
            Write-Host "Press any key for more results, or type Q then press Enter to stop." -ForegroundColor DarkGray
            try { $key=$Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown"); if ($key -and $key.Character -in 'q','Q') { break } }
            catch { $resp = Prompt-Selection "Press Enter for more results or type Q to stop"; if ($resp -match '^[qQ]$') { break } }
        }
        $index=$end
    }
}

# ---- Main loop ----
try {
    Ensure-NmapReady

    while ($true) {
        Show-Header "Nmap Data Collection - Local Network Overview"

        $ifaces = Get-IPv4Interfaces
        if (-not $ifaces) { $ifaces = @([pscustomobject]@{ Name='Localhost'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null }) }

        $targetChoice = Choose-Targets -Ifaces $ifaces

        # FIXED: safe hashtable key check (prevents your error)
        if ($targetChoice -is [hashtable] -and $targetChoice.ContainsKey('ExitToLauncher') -and $targetChoice['ExitToLauncher']) {
            Restart-LauncherSameWindow
            break
        }

        $mode = Choose-ScanMode

        $disc = Run-NmapDiscovery -Targets $targetChoice.Targets

        Write-Host ""
        Write-Host ("[INFO] Phase 1 complete. Discovery duration: {0}" -f $disc.Duration.ToString()) -ForegroundColor Gray
        Write-Host ("[INFO] Hosts up found: {0}" -f ($disc.UpHosts.Count)) -ForegroundColor Gray

        if (-not $disc.UpHosts -or $disc.UpHosts.Count -eq 0) {
            Write-Host "No hosts were detected as up in discovery phase. Nothing to scan." -ForegroundColor Yellow
            Pause-Script "Press any key to return to the main menu..."
            continue
        }

        $scan = Run-NmapScanPhase2 -TargetsUp $disc.UpHosts -ProfileName $mode.Name -Args $mode.Args

        $itemsXml  = Parse-NmapXml  -XmlPath  $scan.OutXml
        $itemsText = Parse-NmapText -TextPath $scan.OutText
        $hostsUpFromText = Parse-NmapTextHostsUp -TextPath $scan.OutText

        $items = @()
        if ($itemsXml -and $itemsXml.Count -gt 0) {
            if ($hostsUpFromText -and ($itemsXml.Count -lt $hostsUpFromText) -and ($itemsText.Count -ge $hostsUpFromText)) { $items = $itemsText }
            else { $items = $itemsXml }
        } else { $items = $itemsText }

        $expected = if ($hostsUpFromText -ne $null) { [int]$hostsUpFromText } else { $disc.UpHosts.Count }

        Show-ScanResultsPaged -Items $items -Targets $targetChoice.Targets -ProfileName $mode.Name -Duration ($disc.Duration + $scan.Duration) -ExpectedHostCount $expected

        Pause-Script "Press any key to return to the main menu..."
    }
} catch {
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-SessionSummary
    Pause-Script "Press any key to return to the Toolbox Launcher..."
    Restart-LauncherSameWindow
}