<# =====================================================================
 CS-Reload-Dependencies.ps1
 - Menu-driven OR silent mode
 - Logs all actions
 - Exports logs to: C:\CS-Toolbox-TEMP\Collected-Info
 - -Silent runs FULL reload with no screen output
 - Exit returns to CS-Toolbox-Launcher.ps1
 ===================================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

# ------------------------- Paths -------------------------

$CollectedInfoDir = "C:\CS-Toolbox-TEMP\Collected-Info"
$LauncherPath     = "C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1"

# ------------------------- Helpers -------------------------

function Ensure-Folder {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

Ensure-Folder $CollectedInfoDir
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile   = Join-Path $CollectedInfoDir "CS-Reload-Dependencies_$Timestamp.log"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","OK","WARN","ERR")] $Level = "INFO"
    )

    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -LiteralPath $LogFile -Value $line

    if (-not $Silent) {
        switch ($Level) {
            "OK"   { Write-Host $line -ForegroundColor Green }
            "WARN" { Write-Host $line -ForegroundColor Yellow }
            "ERR"  { Write-Host $line -ForegroundColor Red }
            default{ Write-Host $line }
        }
    }
}

function Invoke-Service {
    param(
        [string]$Name,
        [ValidateSet("Start","Stop")] $Action
    )

    try {
        Write-Log "Running: net $Action $Name"
        $out = & cmd.exe /c "net $Action $Name" 2>&1
        Add-Content -LiteralPath $LogFile -Value ($out | Out-String)
        Write-Log "$Action service succeeded: $Name" "OK"
        return $true
    } catch {
        Write-Log "$Action service FAILED: $Name | $($_.Exception.Message)" "ERR"
        return $false
    }
}

function Remove-DependencyFiles {
    $files = @(
        "last_dependency_check_time.txt",
        "dependency_details.cfg",
        "dependency.json"
    )

    $roots = @(
        "$env:ProgramData",
        "$env:ProgramFiles",
        "${env:ProgramFiles(x86)}",
        "C:\CyberCNS",
        "C:\CyberCNSAgent"
    ) | Where-Object { Test-Path $_ }

    $found = $false

    foreach ($root in $roots) {
        foreach ($file in $files) {
            Get-ChildItem -Path $root -Filter $file -Recurse -File -ErrorAction SilentlyContinue |
            ForEach-Object {
                try {
                    Write-Log "Deleting: $($_.FullName)"
                    Remove-Item $_.FullName -Force
                    Write-Log "Deleted: $($_.FullName)" "OK"
                    $found = $true
                } catch {
                    Write-Log "Failed deleting $($_.FullName): $($_.Exception.Message)" "ERR"
                }
            }
        }
    }

    if (-not $found) {
        Write-Log "No dependency files found to delete" "WARN"
    }
}

function Run-FullReload {
    Write-Log "=== FULL DEPENDENCY RELOAD START ==="

    Invoke-Service "cybercnsagent"        "Stop" | Out-Null
    Invoke-Service "cybercnsagentmonitor" "Stop" | Out-Null

    Remove-DependencyFiles

    Invoke-Service "cybercnsagent"        "Start" | Out-Null
    Invoke-Service "cybercnsagentmonitor" "Start" | Out-Null

    Write-Log "=== FULL DEPENDENCY RELOAD END ==="
    Write-Log "Log saved to $LogFile"
}

function Return-To-Launcher {
    if (Test-Path $LauncherPath) {
        Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$LauncherPath`""
    }
    exit
}

# ------------------------- Silent Mode -------------------------

if ($Silent) {
    Run-FullReload
    exit
}

# ------------------------- Menu -------------------------

while ($true) {
    Clear-Host
    Write-Host "CS-Reload-Dependencies.ps1" -ForegroundColor Cyan
    Write-Host "Log export folder: $CollectedInfoDir"
    Write-Host "Current log file:   $LogFile"
    Write-Host ""
    Write-Host "Choose an option:"
    Write-Host "  1) Full reload (Stop services -> Delete files -> Start services)"
    Write-Host "  2) Stop services only"
    Write-Host "  3) Delete files only"
    Write-Host "  4) Start services only"
    Write-Host "  0) Return to Toolbox Launcher"
    Write-Host ""

    $choice = Read-Host "Enter selection"

    switch ($choice) {
        "1" { Run-FullReload; Read-Host "Press ENTER to continue" | Out-Null }
        "2" {
            Invoke-Service "cybercnsagent"        "Stop" | Out-Null
            Invoke-Service "cybercnsagentmonitor" "Stop" | Out-Null
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "3" { Remove-DependencyFiles; Read-Host "Press ENTER to continue" | Out-Null }
        "4" {
            Invoke-Service "cybercnsagent"        "Start" | Out-Null
            Invoke-Service "cybercnsagentmonitor" "Start" | Out-Null
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "0" { Return-To-Launcher }
        default {
            Write-Log "Invalid selection: $choice" "WARN"
            Read-Host "Press ENTER to continue" | Out-Null
        }
    }
}
