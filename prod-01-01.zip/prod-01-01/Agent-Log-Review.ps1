<# ====================================================
  Agent-Log-Review.ps1  (v6e - HTML export with "Last 5 minutes" section, PS 5.1 safe)
====================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables ----
$ContextBefore          = 3     # lines before the error line in context
$ContextAfter           = 3     # lines after the error line in context
$MaxExamplesPerPattern  = 12    # max contexts kept per unique pattern in report
$LargeFileContextMB     = 25    # over this size, limit captured contexts to 3/pattern
$FoldUrlToHost          = $true # if true, replace URLs with {URL:host} to group noisy paths/query strings
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$RecentWindowMinutes    = 5     # "Last 5 minutes only" window

# -------- Bootstrap --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) { try { . $commonPath } catch { } }
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header { param([string]$Title='ConnectSecure Technicians Toolbox')
    Write-Host ("`n $Title") -ForegroundColor Cyan
    Write-Host ('='*58)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME,"$env:USERDOMAIN\$env:USERNAME",$isAdmin) -ForegroundColor Gray
    Write-Host ('='*58)
    Write-Host ''
  }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

function Select-Folder {
  param([string]$Description='Select a folder',[string]$InitialDirectory='C:\')
  try {
    $shell = New-Object -ComObject Shell.Application
    $folder = $shell.BrowseForFolder(0,$Description,0,$InitialDirectory)
    if ($folder) { return $folder.Self.Path }
  } catch { }
  return $null
}

function HtmlEscape($s) { return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }

# -------- Normalization helpers --------
function Normalize-LineForPattern {
  param([string]$Line)

  if ($null -eq $Line) { return '' }
  $norm = $Line

  # Remove timestamps: 2025-08-18 10:34:23(.ms)[Z|±hh:mm] and 2025/08/18 10:34:23
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  # Remove standalone HH:MM:SS(.ms)
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''

  # Optional URL folding to host
  if ($FoldUrlToHost) {
    $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}')
  }

  # Mask GUIDs/HEX
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'

  # Compress whitespace
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()

  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

# -------- Timestamp parsing (for "Last 5 minutes" window) --------
function TryParse-LineDateTime {
  param(
    [string]$Line,
    [datetime]$FallbackDate # used when only time-of-day is present
  )
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

  # ISO-like: 2025-10-27 14:03:22(.123)(Z|+02:00)
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
  if ($m.Success) {
    $str = $m.Groups[1].Value + ' ' + $m.Groups[2].Value + $m.Groups[3].Value
    try { return [datetime]::Parse($str) } catch {}
  }

  # Slash date: 2025/10/27 14:03:22(.123)
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success) {
    $str = $m.Groups[1].Value + ' ' + $m.Groups[2].Value + $m.Groups[3].Value
    try { return [datetime]::Parse($str) } catch {}
  }

  # Time only: HH:mm:ss(.fff) -> assume same date as fallback
  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success -and $FallbackDate) {
    $tod = $m.Groups[1].Value
    try {
      $d = Get-Date -Date $FallbackDate.Date -Hour ([int]$tod.Substring(0,2)) -Minute ([int]$tod.Substring(3,2)) -Second ([int]$tod.Substring(6,2))
      return $d
    } catch {}
  }

  return $null
}

# -------- Analysis --------
function Analyze-File {
  param([string]$FilePath)

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $patterns = @{}
  $contexts = @{}  # pattern -> list[string]

  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false
  if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

  $lines = Get-Content -LiteralPath $FilePath -ErrorAction SilentlyContinue

  # --- Recent window prepass (indices of lines with timestamps within last X minutes) ---
  $now = Get-Date
  $windowStart = $now.AddMinutes(-$RecentWindowMinutes)
  $fallbackDate = if ($file) { $file.LastWriteTime } else { $now }
  $recentIdxs = New-Object System.Collections.Generic.List[int]
  for ($ri=0; $ri -lt $lines.Count; $ri++) {
    $dt = TryParse-LineDateTime -Line $lines[$ri] -FallbackDate $fallbackDate
    if ($dt -and $dt -ge $windowStart -and $dt -le $now) { $recentIdxs.Add($ri) }
  }

  # --- Full-file pass for patterns/contexts ---
  for ($i=0;$i -lt $lines.Count;$i++) {
    $line = [string]$lines[$i]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }

      $norm = Normalize-LineForPattern -Line $line
      if (-not $patterns.ContainsKey($norm)) { $patterns[$norm] = 0 }
      $patterns[$norm]++
      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }

      # Decide max contexts per pattern
      $maxCtx = $MaxExamplesPerPattern
      if ($limitCtx) { $maxCtx = [Math]::Min($MaxExamplesPerPattern, 3) }

      if ($contexts[$norm].Count -lt $maxCtx) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        # include indented stack lines
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($null -eq $n -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx="Context for line $($i+1) (&plusmn;$ContextBefore/$ContextAfter)`n"
        for($p=$start;$p -le $end;$p++){ $prefix = ('   '); if($p -eq $i){ $prefix = '>> ' }; $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p]) }
        $contexts[$norm] += $ctx
      }
    }
  }

  # --- Recent window: severity counts & short contexts only around recent indices that also match severity regex ---
  $recentCounts = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $recentSnippets = New-Object System.Collections.Generic.List[string]
  foreach ($idx in $recentIdxs) {
    $line = [string]$lines[$idx]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$recentCounts.ERROR++}
        '^FATAL$'        {$recentCounts.FATAL++}
        '^EXCEPTION$'    {$recentCounts.EXCEPTION++}
        '^WARN$'         {$recentCounts.WARN++}
        '^WARNING$'      {$recentCounts.WARNING++}
        '^FAIL(ED)?$'    {$recentCounts.FAIL++}
        '^TIMEOUT$'      {$recentCounts.TIMEOUT++}
        '^UNAUTHORIZED$' {$recentCounts.UNAUTHORIZED++}
        'ACCESS DENIED'  {$recentCounts.ACCESSDENIED++}
      }

      # Shorter context for recent section
      $rStart=[Math]::Max(0,$idx-1); $rEnd=[Math]::Min($lines.Count-1,$idx+1)
      $ctx="Recent match at line $($idx+1)`n"
      for($p=$rStart;$p -le $rEnd;$p++){ $prefix=('   '); if($p -eq $idx){ $prefix='>> ' }; $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p]) }
      $recentSnippets.Add($ctx)
    }
  }

  return [PSCustomObject]@{
    File           = $FilePath
    Total          = $lines.Count
    Counts         = $countsByLevel
    Patterns       = $patterns
    Contexts       = $contexts
    Limited        = $limitCtx
    RecentWindow   = @{ Start=$windowStart; End=$now }
    RecentCounts   = $recentCounts
    RecentSnippets = $recentSnippets
  }
}

# -------- Report --------
function Collect-And-Report {
  param([string[]]$Roots)

  $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
  Ensure-Folder $outDir
  $ts=Get-Date -Format 'yyyyMMdd_HHmmss'
  $collectDir=Join-Path $outDir ('Collect_'+$ts)
  Ensure-Folder $collectDir

  $patterns='*.log','*.txt','*.json','*.evtx','*.zip','*.gz'
  $found=$false
  foreach($root in ($Roots|Where-Object{Test-Path -LiteralPath $_})){ 
    Write-Info "Scanning $root ..."
    $dest=Join-Path $collectDir ((Split-Path $root -Leaf)-replace'[^\w\.-]','_'); Ensure-Folder $dest
    try {
      $items = Get-ChildItem -Path (Join-Path $root '*') -Recurse -File -Include $patterns -ErrorAction SilentlyContinue
      if ($items) {
        $found=$true
        $i=0; foreach($f in $items){ $i++; if($i%50 -eq 0){ Write-Info (" Copying files... {0}/{1}" -f $i,$items.Count) }
          $rel=try{$f.FullName.Substring($root.Length).TrimStart('\')}catch{$f.Name}
          $tgt=Join-Path $dest $rel; Ensure-Folder (Split-Path $tgt -Parent)
          Copy-Item -LiteralPath $f.FullName -Destination $tgt -Force -ErrorAction SilentlyContinue
        }
        Write-OK ("Copied {0} files from {1}" -f $items.Count,$root)
      } else { Write-Warn ("No matching files found under {0}" -f $root) }
    } catch { Write-Warn ("Scan error on {0}: {1}" -f $root,$_.Exception.Message) }
  }
  if(-not $found){ Write-Warn 'No logs found'; New-Item -ItemType File -Path (Join-Path $collectDir 'NO_LOGS_FOUND.txt') -Force|Out-Null }
  else { Write-OK ('Collected logs to: {0}' -f $collectDir) }

  # Build HTML
  $html=[System.Text.StringBuilder]::new()
  $null=$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>')
  $null=$html.AppendLine('<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:8px;margin:6px 0 10px;}
.kicker h3{margin:0 0 6px 0;}
</style></head><body>')
  $null=$html.AppendLine('<div class="logo-wrap"><img src="'+ (HtmlEscape $LogoUrl) +'" alt="ConnectSecure logo"></div>')
  $null=$html.AppendLine('<h1>ConnectSecure &mdash; Agent Log Review</h1>')

  $textFiles=Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object{$_.Extension -in '.log','.txt','.json'}
  foreach($tf in $textFiles){
    Write-Info ("Analyzing " + $tf.FullName)
    $res=Analyze-File -FilePath $tf.FullName
    $fname=Split-Path $tf.FullName -Leaf

    $null=$html.AppendLine("<details><summary>"+(HtmlEscape $fname)+" &mdash; "+$res.Total+" lines</summary>")

    # ---------- NEW: "Last 5 minutes only" section ----------
    $wStart = $res.RecentWindow.Start.ToString('yyyy-MM-dd HH:mm:ss')
    $wEnd   = $res.RecentWindow.End.ToString('yyyy-MM-dd HH:mm:ss')
    $null=$html.AppendLine('<div class="kicker">')
    $null=$html.AppendLine('<h3>Last '+$RecentWindowMinutes+' minutes only</h3>')
    $null=$html.AppendLine('<div class="small">Window: '+ (HtmlEscape $wStart) +' &rarr; '+ (HtmlEscape $wEnd) +' (local)</div>')
    # Recent severity table
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count (recent)</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.RecentCounts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')
    # Recent snippets (limited to 15 to avoid bloat)
    $maxRecent = [Math]::Min(15, $res.RecentSnippets.Count)
    if ($maxRecent -gt 0) {
      for ($ri=0; $ri -lt $maxRecent; $ri++) {
        $null=$html.AppendLine("<pre>"+ (HtmlEscape $res.RecentSnippets[$ri]) +"</pre>")
      }
      if ($res.RecentSnippets.Count -gt $maxRecent) {
        $null=$html.AppendLine('<div class="small">…'+($res.RecentSnippets.Count - $maxRecent)+' more recent matches omitted for brevity.</div>')
      }
    } else {
      $null=$html.AppendLine('<div class="small">No severity matches within the last '+$RecentWindowMinutes+' minutes.</div>')
    }
    $null=$html.AppendLine('</div>')
    # ---------- END NEW SECTION ----------

    # Severity table (full file)
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){ $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.Counts[$k]+"</td></tr>") }
    $null=$html.AppendLine('</tbody></table>')

    # Patterns & contexts (full file)
    $ordered=$res.Patterns.GetEnumerator()|Sort-Object Value -Descending
    foreach($entry in $ordered){
      $pat=(HtmlEscape $entry.Key); $cnt=$entry.Value
      $null=$html.AppendLine('<details><summary>'+ $pat +' &mdash; <span class="small">'+$cnt+' occurrence(s)</span></summary>')
      $idx=1
      if ($res.Contexts.ContainsKey($entry.Key)) {
        foreach($ctx in $res.Contexts[$entry.Key]){ $null=$html.AppendLine("<h4>Example "+$idx+"</h4><pre>"+(HtmlEscape $ctx)+"</pre>"); $idx++ }
      }
      $null=$html.AppendLine('</details>')
    }
    $null=$html.AppendLine('</details>')

    # CSV per file (full-file pattern summary)
    $csvPath=Join-Path $collectDir ($fname+'_ErrorSummary.csv')
    $res.Patterns.GetEnumerator()|Sort-Object Value -Descending|Select-Object @{n='Pattern';e={$_.Key}},@{n='Count';e={$_.Value}}|Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath

    # CSV per file (recent counts)
    $csvRecent = Join-Path $collectDir ($fname+'_Recent_'+$RecentWindowMinutes+'min.csv')
    [pscustomobject]@($res.RecentCounts) |
      Select-Object @{n='ERROR';e={$_.ERROR}},
                    @{n='FATAL';e={$_.FATAL}},
                    @{n='EXCEPTION';e={$_.EXCEPTION}},
                    @{n='WARN';e={$_.WARN}},
                    @{n='WARNING';e={$_.WARNING}},
                    @{n='FAIL';e={$_.FAIL}},
                    @{n='TIMEOUT';e={$_.TIMEOUT}},
                    @{n='UNAUTHORIZED';e={$_.UNAUTHORIZED}},
                    @{n='ACCESSDENIED';e={$_.ACCESSDENIED}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvRecent
  }

  $null=$html.AppendLine('</body></html>')
  $htmlPath=Join-Path $collectDir 'index.html'
  # Force UTF-8 with BOM for maximum compatibility
  $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html.ToString())
  [System.IO.File]::WriteAllBytes($htmlPath, $bytes)

  Write-OK ("Wrote HTML report: $htmlPath")
  try{ Start-Process $htmlPath }catch{}
}

function Start-AgentLogReview {
  Show-Header -Title 'ConnectSecure Technicians Toolbox'
  Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
  Write-Host ''
  Write-Host ' [1] Local Agent ConnectSecure Logs' -ForegroundColor White
  Write-Host '     - Scans: C:\Program Files (x86)\CyberCNSAgent\logs' -ForegroundColor DarkGray
  Write-Host ' [2] Specify custom scan directory...' -ForegroundColor White
  Write-Host ' [Q] Quit' -ForegroundColor White
  Write-Host ''
  $choice=Read-Host 'Select an option (1/2/Q)'
  switch($choice.ToUpper()) {
    '1'{ $p='C:\Program Files (x86)\CyberCNSAgent\logs'; Collect-And-Report -Roots @($p) }
    '2'{ $picked=Select-Folder -Description 'Choose agent logs folder' -InitialDirectory 'C:\Program Files (x86)\CyberCNSAgent\logs'; if($picked){ Collect-And-Report -Roots @($picked) } else { Write-Warn 'No valid folder' } }
    'Q'{ return }
    Default{ Write-Warn 'Invalid choice.' }
  }
  Write-Host ''; Read-Host 'Press Enter to return...'
}

Start-AgentLogReview
