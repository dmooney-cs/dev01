<# ====================================================
  Agent-Log-Review.ps1

  SWITCHES (top-level):
    -DefaultLogs
    -LogPath "C:\Path With Spaces\logs"
    -ExportOnly

  OUTPUT:
    C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs

  Charting:
    - Recent: last 2 days (48 hourly buckets)
    - Full:   full log range (downsampled buckets)
    - Y axis = hits per bucket
    - X axis labels = MM-DD only

  CURRENT RULES (this revision):
    1) IP section: do NOT review cyberutilities.log or software.log
    2) Ignore any severity line that contains exact text: 'base dir already created'
    3) One combined list (no older-than-2-days section).
    4) Grouping type A (frequency grouping):
       - Only auto-group when Count > 3 AND Frequency is NOT null AND Frequency is identical
       - Otherwise render as individual error
       - Header: "Grouped similar errors - Count: X - Frequency: Y"
         and list each member error line with its Count/Frequency
    5) Grouping type B (text grouping):
       - Group any error line that contains:
           Client.Timeout exceeded while awaiting headers
       - Group any error line that contains:
           nmap
       - Header uses the label text and shows TOTAL (cumulative) count of all members
       - Still show Count/Frequency next to each member line

  Other:
    - Examples: only keep most recent 5 examples per pattern
    - Summary line shows the full error line (pattern). If grouped, show all member patterns.

====================================================== #>

#Requires -Version 5.1
#Requires -RunAsAdministrator

param(
    [switch]$DefaultLogs,
    [Parameter(Mandatory=$false)]
    [string]$LogPath,
    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables ----
$ContextBefore          = 3
$ContextAfter           = 3
$MaxExamplesPerPattern  = 5      # only keep most recent 5 examples per pattern
$LargeFileContextMB     = 25
$FoldUrlToHost          = $true
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$DefaultLogsRoot        = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$SearchPatterns         = @('*.log','*.txt','*.json','*.evtx','*.zip','*.gz')  # copy-only: evtx/zip/gz
$AnalyzeExts            = @('.log','.txt','.json')

# Plot tunables
$PlotRecentDays         = 2
$PlotRecentBuckets      = 48     # 48 hours (1-hour buckets)
$PlotFullMaxBuckets     = 120    # cap number of buckets for full-range plots

# Text-group rules (case-insensitive contains)
$TextGroupLabels        = @(
  'Client.Timeout exceeded while awaiting headers',
  'nmap'
)

# ---- Paths ----
$LauncherPath           = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# -------- Bootstrap (optional common lib) --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) { try { . $commonPath } catch { } }
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

# -------- Silent flag (suppresses ALL console output when $true) --------
$script:SilentMode = $false

# -------- Console helpers --------
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header {
    param([string]$Title='ConnectSecure Technicians Toolbox')
    if ($script:SilentMode) { return }
    Write-Host ("`n $Title") -ForegroundColor Cyan
    Write-Host ('='*58)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME,"$env:USERDOMAIN\$env:USERNAME",$isAdmin) -ForegroundColor Gray
    Write-Host ('='*58); Write-Host ''
  }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) if ($script:SilentMode) { return }; Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) if ($script:SilentMode) { return }; Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) if ($script:SilentMode) { return }; Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

# -------- Utility helpers --------
function HtmlEscape($s) { return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }
function Normalize-PathInput {
  param([Parameter(Mandatory)][string]$Raw)
  $t = $Raw.Trim()
  if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  if ($t.StartsWith("'") -and $t.EndsWith("'") -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  [Environment]::ExpandEnvironmentVariables($t).Trim()
}
function Get-RelativePath {
  param([Parameter(Mandatory)][string]$Base, [Parameter(Mandatory)][string]$Full)
  try {
    $baseUri = (Resolve-Path -LiteralPath $Base -ErrorAction Stop).ProviderPath
    $fullUri = (Resolve-Path -LiteralPath $Full -ErrorAction Stop).ProviderPath
    $u1 = New-Object System.Uri(("file://" + ($baseUri -replace '\\','/').TrimEnd('/') + '/'))
    $u2 = New-Object System.Uri(("file://" + ($fullUri -replace '\\','/')))
    $rel = $u1.MakeRelativeUri($u2).ToString()
    return [Uri]::UnescapeDataString($rel) -replace '/','\'
  } catch { return (Split-Path -Leaf $Full) }
}
function Read-FileLines {
  param([Parameter(Mandatory)][string]$Path)
  try {
    $c = Get-Content -LiteralPath $Path -ErrorAction Stop
    if ($null -eq $c) { return @() }
    if ($c -is [string]) { return @($c) }
    return @($c)
  } catch {
    Write-Warn ("Failed to read file: {0}" -f $_.Exception.Message)
    return @()
  }
}
function ValueOr { param($v,$fallback) if ($null -eq $v) { return $fallback } $sv = [string]$v; if ([string]::IsNullOrWhiteSpace($sv)) { return $fallback } return $sv }

function New-IntArray { param([int]$Len) return (New-Object int[] $Len) }

function Add-Bucket {
  param(
    [Parameter(Mandatory)]$BucketArr,
    [Parameter(Mandatory)][int]$Index,
    [int]$Inc = 1
  )
  if ($null -eq $BucketArr) { return }
  if ($Index -lt 0 -or $Index -ge $BucketArr.Length) { return }
  $BucketArr[$Index] = $BucketArr[$Index] + $Inc
}

function Sum-IntArrays {
  param([Parameter(Mandatory)]$A,[Parameter(Mandatory)]$B)

  if ($null -eq $A -and $null -eq $B) { return (New-Object int[] 0) }
  if ($null -eq $A) { return (@($B) | ForEach-Object { [int]$_ }) }
  if ($null -eq $B) { return (@($A) | ForEach-Object { [int]$_ }) }

  $aArr = @($A) | ForEach-Object { [int]$_ }
  $bArr = @($B) | ForEach-Object { [int]$_ }
  $len = [Math]::Min($aArr.Count, $bArr.Count)
  $out = New-Object int[] $len
  for ($i=0; $i -lt $len; $i++) { $out[$i] = $aArr[$i] + $bArr[$i] }
  return $out
}

function Format-FreqText {
  param($Freq)
  if ($null -eq $Freq) { return 'n/a' }
  return (([double]$Freq).ToString('N2',[System.Globalization.CultureInfo]::InvariantCulture) + ' min')
}

# -------- Timestamp parsing --------
function TryParse-LineDateTime {
  param([string]$Line,[datetime]$FallbackDate)
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success -and $FallbackDate) {
    try {
      $h=[int]$m.Groups[1].Value.Substring(0,2)
      $mi=[int]$m.Groups[1].Value.Substring(3,2)
      $s=[int]$m.Groups[1].Value.Substring(6,2)
      return (Get-Date -Date $FallbackDate.Date -Hour $h -Minute $mi -Second $s)
    } catch {}
  }
  return $null
}

# -------- Pattern normalization --------
function Normalize-LineForPattern {
  param([string]$Line)
  if ($null -eq $Line) { return '' }
  $norm = $Line
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
  if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()
  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

# -------- SVG plot helper --------
function Build-SvgLinePlot {
  param(
    [Parameter(Mandatory)]$Counts,
    [Parameter(Mandatory)][datetime]$Start,
    [Parameter(Mandatory)][datetime]$End,
    [Parameter(Mandatory)][string[]]$TickLabels
  )

  $countsArr = @($Counts) | ForEach-Object { [int]$_ }

  $w = 560
  $h = 70
  $padL = 8
  $padR = 8
  $padT = 8
  $padB = 18

  $plotW = $w - $padL - $padR
  $plotH = $h - $padT - $padB

  $max = 0
  foreach ($v in $countsArr) { if ($v -gt $max) { $max = $v } }
  if ($max -lt 1) { $max = 1 }

  $points = New-Object System.Text.StringBuilder
  for ($i=0; $i -lt $countsArr.Count; $i++) {
    $x = $padL + [math]::Round(($plotW * $i) / ([math]::Max(1,($countsArr.Count-1))),2)
    $yNorm = ($countsArr[$i] / [double]$max)
    $y = $padT + [math]::Round($plotH * (1.0 - $yNorm),2)
    if ($i -gt 0) { $null = $points.Append(' ') }
    $null = $points.Append($x).Append(',').Append($y)
  }

  $tickText = New-Object System.Text.StringBuilder
  $tX = @($padL, ($padL + [int]($plotW/2)), ($padL + $plotW))
  for ($i=0; $i -lt 3; $i++) {
    $lbl = if ($i -lt $TickLabels.Count) { $TickLabels[$i] } else { '' }
    $lblEsc = HtmlEscape $lbl
    $null = $tickText.AppendLine("<text x='$($tX[$i])' y='$($h-4)' font-size='11' fill='#666' text-anchor='middle'>$lblEsc</text>")
  }

  $rangeLabel = ("{0} → {1}" -f $Start.ToString('MM-dd HH:mm'), $End.ToString('MM-dd HH:mm'))
  $rangeEsc = HtmlEscape $rangeLabel

  return @"
<svg width="$w" height="$h" viewBox="0 0 $w $h" role="img" aria-label="Error occurrences over time" style="max-width:100%;height:auto;">
  <rect x="0" y="0" width="$w" height="$h" rx="8" ry="8" fill="#fafafa" stroke="#e5e5e5"></rect>
  <line x1="$padL" y1="$($padT + $plotH)" x2="$($padL + $plotW)" y2="$($padT + $plotH)" stroke="#d9d9d9"></line>
  <polyline fill="none" stroke="#333" stroke-width="2" points="$($points.ToString())"></polyline>
  <text x="$($padL+2)" y="14" font-size="11" fill="#666">$rangeEsc</text>
  $($tickText.ToString())
</svg>
"@
}

# -------- IP extraction (non-local only) --------
function Get-NonLocalIpCountsFromLog {
  param([Parameter(Mandatory)][string]$LogPath)

  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }

  $fileName = ([IO.Path]::GetFileName($LogPath)).ToLowerInvariant()

  # Never consider these files for the IP section
  if ($fileName -eq 'software.log' -or $fileName -eq 'cyberutilities.log') {
    return $counts
  }

  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }

  $ipRegex = [regex]'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)'

  foreach ($lnRaw in $lines) {
    $ln = [string]$lnRaw
    if ([string]::IsNullOrWhiteSpace($ln)) { continue }

    foreach ($m in $ipRegex.Matches($ln)) {
      $ip = $m.Groups[1].Value
      if ([string]::IsNullOrWhiteSpace($ip)) { continue }

      $oct = $ip.Split('.')
      if ($oct.Count -ne 4) { continue }
      $bad = $false
      foreach ($o in $oct) {
        $n = 0
        if (-not [int]::TryParse($o, [ref]$n)) { $bad = $true; break }
        if ($n -lt 0 -or $n -gt 255) { $bad = $true; break }
      }
      if ($bad) { continue }

      if ($m.Index -gt 0) {
        $prev = $ln[$m.Index - 1]
        if ($prev -eq 'v' -or $prev -eq 'V') { continue }
      }

      if ($ip -like '10.*') { continue }
      if ($ip -like '192.168.*') { continue }
      if ($ip -like '172.*') {
        $oct2 = [int]($ip.Split('.')[1])
        if ($oct2 -ge 16 -and $oct2 -le 31) { continue }
      }
      if ($ip -like '127.*') { continue }
      if ($ip -like '169.254.*') { continue }
      if ($ip -like '0.*') { continue }
      if ($ip -like '255.*') { continue }

      if (-not $counts.ContainsKey($ip)) { $counts[$ip] = 0 }
      $counts[$ip]++
    }
  }

  return $counts
}

# -------- Helper: is ConnectSecure host? --------
function Test-IsCsHost {
  param([Parameter(Mandatory)][string]$HostName)
  $h = $HostName.ToLowerInvariant()
  return ( ($h -eq 'myconnectsecure.com') -or ($h -like '*.myconnectsecure.com') -or
           ($h -eq 'mycybercns.com')     -or ($h -like '*.mycybercns.com') )
}

# -------- Any HTTP/HTTPS URL counter (raw) --------
function Get-HttpOrHttpsUrlCountsFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }
  $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
  foreach ($ln in $lines) {
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
      $counts[$u]++
    }
  }
  return $counts
}

# -------- ConnectSecure servers (URLs and bare hostnames) --------
function Get-CsServersFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }

  $urlRegex     = [regex]'https?://[^\s"''\]\)<>]+'
  $hostRegexNet = [regex]'(?i)\b([a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:myconnectsecure\.com|mycybercns\.com))\b'

  foreach ($ln in $lines) {
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      $urlHost = $null
      try { $urlHost = ([Uri]$u).Host } catch {
        $hm = [regex]::Match($u,'^https?://([^/:?#]+)'); if ($hm.Success) { $urlHost = $hm.Groups[1].Value }
      }
      if ($urlHost -and (Test-IsCsHost -HostName $urlHost)) {
        if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
        $counts[$u]++
      }
    }
    foreach ($hm in $hostRegexNet.Matches([string]$ln)) {
      $hostOnlyName = $hm.Groups[1].Value.ToLowerInvariant()
      if (-not $counts.ContainsKey($hostOnlyName)) { $counts[$hostOnlyName] = 0 }
      $counts[$hostOnlyName]++
    }
  }
  return $counts
}

# -------- URL + App extraction for patch logs --------
function Get-UrlAttemptsWithAppFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $result = @{}  # URL -> @{ Count=#, App='...' }
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $result }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $result }

  $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
  $appTokens = @(
    'winget','choco','Chocolatey','msiexec','WindowsUpdateAgent','WuApi','WUAgent','WUAPI',
    'DISM','BITS','Start-BitsTransfer','Invoke-WebRequest','iwr','curl','wget','PowerShell',
    'PatchMyPC','ConnectSecure Agent','Agent','pswindowsupdate','PSWindowsUpdate','sconfig'
  )
  for ($i=0; $i -lt $lines.Count; $i++) {
    $ln = [string]$lines[$i]
    foreach ($m in $urlRegex.Matches($ln)) {
      $url = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($url)) { continue }
      while ($url.Length -gt 0 -and '.;,)]'.Contains($url[$url.Length-1])) { $url = $url.Substring(0,$url.Length-1) }

      if (-not $result.ContainsKey($url)) { $result[$url] = [ordered]@{ Count = 0; App = $null } }
      $result[$url].Count++

      if (-not $result[$url].App) {
        $start = [Math]::Max(0,$i-3); $stop = $i
        $ctxText = ($lines[$start..$stop] -join ' ')
        foreach ($t in $appTokens) { if ($ctxText -match [regex]::Escape($t)) { $result[$url].App = $t; break } }
        if (-not $result[$url].App) {
          $fstop = [Math]::Min($lines.Count-1,$i+3)
          $fText = ($lines[$i..$fstop] -join ' ')
          foreach ($t in $appTokens) { if ($fText -match [regex]::Escape($t)) { $result[$url].App = $t; break } }
        }
      }
    }
  }
  return $result
}

# -------- Patch-log detector --------
function Is-PatchLog {
  param([string]$PathOrName)
  $n = [IO.Path]::GetFileName($PathOrName)
  return ($n -match '(?i)\bpatch|windows.?update|wuapi|wua|pswindowsupdate|dism|kb\d{6,}\b')
}

# -------- Agent Summary Parser --------
function Get-AgentSummaryFromLogs {
  param([Parameter(Mandatory)][string]$CollectDir)

  $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in $AnalyzeExts } |
               Sort-Object FullName | Where-Object { $_.Name -match 'cybercns' } | Select-Object -First 1
  if (-not $candidate) {
    $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.Extension -in $AnalyzeExts } |
                 Where-Object { Select-String -Path $_.FullName -Pattern 'AGENT INFO' -SimpleMatch -ErrorAction SilentlyContinue } |
                 Select-Object -First 1
  }
  if (-not $candidate) { return $null }

  $meta = [ordered]@{
    Hostname     = $null
    IP           = $null
    MAC          = $null
    AgentVersion = $null
    AgentID      = $null
    TenantID     = $null
    CompanyID    = $null
    AgentType    = $null
    PODID        = $null
    SourceFile   = $candidate.FullName
  }

  $lines = Read-FileLines -Path $candidate.FullName
  foreach ($ln in $lines) {
    if (-not $meta.IP -and $ln -match 'IP ADDRESS') {
      $ipm  = [regex]::Match($ln,'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)')
      if ($ipm.Success) { $meta.IP = $ipm.Groups[1].Value }
      $macm = [regex]::Match($ln,'\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b')
      if ($macm.Success) { $meta.MAC = $macm.Groups[1].Value.ToLower() }
      $hostm = [regex]::Match($ln,'HostName.?s\s*\[([^\]]+)\]')
      if ($hostm.Success) { $meta.Hostname = $hostm.Groups[1].Value }
      if (-not $meta.Hostname) {
        $uidm = [regex]::Match($ln,"UniqueId.?s\s*\[([^\]]+)\]")
        if ($uidm.Success) {
          $maybe = ($uidm.Groups[1].Value -split '[\s,]') | Where-Object { $_ -and ($_ -notmatch ':') } | Select-Object -First 1
          if ($maybe) { $meta.Hostname = $maybe }
        }
      }
    }
    if ($ln -match '\[Agent Version\s*:-\s*([^\]]+)\]') { $meta.AgentVersion = $Matches[1].Trim() }
    if ($ln -match '\[Agent ID\s*:-\s*([^\]]+)\]')      { $meta.AgentID      = $Matches[1].Trim() }
    if ($ln -match '\[Tenant ID\s*:-\s*([^\]]+)\]')     { $meta.TenantID     = $Matches[1].Trim() }
    if ($ln -match '\[Company ID\s*:-\s*([^\]]+)\]')    { $meta.CompanyID    = $Matches[1].Trim() }
    if ($ln -match '\[Agent Type\s*:-\s*([^\]]+)\]')    { $meta.AgentType    = $Matches[1].Trim() }
    if ($ln -match '\[PODID\s*:-\s*([^\]]+)\]')         { $meta.PODID        = $Matches[1].Trim() }
  }

  return $meta
}

# -------- Analysis (per-file) --------
function Analyze-File {
  param([string]$FilePath)

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $patterns     = @{}
  $contexts     = @{}
  $patternTimes = @{}  # timestamps for frequency calc
  $patternLast  = @{}  # pattern -> last occurrence datetime
  $recentBucketsByPattern = @{} # pattern -> int[48]
  $fullBucketsByPattern   = @{} # pattern -> int[bucketCount]
  $errorEvents  = New-Object System.Collections.Generic.List[object]

  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false
  if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

  $lines = Read-FileLines -Path $FilePath
  $lines = @($lines)
  if ($lines.Count -eq 0) {
    $now = Get-Date
    return [PSCustomObject]@{
      File=$FilePath; Total=0; Counts=$countsByLevel; Patterns=$patterns; Contexts=$contexts; Limited=$limitCtx;
      Frequencies=@{}; OldestTimestamp=$now; LatestTimestamp=$now; PatternLast=$patternLast;
      RecentWindowStart=$now; RecentWindowEnd=$now; RecentBucketCount=$PlotRecentBuckets; RecentBuckets=$recentBucketsByPattern;
      FullWindowStart=$now; FullWindowEnd=$now; FullBucketSeconds=3600; FullBucketCount=2; FullBuckets=$fullBucketsByPattern;
      Last10=@(); Events=@()
    }
  }

  $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }

  $oldestInFile = $null
  $latestInFile = $null
  foreach ($ln in $lines) {
    $dt = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate
    if ($dt) {
      if ($null -eq $oldestInFile -or $dt -lt $oldestInFile) { $oldestInFile = $dt }
      if ($null -eq $latestInFile -or $dt -gt $latestInFile) { $latestInFile = $dt }
    }
  }
  if (-not $oldestInFile) { $oldestInFile = $fallbackDate }
  if (-not $latestInFile) { $latestInFile = $fallbackDate }

  $recentStart = $latestInFile.AddDays(-1 * $PlotRecentDays)
  $recentEnd   = $latestInFile
  $recentBucketSeconds = 3600
  $recentBucketCount = $PlotRecentBuckets

  $fullStart = $oldestInFile
  $fullEnd   = $latestInFile
  $rangeSec  = [Math]::Max(1, [int]($fullEnd - $fullStart).TotalSeconds)
  $rawBucket = [Math]::Ceiling($rangeSec / [double]$PlotFullMaxBuckets)
  $fullBucketSeconds = [int]([Math]::Max(60, [Math]::Ceiling($rawBucket / 60.0) * 60))
  $fullBucketCount   = [int]([Math]::Ceiling($rangeSec / [double]$fullBucketSeconds) + 1)

  for ($i=0;$i -lt $lines.Count;$i++) {
    $line = [string]$lines[$i]

    # Ignore
    if ($line -like '*base dir already created*') { continue }

    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }

      $norm = Normalize-LineForPattern -Line $line
      if (-not $patterns.ContainsKey($norm)) { $patterns[$norm] = 0 }
      $patterns[$norm]++

      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }
      if (-not $patternTimes.ContainsKey($norm)) { $patternTimes[$norm] = @() }

      $dt2 = TryParse-LineDateTime -Line $line -FallbackDate $fallbackDate
      if ($dt2) {
        $patternTimes[$norm] += $dt2
        if (-not $patternLast.ContainsKey($norm) -or $dt2 -gt $patternLast[$norm]) { $patternLast[$norm] = $dt2 }

        if ($dt2 -ge $recentStart -and $dt2 -le $recentEnd) {
          if (-not $recentBucketsByPattern.ContainsKey($norm)) { $recentBucketsByPattern[$norm] = (New-IntArray -Len $recentBucketCount) }
          $idxR = [int]([Math]::Floor(($dt2 - $recentStart).TotalSeconds / $recentBucketSeconds))
          Add-Bucket -BucketArr $recentBucketsByPattern[$norm] -Index $idxR -Inc 1
        }

        if (-not $fullBucketsByPattern.ContainsKey($norm)) { $fullBucketsByPattern[$norm] = (New-IntArray -Len $fullBucketCount) }
        $idxF = [int]([Math]::Floor(($dt2 - $fullStart).TotalSeconds / $fullBucketSeconds))
        Add-Bucket -BucketArr $fullBucketsByPattern[$norm] -Index $idxF -Inc 1
      }

      $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
      $k=$end+1
      while($k -lt $lines.Count) {
        $n=[string]$lines[$k]
        if($n -eq $null -or $n -eq '') { $k++; break }
        if($n -match '^\s') { $k++ } else { break }
      }
      $end=[Math]::Min($lines.Count-1,$k-1)

      $ctx="Context for line $($i+1) (+/-$ContextBefore/$ContextAfter)`n"
      for($p=$start;$p -le $end;$p++){
        $prefix=('   '); if($p -eq $i){ $prefix='>> ' }
        $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
      }

      $ctxObj = [PSCustomObject]@{ Time = $dt2; Line = $i; Text = $ctx }
      $contexts[$norm] += @($ctxObj)

      # Keep only most recent $MaxExamplesPerPattern examples
      if (@($contexts[$norm]).Count -gt $MaxExamplesPerPattern) {
        $contexts[$norm] = @(
          $contexts[$norm] |
            Sort-Object -Property @{
              Expression = { if ($_.Time) { $_.Time } else { Get-Date '0001-01-01' } }
              Descending = $true
            }, @{
              Expression = { $_.Line }
              Descending = $true
            } |
            Select-Object -First $MaxExamplesPerPattern
        )
      }

      $evStart=[Math]::Max(0,$i-1); $evEnd=[Math]::Min($lines.Count-1,$i+1)
      $evCtx="Event context at line $($i+1)`n"
      for($ep=$evStart;$ep -le $evEnd;$ep++){
        $evPrefix=('   '); if($ep -eq $i){ $evPrefix='>> ' }
        $evCtx += ("{0,5}: {1}{2}`n" -f ($ep+1), $evPrefix, $lines[$ep])
      }
      $errorEvents.Add([PSCustomObject]@{ Time=$dt2; Line=$i; Level=$upper; Pattern=$norm; Text=$evCtx })
    }
  }

  $frequencies = @{}
  foreach ($kv in $patternTimes.GetEnumerator()) {
    $pat = $kv.Key
    $arr = @($kv.Value | Where-Object { $_ } | Sort-Object)
    if ($arr.Count -ge 2) {
      $mins = @()
      for ($j=1; $j -lt $arr.Count; $j++) { $mins += (($arr[$j] - $arr[$j-1]).TotalMinutes) }
      $avg = if ($mins.Count -gt 0) { ($mins | Measure-Object -Average).Average } else { 0 }
      $frequencies[$pat] = [Math]::Round([double]$avg,2)
    } else {
      $frequencies[$pat] = $null
    }
  }

  return [PSCustomObject]@{
    File              = $FilePath
    Total             = $lines.Count
    Counts            = $countsByLevel
    Patterns          = $patterns
    Contexts          = $contexts
    Frequencies       = $frequencies
    OldestTimestamp   = $oldestInFile
    LatestTimestamp   = $latestInFile
    PatternLast       = $patternLast

    RecentWindowStart = $recentStart
    RecentWindowEnd   = $recentEnd
    RecentBucketCount = $recentBucketCount
    RecentBuckets     = $recentBucketsByPattern

    FullWindowStart   = $fullStart
    FullWindowEnd     = $fullEnd
    FullBucketSeconds = $fullBucketSeconds
    FullBucketCount   = $fullBucketCount
    FullBuckets       = $fullBucketsByPattern
  }
}

# -------- Report builder --------
function Collect-And-Report {
  param(
    [Parameter(Mandatory)][string[]]$Roots,
    [switch]$Silent
  )

  $script:SilentMode = [bool]$Silent

  $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
  Ensure-Folder $outDir
  $finalHtmlDir = $outDir  # FINAL HTML ALWAYS LANDS HERE

  $ts=Get-Date -Format 'yyyyMMdd_HHmmss'
  $collectDir=Join-Path $outDir ('Collect_'+$ts)
  Ensure-Folder $collectDir

  $found=$false

  foreach($root in ($Roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) })) {
    if (Test-Path -LiteralPath $root -PathType Leaf) {
      $found = $true
      $dest = Join-Path $collectDir 'SelectedFiles'
      Ensure-Folder $dest
      Copy-Item -LiteralPath $root -Destination (Join-Path $dest (Split-Path $root -Leaf)) -Force -ErrorAction SilentlyContinue
    } else {
      $dest=Join-Path $collectDir ((Split-Path $root -Leaf)-replace'[^\w\.-]','_'); Ensure-Folder $dest
      try {
        $items = Get-ChildItem -LiteralPath (Resolve-Path -LiteralPath $root) -Recurse -File -Include $SearchPatterns -ErrorAction SilentlyContinue
        if ($items) {
          $found=$true
          foreach($f in $items){
            $rel = Get-RelativePath -Base $root -Full $f.FullName
            $tgt = Join-Path $dest $rel
            Ensure-Folder (Split-Path $tgt -Parent)
            Copy-Item -LiteralPath $f.FullName -Destination $tgt -Force -ErrorAction SilentlyContinue
          }
        }
      } catch { }
    }
  }

  if(-not $found){
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
.kicker{background:#fff4d6;border:1px solid #ffd27a;padding:10px;border-radius:8px;}
</style></head><body>
<div class="logo-wrap"><img src="$LogoUrl" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Agent Log Review</h1>
<div class="kicker">
  <h3>No logs were collected</h3>
  <p>We did not find any files matching *.log, *.txt, *.json, *.evtx, *.zip, or *.gz in the selected location(s).</p>
</div>
</body></html>
"@
    $htmlPath=Join-Path $finalHtmlDir ('CS-logreview-NoLogs-'+$ts+'.html')
    [System.IO.File]::WriteAllBytes($htmlPath, [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html))
    if (-not $Silent) { try{ Start-Process $htmlPath }catch{} }
    return
  }

  $html=[System.Text.StringBuilder]::new()
  $null=$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>')
  $null=$html.AppendLine('<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:10px;margin:6px 0 10px;}
.summary{background:#fff7e6;border:1px solid #ffd699;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.summary h2{margin:4px 0 8px 0;}
.summary table{width:auto;border-collapse:separate;border-spacing:0 4px;}
.summary td{border:none;padding:2px 10px 2px 0;}
.key{color:#555;font-weight:600;white-space:nowrap;}
.val{color:#000;}
.src{color:#888;font-size:12px;margin-top:4px;}
.servers{background:#f4f9ff;border:1px solid #cfe6ff;padding:10px 12px;border-radius:10px;margin:8px 0 16px;}
.section-heading{margin-top:18px;border-bottom:2px solid #ddd;padding-bottom:4px;}
.plot-wrap{margin:8px 0 10px 0;}
.group-box{background:#fcfcff;border:1px solid #e6e6f2;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.group-box ul{margin:6px 0 0 18px;}
.member-meta{color:#666;font-size:12px;}
</style></head><body>')
  $null=$html.AppendLine('<div class="logo-wrap"><img src="'+ (HtmlEscape $LogoUrl) +'" alt="ConnectSecure logo"></div>')
  $null=$html.AppendLine('<h1>ConnectSecure - Agent Log Review</h1>')

  $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in '.log','.txt','.json' }

  $allSrvByHost = @{}
  $ipAgg        = @{}
  $thirdPartyByHost = @{}
  $overallLatest  = Get-Date '1900-01-01'

  foreach ($tf in $textFiles) {
    $relFile = Get-RelativePath -Base $collectDir -Full $tf.FullName

    $srv = Get-CsServersFromLog -LogPath $tf.FullName
    foreach ($kv in $srv.GetEnumerator()) {
      $rawKey = [string]$kv.Key
      $val    = [int]$kv.Value
      if ([string]::IsNullOrWhiteSpace($rawKey)) { continue }

      $csHost = $rawKey
      if ($csHost -match '^https?://') {
        try { $csHost = ([Uri]$csHost).Host } catch {
          $hm = [regex]::Match($csHost,'^https?://([^/:?#]+)')
          if ($hm.Success) { $csHost = $hm.Groups[1].Value } else { $csHost = $null }
        }
      }
      if (-not $csHost) { continue }
      $parentHost = $csHost.ToLowerInvariant()

      if (-not $allSrvByHost.ContainsKey($parentHost)) {
        $allSrvByHost[$parentHost] = [ordered]@{ Count=0; Files=@{}; Details=@{} }
      }
      $hostEntry = $allSrvByHost[$parentHost]
      $hostEntry.Count += $val
      $hostEntry.Files[$relFile] = $true

      if (-not $hostEntry.Details.ContainsKey($rawKey)) {
        $hostEntry.Details[$rawKey] = [ordered]@{ Count=0; Files=@{} }
      }
      $hostEntry.Details[$rawKey].Count += $val
      $hostEntry.Details[$rawKey].Files[$relFile] = $true
    }

    $ips = Get-NonLocalIpCountsFromLog -LogPath $tf.FullName
    foreach ($kv in $ips.GetEnumerator()) {
      $ip  = [string]$kv.Key
      $cnt = [int]$kv.Value
      if ([string]::IsNullOrWhiteSpace($ip)) { continue }
      if (-not $ipAgg.ContainsKey($ip)) { $ipAgg[$ip] = [ordered]@{ Count=0; Files=@{} } }
      $ipAgg[$ip].Count += $cnt
      $ipAgg[$ip].Files[$relFile] = $true
    }

    $name = [IO.Path]::GetFileName($tf.FullName)
    if ($name -match '(?i)^cyberpatch(\.|-|_)') {
      $urlCounts = Get-HttpOrHttpsUrlCountsFromLog -LogPath $tf.FullName
      foreach ($kv in $urlCounts.GetEnumerator()) {
        $url = [string]$kv.Key
        $cnt = [int]$kv.Value
        if ([string]::IsNullOrWhiteSpace($url)) { continue }

        $urlHostTP = $null
        try { $urlHostTP = ([Uri]$url).Host } catch {
          $hm = [regex]::Match($url,'^https?://([^/:?#]+)'); if ($hm.Success) { $urlHostTP = $hm.Groups[1].Value }
        }
        if (-not $urlHostTP) { continue }
        if (Test-IsCsHost -HostName $urlHostTP) { continue }

        $tpHost = $urlHostTP.ToLowerInvariant()
        if (-not $thirdPartyByHost.ContainsKey($tpHost)) {
          $thirdPartyByHost[$tpHost] = [ordered]@{ Count=0; Files=@{}; Details=@{} }
        }
        $tpEntry = $thirdPartyByHost[$tpHost]
        $tpEntry.Count += $cnt
        $tpEntry.Files[$relFile] = $true
      }
    }
  }

  $agentMeta = $null
  try { $agentMeta = Get-AgentSummaryFromLogs -CollectDir $collectDir } catch { $agentMeta = $null }

  if ($agentMeta) {
    $h = HtmlEscape( (ValueOr $agentMeta.Hostname '-') )
    $ip= HtmlEscape( (ValueOr $agentMeta.IP       '-') )
    $mc= HtmlEscape( (ValueOr $agentMeta.MAC      '-') )
    $av= HtmlEscape( (ValueOr $agentMeta.AgentVersion '-') )
    $aid=HtmlEscape( (ValueOr $agentMeta.AgentID      '-') )
    $tid=HtmlEscape( (ValueOr $agentMeta.TenantID     '-') )
    $cid=HtmlEscape( (ValueOr $agentMeta.CompanyID    '-') )
    $aty=HtmlEscape( (ValueOr $agentMeta.AgentType    '-') )
    $pod=HtmlEscape( (ValueOr $agentMeta.PODID        '-') )
    $src=HtmlEscape( (ValueOr $agentMeta.SourceFile   '') )

    $null=$html.AppendLine('<div class="summary">')
    $null=$html.AppendLine('<h2>Device Summary</h2>')
    $null=$html.AppendLine('<table>')
    $null=$html.AppendLine("<tr><td class='key'>Hostname</td><td class='val'>$h</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>IP Address</td><td class='val'>$ip</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>MAC Address</td><td class='val'>$mc</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Version</td><td class='val'>$av</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent ID</td><td class='val'>$aid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Tenant ID</td><td class='val'>$tid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Company ID</td><td class='val'>$cid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Type</td><td class='val'>$aty</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>PODID</td><td class='val'>$pod</td></tr>")
    $null=$html.AppendLine('</table>')
    if ($src) { $null=$html.AppendLine("<div class='src'>Parsed from: $src</div>") }
    $null=$html.AppendLine('</div>')
  }

  $null=$html.AppendLine('<h2 class="section-heading">ConnectSecure Agent Traffic Review</h2>')
  $null=$html.AppendLine('<details class="servers"><summary>ConnectSecure Hosts Detected within Logs Reviewed</summary>')
  if ($allSrvByHost.Keys.Count -gt 0) {
    $null=$html.AppendLine('<table><thead><tr><th style="width:30%">Host</th><th style="width:10%">Hits</th><th>Log Files</th></tr></thead><tbody>')
    $allSrvByHost.GetEnumerator() |
      Sort-Object -Property @{Expression={ $_.Value.Count };Descending=$true}, @{Expression='Key'} |
      ForEach-Object {
        $filesJoined = [string]::Join(', ', @($_.Value.Files.Keys | Sort-Object))
        $null=$html.AppendLine('<tr><td>'+ (HtmlEscape $_.Key) +'</td><td>'+ $_.Value.Count +'</td><td>'+ (HtmlEscape $filesJoined) +'</td></tr>')
      }
    $null=$html.AppendLine('</tbody></table>')
  } else {
    $null=$html.AppendLine('<div class="small">No ConnectSecure server references detected across the logs reviewed.</div>')
  }
  $null=$html.AppendLine('</details>')

  $null=$html.AppendLine('<details class="servers"><summary>IP&#39;s Detected within Logs Reviewed</summary>')
  if ($ipAgg.Keys.Count -gt 0) {
    $null=$html.AppendLine('<table><thead><tr><th style="width:20%">IP Address</th><th style="width:10%">Occurrences</th><th>Log Files</th></tr></thead><tbody>')
    $ipAgg.GetEnumerator() |
      Sort-Object -Property @{Expression={ $_.Value.Count };Descending=$true}, @{Expression='Key'} |
      ForEach-Object {
        $filesJoined = [string]::Join(', ', @($_.Value.Files.Keys | Sort-Object))
        $null=$html.AppendLine('<tr><td>'+ (HtmlEscape $_.Key) +'</td><td>'+ $_.Value.Count +'</td><td>'+ (HtmlEscape $filesJoined) +'</td></tr>')
      }
    $null=$html.AppendLine('</tbody></table>')
  } else {
    $null=$html.AppendLine('<div class="small">No non-local IPs detected across the logs reviewed.</div>')
  }
  $null=$html.AppendLine('</details>')

  $null=$html.AppendLine('<h2 class="section-heading">ConnectSecure Agent Message Review</h2>')

  foreach($tf in $textFiles){
    $res=Analyze-File -FilePath $tf.FullName
    if ($res.LatestTimestamp -and $res.LatestTimestamp -gt $overallLatest) { $overallLatest = $res.LatestTimestamp }
    $fname=Split-Path $tf.FullName -Leaf

    $null=$html.AppendLine("<details><summary>"+(HtmlEscape $fname)+" - "+$res.Total+" lines</summary>")

    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.Counts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')

    # Build pattern objects
    $patternObjs = @()
    foreach ($entry in ($res.Patterns.GetEnumerator() | Sort-Object Value -Descending)) {
      $patKey = [string]$entry.Key
      $cnt    = [int]$entry.Value
      $freq   = $null
      if ($res.Frequencies.ContainsKey($patKey)) { $freq = $res.Frequencies[$patKey] }
      $freqKey = if ($null -eq $freq) { 'null' } else { ([double]$freq).ToString('G17',[System.Globalization.CultureInfo]::InvariantCulture) }
      $lastDt = $null
      if ($res.PatternLast.ContainsKey($patKey)) { $lastDt = $res.PatternLast[$patKey] }

      $recentArr = if ($res.RecentBuckets.ContainsKey($patKey)) { $res.RecentBuckets[$patKey] } else { (New-IntArray -Len $res.RecentBucketCount) }
      $ctxItems = @()
      if ($res.Contexts.ContainsKey($patKey)) {
        $ctxItems = @(
          $res.Contexts[$patKey] |
            Sort-Object -Property @{
              Expression = { if ($_.Time) { $_.Time } else { Get-Date '0001-01-01' } }
              Descending = $true
            }, @{
              Expression = { $_.Line }
              Descending = $true
            }
        )
      }

      $patternObjs += [PSCustomObject]@{
        Key        = $patKey
        Count      = $cnt
        Freq       = $freq
        FreqKey    = $freqKey
        Last       = $lastDt
        RecentArr  = $recentArr
        Contexts   = $ctxItems
      }
    }

    # ---- Grouping type B (text grouping) FIRST (multi labels) ----
    $groupsFinal = New-Object System.Collections.Generic.List[object]
    $remaining = @($patternObjs)

    foreach ($lbl in $TextGroupLabels) {
      $members = @($remaining | Where-Object { $_.Key -like ('*' + $lbl + '*') })
      if ($members.Count -ge 2) {
        $remaining = @($remaining | Where-Object { $_.Key -notlike ('*' + $lbl + '*') })

        $maxLast = $null
        foreach ($m in $members) {
          if ($m.Last -and ($null -eq $maxLast -or $m.Last -gt $maxLast)) { $maxLast = $m.Last }
        }

        $totalCount = 0
        foreach ($m in $members) { $totalCount += [int]$m.Count }

        $groupsFinal.Add([PSCustomObject]@{
          Type        = 'Text'
          Label       = $lbl
          TotalCount  = $totalCount
          Members     = @($members | Sort-Object -Property @{Expression='Count';Descending=$true}, @{Expression='Key';Descending=$false})
          LastMax     = $maxLast
        }) | Out-Null
      }
    }

    # ---- Grouping type A (frequency grouping) on remaining ----
    $freqBuckets = @{}
    foreach ($po in $remaining) {
      if ($po.Count -le 3) { continue }
      if ($po.FreqKey -eq 'null') { continue }

      $gk = ("{0}|{1}" -f $po.Count, $po.FreqKey)
      if (-not $freqBuckets.ContainsKey($gk)) {
        $freqBuckets[$gk] = New-Object System.Collections.Generic.List[object]
      }
      $freqBuckets[$gk].Add($po) | Out-Null
    }

    $inFreqGroup = @{}
    foreach ($kv in $freqBuckets.GetEnumerator()) {
      $members = @($kv.Value.ToArray())
      if ($members.Count -lt 2) { continue }

      foreach ($m in $members) { $inFreqGroup[$m.Key] = $true }

      $maxLast = $null
      foreach ($m in $members) {
        if ($m.Last -and ($null -eq $maxLast -or $m.Last -gt $maxLast)) { $maxLast = $m.Last }
      }

      $groupsFinal.Add([PSCustomObject]@{
        Type     = 'Freq'
        Label    = 'Grouped similar errors'
        Count    = [int]$members[0].Count
        Freq     = $members[0].Freq
        Members  = @($members | Sort-Object -Property @{Expression='Key';Descending=$false})
        LastMax  = $maxLast
      }) | Out-Null
    }

    # ---- Singles ----
    foreach ($po in $remaining) {
      if ($inFreqGroup.ContainsKey($po.Key)) { continue }
      $groupsFinal.Add([PSCustomObject]@{
        Type     = 'Single'
        Label    = 'Error'
        Members  = @($po)
        LastMax  = $po.Last
      }) | Out-Null
    }

    # Sort one big list (no older/newer split)
    $groupsSorted = @(
      $groupsFinal |
        Sort-Object -Property `
          @{Expression={
              if ($_.Type -eq 'Freq') { [int]$_.Count }
              elseif ($_.Type -eq 'Single') { [int]$_.Members[0].Count }
              else { [int]$_.TotalCount }
            }; Descending=$true},
          @{Expression={ if ($_.LastMax) { $_.LastMax } else { Get-Date '0001-01-01' } }; Descending=$true},
          @{Expression='Label'; Descending=$false}
    )

    function Render-Group {
      param([Parameter(Mandatory)]$g)

      $members = @($g.Members)
      $isMulti = ($members.Count -gt 1)

      # chart = sum of members (recent window)
      $plotArr = (New-IntArray -Len $res.RecentBucketCount)
      foreach ($m in $members) { $plotArr = (Sum-IntArrays -A $plotArr -B $m.RecentArr) }

      $tickLabels = @(
        $res.RecentWindowStart.ToString('MM-dd'),
        $res.RecentWindowStart.AddDays(1).ToString('MM-dd'),
        $res.RecentWindowEnd.ToString('MM-dd')
      )
      $svg = Build-SvgLinePlot -Counts $plotArr -Start $res.RecentWindowStart -End $res.RecentWindowEnd -TickLabels $tickLabels

      if ($g.Type -eq 'Single') {
        $freqText = Format-FreqText $members[0].Freq
        $null = $html.AppendLine(
          '<details><summary><code>' + (HtmlEscape $members[0].Key) + '</code> - <span class="small">Count: ' +
          $members[0].Count + ' - Frequency: ' + (HtmlEscape $freqText) + '</span></summary>'
        )
      }
      elseif ($g.Type -eq 'Freq') {
        $freqTextG = Format-FreqText $g.Freq
        $null = $html.AppendLine(
          '<details><summary>' + (HtmlEscape $g.Label) + ' - <span class="small">Count: ' +
          $g.Count + ' - Frequency: ' + (HtmlEscape $freqTextG) + '</span><br>'
        )
        foreach ($m in $members) {
          $freqTextM = Format-FreqText $m.Freq
          $null = $html.AppendLine('<code>' + (HtmlEscape $m.Key) + '</code> <span class="member-meta">(' + $m.Count + ' / ' + (HtmlEscape $freqTextM) + ')</span><br>')
        }
        $null = $html.AppendLine('</summary>')
      }
      else {
        # TEXT grouping: cumulative count
        $null = $html.AppendLine(
          '<details><summary>' + (HtmlEscape $g.Label) +
          ' - <span class="small">Total Count: ' + $g.TotalCount + '</span> <span class="small">(grouped by text)</span><br>'
        )
        foreach ($m in $members) {
          $freqTextM = Format-FreqText $m.Freq
          $null = $html.AppendLine('<code>' + (HtmlEscape $m.Key) + '</code> <span class="member-meta">(' + $m.Count + ' / ' + (HtmlEscape $freqTextM) + ')</span><br>')
        }
        $null = $html.AppendLine('</summary>')
      }

      $null=$html.AppendLine('<div class="plot-wrap">'+$svg+'</div>')

      if ($isMulti) {
        $null=$html.AppendLine('<div class="group-box"><div><b>Group members:</b></div><ul>')
        foreach ($m in $members) {
          $freqTextM = Format-FreqText $m.Freq
          $null=$html.AppendLine('<li><code>'+ (HtmlEscape $m.Key) +'</code> <span class="member-meta">('+$m.Count+' / '+(HtmlEscape $freqTextM)+')</span></li>')
        }
        $null=$html.AppendLine('</ul></div>')
      }

      for ($ex=0; $ex -lt $MaxExamplesPerPattern; $ex++) {
        $any = $false
        foreach ($m in $members) { if ($m.Contexts.Count -gt $ex) { $any = $true; break } }
        if (-not $any) { break }

        $null=$html.AppendLine("<h4>Example "+($ex+1)+"</h4><pre>")
        foreach ($m in $members) {
          if ($m.Contexts.Count -gt $ex) {
            $null=$html.AppendLine((HtmlEscape ("--- Pattern: {0} (Count={1}, Freq={2}) ---" -f $m.Key, $m.Count, (Format-FreqText $m.Freq))))
            $null=$html.AppendLine((HtmlEscape $m.Contexts[$ex].Text))
          }
        }
        $null=$html.AppendLine("</pre>")
      }

      $null=$html.AppendLine('</details>')
    }

    foreach ($g in $groupsSorted) { Render-Group -g $g }

    $null=$html.AppendLine('</details>') # end file <details>
  }

  $hostFrag  = if ($agentMeta) { ValueOr $agentMeta.Hostname $env:COMPUTERNAME } else { $env:COMPUTERNAME }
  $agentFrag = if ($agentMeta) { ValueOr $agentMeta.AgentID 'unknown-agent' } else { 'unknown-agent' }
  $lastLogTS = if ($overallLatest -and $overallLatest -gt (Get-Date '1900-01-01')) { $overallLatest } else { Get-Date }
  $lastLogStr = $lastLogTS.ToString('yyyyMMdd_HHmmss')
  $safe = { param($s) ([string]$s -replace '[^\w\.-]','_') }

  $fileName = ('CS-logreview-Host-{0}-agentid-{1}-lastlogdate-{2}.html' -f (&$safe $hostFrag), (&$safe $agentFrag), $lastLogStr)

  $null=$html.AppendLine('</body></html>')

  $htmlPath=Join-Path $finalHtmlDir $fileName
  [System.IO.File]::WriteAllBytes($htmlPath, [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html.ToString()))

  if (-not $Silent) {
    Write-OK ("Wrote HTML report: $htmlPath")
    try{ Start-Process $htmlPath }catch{}
  }
}

# -------- UI (interactive) --------
function Start-AgentLogReview {
  while ($true) {
    Clear-Host
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' [1] Scan default agent log folder' -ForegroundColor White
    Write-Host ("     - {0}" -f $DefaultLogsRoot) -ForegroundColor DarkGray
    Write-Host ' [2] Scan another FOLDER' -ForegroundColor White
    Write-Host ' [3] Scan a SINGLE FILE' -ForegroundColor White
    Write-Host ' [Q] Quit to Toolbox Launcher' -ForegroundColor White
    Write-Host ''
    $choice=Read-Host 'Select an option (1/2/3/Q)'

    switch($choice.ToUpper()) {
      '1'{
        Collect-And-Report -Roots @($DefaultLogsRoot)
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
      }
      '2'{
        $folder = Read-Host ("Enter folder to scan (Enter for default: {0})" -f $DefaultLogsRoot)
        if ([string]::IsNullOrWhiteSpace($folder)) { $folder = $DefaultLogsRoot }
        $folder = Normalize-PathInput -Raw $folder
        if (Test-Path -LiteralPath $folder -PathType Container) {
          Collect-And-Report -Roots @($folder)
        } else {
          Write-Warn ("Folder not found: ""{0}""" -f $folder)
        }
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
      }
      '3'{
        $file = Read-Host "Enter full file path to scan"
        $file = Normalize-PathInput -Raw $file
        if (Test-Path -LiteralPath $file -PathType Leaf) {
          Collect-And-Report -Roots @($file)
        } else {
          Write-Warn ("File not found: ""{0}""" -f $file)
        }
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
      }
      'Q'{
        if (Test-Path -LiteralPath $LauncherPath) { & $LauncherPath } else { Write-Warn ("Launcher not found: {0}" -f $LauncherPath) }
        return
      }
      Default{
        Write-Warn 'Invalid choice.'
        Start-Sleep -Milliseconds 800
      }
    }
  }
}

# -------- Entry Point --------
if (($PSBoundParameters.ContainsKey('LogPath') -and -not [string]::IsNullOrWhiteSpace($LogPath)) -or $DefaultLogs -or $ExportOnly) {
  $script:SilentMode = $true
}

if ($PSBoundParameters.ContainsKey('LogPath') -and -not [string]::IsNullOrWhiteSpace($LogPath)) {
  $resolved = Normalize-PathInput -Raw $LogPath
  if (-not (Test-Path -LiteralPath $resolved)) { throw ('-LogPath not found: "{0}"' -f $resolved) }
  Collect-And-Report -Roots @($resolved) -Silent
}
elseif ($DefaultLogs -or $ExportOnly) {
  Collect-And-Report -Roots @($DefaultLogsRoot) -Silent
}
else {
  Start-AgentLogReview
}
```
