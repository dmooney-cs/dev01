# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# =================================================================================================
# Agent-Log-Review.ps1 (R3c) - Default logs path + Top Errors (PowerShell 5.1 Safe)
# - Default path (Option 1): C:\Program Files (x86)\CyberCNSAgent\logs
# - Option 2: Browse (Folder or File(s)); folder scans ALL files recursively
# - Shows on-screen Top repeated error patterns and exports them
# - Exports per-file metrics, TopErrors, and KeywordCounts to Collected-Info\AgentLogs
# - Loops if default path missing or contains no files
# =================================================================================================

$ErrorActionPreference = 'Continue'

# Paths
$DefaultLogFolder = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$ExportDir        = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'
$LauncherPath     = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'

# Ensure export folder
New-Item -ItemType Directory -Path $ExportDir -Force | Out-Null

function Add-WinForms {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        return $true
    } catch {
        Write-Host "⚠️ Unable to load Windows.Forms; falling back to console input. $_" -ForegroundColor Yellow
        return $false
    }
}

function Select-FolderDialog {
    param([string]$Description = "Select a folder containing logs")
    if (-not (Add-WinForms)) { return $null }
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    $dialog.ShowNewFolderButton = $false
    $dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
    $result = $dialog.ShowDialog()
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.SelectedPath
    }
    return $null
}

function Select-FileDialog {
    param([string]$Title = "Select one or more log files")
    if (-not (Add-WinForms)) { return @() }
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = $Title
    $ofd.Filter = "Common logs (*.log;*.txt;*.csv)|*.log;*.txt;*.csv|All files (*.*)|*.*"
    $ofd.Multiselect = $true
    $ofd.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    $null = $ofd.ShowDialog()
    if ([string]::IsNullOrWhiteSpace($ofd.FileName)) { return @() }
    return @($ofd.FileNames)
}

function Get-FilesFromFolder {
    param(
        [Parameter(Mandatory)][string]$FolderPath,
        [switch]$DetectedFolderMode # when true, filter to log-like files; else scan all
    )
    if (-not (Test-Path -LiteralPath $FolderPath -PathType Container)) {
        throw "Folder not found: $FolderPath"
    }
    if ($DetectedFolderMode) {
        $patterns = @('*.log','*.txt','*.csv')
        $files = foreach ($pat in $patterns) {
            Get-ChildItem -LiteralPath $FolderPath -Recurse -File -Filter $pat -ErrorAction SilentlyContinue
        }
        return @($files | Sort-Object FullName -Unique)
    } else {
        return @(Get-ChildItem -LiteralPath $FolderPath -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName)
    }
}

function Normalize-LogLine {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return "" }
    $s = $Line

    # Remove common timestamp prefixes (various formats)
    $s = [regex]::Replace($s, '^\s*\[?\d{4}[-/]\d{2}[-/]\d{2}[ T]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?\]?\s*', '')
    $s = [regex]::Replace($s, '^\s*\d{1,2}[-/][A-Za-z]{3}[-/]\d{2,4}\s+\d{2}:\d{2}:\d{2}\s*', '')

    # Replace GUIDs, IPv4s, hex, long numbers
    $s = [regex]::Replace($s, '\b[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b', '{GUID}')
    $s = [regex]::Replace($s, '\b\d{1,3}(\.\d{1,3}){3}\b', '#.#.#.#')
    $s = [regex]::Replace($s, '0x[0-9A-Fa-f]+', '0x#')
    $s = [regex]::Replace($s, '\b\d{3,}\b', '#')

    # Collapse whitespace
    $s = [regex]::Replace($s, '\s+', ' ').Trim()

    return $s
}

function Analyze-Logs {
    param(
        [Parameter(Mandatory)][System.IO.FileInfo[]]$Files,
        [int]$Days = 7
    )

    $regexError = '(?i)\b(error|exception|fail(ed|ure)?|critical|fatal)\b'
    $records = New-Object System.Collections.Generic.List[object]
    $errorLines = New-Object System.Collections.Generic.List[object]

    foreach ($f in $Files) {
        try {
            $text = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
            if ([string]::IsNullOrWhiteSpace($text)) {
                $text = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue
            }
            if ([string]::IsNullOrWhiteSpace($text)) { continue }

            $lines = @($text -split "`r?`n")
            $lineCount = ($lines | Measure-Object).Count

            # Collect error lines and normalize
            $errLines  = @($lines | Where-Object { $_ -match $regexError })
            $errCount  = ($errLines | Measure-Object).Count
            if ($errCount -gt 0) {
                $idx = 0
                foreach ($el in $errLines) {
                    $idx++
                    $errorLines.Add([pscustomobject]@{
                        File       = $f.FullName
                        Text       = $el
                        Normalized = (Normalize-LogLine -Line $el)
                    })
                }
            }

            # Rough date extraction (first date-like token encountered)
            $fileDate = $null
            foreach ($ln in $lines) {
                $m = [regex]::Match($ln, '(?<!\d)(20\d{2}|19\d{2})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])')
                if ($m.Success) { $fileDate = [datetime]::Parse($m.Value); break }
            }

            $records.Add([pscustomobject]@{
                File              = $f.FullName
                SizeKB            = [math]::Round($f.Length/1KB,2)
                Lines             = $lineCount
                ErrorLines        = $errCount
                ErrorPct          = if ($lineCount -gt 0) { [math]::Round(($errCount/$lineCount)*100,2) } else { 0 }
                FirstDetectedDate = $fileDate
                LastWriteTime     = $f.LastWriteTime
            })
        } catch {
            Write-Host "⚠️ Error analyzing $($f.Name): $_" -ForegroundColor Yellow
        }
    }

    return @{
        Records    = $records
        ErrorLines = $errorLines
    }
}

function Summarize-Errors {
    param([Parameter(Mandatory)][System.Collections.Generic.List[object]]$ErrorLines,[int]$TopN = 10)
    $groups = @{}
    foreach ($e in $ErrorLines) {
        $key = if ([string]::IsNullOrWhiteSpace($e.Normalized)) { $e.Text } else { $e.Normalized }
        if (-not $groups.ContainsKey($key)) {
            $groups[$key] = @{
                Count = 0
                SampleText = $e.Text
            }
        }
        $groups[$key].Count++
    }

    $top = $groups.GetEnumerator() |
        Sort-Object { $_.Value.Count } -Descending |
        Select-Object -First $TopN |
        ForEach-Object {
            [pscustomobject]@{
                Pattern    = $_.Key
                Count      = $_.Value.Count
                SampleText = $_.Value.SampleText
            }
        }

    # Keyword counts
    $kw = @{
        error     = 0
        exception = 0
        fail      = 0
        critical  = 0
        fatal     = 0
    }
    foreach ($e in $ErrorLines) {
        $t = $e.Text.ToLowerInvariant()
        if ($t -match '\berror\b')     { $kw.error++ }
        if ($t -match '\bexception\b') { $kw.exception++ }
        if ($t -match '\bfail(ed|ure)?\b') { $kw.fail++ }
        if ($t -match '\bcritical\b')  { $kw.critical++ }
        if ($t -match '\bfatal\b')     { $kw.fatal++ }
    }

    return @{
        TopErrors      = $top
        KeywordCounts  = $kw
        TotalErrLines  = ($ErrorLines | Measure-Object).Count
    }
}

function Print-TopErrors {
    param([object[]]$TopErrors,[int]$TotalErrLines)
    Write-Host ""
    Write-Host " Top repeated error patterns (normalized) " -ForegroundColor Cyan
    Write-Host "========================================================="
    if (($TopErrors | Measure-Object).Count -eq 0) {
        Write-Host (" No repeated error patterns found. Total error lines: {0}" -f $TotalErrLines) -ForegroundColor DarkYellow
        return
    }
    $i = 0
    foreach ($t in $TopErrors) {
        $i++
        $msg = if ($t.Pattern.Length -gt 100) { $t.Pattern.Substring(0,100) + '…' } else { $t.Pattern }
        Write-Host (" {0,2}. {1}  (x{2})" -f $i, $msg, $t.Count)
    }
}

function Save-Results {
    param(
        [Parameter(Mandatory)][System.Collections.Generic.List[object]]$Records,
        [string]$Label,
        [object[]]$TopErrors,
        [hashtable]$KeywordCounts,
        [int]$TotalErrLines
    )
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base  = Join-Path $ExportDir ("AgentLogReview_{0}" -f $stamp)
    $csv   = "$base.csv"
    $json  = "$base.json"
    $topCsv   = "$base`_TopErrors.csv"
    $kwCsv    = "$base`_ErrorKeywords.csv"
    $summaryJ = "$base`_Summary.json"

    try {
        $Records | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        $Records | ConvertTo-Json -Depth 4 | Out-File -FilePath $json -Encoding UTF8

        if (($TopErrors | Measure-Object).Count -gt 0) {
            $TopErrors | Export-Csv -Path $topCsv -NoTypeInformation -Encoding UTF8
        } else {
            '' | Out-File -FilePath $topCsv -Encoding UTF8
        }

        $kwRows = @()
        foreach ($k in $KeywordCounts.Keys) {
            $kwRows += [pscustomobject]@{ Keyword = $k; Count = $KeywordCounts[$k] }
        }
        $kwRows | Export-Csv -Path $kwCsv -NoTypeInformation -Encoding UTF8

        $summary = [pscustomobject]@{
            Source          = $Label
            Timestamp       = (Get-Date)
            TotalErrorLines = $TotalErrLines
            TopErrors       = $TopErrors
            KeywordCounts   = $kwRows
            Files           = $Records
        }
        $summary | ConvertTo-Json -Depth 6 | Out-File -FilePath $summaryJ -Encoding UTF8

        Write-Host ""
        Write-Host " Saved:" -ForegroundColor Green
        Write-Host "  - $csv"
        Write-Host "  - $json"
        Write-Host "  - $topCsv"
        Write-Host "  - $kwCsv"
        Write-Host "  - $summaryJ"
    } catch {
        Write-Host "❌ Failed to save results: $_" -ForegroundColor Red
    }
}

function Get-LogTargets {
    $files = @()
    $label = ""
    $evtx  = @()

    Write-Host ""
    Write-Host " Log Source Selection" -ForegroundColor Cyan
    Write-Host "========================================================="
    Write-Host (" [1] Use default ConnectSecure logs  - {0}" -f $DefaultLogFolder)
    Write-Host " [2] Browse and pick a FOLDER or FILE(S)"
    Write-Host " [Q] Return to Launcher"
    $mode = Read-Host "Enter choice (1/2/Q)"
    if ($mode -match '^(q|Q)$') { return @{Files=@(); Label=''; EvtxFiles=@(); Quit=$true} }

    switch ($mode) {
        '1' {
            if (-not (Test-Path -LiteralPath $DefaultLogFolder -PathType Container)) {
                Write-Host "❌ Default path not found: $DefaultLogFolder" -ForegroundColor Yellow
                Pause-Script
                return Get-LogTargets
            }
            $files = @(Get-FilesFromFolder -FolderPath $DefaultLogFolder -DetectedFolderMode)
            if ((@($files) | Measure-Object).Count -eq 0) {
                Write-Host "❌ No log-like files (*.log;*.txt;*.csv) found in: $DefaultLogFolder" -ForegroundColor Yellow
                Pause-Script
                return Get-LogTargets
            }
            $label = "ConnectSecure Logs ($DefaultLogFolder)"
            $evtx  = @(Get-ChildItem -LiteralPath $DefaultLogFolder -Recurse -File -Filter *.evtx -ErrorAction SilentlyContinue)
        }
        '2' {
            Write-Host ""
            Write-Host " Pick source type:" -ForegroundColor Cyan
            Write-Host "  [F] Folder (scan ALL files recursively)"
            Write-Host "  [L] File (you can multi-select)"
            $pick = Read-Host "Enter choice (F/L)"
            if ($pick -match '^(f|F)$') {
                $folder = Select-FolderDialog -Description "Select a folder to scan (all files)"
                if (-not $folder) { Write-Host "No folder selected."; return Get-LogTargets }
                $files = @(Get-FilesFromFolder -FolderPath $folder)
                if ((@($files) | Measure-Object).Count -eq 0) {
                    Write-Host "❌ Folder contains no files: $folder" -ForegroundColor Yellow
                    Pause-Script
                    return Get-LogTargets
                }
                $label = "Folder: $folder"
                $evtx  = @(Get-ChildItem -LiteralPath $folder -Recurse -File -Filter *.evtx -ErrorAction SilentlyContinue)
            } elseif ($pick -match '^(l|L)$') {
                $selected = @(Select-FileDialog -Title "Select one or more log files")
                if (($selected | Measure-Object).Count -eq 0) { Write-Host "No files selected."; return Get-LogTargets }
                $files = @()
                foreach ($f in $selected) {
                    if (Test-Path -LiteralPath $f -PathType Leaf) {
                        $files += Get-Item -LiteralPath $f
                    }
                }
                $label = if ((@($files) | Measure-Object).Count -eq 1) { "File: $($files[0].FullName)" } else { "Files: $((@($files) | Measure-Object).Count) selected" }
                $folders = $files | ForEach-Object { Split-Path -Parent $_.FullName } | Sort-Object -Unique
                foreach ($fd in $folders) {
                    $evtx += Get-ChildItem -LiteralPath $fd -File -Filter *.evtx -ErrorAction SilentlyContinue
                }
                $evtx = @($evtx | Sort-Object FullName -Unique)
            } else {
                Write-Host "Invalid selection." -ForegroundColor Yellow
                return Get-LogTargets
            }
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            return Get-LogTargets
        }
    }

    $files = @($files | Where-Object { $_ -is [System.IO.FileInfo] })
    if ((@($files) | Measure-Object).Count -eq 0) {
        Write-Host "❌ No files found to analyze." -ForegroundColor Yellow
        Pause-Script
        return Get-LogTargets
    }

    return @{
        Files     = $files
        Label     = $label
        EvtxFiles = @($evtx)
        Quit      = $false
    }
}

function Run-ReviewOnce {
    $pick = Get-LogTargets
    if ($pick.Quit) { return @{ Quit = $true } }

    $files = @($pick.Files)
    $evtx  = @($pick.EvtxFiles)
    $label = $pick.Label

    $fileCount = (@($files) | Measure-Object).Count
    Write-Host ""
    Write-Host " Selected: $label" -ForegroundColor Cyan
    Write-Host (" Files to analyze: {0}" -f $fileCount)

    $daysIn = Read-Host "How many days of logs to review? (Default 7)"
    if ([string]::IsNullOrWhiteSpace($daysIn)) { $daysIn = '7' }
    $days = 7
    [void][int]::TryParse($daysIn, [ref]$days)

    try {
        $analysis = Analyze-Logs -Files $files -Days $days
        $records  = $analysis.Records
        $errLines = $analysis.ErrorLines

        $summary = Summarize-Errors -ErrorLines $errLines -TopN 10
        Print-TopErrors -TopErrors $summary.TopErrors -TotalErrLines $summary.TotalErrLines

        Save-Results -Records $records -Label $label -TopErrors $summary.TopErrors -KeywordCounts $summary.KeywordCounts -TotalErrLines $summary.TotalErrLines

        # Optional EVTX collection (unchanged)
        $ans = Read-Host "Include live Windows Event Logs (Application/System)? (Y/N)"
        if ($ans -match '^(y|Y)$') {
            $app = Get-WinEvent -LogName Application -MaxEvents 500 -ErrorAction SilentlyContinue
            $sys = Get-WinEvent -LogName System -MaxEvents 500 -ErrorAction SilentlyContinue
            $events = @($app + $sys)
            if ((@($events) | Measure-Object).Count -gt 0) {
                $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
                $evtxJson = Join-Path $ExportDir ("AgentLogReview_Events_{0}.json" -f $stamp)
                try {
                    $events | Select-Object TimeCreated, Id, ProviderName, LevelDisplayName, Message |
                        ConvertTo-Json -Depth 3 | Out-File -FilePath $evtxJson -Encoding UTF8
                    Write-Host "  - Saved Event summary: $evtxJson"
                } catch {}
            }
        }

        Write-Host ""
        Write-Host " Review complete." -ForegroundColor Green
    } catch {
        Write-Host "ERROR during log review: $($_.Exception.Message)" -ForegroundColor Red
        Pause-Script
    }

    return @{ Quit = $false }
}

# -----------------------------------
# Main
# -----------------------------------
Clear-Host
Show-Header -Title "CyberCNS Agent Log Review" -Subtitle "Analyze errors, repetition and correlate with Windows"

do {
    $result = Run-ReviewOnce
    if ($result.Quit) { break }

    Write-Host ""
    $again = Read-Host "Run another log review? (Y to continue, Q to return to Launcher)"
    if ($again -match '^(q|Q)$') { break }

} while ($true)

# Return to Launcher in same window
try {
    if (Test-Path -LiteralPath $LauncherPath) {
        Launch-Tool -Target $LauncherPath -InProcess
    }
} catch {}
