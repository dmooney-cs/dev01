<# ====================================================
  Agent-Log-Review.ps1  (v6k - "Last N minutes" anchored to file's last timestamp, robust pickers, ASCII UI)
====================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables ----
$ContextBefore          = 3
$ContextAfter           = 3
$MaxExamplesPerPattern  = 12
$LargeFileContextMB     = 25
$FoldUrlToHost          = $true
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$RecentWindowMinutes    = 5     # last N minutes of logs, anchored to each file's last timestamp

# -------- Bootstrap --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) { try { . $commonPath } catch { } }
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header { param([string]$Title='ConnectSecure Technicians Toolbox')
    Write-Host ("`n $Title") -ForegroundColor Cyan
    Write-Host ('='*58)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME,"$env:USERDOMAIN\$env:USERNAME",$isAdmin) -ForegroundColor Gray
    Write-Host ('='*58)
    Write-Host ''
  }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

# -------- STA invoker for dialogs --------
function Invoke-STA {
  param([Parameter(Mandatory)][string]$ScriptText)
  try { & powershell.exe -NoProfile -STA -Command $ScriptText 2>$null } catch { @() }
}

# -------- Dialog helpers --------
function Select-FolderDialog {
  param([string]$Description='Select a folder containing logs',[string]$InitialDirectory='C:\')
  $script = @"
Add-Type -AssemblyName System.Windows.Forms
`$fd = New-Object System.Windows.Forms.FolderBrowserDialog
`$fd.Description = '$($Description -replace "'","''")'
if (Test-Path '$InitialDirectory') { `$fd.SelectedPath = '$($InitialDirectory -replace "'","''")' }
[void]`$fd.ShowDialog()
if (`$fd.SelectedPath) { [Console]::WriteLine(`$fd.SelectedPath) }
"@
  $sel = Invoke-STA -ScriptText $script
  if (-not $sel) { return $null }
  if ($sel -is [string]) { $sel = @($sel) }
  $candidate = ($sel | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -First 1)
  if ($candidate) { return $candidate.Trim() }
  return $null
}

function Select-FilesDialog {
  param(
    [string]$Title='Select log file(s)',
    [string]$InitialDirectory='C:\',
    [string]$Filter='Log/Text files (*.log;*.txt;*.json)|*.log;*.txt;*.json|All files (*.*)|*.*'
  )
  $script = @"
Add-Type -AssemblyName System.Windows.Forms
`$ofd = New-Object System.Windows.Forms.OpenFileDialog
`$ofd.Title = '$($Title -replace "'","''")'
`$ofd.Multiselect = `$true
`$ofd.Filter = '$($Filter -replace "'","''")'
if (Test-Path '$InitialDirectory') { `$ofd.InitialDirectory = '$($InitialDirectory -replace "'","''")' }
[void]`$ofd.ShowDialog()
if (`$ofd.FileNames) { `$ofd.FileNames | ForEach-Object { [Console]::WriteLine($_) } }
"@
  $sel = Invoke-STA -ScriptText $script
  $clean = @()
  if ($sel) {
    if ($sel -is [string]) { $sel = @($sel) }
    foreach ($s in $sel) { if (-not [string]::IsNullOrWhiteSpace($s)) { $clean += $s.Trim() } }
  }
  return ,$clean
}

# -------- Utilities --------
function HtmlEscape($s) { return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }

# Always return a string[]; never $null or scalar
function Read-FileLines {
  param([Parameter(Mandatory)][string]$Path)
  try {
    $c = Get-Content -LiteralPath $Path -ErrorAction Stop
    if ($null -eq $c) { return @() }
    if ($c -is [string]) { return @($c) }
    return @($c)
  } catch {
    Write-Warn ("Failed to read file: {0}" -f $_.Exception.Message)
    return @()
  }
}

# -------- Normalization helpers --------
function Normalize-LineForPattern {
  param([string]$Line)
  if ($null -eq $Line) { return '' }
  $norm = $Line
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
  if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()
  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

# -------- Timestamp parsing --------
function TryParse-LineDateTime {
  param([string]$Line,[datetime]$FallbackDate)
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

  # ISO-like: 2025-10-27 14:03:22(.123)(Z|+02:00)
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  # Slash date: 2025/10/27 14:03:22(.123)
  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  # Time only: HH:mm:ss(.fff) -> assume same date as fallback
  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success -and $FallbackDate) {
    try {
      $h=[int]$m.Groups[1].Value.Substring(0,2)
      $mi=[int]$m.Groups[1].Value.Substring(3,2)
      $s=[int]$m.Groups[1].Value.Substring(6,2)
      return (Get-Date -Date $FallbackDate.Date -Hour $h -Minute $mi -Second $s)
    } catch {}
  }
  return $null
}

# -------- Analysis --------
function Analyze-File {
  param([string]$FilePath)

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $patterns = @{}
  $contexts = @{}

  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false
  if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

  $lines = Read-FileLines -Path $FilePath
  $lines = @($lines)  # force array
  if ($lines.Count -eq 0) {
    Write-Warn ("Skipping empty or unreadable file: {0}" -f $FilePath)
    $now = Get-Date
    return [PSCustomObject]@{
      File=$FilePath; Total=0; Counts=$countsByLevel; Patterns=$patterns; Contexts=$contexts;
      Limited=$limitCtx; RecentWindow=@{Start=$now;End=$now};
      RecentCounts=@{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 };
      RecentSnippets=@()
    }
  }

  # ---- Determine latest timestamp in this file (for anchoring the window) ----
  $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }
  $latestInFile = $null
  foreach ($ln in $lines) {
    $dt = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate
    if ($dt) {
      if ($null -eq $latestInFile -or $dt -gt $latestInFile) { $latestInFile = $dt }
    }
  }
  if (-not $latestInFile) { $latestInFile = $fallbackDate }

  $windowEnd   = $latestInFile
  $windowStart = $windowEnd.AddMinutes(-$RecentWindowMinutes)

  # ---- Recent window prepass (indices within window anchored to latestInFile) ----
  $recentIdxs = New-Object System.Collections.Generic.List[int]
  for ($ri=0; $ri -lt $lines.Count; $ri++) {
    $dt = TryParse-LineDateTime -Line $lines[$ri] -FallbackDate $fallbackDate
    if ($dt -and $dt -ge $windowStart -and $dt -le $windowEnd) { $recentIdxs.Add($ri) }
  }

  # ---- Full-file pass for counts/patterns/contexts ----
  for ($i=0;$i -lt $lines.Count;$i++) {
    $line = [string]$lines[$i]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }

      $norm = Normalize-LineForPattern -Line $line
      if (-not $patterns.ContainsKey($norm)) { $patterns[$norm] = 0 }
      $patterns[$norm]++
      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }

      $maxCtx = if ($limitCtx) { [Math]::Min($MaxExamplesPerPattern,3) } else { $MaxExamplesPerPattern }
      if ($contexts[$norm].Count -lt $maxCtx) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($null -eq $n -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx="Context for line $($i+1) (+/-$ContextBefore/$ContextAfter)`n"
        for($p=$start;$p -le $end;$p++){
          $prefix=('   '); if($p -eq $i){ $prefix='>> ' }
          $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
        }
        $contexts[$norm] += $ctx
      }
    }
  }

  # ---- Recent window: counts + short contexts ----
  $recentCounts = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $recentSnippets = New-Object System.Collections.Generic.List[string]
  foreach ($idx in $recentIdxs) {
    $line = [string]$lines[$idx]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$recentCounts.ERROR++}
        '^FATAL$'        {$recentCounts.FATAL++}
        '^EXCEPTION$'    {$recentCounts.EXCEPTION++}
        '^WARN$'         {$recentCounts.WARN++}
        '^WARNING$'      {$recentCounts.WARNING++}
        '^FAIL(ED)?$'    {$recentCounts.FAIL++}
        '^TIMEOUT$'      {$recentCounts.TIMEOUT++}
        '^UNAUTHORIZED$' {$recentCounts.UNAUTHORIZED++}
        'ACCESS DENIED'  {$recentCounts.ACCESSDENIED++}
      }
      $rStart=[Math]::Max(0,$idx-1); $rEnd=[Math]::Min($lines.Count-1,$idx+1)
      $ctx="Recent match at line $($idx+1)`n"
      for($p=$rStart;$p -le $rEnd;$p++){
        $prefix=('   '); if($p -eq $idx){ $prefix='>> ' }
        $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
      }
      $recentSnippets.Add($ctx)
    }
  }

  return [PSCustomObject]@{
    File           = $FilePath
    Total          = $lines.Count
    Counts         = $countsByLevel
    Patterns       = $patterns
    Contexts       = $contexts
    Limited        = $limitCtx
    RecentWindow   = @{ Start=$windowStart; End=$windowEnd; Anchored='FileLastTimestamp' }
    RecentCounts   = $recentCounts
    RecentSnippets = $recentSnippets
  }
}

# -------- Report --------
function Collect-And-Report {
  param([string[]]$Roots)

  $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
  Ensure-Folder $outDir
  $ts=Get-Date -Format 'yyyyMMdd_HHmmss'
  $collectDir=Join-Path $outDir ('Collect_'+$ts)
  Ensure-Folder $collectDir

  $patterns='*.log','*.txt','*.json','*.evtx','*.zip','*.gz'
  $found=$false

  foreach($root in ($Roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) })) {
    Write-Info "Scanning $root ..."
    if (Test-Path -LiteralPath $root -PathType Leaf) {
      $found = $true
      $dest = Join-Path $collectDir 'SelectedFiles'
      Ensure-Folder $dest
      Copy-Item -LiteralPath $root -Destination (Join-Path $dest (Split-Path $root -Leaf)) -Force -ErrorAction SilentlyContinue
      Write-OK ("Copied file: {0}" -f $root)
    } else {
      $dest=Join-Path $collectDir ((Split-Path $root -Leaf)-replace'[^\w\.-]','_'); Ensure-Folder $dest
      try {
        $items = Get-ChildItem -Path (Join-Path $root '*') -Recurse -File -Include $patterns -ErrorAction SilentlyContinue
        if ($items) {
          $found=$true
          $i=0; foreach($f in $items){ $i++; if($i%50 -eq 0){ Write-Info (" Copying files... {0}/{1}" -f $i,$items.Count) }
            $rel=try{$f.FullName.Substring($root.Length).TrimStart('\','/')}catch{$f.Name}
            $tgt=Join-Path $dest $rel; Ensure-Folder (Split-Path $tgt -Parent)
            Copy-Item -LiteralPath $f.FullName -Destination $tgt -Force -ErrorAction SilentlyContinue
          }
          Write-OK ("Copied {0} files from {1}" -f $items.Count,$root)
        } else { Write-Warn ("No matching files found under {0}" -f $root) }
      } catch { Write-Warn ("Scan error on {0}: {1}" -f $root,$_.Exception.Message) }
    }
  }

  # Early exit if no logs found
  if(-not $found){
    Write-Warn 'No logs found'
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
.kicker{background:#fff4d6;border:1px solid #ffd27a;padding:10px;border-radius:8px;}
</style></head><body>
<div class="logo-wrap"><img src="$LogoUrl" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Agent Log Review</h1>
<div class="kicker">
  <h3>No logs were collected</h3>
  <p>We did not find any files matching *.log, *.txt, *.json, *.evtx, *.zip, or *.gz in the selected location(s).</p>
</div>
</body></html>
"@
    $htmlPath=Join-Path $collectDir 'index.html'
    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html)
    [System.IO.File]::WriteAllBytes($htmlPath, $bytes)
    Write-OK ("Wrote HTML report: $htmlPath")
    try{ Start-Process $htmlPath }catch{}
    return
  }

  # Build report
  $html=[System.Text.StringBuilder]::new()
  $null=$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>')
  $null=$html.AppendLine('<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:8px;margin:6px 0 10px;}
.kicker h3{margin:0 0 6px 0;}
.badge{display:inline-block;padding:2px 6px;border:1px solid #aaa;border-radius:6px;font-size:12px;color:#555;background:#fafafa;margin-left:6px;}
</style></head><body>')
  $null=$html.AppendLine('<div class="logo-wrap"><img src="'+ (HtmlEscape $LogoUrl) +'" alt="ConnectSecure logo"></div>')
  $null=$html.AppendLine('<h1>ConnectSecure - Agent Log Review</h1>')

  $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in '.log','.txt','.json' }

  foreach($tf in $textFiles){
    Write-Info ("Analyzing " + $tf.FullName)
    $res=Analyze-File -FilePath $tf.FullName
    $fname=Split-Path $tf.FullName -Leaf

    $null=$html.AppendLine("<details><summary>"+(HtmlEscape $fname)+" - "+$res.Total+" lines<span class=""badge"">Recent window anchored to last timestamp</span></summary>")

    # Last N minutes section (anchored to last timestamp)
    $wStart = $res.RecentWindow.Start.ToString('yyyy-MM-dd HH:mm:ss')
    $wEnd   = $res.RecentWindow.End.ToString('yyyy-MM-dd HH:mm:ss')
    $null=$html.AppendLine('<div class="kicker">')
    $null=$html.AppendLine('<h3>Last '+$RecentWindowMinutes+' minutes only</h3>')
    $null=$html.AppendLine('<div class="small">Window: '+ (HtmlEscape $wStart) +' -> '+ (HtmlEscape $wEnd) +' (anchored to last timestamp in this file)</div>')
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count (recent)</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.RecentCounts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')
    $maxRecent = [Math]::Min(25, $res.RecentSnippets.Count)  # bumped to 25 since this is focused
    if ($maxRecent -gt 0) {
      for ($ri=0; $ri -lt $maxRecent; $ri++) {
        $null=$html.AppendLine("<pre>"+ (HtmlEscape $res.RecentSnippets[$ri]) +"</pre>")
      }
      if ($res.RecentSnippets.Count -gt $maxRecent) {
        $null=$html.AppendLine('<div class="small">...'+($res.RecentSnippets.Count - $maxRecent)+' more recent matches omitted for brevity.</div>')
      }
    } else {
      $null=$html.AppendLine('<div class="small">No severity matches within the recent window.</div>')
    }
    $null=$html.AppendLine('</div>')

    # Severity table (full file)
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.Counts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')

    # Patterns & contexts
    $ordered=$res.Patterns.GetEnumerator()|Sort-Object Value -Descending
    foreach($entry in $ordered){
      $pat=(HtmlEscape $entry.Key); $cnt=$entry.Value
      $null=$html.AppendLine('<details><summary>'+ $pat +' - <span class="small">'+$cnt+' occurrence(s)</span></summary>')
      $idx=1
      if ($res.Contexts.ContainsKey($entry.Key)) {
        foreach($ctx in $res.Contexts[$entry.Key]){ $null=$html.AppendLine("<h4>Example "+$idx+"</h4><pre>"+(HtmlEscape $ctx)+"</pre>"); $idx++ }
      }
      $null=$html.AppendLine('</details>')
    }
    $null=$html.AppendLine('</details>')

    # CSVs
    $csvPath=Join-Path $collectDir ($fname+'_ErrorSummary.csv')
    $res.Patterns.GetEnumerator()|Sort-Object Value -Descending|
      Select-Object @{n='Pattern';e={$_.Key}},@{n='Count';e={$_.Value}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath

    $csvRecent = Join-Path $collectDir ($fname+'_Recent_'+$RecentWindowMinutes+'min_anchored.csv')
    [pscustomobject]@($res.RecentCounts) |
      Select-Object @{n='ERROR';e={$_.ERROR}},
                    @{n='FATAL';e={$_.FATAL}},
                    @{n='EXCEPTION';e={$_.EXCEPTION}},
                    @{n='WARN';e={$_.WARN}},
                    @{n='WARNING';e={$_.WARNING}},
                    @{n='FAIL';e={$_.FAIL}},
                    @{n='TIMEOUT';e={$_.TIMEOUT}},
                    @{n='UNAUTHORIZED';e={$_.UNAUTHORIZED}},
                    @{n='ACCESSDENIED';e={$_.ACCESSDENIED}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvRecent
  }

  $null=$html.AppendLine('</body></html>')
  $htmlPath=Join-Path $collectDir 'index.html'
  $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html.ToString())
  [System.IO.File]::WriteAllBytes($htmlPath, $bytes)

  Write-OK ("Wrote HTML report: $htmlPath")
  try{ Start-Process $htmlPath }catch{}
}

function Start-AgentLogReview {
  Show-Header -Title 'ConnectSecure Technicians Toolbox'
  Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
  Write-Host ''
  Write-Host ' [1] Local Agent ConnectSecure Logs' -ForegroundColor White
  Write-Host '     - Scans: C:\Program Files (x86)\CyberCNSAgent\logs' -ForegroundColor DarkGray
  Write-Host ' [2] Browse for FOLDER...' -ForegroundColor White
  Write-Host ' [3] Browse for FILE(S)...' -ForegroundColor White
  Write-Host ' [Q] Quit' -ForegroundColor White
  Write-Host ''
  $choice=Read-Host 'Select an option (1/2/3/Q)'
  switch($choice.ToUpper()) {
    '1'{ Collect-And-Report -Roots @('C:\Program Files (x86)\CyberCNSAgent\logs') }
    '2'{ $picked=Select-FolderDialog -Description 'Choose agent logs folder' -InitialDirectory 'C:\Program Files (x86)\CyberCNSAgent\logs'
         if(-not [string]::IsNullOrWhiteSpace($picked)){ Collect-And-Report -Roots @($picked) } else { Write-Warn 'No valid folder selected.' } }
    '3'{ $files=Select-FilesDialog -Title 'Choose one or more log files' -InitialDirectory 'C:\Program Files (x86)\CyberCNSAgent\logs'
         if($files -and $files.Count -gt 0){ Collect-And-Report -Roots $files } else { Write-Warn 'No files selected.' } }
    'Q'{ return }
    Default{ Write-Warn 'Invalid choice.' }
  }
  Write-Host ''
  Read-Host 'Press Enter to return...'
}

Start-AgentLogReview
