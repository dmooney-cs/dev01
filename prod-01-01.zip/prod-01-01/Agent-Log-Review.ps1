﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿
# ===== Header Compatibility Wrapper =====
function Invoke-Header {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [string]$Subtitle
    )
    try {
        $cmd = Get-Command -Name Show-Header -ErrorAction Stop
        if ($cmd.Parameters.ContainsKey('Subtitle') -and $Subtitle) {
            Show-Header -Title $Title -Subtitle $Subtitle
        } else {
            Show-Header -Title $Title
            if ($Subtitle) {
                Write-Host (" " + $Subtitle) -ForegroundColor Yellow
            }
        }
    } catch {
        # Fallback rendering if Show-Header is not available
        Write-Host ""
        Write-Host ("=" * 65) -ForegroundColor Cyan
        Write-Host (" " + $Title) -ForegroundColor White
        if ($Subtitle) {
            Write-Host (" " + $Subtitle) -ForegroundColor Yellow
        }
        Write-Host ("=" * 65) -ForegroundColor Cyan
        Write-Host ""
    }
}
# ===== End Wrapper =====


# ===== CyberCNS Logs Collector =====
function Collect-CyberCNSLogs {
    [CmdletBinding()]
    param(
        [string]$SourceDir = "C:\Program Files (x86)\CyberCNSAgent\logs",
        [string]$DestDir   = "C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs"
    )

    $services = @("CyberCNSAgent", "CyberCNSAgentMonitor")
    try {
        Write-Host "Stopping CyberCNS services..." -ForegroundColor Cyan
        foreach ($s in $services) {
            try { Stop-Service -Name $s -Force -ErrorAction Stop; Write-Host "  - Stopped $s" -ForegroundColor DarkGray } catch {}
        }

        try { New-Item -ItemType Directory -Path $DestDir -Force | Out-Null } catch {}
        Write-Host "Copying logs from $SourceDir to $DestDir ..." -ForegroundColor Cyan
        Copy-Item -Path (Join-Path $SourceDir "*") -Destination $DestDir -Recurse -Force -ErrorAction Stop
        Write-Host "Logs copied successfully." -ForegroundColor Green
    }
    catch {
        Write-Host ("ERROR copying logs: {0}" -f $_.Exception.Message) -ForegroundColor Red
    }
    finally {
        Write-Host "Restarting CyberCNS services..." -ForegroundColor Cyan
        foreach ($s in $services) {
            try { Start-Service -Name $s -ErrorAction Stop; Write-Host "  - Started $s" -ForegroundColor DarkGray } catch {}
        }
    }
}
# ===== End CyberCNS Logs Collector =====

# Default CS-Toolbox temp root
if (!$env:CS_TOOLBOX_TEMP) { $env:CS_TOOLBOX_TEMP = 'C:\CS-Toolbox-TEMP' }

# ===== Correlation Helpers =====
function Get-AgentErrorRecords { param([string[]]$Files,[int]$Days=7)
    $cutoff=(Get-Date).AddDays(-[math]::Abs($Days));$recs=@()
    $pat1='^\s*\[?(?<ts>\d{4}[-/]\d{2}[-/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\]?\s*'
    $pat2='^\s*(?<ts>\d{1,2}[-/][A-Za-z]{3}[-/]\d{2,4}\s+\d{2}:\d{2}:\d{2})\s*'
    foreach($f in $Files){ try{ Get-Content -LiteralPath $f -ErrorAction Stop | %{
        $l=$_; if($l -notmatch '(?i)\b(error|exception|fail(ed)?|fatal)\b'){ return }
        $ts=$null; foreach($p in @($pat1,$pat2)){ $m=[regex]::Match($l,$p); if($m.Success){ $ts=Get-Date $m.Groups['ts'].Value -ErrorAction SilentlyContinue; break } }
        if(-not $ts){ $ts=Get-Date }; if($ts -lt $cutoff){ return }
        $norm=$l.ToLowerInvariant(); $norm=($norm -replace '[^a-z0-9 ]',' ').Trim()
        $tok=$norm -split '\s+' | ? { $_.Length -ge 4 } | select -First 12
        $sig=($tok -join ' ')
        $recs += [PSCustomObject]@{ File=$f; Time=$ts; Line=$l.Trim(); Signature=$sig }
    }} catch{} }
    $groups = $recs | Group-Object Signature | Sort-Object Count -Descending
    [PSCustomObject]@{ Records=$recs; Groups=$groups }
}
function Get-WindowsEventsWindow { param([string[]]$EvtxFiles,[int]$Days=7)
    $cutoff=(Get-Date).AddDays(-[math]::Abs($Days)); $evs=@()
    foreach($ev in $EvtxFiles){ try{ Get-WinEvent -Path $ev -FilterHashtable @{ StartTime=$cutoff } -ErrorAction SilentlyContinue | %{
        $evs += [PSCustomObject]@{ Time=$_.TimeCreated; Id=$_.Id; Source=$_.ProviderName; Level=$_.LevelDisplayName; Text=$_.Message }
    } } catch{} }
    $evs
}
function Correlate-AgentWithWindows { param([object[]]$AgentErrors,[object[]]$WinEvents,[int]$MinutesSkew=1)
    $win=[TimeSpan]::FromMinutes([math]::Abs($MinutesSkew))
    $idx = $WinEvents | %{
        $n=($_.Text -replace '[^a-z0-9 ]',' ').ToLowerInvariant()
        $tkn=$n -split '\s+' | ? { $_.Length -ge 4 }
        [PSCustomObject]@{ Ref=$_; Time=$_.Time; Tok=$tkn }
    }
    $out=@()
    foreach($r in $AgentErrors){
        $t0=$r.Time; $aTok=($r.Signature -split '\s+') | ? { $_.Length -ge 4 }
        $cands = $idx | ? { $_.Time -ge ($t0 - $win) -and $_.Time -le ($t0 + $win) }
        $best=$null; $score=0
        foreach($c in $cands){
            if(-not $c.Tok){ continue }
            $inter = @(@($aTok)+@($c.Tok)) | Group-Object | ? { $_.Count -gt 1 } | % { $_.Name } | select -Unique
            $s = (@($inter) | Measure-Object).Count
            if($s -gt $score){ $score=$s; $best=$c.Ref }
        }
        if($best){
            $out += [PSCustomObject]@{ AgentTime=$r.Time; AgentFile=$r.File; AgentLine=$r.Line; WindowsTime=$best.Time; EventId=$best.Id; Source=$best.Source; Level=$best.Level; EventText=$best.Text; TokenOverlap=$score }
        }
    }
    $out | Sort-Object -Property TokenOverlap, AgentTime -Descending
}
# ===== End Correlation Helpers =====


# ===== Robust EVTX Loader =====
function Get-WindowsEventsFromEvtxRobust {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$EvtxFiles,
        [datetime]$StartTime = (Get-Date).AddDays(-7)
    )
    $events = New-Object System.Collections.Generic.List[object]

    foreach ($ev in $EvtxFiles) {
        $count = 0
        try {
            # First try the standard path
            $subset = Get-WinEvent -Path $ev -FilterHashtable @{ StartTime = $StartTime } -ErrorAction SilentlyContinue
            foreach ($e in $subset) {
                [void]$events.Add([PSCustomObject]@{
                    Time   = $e.TimeCreated
                    Id     = $e.Id
                    Source = $e.ProviderName
                    Level  = $e.LevelDisplayName
                    Text   = $e.Message
                })
                $count++
            }
        } catch {}
        if ($count -eq 0) {
            # Retry via .NET EventLogReader (more tolerant across OS builds)
            try {
                Add-Type -AssemblyName System.Core -ErrorAction SilentlyContinue | Out-Null
                $PathType = [System.Diagnostics.Eventing.Reader.PathType]::FilePath
                $Query = New-Object System.Diagnostics.Eventing.Reader.EventLogQuery($ev, $PathType, "*")
                $Reader = New-Object System.Diagnostics.Eventing.Reader.EventLogReader($Query)
                while ($true) {
                    $rec = $Reader.ReadEvent()
                    if (-not $rec) { break }
                    $tc = $rec.TimeCreated
                    if ($tc -and $tc -ge $StartTime) {
                        [void]$events.Add([PSCustomObject]@{
                            Time   = $tc
                            Id     = $rec.Id
                            Source = $rec.ProviderName
                            Level  = $rec.LevelDisplayName
                            Text   = $rec.FormatDescription()
                        })
                        $count++
                    }
                }
            } catch {
                Write-Host ("WARN: EVTX read via EventLogReader failed for {0}: {1}" -f $ev, $_.Exception.Message) -ForegroundColor Yellow
            }
        }
    }
    return $events
}
# ===== End Robust EVTX Loader =====


# ===== Windows Events JSON Loader =====
function Get-WindowsEventsFromJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$JsonPath
    )
    if (-not (Test-Path -LiteralPath $JsonPath -PathType Leaf)) {
        return @()
    }
    try {
        $raw = Get-Content -LiteralPath $JsonPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        $events = @()
        foreach ($e in $raw) {
            # Support both our exported fields and potential variations
            $t = $e.TimeCreated
            if (-not $t) { $t = $e.Time }
            try { $timeObj = Get-Date $t -ErrorAction SilentlyContinue } catch { $timeObj = $null }
            $events += [PSCustomObject]@{
                Time   = $timeObj
                Id     = $e.Id
                Source = $e.ProviderName
                Level  = $e.LevelDisplayName
                Text   = $e.Message
            }
        }
        # Filter null times just in case
        return $events | Where-Object { $_.Time }
    } catch {
        return @()
    }
}
# ===== End Windows Events JSON Loader =====


# ===== Input Resolver for Correlation =====

function Resolve-CorrelationInputs {
    [CmdletBinding()]
    param(
        [int]$Days = 7,
        [string]$ScanDir = (Join-Path $env:CS_TOOLBOX_TEMP 'Collected-Info\AgentLogs')
    )
    if (-not $env:CS_TOOLBOX_TEMP) { $env:CS_TOOLBOX_TEMP = 'C:\CS-Toolbox-TEMP' }
    $cutoff = (Get-Date).AddDays(-[math]::Abs($Days))

    # --- Agent side: only raw *.log files ---
    $agentTextFiles = @()
    if (Test-Path -LiteralPath $ScanDir) {
        $agentTextFiles = Get-ChildItem -LiteralPath $ScanDir -File -Filter '*.log' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -notlike 'AgentLogReview_*' } |
            Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName -Unique
    }
    $agentRecords = @()
    if ((@($agentTextFiles) | Measure-Object).Count -gt 0) {
        $agent = Get-AgentErrorRecords -Files $agentTextFiles -Days $Days
        $agentRecords = $agent.Records
        $agentSourceKind = 'raw-log'
    } else {
        $agentSourceKind = 'none'
    }

    # --- Windows Events side: prefer EVTX paths ---
    $evtxFiles = @()
    if (Test-Path -LiteralPath $ScanDir) {
        $evtxFiles = Get-ChildItem -LiteralPath $ScanDir -File -Filter '*.evtx' -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName -Unique
    }

    $wins = @()
    $eventsSourceKind = 'none'
    if ((@($evtxFiles) | Measure-Object).Count -gt 0) {
        # Try filtered by StartTime first
        $tmp = @()
        foreach ($ev in $evtxFiles) {
            try {
                $subset = Get-WinEvent -Path $ev -FilterHashtable @{ StartTime = $cutoff } -ErrorAction SilentlyContinue
                if ((@($subset) | Measure-Object).Count -eq 0) {
                    # Retry without filter, then filter in memory
                    $subset = Get-WinEvent -Path $ev -ErrorAction SilentlyContinue | Where-Object { $_.TimeCreated -ge $cutoff }
                }
                $tmp += $subset
            } catch {}
        }
        $wins = Get-WindowsEventsFromEvtxRobust -EvtxFiles $evtxFiles -StartTime $cutoff
        if ((@($wins) | Measure-Object).Count -gt 0) { $eventsSourceKind = 'evtx' }
    } else {
        # Fallback to Events JSON if present
        $eventsJson = $null
        if (Test-Path -LiteralPath $ScanDir) {
            $eventsJson = Get-ChildItem -LiteralPath $ScanDir -Filter 'AgentLogReview_Events_*.json' -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName -First 1
        }
        if ($eventsJson) {
            $wins = Get-WindowsEventsFromJson -JsonPath $eventsJson
            if ((@($wins) | Measure-Object).Count -gt 0) { $eventsSourceKind = 'json' }
        }
    }

    # Diagnostics (concise)
    Write-Host " [diag] Inputs:" -ForegroundColor DarkGray
    Write-Host ("   - dir: {0}" -f $ScanDir) -ForegroundColor DarkGray
    Write-Host ("   - agent: {0} (records={1})" -f $agentSourceKind, ((@($agentRecords)|Measure-Object).Count)) -ForegroundColor DarkGray
    Write-Host ("   - events: {0} (events={1})" -f $eventsSourceKind, ((@($wins)|Measure-Object).Count)) -ForegroundColor DarkGray

    return [PSCustomObject]@{
        AgentRecords = $agentRecords
        WindowsEvents= $wins
    }
}

# ===== End Input Resolver =====

# ===== EVTX Export Helper =====
function Export-RecentEvtx {
    [CmdletBinding()]
    param(
        [int]$Days = 7,
        [Parameter(Mandatory=$true)][string]$OutDir,
        [string[]]$Channels = @('Application','System')
    )
    try { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null } catch {}
    $stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
    $exported = @()
    foreach ($ch in $Channels) {
        $out = Join-Path $OutDir ("{0}_{1}.evtx" -f $ch, $stamp)
        try {
            # Export FULL log (no /q filter); we'll filter by time during read to avoid empty exports on some systems
            wevtutil epl $ch $out /ow:true | Out-Null
            Start-Sleep -Milliseconds 200
            if (Test-Path -LiteralPath $out) { $exported += $out }
        } catch {
            Write-Host ("WARN: failed to export {0}: {1}" -f $ch, $_.Exception.Message) -ForegroundColor Yellow
        }
    }
    return $exported
}

# ===== End EVTX Export Helper =====


# ===== Agent Summary Loaders =====
function Get-AgentErrorsFromJsonFile {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$JsonPath,[int]$Days=7)
    $cutoff=(Get-Date).AddDays(-[math]::Abs($Days))
    if(-not (Test-Path -LiteralPath $JsonPath -PathType Leaf)){ return @() }
    try{
        $items = Get-Content -LiteralPath $JsonPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    } catch { return @() }
    $out=@()
    foreach($it in $items){
        $t=$null
        foreach($k in @('Time','TimeCreated','Timestamp','Date','DateTime')){
            if($it.PSObject.Properties.Name -contains $k){ $t=$it.$k; break }
        }
        try{ $ts = Get-Date $t -ErrorAction SilentlyContinue } catch { $ts=$null }
        if(-not $ts){ continue }
        if($ts -lt $cutoff){ continue }

        # Find text and level-ish fields
        $text=$null; foreach($k in @('Text','Message','Line','Entry','Detail')){ if($it.PSObject.Properties.Name -contains $k){ $text=$it.$k; break } }
        $level=$null; foreach($k in @('Level','Severity','Type')){ if($it.PSObject.Properties.Name -contains $k){ $level=$it.$k; break } }

        $isErr = ($level -match '(?i)err|fatal|exception') -or ($text -match '(?i)\b(error|exception|fail(ed)?|fatal)\b')
        if(-not $isErr){ continue }

        # Signature tokens
        $norm=("$text" ).ToLowerInvariant(); $norm=($norm -replace '[^a-z0-9 ]',' ').Trim()
        $tok=$norm -split '\s+' | ? { $_.Length -ge 4 } | select -First 12
        $sig=($tok -join ' ')
        $out += [PSCustomObject]@{ File=$JsonPath; Time=$ts; Line=$text; Signature=$sig }
    }
    $out
}

function Get-AgentErrorsFromCsvFile {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$CsvPath,[int]$Days=7)
    $cutoff=(Get-Date).AddDays(-[math]::Abs($Days))
    if(-not (Test-Path -LiteralPath $CsvPath -PathType Leaf)){ return @() }
    try{ $rows = Import-Csv -LiteralPath $CsvPath -ErrorAction Stop } catch { return @() }
    $out=@()
    foreach($r in $rows){
        $t=$null
        foreach($k in @('Time','TimeCreated','Timestamp','Date','DateTime')){
            if($r.PSObject.Properties.Name -contains $k){ $t=$r.$k; break }
        }
        try{ $ts = Get-Date $t -ErrorAction SilentlyContinue } catch { $ts=$null }
        if(-not $ts){ continue }
        if($ts -lt $cutoff){ continue }
        $text=$null; foreach($k in @('Text','Message','Line','Entry','Detail')){ if($r.PSObject.Properties.Name -contains $k){ $text=$r.$k; break } }
        $level=$null; foreach($k in @('Level','Severity','Type')){ if($r.PSObject.Properties.Name -contains $k){ $level=$r.$k; break } }
        $isErr = ($level -match '(?i)err|fatal|exception') -or ($text -match '(?i)\b(error|exception|fail(ed)?|fatal)\b')
        if(-not $isErr){ continue }
        $norm=("$text").ToLowerInvariant(); $norm=($norm -replace '[^a-z0-9 ]',' ').Trim()
        $tok=$norm -split '\s+' | ? { $_.Length -ge 4 } | select -First 12
        $sig=($tok -join ' ')
        $out += [PSCustomObject]@{ File=$CsvPath; Time=$ts; Line=$text; Signature=$sig }
    }
    $out
}
# ===== End Agent Summary Loaders =====


# Load shared functions first - required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# =================================================================================================
# Agent-Log-Review.ps1 (R3c) - Default logs path + Top Errors (PowerShell 5.1 Safe)
# - Default path (Option 1): C:\Program Files (x86)\CyberCNSAgent\logs
# - Option 2: Browse (Folder or File(s)); folder scans ALL files recursively
# - Shows on-screen Top repeated error patterns and exports them
# - Exports per-file metrics, TopErrors, and KeywordCounts to Collected-Info\AgentLogs
# - Loops if default path missing or contains no files
# =================================================================================================

$ErrorActionPreference = 'Continue'

# Paths
$DefaultLogFolder = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$ExportDir        = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'
$LauncherPath     = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'

# Ensure export folder
New-Item -ItemType Directory -Path $ExportDir -Force | Out-Null

function Add-WinForms {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        return $true
    } catch {
        Write-Host "⚠️ Unable to load Windows.Forms; falling back to console input. $_" -ForegroundColor Yellow
        return $false
    }
}

function Select-FolderDialog {
    param([string]$Description = "Select a folder containing logs")
    if (-not (Add-WinForms)) { return $null }
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    $dialog.ShowNewFolderButton = $false
    $dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
    $result = $dialog.ShowDialog()
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.SelectedPath
    }
    return $null
}

function Select-FileDialog {
    param([string]$Title = "Select one or more log files")
    if (-not (Add-WinForms)) { return @() }
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = $Title
    $ofd.Filter = "Common logs (*.log;*.txt;*.csv)|*.log;*.txt;*.csv|All files (*.*)|*.*"
    $ofd.Multiselect = $true
    $ofd.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    $null = $ofd.ShowDialog()
    if ([string]::IsNullOrWhiteSpace($ofd.FileName)) { return @() }
    return @($ofd.FileNames)
}

function Get-FilesFromFolder {
    param(
        [Parameter(Mandatory)][string]$FolderPath,
        [switch]$DetectedFolderMode # when true, filter to log-like files; else scan all
    )
    if (-not (Test-Path -LiteralPath $FolderPath -PathType Container)) {
        throw "Folder not found: $FolderPath"
    }
    if ($DetectedFolderMode) {
        $patterns = @('*.log','*.txt','*.csv')
        $files = foreach ($pat in $patterns) {
            Get-ChildItem -LiteralPath $FolderPath -Recurse -File -Filter $pat -ErrorAction SilentlyContinue
        }
        return @($files | Sort-Object FullName -Unique)
    } else {
        return @(Get-ChildItem -LiteralPath $FolderPath -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName)
    }
}

function Normalize-LogLine {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return "" }
    $s = $Line

    # Remove common timestamp prefixes (various formats)
    $s = [regex]::Replace($s, '^\s*\[?\d{4}[-/]\d{2}[-/]\d{2}[ T]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?\]?\s*', '')
    $s = [regex]::Replace($s, '^\s*\d{1,2}[-/][A-Za-z]{3}[-/]\d{2,4}\s+\d{2}:\d{2}:\d{2}\s*', '')

    # Replace GUIDs, IPv4s, hex, long numbers
    $s = [regex]::Replace($s, '\b[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b', '{GUID}')
    $s = [regex]::Replace($s, '\b\d{1,3}(\.\d{1,3}){3}\b', '#.#.#.#')
    $s = [regex]::Replace($s, '0x[0-9A-Fa-f]+', '0x#')
    $s = [regex]::Replace($s, '\b\d{3,}\b', '#')

    # Collapse whitespace
    $s = [regex]::Replace($s, '\s+', ' ').Trim()

    return $s
}

function Analyze-Logs {
    param(
        [Parameter(Mandatory)][System.IO.FileInfo[]]$Files,
        [int]$Days = 7
    )

    $regexError = '(?i)\b(error|exception|fail(ed|ure)?|critical|fatal)\b'
    $records = New-Object System.Collections.Generic.List[object]
    $errorLines = New-Object System.Collections.Generic.List[object]

    foreach ($f in $Files) {
        try {
            $text = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
            if ([string]::IsNullOrWhiteSpace($text)) {
                $text = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue
            }
            if ([string]::IsNullOrWhiteSpace($text)) { continue }

            $lines = @($text -split "`r?`n")
            $lineCount = ($lines | Measure-Object).Count

            # Collect error lines and normalize
            $errLines  = @($lines | Where-Object { $_ -match $regexError })
            $errCount  = ($errLines | Measure-Object).Count
            if ($errCount -gt 0) {
                $idx = 0
                foreach ($el in $errLines) {
                    $idx++
                    $errorLines.Add([pscustomobject]@{
                        File       = $f.FullName
                        Text       = $el
                        Normalized = (Normalize-LogLine -Line $el)
                    })
                }
            }

            # Rough date extraction (first date-like token encountered)
            $fileDate = $null
            foreach ($ln in $lines) {
                $m = [regex]::Match($ln, '(?<!\d)(20\d{2}|19\d{2})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])')
                if ($m.Success) { $fileDate = [datetime]::Parse($m.Value); break }
            }

            $records.Add([pscustomobject]@{
                File              = $f.FullName
                SizeKB            = [math]::Round($f.Length/1KB,2)
                Lines             = $lineCount
                ErrorLines        = $errCount
                ErrorPct          = if ($lineCount -gt 0) { [math]::Round(($errCount/$lineCount)*100,2) } else { 0 }
                FirstDetectedDate = $fileDate
                LastWriteTime     = $f.LastWriteTime
            })
        } catch {
            Write-Host "⚠️ Error analyzing $($f.Name): $_" -ForegroundColor Yellow
        }
    }

    return @{
        Records    = $records
        ErrorLines = $errorLines
    }
}

function Summarize-Errors {
    param([Parameter(Mandatory)][System.Collections.Generic.List[object]]$ErrorLines,[int]$TopN = 10)
    $groups = @{}
    foreach ($e in $ErrorLines) {
        $key = if ([string]::IsNullOrWhiteSpace($e.Normalized)) { $e.Text } else { $e.Normalized }
        if (-not $groups.ContainsKey($key)) {
            $groups[$key] = @{
                Count = 0
                SampleText = $e.Text
            }
        }
        $groups[$key].Count++
    }

    $top = $groups.GetEnumerator() |
        Sort-Object { $_.Value.Count } -Descending |
        Select-Object -First $TopN |
        ForEach-Object {
            [pscustomobject]@{
                Pattern    = $_.Key
                Count      = $_.Value.Count
                SampleText = $_.Value.SampleText
            }
        }

    # Keyword counts
    $kw = @{
        error     = 0
        exception = 0
        fail      = 0
        critical  = 0
        fatal     = 0
    }
    foreach ($e in $ErrorLines) {
        $t = $e.Text.ToLowerInvariant()
        if ($t -match '\berror\b')     { $kw.error++ }
        if ($t -match '\bexception\b') { $kw.exception++ }
        if ($t -match '\bfail(ed|ure)?\b') { $kw.fail++ }
        if ($t -match '\bcritical\b')  { $kw.critical++ }
        if ($t -match '\bfatal\b')     { $kw.fatal++ }
    }

    return @{
        TopErrors      = $top
        KeywordCounts  = $kw
        TotalErrLines  = ($ErrorLines | Measure-Object).Count
    }
}

function Print-TopErrors {
    param([object[]]$TopErrors,[int]$TotalErrLines)
    Write-Host ""
    Write-Host " Top repeated error patterns (normalized) " -ForegroundColor Cyan
    Write-Host "========================================================="
    if (($TopErrors | Measure-Object).Count -eq 0) {
        Write-Host (" No repeated error patterns found. Total error lines: {0}" -f $TotalErrLines) -ForegroundColor DarkYellow
        return
    }
    $i = 0
    foreach ($t in $TopErrors) {
        $i++
        $msg = if ($t.Pattern.Length -gt 100) { $t.Pattern.Substring(0,100) + '...' } else { $t.Pattern }
        Write-Host (" {0,2}. {1}  (x{2})" -f $i, $msg, $t.Count)
    }
}

function Save-Results {
    param(
        [Parameter(Mandatory)][System.Collections.Generic.List[object]]$Records,
        [string]$Label,
        [object[]]$TopErrors,
        [hashtable]$KeywordCounts,
        [int]$TotalErrLines
    )
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base  = Join-Path $ExportDir ("AgentLogReview_{0}" -f $stamp)
    $csv   = "$base.csv"
    $json  = "$base.json"
    $topCsv   = "$base`_TopErrors.csv"
    $kwCsv    = "$base`_ErrorKeywords.csv"
    $summaryJ = "$base`_Summary.json"

    try {
        $Records | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        $Records | ConvertTo-Json -Depth 4 | Out-File -FilePath $json -Encoding UTF8

        if (($TopErrors | Measure-Object).Count -gt 0) {
            $TopErrors | Export-Csv -Path $topCsv -NoTypeInformation -Encoding UTF8
        } else {
            '' | Out-File -FilePath $topCsv -Encoding UTF8
        }

        $kwRows = @()
        foreach ($k in $KeywordCounts.Keys) {
            $kwRows += [pscustomobject]@{ Keyword = $k; Count = $KeywordCounts[$k] }
        }
        $kwRows | Export-Csv -Path $kwCsv -NoTypeInformation -Encoding UTF8

        $summary = [pscustomobject]@{
            Source          = $Label
            Timestamp       = (Get-Date)
            TotalErrorLines = $TotalErrLines
            TopErrors       = $TopErrors
            KeywordCounts   = $kwRows
            Files           = $Records
        }
        $summary | ConvertTo-Json -Depth 6 | Out-File -FilePath $summaryJ -Encoding UTF8

        Write-Host ""
        Write-Host " Saved:" -ForegroundColor Green
        Write-Host "  - $csv"
        Write-Host "  - $json"
        Write-Host "  - $topCsv"
        Write-Host "  - $kwCsv"
        Write-Host "  - $summaryJ"
    } catch {
        Write-Host "❌ Failed to save results: $_" -ForegroundColor Red
    }
}

function Get-LogTargets {
    $files = @()
    $label = ""
    $evtx  = @()

    Write-Host ""
    Write-Host " Log Source Selection" -ForegroundColor Cyan
    Write-Host "========================================================="
    Write-Host (" [1] Use default ConnectSecure logs  - {0}" -f $DefaultLogFolder)
    Write-Host " [2] Browse and pick a FOLDER or FILE(S)"
    Write-Host " [Q] Return to Launcher"
    $mode = Read-Host "Enter choice (1/2/Q)"
    if ($mode -match '^(q|Q)$') { return @{Files=@(); Label=''; EvtxFiles=@(); Quit=$true} }

    switch ($mode) {
        '1' {
            if (-not (Test-Path -LiteralPath $DefaultLogFolder -PathType Container)) {
                Write-Host "❌ Default path not found: $DefaultLogFolder" -ForegroundColor Yellow
                Pause-Script
                return Get-LogTargets
            }
            $files = @(Get-FilesFromFolder -FolderPath $DefaultLogFolder -DetectedFolderMode)
            if ((@($files) | Measure-Object).Count -eq 0) {
                Write-Host "❌ No log-like files (*.log;*.txt;*.csv) found in: $DefaultLogFolder" -ForegroundColor Yellow
                Pause-Script
                return Get-LogTargets
            }
            $label = "ConnectSecure Logs ($DefaultLogFolder)"
            $evtx  = @(Get-ChildItem -LiteralPath $DefaultLogFolder -Recurse -File -Filter *.evtx -ErrorAction SilentlyContinue)
        }
        '2' {
            Write-Host ""
            Write-Host " Pick source type:" -ForegroundColor Cyan
            Write-Host "  [F] Folder (scan ALL files recursively)"
            Write-Host "  [L] File (you can multi-select)"
            $pick = Read-Host "Enter choice (F/L)"
            if ($pick -match '^(f|F)$') {
                $folder = Select-FolderDialog -Description "Select a folder to scan (all files)"
                if (-not $folder) { Write-Host "No folder selected."; return Get-LogTargets }
                $files = @(Get-FilesFromFolder -FolderPath $folder)
                if ((@($files) | Measure-Object).Count -eq 0) {
                    Write-Host "❌ Folder contains no files: $folder" -ForegroundColor Yellow
                    Pause-Script
                    return Get-LogTargets
                }
                $label = "Folder: $folder"
                $evtx  = @(Get-ChildItem -LiteralPath $folder -Recurse -File -Filter *.evtx -ErrorAction SilentlyContinue)
            } elseif ($pick -match '^(l|L)$') {
                $selected = @(Select-FileDialog -Title "Select one or more log files")
                if (($selected | Measure-Object).Count -eq 0) { Write-Host "No files selected."; return Get-LogTargets }
                $files = @()
                foreach ($f in $selected) {
                    if (Test-Path -LiteralPath $f -PathType Leaf) {
                        $files += Get-Item -LiteralPath $f
                    }
                }
                $label = if ((@($files) | Measure-Object).Count -eq 1) { "File: $($files[0].FullName)" } else { "Files: $((@($files) | Measure-Object).Count) selected" }
                $folders = $files | ForEach-Object { Split-Path -Parent $_.FullName } | Sort-Object -Unique
                foreach ($fd in $folders) {
                    $evtx += Get-ChildItem -LiteralPath $fd -File -Filter *.evtx -ErrorAction SilentlyContinue
                }
                $evtx = @($evtx | Sort-Object FullName -Unique)
            } else {
                Write-Host "Invalid selection." -ForegroundColor Yellow
                return Get-LogTargets
            }
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            return Get-LogTargets
        }
    }

    $files = @($files | Where-Object { $_ -is [System.IO.FileInfo] })
    if ((@($files) | Measure-Object).Count -eq 0) {
        Write-Host "❌ No files found to analyze." -ForegroundColor Yellow
        Pause-Script
        return Get-LogTargets
    }

    return @{
        Files     = $files
        Label     = $label
        EvtxFiles = @($evtx)
        Quit      = $false
    }
}

function Run-ReviewOnce {
# Ensure we have the freshest CyberCNS logs available for analysis
try {
    Collect-CyberCNSLogs
} catch {
    Write-Host ("WARN: Collect-CyberCNSLogs failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}


    $pick = Get-LogTargets
    if ($pick.Quit) { return @{ Quit = $true } }

    $files = @($pick.Files)
    $evtx  = @($pick.EvtxFiles)
    $label = $pick.Label

    $fileCount = (@($files) | Measure-Object).Count
    Write-Host ""
    Write-Host " Selected: $label" -ForegroundColor Cyan
    Write-Host (" Files to analyze: {0}" -f $fileCount)

    $daysIn = Read-Host "How many days of logs to review? (Default 7)"
    if ([string]::IsNullOrWhiteSpace($daysIn)) { $daysIn = '7' }
    $days = 7
    [void][int]::TryParse($daysIn, [ref]$days)

    try {
        $analysis = Analyze-Logs -Files $files -Days $days
        $records  = $analysis.Records
        $errLines = $analysis.ErrorLines

        $summary = Summarize-Errors -ErrorLines $errLines -TopN 10
        Print-TopErrors -TopErrors $summary.TopErrors -TotalErrLines $summary.TotalErrLines

        Save-Results -Records $records -Label $label -TopErrors $summary.TopErrors -KeywordCounts $summary.KeywordCounts -TotalErrLines $summary.TotalErrLines

        # Optional EVTX collection (unchanged)
        $ans = Read-Host "Include live Windows Event Logs (Application/System)? (Y/N)"
        if ($ans -match '^(y|Y)$') {
            $app = Get-WinEvent -LogName Application -MaxEvents 500 -ErrorAction SilentlyContinue
            $sys = Get-WinEvent -LogName System -MaxEvents 500 -ErrorAction SilentlyContinue
            $events = @($app + $sys)
            if ((@($events) | Measure-Object).Count -gt 0) {
                $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
                $evtxJson = Join-Path $ExportDir ("AgentLogReview_Events_{0}.json" -f $stamp)
                try {
                    $events | Select-Object TimeCreated, Id, ProviderName, LevelDisplayName, Message |
                        ConvertTo-Json -Depth 3 | Out-File -FilePath $evtxJson -Encoding UTF8
                    Write-Host "  - Saved Event summary: $evtxJson"
                

# Export EVTX files for correlation (last N days) into same folder
try {
    $evtxExported = Export-RecentEvtx -Days $days -OutDir $ExportDir
    if ((@($evtxExported) | Measure-Object).Count -gt 0) {
        Write-Host ("  - Exported EVTX for correlation:`n    " + ($evtxExported -join "`n    "))
        # Make sure correlation sees them
        $evtx = @($evtx + $evtxExported) | Sort-Object -Unique
    } else {
        Write-Host "  - No EVTX exported (check channel access/permissions)" -ForegroundColor Yellow
    }
} catch {
    Write-Host ("  - EVTX export error: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}
} catch {}
            }
        }

        Write-Host ""
        
        
# === Correlate agent errors with Windows events ===
try {
    # Always resolve inputs from the canonical scan dir to avoid mismatches
    $scanDir = (Join-Path $env:CS_TOOLBOX_TEMP "Collected-Info\AgentLogs")
    $resolved = Resolve-CorrelationInputs -Days $days -ScanDir $scanDir
    $agentRecords = $resolved.AgentRecords
    $wins         = $resolved.WindowsEvents

    if ((@($agentRecords) | Measure-Object).Count -gt 0 -and ((@($wins) | Measure-Object).Count -gt 0)) {
        $corr  = Correlate-AgentWithWindows -AgentErrors $agentRecords -WinEvents $wins -MinutesSkew 1

        Write-Host ""
        Write-Host " Correlated Errors (Agent <-> Windows within +/-5 min)" -ForegroundColor Cyan
        Write-Host "====================================================="
        if (($corr | Measure-Object).Count -eq 0) {
            Write-Host " No correlated items found in the selected window." -ForegroundColor Yellow
        } else {
            $max = 15
            $i = 0
            foreach ($row in $corr) {
                $i++
                Write-Host ("[{0}] {1:yyyy-MM-dd HH:mm:ss}  Agent: {2}" -f $i, $row.AgentTime, $row.AgentLine) -ForegroundColor White
                Write-Host ("     -> {0:yyyy-MM-dd HH:mm:ss}  EventID {1} {2} [{3}]  overlap={4}" -f $row.WindowsTime, $row.EventId, $row.Source, $row.Level, $row.TokenOverlap) -ForegroundColor DarkCyan
                if ($row.EventText) {
                    $preview = ($row.EventText -replace '\s+', ' ')
                    if ($preview.Length -gt 180) { $preview = $preview.Substring(0,180) + '...' }
                    Write-Host ("        " + $preview)
                }
                if ($i -ge $max) { break }
            }
            if (($corr | Measure-Object).Count -gt $max) {
                Write-Host (" ...and {0} more. Use a narrower day window to refine." -f ((@($corr)|Measure-Object).Count - $max)) -ForegroundColor DarkGray
            }

# === Export correlated details and summary to CSV ===
try {
    if (-not $env:CS_TOOLBOX_TEMP) { $env:CS_TOOLBOX_TEMP = 'C:\CS-Toolbox-TEMP' }
    $scanDir = (Join-Path $env:CS_TOOLBOX_TEMP "Collected-Info\AgentLogs")
    New-Item -ItemType Directory -Path $scanDir -Force | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csvDetails = Join-Path $scanDir ("AgentLogReview_Correlated_{0}.csv" -f $stamp)
    $csvSummary = Join-Path $scanDir ("AgentLogReview_Correlated_Summary_{0}.csv" -f $stamp)

    # Flatten EventText and export details
    $corr | Select-Object -Property @(
                        'AgentTime','AgentFile','AgentLine','WindowsTime','EventId','Source','Level','TokenOverlap',
                        @{ Name='EventText'; Expression = { if ($_.EventText) { ($_.EventText -replace '\s+',' ') } else { '' } } }
                    ) | Export-Csv -Path $csvDetails -NoTypeInformation -Encoding UTF8

    # Build summary by EventId/Source/Level
    $summary = $corr | Group-Object EventId, Source, Level | ForEach-Object {
        $g = $_.Group
        $first = ($g | Sort-Object WindowsTime | Select-Object -First 1).WindowsTime
        $last  = ($g | Sort-Object WindowsTime -Descending | Select-Object -First 1).WindowsTime
        [PSCustomObject]@{
            EventId   = $g[0].EventId
            Source    = $g[0].Source
            Level     = $g[0].Level
            Count     = $_.Count
            FirstSeen = $first
            LastSeen  = $last
        }
    } | Sort-Object Count -Descending

    $summary | Export-Csv -Path $csvSummary -NoTypeInformation -Encoding UTF8
# Build pairwise summary: Agent log line snippet -> EventId/Source/Level
$pairSummary = $corr | ForEach-Object {
    $snippet = ($_.AgentLine -replace '\s+',' ')
    if ($snippet.Length -gt 100) { $snippet = $snippet.Substring(0,100) }
    [PSCustomObject]@{
        AgentSnippet = $snippet
        EventId      = $_.EventId
        Source       = $_.Source
        Level        = $_.Level
    }
} | Group-Object AgentSnippet, EventId, Source, Level | ForEach-Object {
    $g = $_.Group
    [PSCustomObject]@{
        AgentSnippet = $g[0].AgentSnippet
        EventId      = $g[0].EventId
        Source       = $g[0].Source
        Level        = $g[0].Level
        Count        = $_.Count
    }
} | Sort-Object Count -Descending

$pairCsv = Join-Path $scanDir ("AgentLogReview_Correlated_Pairs_{0}.csv" -f $stamp)
$pairSummary | Export-Csv -Path $pairCsv -NoTypeInformation -Encoding UTF8

# Print concise pairwise summary (top 10)
Write-Host ""
Write-Host " Top agent->event matches" -ForegroundColor Cyan
Write-Host "------------------------"
$topPairs = $pairSummary | Select-Object -First 10
if (($topPairs | Measure-Object).Count -eq 0) {
    Write-Host " No pairwise rows." -ForegroundColor DarkGray
} else {
    foreach ($row in $topPairs) {
        Write-Host (" {0}x  '{1}'  ->  EventID {2} {3} [{4}]" -f $row.Count, $row.AgentSnippet, $row.EventId, $row.Source, $row.Level) -ForegroundColor White
    }
}
Write-Host (" Saved pairs CSV: {0}" -f $pairCsv) -ForegroundColor DarkGray


    # Print concise summary on screen (top 10)
    Write-Host ""
    Write-Host " Correlation summary (top by count)" -ForegroundColor Cyan
    Write-Host "-------------------------------------"
    $top = $summary | Select-Object -First 10
    if (($top | Measure-Object).Count -eq 0) {
        Write-Host " No summary rows." -ForegroundColor DarkGray
    } else {
        foreach ($row in $top) {
            Write-Host (" EventID {0} {1} [{2}]  matches={3}  window={4:yyyy-MM-dd HH:mm:ss} .. {5:yyyy-MM-dd HH:mm:ss}" `
                -f $row.EventId, $row.Source, $row.Level, $row.Count, $row.FirstSeen, $row.LastSeen) -ForegroundColor White
        }
    }
    Write-Host (" Saved: `n  - {0}`n  - {1}" -f $csvDetails, $csvSummary) -ForegroundColor DarkGray
} catch {
    Write-Host (" Export error: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}


        }
    } else {
        Write-Host " Skipping correlation (need agent errors and Windows events)." -ForegroundColor DarkGray
    }
} catch {
    Write-Host (" Correlation error: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}
        Write-Host " Review complete." -ForegroundColor Green
    } catch {
        Write-Host "ERROR during log review: $($_.Exception.Message)" -ForegroundColor Red
        Pause-Script
    }

    return @{ Quit = $false }
}

# -----------------------------------
# Main
# -----------------------------------
Clear-Host
Invoke-Header -Title "CyberCNS Agent Log Review" -Subtitle "Analyze errors, repetition and correlate with Windows"

do {
    $result = Run-ReviewOnce
    if ($result.Quit) { break }

    Write-Host ""
    $again = Read-Host "Run another log review? (Y to continue, Q to return to Launcher)"
    if ($again -match '^(q|Q)$') { break }

} while ($true)

# Return to Launcher in same window
try {
    if (Test-Path -LiteralPath $LauncherPath) {
        Launch-Tool -Target $LauncherPath -InProcess
    }
} catch {}
