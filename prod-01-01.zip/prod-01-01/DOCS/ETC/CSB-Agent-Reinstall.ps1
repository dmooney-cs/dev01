#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =====================================================================
# REPLACE THESE VALUES
# =====================================================================
$CompanyName      = 'changeme-optional'     # if blank/whitespace -> CSB Upload step is skipped
$TicketNumber     = 'changeme-optional'                   # if blank/whitespace -> CSB Upload step is skipped

$CompanyID        = 'changeme'
$TenantID         = 'changeme'

$UserSecretJ      = 'changeme'

$UninstallSecret  = 'changeme-optional'   # optional until 2026-04-01 (ONLY passed if non-empty)

$SkipToolboxDownload = $false   # $true = do not download toolbox, $false = normal behavior
# =====================================================================

# ---------------------------
# Step helpers
# ---------------------------
$script:StepCounter = 1

function Write-Step {
    param([int]$Num,[string]$Text)
    if ($Silent) { return }
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ("[Step {0}] {1}" -f $Num,$Text) -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
}

function Invoke-Step {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action
    )

    Write-Step -Num $script:StepCounter -Text $Name
    $script:StepCounter++

    if ($Silent) {
        & $Action *> $null
    } else {
        & $Action
    }
}

function Pause-ForUser {
    if ($Silent) { return }
    Write-Host ""
    Write-Host "Press any key to close..." -ForegroundColor Yellow
    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Start-Sleep 15 }
}

function Test-AgentDetected {
    $svc = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    if ($svc) { return $true }
    if (Test-Path -LiteralPath 'C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe') { return $true }
    return $false
}

function Resolve-InstallToolParamMap {
    param([Parameter(Mandatory)][string]$ScriptPath)

    $cmd  = Get-Command -Name $ScriptPath -ErrorAction Stop
    $keys = @($cmd.Parameters.Keys)

    function Pick([string[]]$cands) {
        foreach ($c in $cands) {
            if ($keys -contains $c) { return $c }
        }
        return $null
    }

    $map = [PSCustomObject]@{
        Company     = (Pick @('Company','CompanyId','CompanyID','c'))
        Tenant      = (Pick @('Tenant','TenantId','TenantID','e'))
        Secret      = (Pick @('Secret','UserSecret','UserSecretJ','j'))

        Reinstall   = (Pick @('Reinstall','ReInstall'))
        Silent      = (Pick @('Silent'))
        Quiet       = (Pick @('Quiet'))
        ExportOnly  = (Pick @('ExportOnly'))
        Uninst      = (Pick @('UninstallSecret','us','y'))
    }

    if (-not $map.Company -or -not $map.Tenant -or -not $map.Secret) {
        $supported = ($keys | Sort-Object) -join ', '
        throw "Agent-Install-Tool.ps1 missing required params for Company/Tenant/Secret. Supported: $supported"
    }

    return $map
}

function Invoke-AgentInstallTool {
    param(
        [Parameter(Mandatory)][string]$ToolPath,
        [Parameter(Mandatory)][string]$CompanyID,
        [Parameter(Mandatory)][string]$TenantID,
        [Parameter(Mandatory)][string]$UserSecret,
        [string]$UninstallSecret,
        [switch]$DoReinstall,
        [switch]$SilentMode
    )

    $map = Resolve-InstallToolParamMap -ScriptPath $ToolPath

    $splat = @{}
    $splat[$map.Company] = $CompanyID
    $splat[$map.Tenant]  = $TenantID
    $splat[$map.Secret]  = $UserSecret

    if ($DoReinstall -and $map.Reinstall) { $splat[$map.Reinstall] = $true }

    if (-not [string]::IsNullOrWhiteSpace($UninstallSecret) -and $map.Uninst) {
        $splat[$map.Uninst] = $UninstallSecret
    }

    if ($SilentMode) {
        if ($map.Silent)     { $splat[$map.Silent] = $true }
        elseif ($map.Quiet)  { $splat[$map.Quiet]  = $true }
        if ($map.ExportOnly) { $splat[$map.ExportOnly] = $true }

        & $ToolPath @splat *> $null
    } else {
        & $ToolPath @splat
    }
}

function Invoke-DevToolsDlWithRetry {
    param(
        [Parameter(Mandatory)][string]$Url,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $lastErr = $null
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        if (-not $Silent) {
            Write-Host ("DevTools DL: Attempt {0}/{1}" -f $i, $MaxAttempts) -ForegroundColor Cyan
        }

        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $content = Invoke-RestMethod -Method Get -Uri $Url -ErrorAction Stop
            if (-not $content -or [string]::IsNullOrWhiteSpace([string]$content)) {
                throw "Downloaded content was empty."
            }

            Invoke-Expression $content
            return $true
        }
        catch {
            $lastErr = $_.Exception.Message
            if ($i -lt $MaxAttempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    throw "DevTools DL failed after $MaxAttempts attempts. Last error: $lastErr"
}

# Elevate if needed
if (-not ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)) {

    $args = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    if ($Silent) { $args += " -Silent" }

    Start-Process powershell.exe -ArgumentList $args -Verb RunAs -WindowStyle Normal
    exit
}

# Header
Clear-Host
$host.UI.RawUI.WindowTitle = "ConnectSecure Toolbox - Operation Running"
if (-not $Silent) {
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " ConnectSecure Toolbox - Operation Running (Admin Required) "
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "After it completes check:" -ForegroundColor White
    Write-Host "  C:\CS-Toolbox-TEMP\ZIP" -ForegroundColor Green
    Write-Host ""
}

try {
    Invoke-Step -Name "Prepare PowerShell session" -Action {
        Set-ExecutionPolicy -Scope Process Bypass -Force
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    }

    if (-not $SkipToolboxDownload) {
        Invoke-Step -Name "Download/Stage toolbox (DevTools DL)" -Action {
            Invoke-DevToolsDlWithRetry -Url 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' -MaxAttempts 3 -DelaySeconds 2
        }
    } else {
        Invoke-Step -Name "Skip toolbox download (testing mode)" -Action {
            if (-not $Silent) {
                Write-Host "Skipping DevTools DL step because `$SkipToolboxDownload = `$true." -ForegroundColor Yellow
            }
        }
    }

    Invoke-Step -Name "Set working directory + unblock scripts" -Action {
        Set-Location "C:\CS-Toolbox-TEMP\prod-01-01"
        Get-ChildItem -Recurse -Filter *.ps1 -File | Unblock-File
    }

    Invoke-Step -Name "Run Agent-Log-Review" -Action {
        .\Agent-Log-Review.ps1 -DefaultLogs -ExportOnly
    }

    Invoke-Step -Name "Run Agent-msg-Correlator" -Action {
        .\Agent-msg-Correlator.ps1 -DefaultLogs -ExportOnly
    }

    Invoke-Step -Name "Run Agent-Job-Review" -Action {
        .\Agent-Job-Review.ps1 -AllLogs -Silent
    }

    Invoke-Step -Name "Run Agent-Install-Tool (auto reinstall if agent detected)" -Action {
        Add-Type -AssemblyName System.Windows.Forms

        $toolPath = Join-Path (Get-Location) 'Agent-Install-Tool.ps1'
        if (-not (Test-Path -LiteralPath $toolPath)) {
            throw "Agent-Install-Tool.ps1 not found at: $toolPath"
        }

        $doReinstall = Test-AgentDetected
        if (-not $Silent) {
            Write-Host ""
            if ($doReinstall) { Write-Host "Agent detected -> automatically triggering reinstall." -ForegroundColor Yellow }
            else              { Write-Host "Agent not detected -> running install." -ForegroundColor Yellow }

            Start-Job -ScriptBlock {
                Add-Type -AssemblyName System.Windows.Forms
                Start-Sleep -Seconds 5
                [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
            } | Out-Null
        }

        Invoke-AgentInstallTool `
            -ToolPath $toolPath `
            -CompanyID $CompanyID `
            -TenantID $TenantID `
            -UserSecret $UserSecretJ `
            -UninstallSecret $UninstallSecret `
            -DoReinstall:$doReinstall `
            -SilentMode:$Silent
    }

    Invoke-Step -Name "Agent-X Communications test" -Action {
        $toolboxRoot = 'C:\CS-Toolbox-TEMP\prod-01-01'
        $agentXPath  = Join-Path $toolboxRoot 'cs-agentx.ps1'

        if (-not (Test-Path -LiteralPath $toolboxRoot)) {
            throw "Toolbox folder not found at: $toolboxRoot"
        }
        if (-not (Test-Path -LiteralPath $agentXPath)) {
            $found = Get-ChildItem -Path 'C:\CS-Toolbox-TEMP' -Recurse -Filter 'cs-agentx.ps1' -File -ErrorAction SilentlyContinue |
                     Select-Object -First 1 -ExpandProperty FullName
            if ($found) {
                $agentXPath = $found
            } else {
                throw "cs-agentx.ps1 not found under C:\CS-Toolbox-TEMP"
            }
        }

        Set-Location (Split-Path -Path $agentXPath -Parent)
        & $agentXPath -silent
    }

    $canPackage = (-not [string]::IsNullOrWhiteSpace($CompanyName)) -and (-not [string]::IsNullOrWhiteSpace($TicketNumber))

    if ($canPackage) {
        Invoke-Step -Name "Create encrypted CSB bundle" -Action {
            .\zip-encrypt-htmltemplate.ps1 -s -c $CompanyName -t $TicketNumber
        }
    } else {
        if (-not $Silent) {
            Invoke-Step -Name "Skip CSB bundle (CompanyName or TicketNumber not provided)" -Action {
                Write-Host "Skipping zip-encrypt-htmltemplate.ps1 because CompanyName/TicketNumber is blank." -ForegroundColor Yellow
            }
        }
    }

    Invoke-Step -Name "Cleanup / Self-destruct" -Action {
        .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent -PlusCol
    }

    if (-not $Silent) {
        Write-Host ""
        Write-Host "[OK] All steps completed." -ForegroundColor Green
    }
}
catch {
    if (-not $Silent) {
        Write-Host ""
        Write-Host "[ERROR] The operation encountered an error:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    exit 1
}
finally {
    if (-not $Silent) {
        Write-Host ""
        Write-Host "============================================================"
        Write-Host " Operation finished."
        Write-Host " Check: C:\CS-Toolbox-TEMP\ZIP"
        Write-Host "============================================================"
    }
    Pause-ForUser
}
