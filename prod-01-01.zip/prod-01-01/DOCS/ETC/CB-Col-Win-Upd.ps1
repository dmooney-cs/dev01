﻿cd C:\CS-Toolbox-TEMP\prod-01-01
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
.\Windows-Update-Details.ps1 -Exportonly
.\OSQuery-WMIC-Patch.ps1 -Exportonly