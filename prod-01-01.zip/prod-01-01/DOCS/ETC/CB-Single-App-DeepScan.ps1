﻿Set-ExecutionPolicy -Scope Process Bypass -Force; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex
cd C:\CS-Toolbox-TEMP\prod-01-01
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
$App = "Chrome"
.\Registry-Search.ps1 -App $App -NoMenu
.\Osquery-Data-Collection.ps1 -App “$App” -ExportOnly
.\Windows-Modern-App-Discovery.ps1 -App "$App"
.\Browser-Extensions-Details.ps1 -App "$App" -Exportonly