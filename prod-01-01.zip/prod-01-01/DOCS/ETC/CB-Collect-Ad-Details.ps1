﻿Set-ExecutionPolicy -Scope Process Bypass -Force; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
cd C:\CS-Toolbox-TEMP\prod-01-01
.\Active-Directory-Tools.ps1 -all -quiet
.\zip-encrypt-htmltemplate.ps1 -s -c 4821 -t SR-REPACK
.\Toolbox-Cleanup-SelfDestruct.ps1 -Silent
