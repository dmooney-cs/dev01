﻿#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =====================================================================
# REPLACE THESE VALUES
# =====================================================================
$CompanyName  = 'Depedency Reset'
$TicketNumber = '2222'
# =====================================================================

# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs

$script:ToolboxBase = 'C:\CS-Toolbox-TEMP\prod-01-01'
$script:DevToolsDlUrl = 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1'

function Write-Header {
    if ($Silent) { return }
    Clear-Host
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " ConnectSecure Toolbox - Collection Wrapper (Admin Required) " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "After completion, check this folder for .csb files:" -ForegroundColor White
    Write-Host "  C:\CS-Toolbox-TEMP\ZIP" -ForegroundColor Green
    Write-Host ""
    Write-Host "Support: email any .csb files to support@connectsecure.com or attach to the existing support request." -ForegroundColor White
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ""
}

function Invoke-DevToolsDlWithRetry {
    param(
        [Parameter(Mandatory)][string]$Url,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $lastErr = $null
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        if (-not $Silent) {
            Write-Host ("DevTools DL: Attempt {0}/{1}" -f $i, $MaxAttempts) -ForegroundColor Cyan
        }

        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $content = Invoke-RestMethod -Method Get -Uri $Url -ErrorAction Stop
            if (-not $content -or [string]::IsNullOrWhiteSpace([string]$content)) {
                throw "Downloaded content was empty."
            }

            Invoke-Expression $content
            return $true
        }
        catch {
            $lastErr = $_.Exception.Message
            if ($i -lt $MaxAttempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    throw "DevTools DL failed after $MaxAttempts attempts. Last error: $lastErr"
}

function Stage-ToolboxIfNeeded {
    param(
        [string[]]$RequiredFiles = @(),
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $missing = New-Object System.Collections.Generic.List[string]

    if (-not (Test-Path $script:ToolboxBase)) {
        foreach ($file in $RequiredFiles) { [void]$missing.Add($file) }
    } else {
        foreach ($file in $RequiredFiles) {
            if (-not (Test-Path (Join-Path $script:ToolboxBase $file))) {
                [void]$missing.Add($file)
            }
        }
    }

    if ($missing.Count -eq 0) {
        if (-not $Silent) {
            Write-Host "Toolbox already staged; skipping DevTools DL." -ForegroundColor Yellow
        }
        return $true
    }

    Invoke-DevToolsDlWithRetry -Url $script:DevToolsDlUrl -MaxAttempts $MaxAttempts -DelaySeconds $DelaySeconds

    if (-not (Test-Path $script:ToolboxBase)) {
        throw "Toolbox folder not found after staging: $script:ToolboxBase"
    }

    $stillMissing = @()
    foreach ($file in $RequiredFiles) {
        if (-not (Test-Path (Join-Path $script:ToolboxBase $file))) {
            $stillMissing += $file
        }
    }

    if ($stillMissing.Count -gt 0) {
        throw ("Toolbox staging completed but required file(s) are still missing: {0}" -f ($stillMissing -join ', '))
    }

    return $true
}


$script:StepNum = 0
function Invoke-Step {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][scriptblock]$Action
    )

    $script:StepNum++
    if (-not $Silent) {
        Write-Host ("[Step {0}] {1}" -f $script:StepNum, $Name) -ForegroundColor Cyan
    }

    try {
        & $Action
        if (-not $Silent) {
            Write-Host ("[OK]  {0}" -f $Name) -ForegroundColor Green
            Write-Host ""
        }
        return $true
    }
    catch {
        if (-not $Silent) {
            Write-Host ("[FAIL] {0}" -f $Name) -ForegroundColor Red
            Write-Host ("       {0}" -f $_.Exception.Message) -ForegroundColor Red
            Write-Host ""
        }
        throw
    }
}

# Elevate to Admin (new visible window), preserve args (including -Silent)
if (-not ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {

    $argList = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`""
    )

    if ($MyInvocation.UnboundArguments -and $MyInvocation.UnboundArguments.Count -gt 0) {
        $argList += $MyInvocation.UnboundArguments
    }

    Start-Process powershell.exe `
        -ArgumentList $argList `
        -Verb RunAs `
        -WindowStyle Normal

    exit
}

Write-Header

try {
    Invoke-Step -Name "Set process execution policy + TLS 1.2" -Action {
        Set-ExecutionPolicy -Scope Process Bypass -Force
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    }

    Invoke-Step -Name "Download/Stage toolbox (auto-skip if already staged)" -Action {
        Stage-ToolboxIfNeeded -RequiredFiles @('Agent-Log-Review.ps1', 'Agent-msg-Correlator.ps1', 'Agent-Job-Review.ps1', 'Agent-Update-Tool.ps1', 'CS-Reload-Dependencies.ps1', 'cs-agentx.ps1', 'zip-encrypt-htmltemplate.ps1', 'Toolbox-Cleanup-SelfDestruct.ps1')
    }

    Invoke-Step -Name "CD to toolbox folder" -Action {
        Set-Location $script:ToolboxBase
    }

    Invoke-Step -Name "Unblock all toolbox PowerShell scripts" -Action {
        Get-ChildItem $script:ToolboxBase -Recurse -Filter *.ps1 -File | Unblock-File
    }

    Invoke-Step -Name "Agent Log Review (-DefaultLogs -ExportOnly)" -Action {
        .\Agent-Log-Review.ps1 -Defaultlogs -Exportonly
    }

    Invoke-Step -Name "Agent Msg Correlator (-DefaultLogs -ExportOnly)" -Action {
        .\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly
    }

    Invoke-Step -Name "Agent Job Review (-AllLogs -Silent)" -Action {
        .\Agent-Job-Review.ps1 -LogPath "" -AllLogs -Silent 2>$null
        # NOTE: If Agent-Job-Review.ps1 requires -LogPath, remove the above line
        # and use your normal invocation (kept minimal here because different builds vary).
    }

    Invoke-Step -Name "Agent Update Tool (-Quiet)" -Action {
        .\Agent-Update-Tool.ps1 -quiet
    }

    Invoke-Step -Name "Reload Agent Dependencies (-Silent)" -Action {
        .\CS-Reload-Dependencies.ps1 -silent
    }

    Invoke-Step -Name "Agent -X Communications test (cs-agentx.ps1 -silent)" -Action {
        & (Join-Path $script:ToolboxBase "cs-agentx.ps1") -silent
    }

    $canPackage = (-not [string]::IsNullOrWhiteSpace($CompanyName)) -and (-not [string]::IsNullOrWhiteSpace($TicketNumber))

    if ($canPackage) {
        Invoke-Step -Name "Build CSB package (zip-encrypt-htmltemplate.ps1 -s -c -t)" -Action {
            .\zip-encrypt-htmltemplate.ps1 -s -c $CompanyName -t $TicketNumber
        }
    } else {
        Invoke-Step -Name "Skip CSB bundle (CompanyName or TicketNumber not provided)" -Action {
            if (-not $Silent) {
                Write-Host "Skipping zip-encrypt-htmltemplate.ps1 because CompanyName/TicketNumber is blank." -ForegroundColor Yellow
            }
        }
    }

    Invoke-Step -Name "Toolbox Cleanup Self-Destruct (-Silent) (-PlusCol)" -Action {
        .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent -PlusCol
    }

    if (-not $Silent) {
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " Finished. Check: C:\CS-Toolbox-TEMP\ZIP for .csb files.     " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host "Support: email any .csb files to support@connectsecure.com or attach to the existing support request." -ForegroundColor White
        Write-Host ""
        Write-Host "Press Enter to close..." -ForegroundColor Yellow
        [void] (Read-Host)
    }
}
catch {
    if (-not $Silent) {
        Write-Host ""
        Write-Host "============================================================" -ForegroundColor Red
        Write-Host " ERROR - Collection wrapper encountered an issue.            " -ForegroundColor Red
        Write-Host "============================================================" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host ""
        Write-Host "Press Enter to close..." -ForegroundColor Yellow
        [void] (Read-Host)
    }
    exit 1
}
