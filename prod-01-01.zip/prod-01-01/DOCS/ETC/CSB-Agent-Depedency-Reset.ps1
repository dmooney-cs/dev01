﻿#requires -version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs

# Elevate to Admin (new visible window)
if (-not ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {

    Start-Process powershell.exe `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" `
        -Verb RunAs `
        -WindowStyle Normal

    exit
}

# --- Always-visible status message ---
Clear-Host
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ConnectSecure Toolbox - Operation Running (Admin Required)  " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script is running. This window will auto-close in under 5 minutes." -ForegroundColor Yellow
Write-Host ""
Write-Host "After it completes, check this folder for .csb files:" -ForegroundColor White
Write-Host "  C:\CS-Toolbox-TEMP\ZIP" -ForegroundColor Green
Write-Host ""
Write-Host "For support-related issues, send any .csb files to support@connectsecure.com or attach them to the existing support request." -ForegroundColor White
Write-Host ""
Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host ""

try {
    Set-ExecutionPolicy -Scope Process Bypass -Force
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex

    Set-Location "C:\CS-Toolbox-TEMP\prod-01-01"

    Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File

    .\Agent-Log-Review.ps1 -Defaultlogs -Exportonly
    .\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly
    .\Agent-Job-Review.ps1 -AllLogs -Silent
	.\Agent-Update-Tool.ps1 -quiet
    .\CS-Reload-Dependencies.ps1 -silent
    .\zip-encrypt-htmltemplate.ps1 -s -c CompanyName -t TicketNumber
    .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent
}
catch {
    Write-Host ""
    Write-Host "[ERROR] The operation encountered an error:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}
finally {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " Operation finished (or exited).                             " -ForegroundColor Cyan
    Write-Host " Check: C:\CS-Toolbox-TEMP\ZIP for .csb files.               " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "For support-related issues, send any .csb files to support@connectsecure.com or attach them to the existing support request." -ForegroundColor White
    Write-Host "Closing in 30 seconds..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
}
```
