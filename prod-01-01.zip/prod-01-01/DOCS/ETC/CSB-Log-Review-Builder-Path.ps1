﻿#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# NOTE- Script could take between 5sec–several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs

# -----------------------------
# Config (edit here only)
# -----------------------------
$script:CollectedInfoRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:EulaStatePath       = Join-Path $script:CollectedInfoRoot 'EulaAcceptedAt.txt'  # ISO 8601 "o"
$script:EulaSourceUrl       = 'https://connectsecure.com/eula'
$script:EulaPromptWindowMin = 15

$script:ToolboxBase   = 'C:\CS-Toolbox-TEMP\prod-01-01'
$script:DevToolsDlUrl = 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1'

# IMPORTANT: This is the LogPath passed to the 3 scripts below (folder path)
$script:LogPath = 'C:\Users\dmoon\Downloads\185001'

# Internal flag (do not document) so we can re-launch elevated/hidden without looping
$IsInner = ($env:CS_TOOLBOX_SILENT_INNER -eq '1')

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Invoke-DevToolsDlWithRetry {
    param(
        [Parameter(Mandatory)][string]$Url,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $lastErr = $null
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        if (-not $Silent) {
            Write-Host ("DevTools DL: Attempt {0}/{1}" -f $i, $MaxAttempts) -ForegroundColor Cyan
        }

        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $content = Invoke-RestMethod -Method Get -Uri $Url -ErrorAction Stop
            if (-not $content -or [string]::IsNullOrWhiteSpace([string]$content)) {
                throw "Downloaded content was empty."
            }

            Invoke-Expression $content
            return $true
        }
        catch {
            $lastErr = $_.Exception.Message
            if ($i -lt $MaxAttempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    throw "DevTools DL failed after $MaxAttempts attempts. Last error: $lastErr"
}

function Stage-ToolboxIfNeeded {
    param(
        [string[]]$RequiredFiles = @(),
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $missing = New-Object System.Collections.Generic.List[string]

    if (-not (Test-Path $script:ToolboxBase)) {
        foreach ($file in $RequiredFiles) { [void]$missing.Add($file) }
    } else {
        foreach ($file in $RequiredFiles) {
            if (-not (Test-Path (Join-Path $script:ToolboxBase $file))) {
                [void]$missing.Add($file)
            }
        }
    }

    if ($missing.Count -eq 0) {
        if (-not $Silent) {
            Write-Host "Toolbox already staged; skipping DevTools DL." -ForegroundColor Yellow
        }
        return $true
    }

    Invoke-DevToolsDlWithRetry -Url $script:DevToolsDlUrl -MaxAttempts $MaxAttempts -DelaySeconds $DelaySeconds

    if (-not (Test-Path $script:ToolboxBase)) {
        throw "Toolbox folder not found after staging: $script:ToolboxBase"
    }

    $stillMissing = @()
    foreach ($file in $RequiredFiles) {
        if (-not (Test-Path (Join-Path $script:ToolboxBase $file))) {
            $stillMissing += $file
        }
    }

    if ($stillMissing.Count -gt 0) {
        throw ("Toolbox staging completed but required file(s) are still missing: {0}" -f ($stillMissing -join ', '))
    }

    return $true
}


function Pause-AnyKey {
    param([string]$Message = 'Press any key to continue...')
    Write-Host ""
    Write-Host $Message -ForegroundColor Yellow
    try {
        $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    } catch {
        [void](Read-Host 'Press Enter to continue...')
    }
}

function Start-ElevatedInstance {
    param([switch]$Hidden)

    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    if ($Silent) { $args += '-Silent' }

    Start-Process powershell.exe `
        -Verb RunAs `
        -WindowStyle ($(if ($Hidden) { 'Hidden' } else { 'Normal' })) `
        -ArgumentList ($args -join ' ') | Out-Null
}

function Show-StatusHeader {
    Clear-Host
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " ConnectSecure Toolbox - Agent Logs Collection (Admin Req)   " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Exports/logs will be saved under:" -ForegroundColor White
    Write-Host ("  {0}" -f $script:LogPath) -ForegroundColor Green
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ""
}

function Show-Footer-AndPause {
    param([switch]$HadErrors)

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    if ($HadErrors) {
        Write-Host " Operation finished WITH ERRORS (see above).                 " -ForegroundColor Red
    } else {
        Write-Host " Operation finished.                                         " -ForegroundColor Cyan
    }
    Write-Host " Check logs/output at:" -ForegroundColor Cyan
    Write-Host ("  {0}" -f $script:LogPath) -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Cyan
    Pause-AnyKey -Message "Press any key to close..."
}

# -----------------------------
# EULA helpers (immediate Y option + M paging)
# -----------------------------
function Save-EulaAcceptedAt([datetime]$dt) {
    try {
        Ensure-Folder -Path $script:CollectedInfoRoot
        Set-Content -LiteralPath $script:EulaStatePath -Value $dt.ToString('o') -Encoding UTF8 -Force
    } catch { }
}

function Load-EulaAcceptedAt {
    try {
        if (-not (Test-Path $script:EulaStatePath)) { return $null }
        $raw = (Get-Content -LiteralPath $script:EulaStatePath -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1).Trim()
        if (-not $raw) { return $null }
        return [datetime]::Parse($raw)
    } catch { return $null }
}

function Test-EulaStillValid {
    $dt = Load-EulaAcceptedAt
    if (-not $dt) { return $false }
    $ageMin = (New-TimeSpan -Start $dt -End (Get-Date)).TotalMinutes
    return ($ageMin -lt [double]$script:EulaPromptWindowMin)
}

function Get-EulaFromWeb {
    $result = [ordered]@{
        FetchOk        = $false
        SourceUrl      = $script:EulaSourceUrl
        FetchError     = $null
        SourcedAtLocal = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        LastUpdated    = $null
        Paras          = New-Object System.Collections.Generic.List[string]
    }

    try {
        $resp = Invoke-WebRequest -Uri $script:EulaSourceUrl -UseBasicParsing -TimeoutSec 12 -ErrorAction Stop
        $html = $resp.Content
        if (-not $html) { throw "Empty response content." }

        $mUpd = [regex]::Match($html, '(?i)last\s+updated[^<]{0,80}')
        if ($mUpd.Success) { $result.LastUpdated = ($mUpd.Value -replace '\s+', ' ').Trim() }

        $pMatches = [regex]::Matches($html, '(?is)<p\b[^>]*>(.*?)</p>')
        foreach ($m in $pMatches) {
            $inner = $m.Groups[1].Value
            $inner = ($inner -replace '(?is)<br\s*/?>', "`n")
            $inner = ($inner -replace '(?is)<[^>]+>', ' ')
            $inner = [System.Net.WebUtility]::HtmlDecode($inner)
            $inner = ($inner -replace '\s+\n', "`n")
            $inner = ($inner -replace '\n\s+', "`n")
            $inner = ($inner -replace '[ \t]{2,}', ' ')
            $inner = $inner.Trim()
            if ($inner) { [void]$result.Paras.Add($inner) }
        }

        if ($result.Paras.Count -lt 1) { throw "Unable to parse EULA text (no paragraphs found)." }

        $result.FetchOk = $true
        return [pscustomobject]$result
    } catch {
        $result.FetchOk    = $false
        $result.FetchError = $_.Exception.Message
        return [pscustomobject]$result
    }
}

function Invoke-SelfDestructAndExit {
    try {
        $sd = Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1'
        if (Test-Path $sd) { & $sd -Silent }
    } catch { }
    exit 1
}

function Ensure-EulaGate {
    if (Test-EulaStillValid) { return $true }

    $eula = Get-EulaFromWeb

    if (-not $eula.FetchOk) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " End User License Agreement (EULA) - Required                " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host (" Sourced Date: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $script:EulaSourceUrl) -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "[WARN]  This device could not retrieve the EULA from the website." -ForegroundColor Yellow
        Write-Host ("       Please view the EULA here: {0}" -f $script:EulaSourceUrl) -ForegroundColor Yellow
        Write-Host ""

        while ($true) {
            Write-Host "Y) Agree and proceed" -ForegroundColor White
            Write-Host "N) Decline (cleanup/self-destruct) and exit" -ForegroundColor White
            Write-Host ""
            $resp = (Read-Host "Selection (Y/N)").Trim().ToUpperInvariant()
            switch ($resp) {
                'Y' { Save-EulaAcceptedAt (Get-Date); return $true }
                'N' { Invoke-SelfDestructAndExit; return $false }
                default { Write-Host "[WARN] Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
            }
        }
    }

    $idx = 0
    while ($true) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " End User License Agreement (EULA) - Required                " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host (" Sourced Date: {0}" -f $eula.SourcedAtLocal) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $eula.SourceUrl) -ForegroundColor DarkGray
        if ($eula.LastUpdated) { Write-Host (" {0}" -f $eula.LastUpdated) -ForegroundColor DarkGray }
        Write-Host ""
        Write-Host (" Paragraph {0} of {1}" -f ($idx + 1), $eula.Paras.Count) -ForegroundColor DarkGray
        Write-Host ""
        Write-Host $eula.Paras[$idx] -ForegroundColor Yellow
        Write-Host ""

        Write-Host "Y) Agree and proceed" -ForegroundColor White
        Write-Host "N) Decline (cleanup/self-destruct) and exit" -ForegroundColor White
        if ($eula.Paras.Count -gt 1 -and $idx -lt ($eula.Paras.Count - 1)) {
            Write-Host "M) Show next paragraph" -ForegroundColor White
        }
        Write-Host ""

        $resp = (Read-Host "Selection (Y/N/M)").Trim().ToUpperInvariant()
        switch ($resp) {
            'Y' { Save-EulaAcceptedAt (Get-Date); return $true }
            'N' { Invoke-SelfDestructAndExit; return $false }
            'M' { if ($idx -lt ($eula.Paras.Count - 1)) { $idx++ } }
            default { Write-Host "[WARN] Invalid selection. Please enter Y, N, or M." -ForegroundColor Yellow }
        }
    }
}

# -----------------------------
# Step runner (continue on failure)
# FIX: Do NOT treat non-zero exit code as wrapper failure for these scripts.
# Some of your scripts legitimately return exit 1 while still producing output.
# -----------------------------
function Invoke-Step {
    param(
        [Parameter(Mandatory)][int]$Number,
        [Parameter(Mandatory)][int]$Total,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action
    )

    $result = [ordered]@{
        Step    = "$Number/$Total"
        Name    = $Name
        Status  = 'OK'
        Message = ''
    }

    try {
        Write-Host ("[Step {0}/{1}] {2}" -f $Number, $Total, $Name) -ForegroundColor Cyan

        & $Action

        # IMPORTANT: do NOT fail the step based on $LASTEXITCODE
        Write-Host ("[ OK ] {0}" -f $Name) -ForegroundColor Green
        Write-Host ""
    }
    catch {
        $result.Status  = 'FAIL'
        $result.Message = $_.Exception.Message
        Write-Host ("[FAIL] {0}" -f $Name) -ForegroundColor Red
        Write-Host ("       {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Host ""
    }

    return [pscustomobject]$result
}

# -----------------------------
# Elevate to Admin
# -----------------------------
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    if ($Silent) {
        $env:CS_TOOLBOX_SILENT_INNER = '1'
        Start-ElevatedInstance -Hidden
        exit
    } else {
        Start-ElevatedInstance
        exit
    }
}

# If already admin AND -Silent requested, spawn hidden worker and exit visible instance
if ($Silent -and -not $IsInner) {
    $env:CS_TOOLBOX_SILENT_INNER = '1'
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', "`"$PSCommandPath`"",
        '-Silent'
    ) | Out-Null
    exit
}

# -----------------------------
# Run
# -----------------------------
Ensure-Folder -Path $script:CollectedInfoRoot
$results = New-Object System.Collections.Generic.List[object]
$hadAnyErrors = $false

try {
    Set-ExecutionPolicy -Scope Process Bypass -Force
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    if (-not $Silent) {
        Ensure-EulaGate | Out-Null
        Show-StatusHeader
    }

    # Stage toolbox like other wrappers
    Invoke-Step 1 4 "Download/Stage Toolbox (auto-skip if already staged)" {
        Stage-ToolboxIfNeeded -RequiredFiles @('Agent-Log-Review.ps1', 'Agent-msg-Correlator.ps1', 'Agent-Job-Review.ps1')
    } | Out-Null

    # Ensure LogPath exists
    Invoke-Step 2 4 "Ensure LogPath folder exists" {
        Ensure-Folder -Path $script:LogPath
    } | Out-Null

    # Unblock scripts
    Invoke-Step 3 4 "Unblock toolbox scripts" {
        if (-not (Test-Path $script:ToolboxBase)) { throw "Toolbox folder not found: $script:ToolboxBase" }
        Set-Location $script:ToolboxBase
        Get-ChildItem $script:ToolboxBase -Recurse -Filter *.ps1 -File | Unblock-File
    } | Out-Null

    # Run the OG commands (same parameters/flow)
    $r4 = Invoke-Step 4 4 "Run Agent Logs tools (Log Review / Msg Correlator / Job Review)" {
        Set-Location $script:ToolboxBase

        .\Agent-Log-Review.ps1 -LogPath $script:LogPath
        .\Agent-msg-Correlator.ps1 -LogPath $script:LogPath -Exportonly
        .\Agent-Job-Review.ps1 -LogPath $script:LogPath -AllLogs -Silent
    }
    $results.Add($r4) | Out-Null
    if ($r4.Status -ne 'OK') { $hadAnyErrors = $true }
}
catch {
    $hadAnyErrors = $true
    if (-not $Silent) {
        Write-Host ""
        Write-Host "[ERROR] Wrapper-level error:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}
finally {
    if ($Silent) {
        exit
    } else {
        Show-Footer-AndPause -HadErrors:([bool]$hadAnyErrors)
        exit
    }
}
```
