﻿Set-ExecutionPolicy -Scope Process Bypass -Force; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
cd C:\CS-Toolbox-TEMP\prod-01-01
.\Osquery-Data-Collection.ps1 -All
.\Windows-Modern-App-Discovery.ps1 -ExportOnly
.\Browser-Extensions-Details.ps1 -Exportonly
.\zip-encrypt-htmltemplate.ps1 -s -c 4821 -t SR-REPACK
.\Toolbox-Cleanup-SelfDestruct.ps1 -Silent