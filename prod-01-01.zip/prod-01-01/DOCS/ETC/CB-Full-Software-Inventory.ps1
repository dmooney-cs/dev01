﻿cd C:\CS-Toolbox-TEMP\prod-01-01
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Osquery-Data-Collection.ps1 -All
.\Windows-Modern-App-Discovery.ps1 -ExportOnly
.\Browser-Extensions-Details.ps1 -Exportonly