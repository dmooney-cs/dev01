﻿# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs
cd C:\CS-Toolbox-TEMP\prod-01-01
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Agent-Log-Review.ps1 -Defaultlogs -Exportonly
.\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly
.\Agent-Job-Review.ps1 -AllLogs -Silent