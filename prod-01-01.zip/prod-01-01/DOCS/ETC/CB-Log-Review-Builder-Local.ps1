﻿# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs
Set-ExecutionPolicy -Scope Process Bypass -Force; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex
cd C:\CS-Toolbox-TEMP\prod-01-01
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
.\Agent-Log-Review.ps1 -Defaultlogs -Exportonly
.\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly
.\Agent-Job-Review.ps1 -AllLogs -Silent
.\zip-encrypt-htmltemplate.ps1 -s -c 4821 -t SR-REPACK
.\Toolbox-Cleanup-SelfDestruct.ps1 -Silent