﻿<# =====================================================================
  Agent-Log-Review.ps1
  ConnectSecure Technicians Toolbox â€” Agent Log Review
  - Collects CyberCNS agent logs and exports results
  - Uses v9 zip/encrypt flow when available; safe fallback otherwise
===================================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# --- Import Common Functions ---
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try { . $commonPath } catch { Write-Host ('[WARN] Could not import common functions: {0}' -f $_.Exception.Message) -ForegroundColor Yellow }
}

# Safe defaults for globals if not present
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

# Shim helpers if missing
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = 'ConnectSecure Technicians Toolbox')
        Write-Host ''
        Write-Host (' ' + $Title) -ForegroundColor Cyan
        Write-Host ('=' * 64)
    }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ('[INFO] {0}' -f $Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ('[OK]   {0}' -f $Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ('[WARN] {0}' -f $Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Write-Err  -ErrorAction SilentlyContinue)) { function Write-Err  { param([string]$Msg) Write-Host ('[ERROR] {0}' -f $Msg) -ForegroundColor Red } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) {
    function Ensure-Folder {
        param([Parameter(Mandatory)][string]$Path)
        if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null }
    }
}

function Start-AgentLogReview {
    $ToolName = 'Agent Log Review'
    try {
        Show-Header -Title 'ConnectSecure Technicians Toolbox'
        Write-Host (' Tool: {0}' -f $ToolName) -ForegroundColor Cyan
        Write-Host ''

        $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
        Ensure-Folder $outDir

        $timestamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
        $collectDir = Join-Path $outDir ('Collect_{0}' -f $timestamp)
        Ensure-Folder $collectDir

        Write-Info 'Searching known log locations...'
        $logRoots = @(
            (Join-Path $env:ProgramData         'CyberCNSAgent\logs'),
            (Join-Path $env:ProgramFiles        'CyberCNS\Agent\logs'),
            (Join-Path ${env:ProgramFiles(x86)} 'CyberCNS\Agent\logs')
        )

        $foundAny = $false
        foreach ($root in $logRoots) {
            if ([string]::IsNullOrWhiteSpace($root)) { continue }
            if (Test-Path -LiteralPath $root) {
                Write-Info ('Found: {0}' -f $root)
                $dest = Join-Path $collectDir (Split-Path $root -Leaf)
                Ensure-Folder $dest
                try {
                    Copy-Item -Path (Join-Path $root '*') -Destination $dest -Recurse -Force -ErrorAction Stop
                    $foundAny = $true
                } catch {
                    Write-Warn ('Failed to copy from {0}: {1}' -f $root, $_.Exception.Message)
                }
            }
        }

        if (-not $foundAny) {
            Write-Warn 'No logs found in default locations.'
            New-Item -ItemType File -Path (Join-Path $collectDir 'NO_LOGS_FOUND.txt') -Force | Out-Null
        } else {
            Write-OK ('Collected logs to: {0}' -f $collectDir)
        }

        # Build merged view
        $merged = Join-Path $collectDir ('Merged_Agent_Logs_{0}.txt' -f $timestamp)
        try {
            Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in '.log', '.txt', '.json' } |
                ForEach-Object {
                    '===== FILE: ' + $_.FullName + ' ====='
                    Get-Content -LiteralPath $_.FullName -ErrorAction SilentlyContinue
                    ''
                } | Out-File -FilePath $merged -Encoding UTF8
            Write-OK ('Merged view: {0}' -f $merged)
        } catch {
            Write-Warn ('Could not build merged view: {0}' -f $_.Exception.Message)
        }

        # Bundle & encrypt if available
        if (Get-Command Invoke-ZipAndEncrypt -ErrorAction SilentlyContinue) {
            Write-Info 'Bundling with v9 zip/encrypt flow...'
            Invoke-ZipAndEncrypt -SourcePath $collectDir -ToolName 'Agent-Log-Review'
        } else {
            $zipPath = Join-Path $outDir ('AgentLogs_{0}.zip' -f $timestamp)
            Write-Warn 'Invoke-ZipAndEncrypt not found â€” using Compress-Archive fallback.'
            if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue }
            Compress-Archive -Path (Join-Path $collectDir '*') -DestinationPath $zipPath -Force
            Write-OK ('Wrote ZIP: {0}' -f $zipPath)
        }
    }
    catch {
        Write-Err ('Failed to run {0}: {1}' -f $ToolName, $_.Exception.Message)
    }
    finally {
        Write-Host ''
        Read-Host 'Press Enter to return...'
    }
}

Start-AgentLogReview
