<# =====================================================================
 Agent-Update-Tool.ps1 (API v4 — parse version from URL before download)
 - Supports -ForceUpdate (skips prompt only)
 - Supports -Quiet (no console output at all)
 - Uses working installed-version detection:
     1) EXE '--version' output
     2) EXE file version
 - Skips download entirely if already on current version
 - Cleans up temp files and restores TLS on every path
 - Exit codes:
     10 = success / up-to-date
     15 = API/URL resolve failure
     20 = download failure
     30 = stop services failed
     40 = replace binary failed
     50 = start services failed or post-check older than server
===================================================================== #>

[CmdletBinding()]
param(
    [switch]$ForceUpdate,
    [switch]$Quiet
)

# ---------------- Constants ----------------
$AgentApiUrl   = 'https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows'
$AgentExePath  = 'C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe'
$ServiceNames  = @('CyberCNSAgent','CyberCNSAgentMonitor')

# ---------------- Service startup helpers ----------------
function Disable-AgentServices {
    foreach ($n in $ServiceNames) {
        try { Set-Service -Name $n -StartupType Disabled -ErrorAction SilentlyContinue } catch { }
    }
}
function Enable-AgentServices {
    foreach ($n in $ServiceNames) {
        try { Set-Service -Name $n -StartupType Automatic -ErrorAction SilentlyContinue } catch { }
    }
}

# ---------------- Logging (respect -Quiet) ----------------
function Write-Ok   { param([string]$m) if (-not $Quiet) { Write-Host "[OK]    $m"   -ForegroundColor Green } }
function Write-Info { param([string]$m) if (-not $Quiet) { Write-Host "[INFO]  $m"  -ForegroundColor Cyan } }
function Write-Step { param([string]$m) if (-not $Quiet) { Write-Host "[STEP]  $m"  -ForegroundColor Magenta } }
function Write-Warn { param([string]$m) if (-not $Quiet) { Write-Warning $m } }
function Write-Err  { param([string]$m) if (-not $Quiet) { Write-Error   $m } }

# ---------------- TLS helpers ----------------
function Ensure-Tls12 {
    try {
        $script:_oldTls = [System.Net.ServicePointManager]::SecurityProtocol
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        Write-Info "TLS set to TLS1.2"
    } catch {
        Write-Warn "Could not enforce TLS1.2: $($_.Exception.Message)"
    }
}
function Restore-Tls {
    try {
        if ($script:_oldTls) {
            [System.Net.ServicePointManager]::SecurityProtocol = $script:_oldTls
        }
    } catch { }
}

# ---------------- Version utilities (matches your working logic) ----------------
function Get-FileVersionString { 
    param([string]$Path) 
    if (Test-Path -LiteralPath $Path) {
        try { return (Get-Item -LiteralPath $Path).VersionInfo.FileVersion } catch { return $null }
    }
    return $null
}
function Get-ExeVersionViaSwitchV {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue
        # attempt a hidden run, allow for tools that print to STDOUT
        $p = Start-Process -FilePath $Path -ArgumentList '--version' -WindowStyle Hidden -NoNewWindow -PassThru -ErrorAction SilentlyContinue
        if ($p) { [void]$p.WaitForExit(3000) }
        $out = & $Path '--version' 2>$null
        if ($out) {
            $m = [regex]::Match(($out | Out-String), '(\d+\.\d+\.\d+)')
            if ($m.Success){ return $m.Groups[1].Value }
        }
    } catch { }
    return $null
}
function Get-InstalledAgentVersion {
    if (Test-Path -LiteralPath $AgentExePath) {
        $ver = Get-ExeVersionViaSwitchV -Path $AgentExePath
        if ($ver) { return $ver }
        $fv = Get-FileVersionString -Path $AgentExePath
        if ($fv) { return $fv }
    }
    return $null
}
function Normalize-Version3 {
    param([string]$v)
    if (-not $v) { return $null }
    $v = $v.Trim()
    # Accept 3 or 4-part versions; fold to MAJOR.MINOR.PATCH
    $m = [regex]::Match($v, '^\s*(\d+)\.(\d+)\.(\d+)(?:\.\d+)?\s*$')
    if ($m.Success) { return '{0}.{1}.{2}' -f $m.Groups[1].Value,$m.Groups[2].Value,$m.Groups[3].Value }
    $m = [regex]::Match($v, '\b(\d+)\.(\d+)\.(\d+)\b')
    if ($m.Success) { return '{0}.{1}.{2}' -f $m.Groups[1].Value,$m.Groups[2].Value,$m.Groups[3].Value }
    return $null
}

# ---------------- API / URL helpers ----------------
function Resolve-LatestDownloadUrl {
    Ensure-Tls12
    try {
        Write-Step "Resolving latest download link from API..."
        $resp = Invoke-WebRequest -Uri $AgentApiUrl -UseBasicParsing -ErrorAction Stop
        $raw  = $resp.Content.Trim()
        # Try JSON with common keys first
        try { 
            $obj = $raw | ConvertFrom-Json
            foreach($k in 'url','URL','agentlink','AgentLink','link'){ if ($obj.$k){ return [string]$obj.$k } }
        } catch {}
        # Fallback: raw string URL
        if ($raw -match '^https?://') { return $raw }
        Write-Err "API returned unrecognized format."
        return $null
    } catch {
        Write-Err ("Failed to resolve latest link: {0}" -f $_.Exception.Message)
        return $null
    }
    finally { Restore-Tls }
}
function Parse-VersionFromUrl {
    param([string]$Url)
    if ($Url -match "/agents/([0-9]+\.[0-9]+\.[0-9]+)") { return $Matches[1] }
    return $null
}
function Download-File {
    param([string]$Url,[string]$OutFile)
    Ensure-Tls12
    try { 
        Write-Step "Downloading agent installer..."
        Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
        try { Unblock-File -LiteralPath $OutFile -ErrorAction SilentlyContinue } catch { }
        Write-Ok ("Downloaded to {0}" -f $OutFile)
        return $true 
    }
    catch { 
        Write-Err ("Download failed: {0}" -f $_.Exception.Message)
        return $false 
    }
    finally { Restore-Tls }
}

# ---------------- Service control ----------------
function Stop-AgentServices {
    Disable-AgentServices
    foreach ($n in $ServiceNames) {
        try { Stop-Service -Name $n -Force -ErrorAction SilentlyContinue } catch { }
    }
    # Wait up to 30s to stop
    $deadline = (Get-Date).AddSeconds(30)
    foreach ($n in $ServiceNames) {
        try {
            while ((Get-Service -Name $n -ErrorAction SilentlyContinue).Status -ne 'Stopped' -and (Get-Date) -lt $deadline) {
                Start-Sleep -Milliseconds 500
            }
        } catch { }
    }
    # Kill lingering processes
    foreach ($procName in @('cybercnsagent','CyberCNSAgentMonitor')) {
        try { Get-Process -Name $procName -ErrorAction SilentlyContinue | ForEach-Object { $_ | Stop-Process -Force -ErrorAction SilentlyContinue } } catch { }
    }
    # Verify stopped
    foreach ($n in $ServiceNames) {
        try { 
            $s = Get-Service -Name $n -ErrorAction SilentlyContinue 
            if ($s -and $s.Status -ne 'Stopped') { Write-Err ("Service did not stop: {0}" -f $n); return $false }
        } catch { }
    }
    return $true
}
function Start-AgentServices {
    Enable-AgentServices
    foreach ($n in $ServiceNames) { try { Start-Service -Name $n -ErrorAction SilentlyContinue } catch { } }
    # Wait up to 30s to start
    $deadline = (Get-Date).AddSeconds(30)
    foreach ($n in $ServiceNames) {
        try {
            while ((Get-Service -Name $n -ErrorAction SilentlyContinue).Status -ne 'Running' -and (Get-Date) -lt $deadline) {
                Start-Sleep -Milliseconds 500
            }
        } catch { }
    }
    foreach ($n in $ServiceNames) {
        try { 
            $s = Get-Service -Name $n -ErrorAction SilentlyContinue 
            if ($s -and $s.Status -ne 'Running') { Write-Err ("Service did not start: {0}" -f $n); return $false }
        } catch { }
    }
    return $true
}

# ---------------- Prompt (skips when -Quiet or -ForceUpdate) ----------------
function Should-Continue {
    param([string]$Message)
    if ($Quiet -or $ForceUpdate) { return $true }
    $resp = Read-Host $Message
    return ($resp -match '^(y|yes)$')
}

# ---------------- UI Header ----------------
if (-not $Quiet) {
    Write-Host ""
    Write-Host "  ConnectSecure Agent Update Tool" -ForegroundColor Yellow
    Write-Host "==========================================================" -ForegroundColor Yellow
}

# ---------------- Main ----------------
# Show installed (using your working detection routine)
$installedVersionStr = Get-InstalledAgentVersion
if (-not $Quiet) {
    if ($installedVersionStr) { Write-Info ("Installed version: {0}" -f $installedVersionStr) }
    else { Write-Info "Installed version: (not found)" }
}

# Resolve link and parse server version BEFORE any download
$dlUrl = Resolve-LatestDownloadUrl
if (-not $dlUrl) { exit 15 }
$serverVersionStr = Parse-VersionFromUrl -Url $dlUrl
if (-not $Quiet -and $serverVersionStr) { Write-Info ("Server version (from URL): {0}" -f $serverVersionStr) }

# --- Decide if update is needed (never reinstall same version) ---
$needUpdate = $true
try {
    $installedNorm = Normalize-Version3 $installedVersionStr
    $serverNorm    = Normalize-Version3 $serverVersionStr
    if ($installedNorm -and $serverNorm) {
        if ([version]$installedNorm -ge [version]$serverNorm) { $needUpdate = $false }
    } elseif (-not $installedNorm) {
        $needUpdate = $true
    }
} catch { $needUpdate = $true }

if (-not $needUpdate) {
    if (-not $Quiet) { Write-Ok "Already up to date. No update needed." }
    exit 10
}

# Confirm (unless -ForceUpdate or -Quiet)
$pv = if ($serverVersionStr) { $serverVersionStr } else { "(unknown)" }
if (-not (Should-Continue ("New version available ({0}). Install now? (Y/N)" -f $pv))) {
    if (-not $Quiet) { Write-Warn "User declined update. No changes made." }
    exit 10
} elseif (-not $Quiet -and $ForceUpdate) {
    Write-Info "ForceUpdate requested; proceeding without prompt."
}

# Build safe filename from URL path (ignore query string)
try { $uri = [uri]$dlUrl; $safeName = [IO.Path]::GetFileName($uri.AbsolutePath) } catch { $safeName = "cybercnsagent.exe" }
if (-not $safeName) { $safeName = "cybercnsagent.exe" }

# Download to temp
$tempDir = Join-Path $env:TEMP ("CS-AgentUpdate-" + (Get-Date -Format yyyyMMdd_HHmmss))
New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
$tempExe = Join-Path $tempDir $safeName

if (-not (Download-File -Url $dlUrl -OutFile $tempExe)) {
    try { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    exit 20
}

# Stop services
Write-Step "Stopping services..."
if (-not (Stop-AgentServices)) {
    try { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    exit 30
}

# Ensure target directory exists
$exeDir = Split-Path -Parent $AgentExePath
if (-not (Test-Path -LiteralPath $exeDir)) { try { New-Item -Path $exeDir -ItemType Directory -Force | Out-Null } catch { } }

# Backup and robust replace
Write-Step "Installing new binary..."
$replaced = $false
try {
    if (Test-Path -LiteralPath $AgentExePath) {
        $bak = "$AgentExePath.bak_{0}" -f (Get-Date -Format yyyyMMdd_HHmmss)
        Copy-Item -LiteralPath $AgentExePath -Destination $bak -Force -ErrorAction SilentlyContinue
    }
    # Try a few times in case of transient locks
    for ($i=1; $i -le 5 -and -not $replaced; $i++) {
        try {
            $old = $AgentExePath + ".old"
            if (Test-Path -LiteralPath $AgentExePath) {
                try { Rename-Item -LiteralPath $AgentExePath -NewName (Split-Path -Leaf $old) -Force -ErrorAction SilentlyContinue } catch { }
            }
            Copy-Item -LiteralPath $tempExe -Destination $AgentExePath -Force
            $replaced = $true
        } catch {
            if ($i -eq 5) { throw }
            Start-Sleep -Milliseconds 700
        }
    }
} catch {
    Write-Err ("Failed to replace EXE: {0}" -f $_.Exception.Message)
    try { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    exit 40
}
# Clean up any .old leftover if present
try { $old = $AgentExePath + ".old"; if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Force -ErrorAction SilentlyContinue } } catch {}

# Start services
Write-Step "Starting services..."
if (-not (Start-AgentServices)) {
    try { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    exit 50
}

Start-Sleep -Seconds 2

# Verify
$newVersionStr = Get-InstalledAgentVersion
if (-not $Quiet) {
    if ($newVersionStr) { Write-Ok ("Installed version is now: {0}" -f $newVersionStr) }
    else { Write-Warn "Could not read installed version after update." }
}

# Cleanup
try { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }

# Exit code (verify we reached server version or better)
try {
    $serverNorm = Normalize-Version3 $serverVersionStr
    $newNorm    = Normalize-Version3 $newVersionStr
    if ($serverNorm -and $newNorm) {
        if ([version]$newNorm -ge [version]$serverNorm) { exit 10 } else { exit 50 }
    } else {
        if (Test-Path -LiteralPath $AgentExePath) { exit 10 } else { exit 50 }
    }
} catch { exit 10 }
