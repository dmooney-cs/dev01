<# =====================================================================
 Agent-Update-Tool.ps1 (API v4 — parse version from URL before download)
 - Supports -ForceUpdate (skips prompt only)
 - Supports -Quiet (no console output or progress bar)
 - 3x retry logic for API and download
 - Exit codes:
     10 = success / up-to-date
     15 = API/URL resolve failure
     20 = download failure
     30 = stop services failed
     40 = replace binary failed
     50 = start services failed or post-check older than server
===================================================================== #>

[CmdletBinding()]
param(
    [switch]$ForceUpdate,
    [switch]$Quiet
)

# ---------------- Constants ----------------
$AgentApiUrl   = 'https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows'
$AgentExePath  = 'C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe'
$ServiceNames  = @('CyberCNSAgent','CyberCNSAgentMonitor')

# ---------------- Logging helpers ----------------
function Write-Ok   { param([string]$m) if (-not $Quiet) { Write-Host "[OK]    $m"   -ForegroundColor Green } }
function Write-Info { param([string]$m) if (-not $Quiet) { Write-Host "[INFO]  $m"  -ForegroundColor Cyan } }
function Write-Step { param([string]$m) if (-not $Quiet) { Write-Host "[STEP]  $m"  -ForegroundColor Magenta } }
function Write-Warn { param([string]$m) if (-not $Quiet) { Write-Warning $m } }
function Write-Err  { param([string]$m) if (-not $Quiet) { Write-Error   $m } }

# ---------------- TLS helpers ----------------
function Ensure-Tls12 {
    try {
        $script:_oldTls = [System.Net.ServicePointManager]::SecurityProtocol
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        if (-not $Quiet) { Write-Info "TLS set to TLS1.2" }
    } catch {
        Write-Warn "Could not enforce TLS1.2: $($_.Exception.Message)"
    }
}
function Restore-Tls {
    try {
        if ($script:_oldTls) { [System.Net.ServicePointManager]::SecurityProtocol = $script:_oldTls }
    } catch { }
}

# ---------------- Retry helpers (3 attempts, suppress progress) ----------------
function Invoke-WebRequestContentWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "latest agent link"
    )
    Ensure-Tls12
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
            if (-not $Quiet) { Write-Host ("Requesting {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) -ForegroundColor Cyan }
            try {
                $resp = Invoke-WebRequest -Uri $Uri -UseBasicParsing -ErrorAction Stop
                if ($resp -and $resp.Content) {
                    if (-not $Quiet) { Write-Host "✅ Request successful." -ForegroundColor Green }
                    return ($resp.Content)
                } else {
                    throw "Response had no content."
                }
            } catch {
                if ($attempt -eq $MaxAttempts) {
                    if (-not $Quiet) { Write-Host ("❌ Failed to fetch {0}: {1}" -f $What, $_.Exception.Message) -ForegroundColor Red }
                    return $null
                } else {
                    if (-not $Quiet) {
                        Write-Host ("⚠️ Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Yellow
                        Write-Host ("   Retrying in {0}s..." -f $DelaySeconds) -ForegroundColor Yellow
                    }
                    Start-Sleep -Seconds $DelaySeconds
                }
            }
        }
        return $null
    } finally {
        $ProgressPreference = $oldProgress
        Restore-Tls
    }
}

function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "agent installer"
    )
    Ensure-Tls12
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        $outDir = Split-Path -Parent $OutFile
        if (-not (Test-Path -LiteralPath $outDir)) {
            New-Item -ItemType Directory -Path $outDir -Force | Out-Null
        }
        if (Test-Path -LiteralPath $OutFile) {
            Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
        }

        for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
            if (-not $Quiet) { Write-Host ("Downloading {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) -ForegroundColor Cyan }
            try {
                Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
                if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                    try { Unblock-File -LiteralPath $OutFile -ErrorAction SilentlyContinue } catch { }
                    if (-not $Quiet) { Write-Host ("✅ Downloaded to {0}" -f $OutFile) -ForegroundColor Green }
                    return $true
                } else { throw "Downloaded file is missing or empty." }
            } catch {
                if (Test-Path -LiteralPath $OutFile) {
                    Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
                }
                if ($attempt -eq $MaxAttempts) {
                    if (-not $Quiet) { Write-Host ("❌ Download failed: {0}" -f $_.Exception.Message) -ForegroundColor Red }
                    return $false
                } else {
                    if (-not $Quiet) {
                        Write-Host ("⚠️ Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Yellow
                        Write-Host ("   Retrying in {0}s..." -f $DelaySeconds) -ForegroundColor Yellow
                    }
                    Start-Sleep -Seconds $DelaySeconds
                }
            }
        }
        return $false
    } finally {
        $ProgressPreference = $oldProgress
        Restore-Tls
    }
}

# ---------------- Version utilities ----------------
function Get-FileVersionString { 
    param([string]$Path) 
    if (Test-Path -LiteralPath $Path) {
        try { return (Get-Item -LiteralPath $Path).VersionInfo.FileVersion } catch { return $null }
    }
    return $null
}
function Get-ExeVersionViaSwitchV {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue
        $out = & $Path '--version' 2>$null
        if ($out) {
            $m = [regex]::Match(($out | Out-String), '(\d+\.\d+\.\d+)')
            if ($m.Success){ return $m.Groups[1].Value }
        }
    } catch { }
    return $null
}
function Get-InstalledAgentVersion {
    if (Test-Path -LiteralPath $AgentExePath) {
        $ver = Get-ExeVersionViaSwitchV -Path $AgentExePath
        if ($ver) { return $ver }
        $fv = Get-FileVersionString -Path $AgentExePath
        if ($fv) { return $fv }
    }
    return $null
}
function Normalize-Version3 {
    param([string]$v)
    if (-not $v) { return $null }
    $v = $v.Trim()
    $m = [regex]::Match($v, '(\d+)\.(\d+)\.(\d+)')
    if ($m.Success) { return '{0}.{1}.{2}' -f $m.Groups[1].Value,$m.Groups[2].Value,$m.Groups[3].Value }
    return $null
}

# ---------------- API / URL helpers (with retry) ----------------
function Resolve-LatestDownloadUrl {
    Write-Step "Resolving latest download link from API..."
    $raw = Invoke-WebRequestContentWithRetry -Uri $AgentApiUrl -MaxAttempts 3 -DelaySeconds 2 -What "agent link"
    if (-not $raw) { Write-Err "API request failed after retries."; return $null }

    $raw = $raw.Trim()
    try { 
        $obj = $raw | ConvertFrom-Json
        foreach($k in 'url','URL','agentlink','AgentLink','link'){ if ($obj.$k){ return [string]$obj.$k } }
    } catch {}
    if ($raw -match '^https?://') { return $raw }
    Write-Err "API returned unrecognized format."
    return $null
}
function Parse-VersionFromUrl { param([string]$Url) if ($Url -match "/agents/(\d+\.\d+\.\d+)") { return $Matches[1] } return $null }
function Download-File { param([string]$Url,[string]$OutFile) Write-Step "Preparing to download agent installer..."; return (Invoke-DownloadWithRetry -Uri $Url -OutFile $OutFile -MaxAttempts 3 -DelaySeconds 2 -What "agent installer") }

# ---------------- Services ----------------
function Disable-AgentServices { foreach ($n in $ServiceNames) { try { Set-Service -Name $n -StartupType Disabled -ErrorAction SilentlyContinue } catch { } } }
function Enable-AgentServices  { foreach ($n in $ServiceNames) { try { Set-Service -Name $n -StartupType Automatic -ErrorAction SilentlyContinue } catch { } } }
function Stop-AgentServices {
    Disable-AgentServices
    foreach ($n in $ServiceNames) { try { Stop-Service -Name $n -Force -ErrorAction SilentlyContinue } catch { } }
    Start-Sleep -Seconds 2
    foreach ($proc in @('cybercnsagent','CyberCNSAgentMonitor')) { try { Get-Process -Name $proc -ErrorAction SilentlyContinue | Stop-Process -Force } catch { } }
    return $true
}
function Start-AgentServices {
    Enable-AgentServices
    foreach ($n in $ServiceNames) { try { Start-Service -Name $n -ErrorAction SilentlyContinue } catch { } }
    Start-Sleep -Seconds 2
    return $true
}

# ---------------- Prompt ----------------
function Should-Continue {
    param([string]$Message)
    if ($Quiet -or $ForceUpdate) { return $true }
    $resp = Read-Host $Message
    return ($resp -match '^(y|yes)$')
}

# ---------------- UI Header ----------------
if (-not $Quiet) {
    Write-Host ""
    Write-Host "  ConnectSecure Agent Update Tool" -ForegroundColor Yellow
    Write-Host "==========================================================" -ForegroundColor Yellow
}

# ---------------- Main ----------------
$installedVersionStr = Get-InstalledAgentVersion
if (-not $Quiet) {
    if ($installedVersionStr) { Write-Info ("Installed version: {0}" -f $installedVersionStr) }
    else { Write-Info "Installed version: (not found)" }
}

$dlUrl = Resolve-LatestDownloadUrl
if (-not $dlUrl) { exit 15 }
$serverVersionStr = Parse-VersionFromUrl -Url $dlUrl
if (-not $Quiet -and $serverVersionStr) { Write-Info ("Server version (from URL): {0}" -f $serverVersionStr) }

$needUpdate = $true
try {
    $installedNorm = Normalize-Version3 $installedVersionStr
    $serverNorm    = Normalize-Version3 $serverVersionStr
    if ($installedNorm -and $serverNorm -and [version]$installedNorm -ge [version]$serverNorm) { $needUpdate = $false }
} catch { }

if (-not $needUpdate) { if (-not $Quiet) { Write-Ok "Already up to date." }; exit 10 }

$pv = if ($serverVersionStr) { $serverVersionStr } else { "(unknown)" }
if (-not (Should-Continue ("New version available ({0}). Install now? (Y/N)" -f $pv))) {
    if (-not $Quiet) { Write-Warn "User declined update." }
    exit 10
}

try { $uri = [uri]$dlUrl; $safeName = [IO.Path]::GetFileName($uri.AbsolutePath) } catch { $safeName = "cybercnsagent.exe" }
if (-not $safeName) { $safeName = "cybercnsagent.exe" }

$tempDir = Join-Path $env:TEMP ("CS-AgentUpdate-" + (Get-Date -Format yyyyMMdd_HHmmss))
New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
$tempExe = Join-Path $tempDir $safeName

if (-not (Download-File -Url $dlUrl -OutFile $tempExe)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 20
}

Write-Step "Stopping services..."
if (-not (Stop-AgentServices)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 30
}

Write-Step "Installing new binary..."
$replaced = $false
try {
    if (Test-Path -LiteralPath $AgentExePath) {
        Copy-Item -LiteralPath $AgentExePath -Destination "$AgentExePath.bak" -Force -ErrorAction SilentlyContinue
    }
    Copy-Item -LiteralPath $tempExe -Destination $AgentExePath -Force
    $replaced = $true
} catch {
    Write-Err ("Failed to replace EXE: {0}" -f $_.Exception.Message)
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 40
}

Write-Step "Starting services..."
if (-not (Start-AgentServices)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 50
}

Start-Sleep -Seconds 2
$newVersionStr = Get-InstalledAgentVersion
if (-not $Quiet -and $newVersionStr) { Write-Ok ("Installed version is now: {0}" -f $newVersionStr) }

Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue

try {
    $serverNorm = Normalize-Version3 $serverVersionStr
    $newNorm    = Normalize-Version3 $newVersionStr
    if ($serverNorm -and $newNorm -and [version]$newNorm -ge [version]$serverNorm) { exit 10 } else { exit 50 }
} catch { exit 10 }
