<# =====================================================================
 Agent-Update-Tool.ps1 (API v4 - parse version from URL before download)
===================================================================== #>

[CmdletBinding()]
param(
    [switch]$ForceUpdate,
    [switch]$Quiet
)

# ---------------- Constants ----------------
$AgentApiUrl   = 'https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows'
$AgentExePath  = 'C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe'
$ServiceNames  = @('CyberCNSAgent','CyberCNSAgentMonitor')

# ---------------- Utils ----------------
function Write-Ok   { param([string]$m) if (-not $Quiet) { Write-Host "[OK]    $m" -ForegroundColor Green } }
function Write-Info { param([string]$m) if (-not $Quiet) { Write-Host "[INFO]  $m" -ForegroundColor Cyan } }
function Write-Step { param([string]$m) if (-not $Quiet) { Write-Host "[STEP]  $m" -ForegroundColor Magenta } }
function Write-Warn { param([string]$m) Write-Warning $m }
function Write-Err  { param([string]$m) Write-Error $m }

function Ensure-Tls12 {
    try {
        $global:__oldTls = [System.Net.ServicePointManager]::SecurityProtocol
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        Write-Info "TLS set to TLS1.2"
    } catch {
        Write-Warn "Could not enforce TLS1.2: $($_.Exception.Message)"
    }
}
function Restore-Tls { try { if ($global:__oldTls) { [System.Net.ServicePointManager]::SecurityProtocol = $global:__oldTls } } catch { } }

function Get-FileVersionString { param([string]$Path) if (Test-Path -LiteralPath $Path) { try { (Get-Item -LiteralPath $Path).VersionInfo.FileVersion } catch { $null } } else { $null } }
function Get-ExeVersionViaSwitchV {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try { Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue; $out = & $Path '-v' 2>$null; if ($out){ $m=[regex]::Match(($out|Out-String),'(\d+\.\d+\.\d+(?:\.\d+)?)'); if ($m.Success){ return $m.Groups[1].Value } } } catch { }
    return $null
}
function Get-InstalledAgentVersion {
    if (Test-Path -LiteralPath $AgentExePath) {
        $ver = Get-ExeVersionViaSwitchV -Path $AgentExePath
        if ($ver) { return $ver }
        $fv = Get-FileVersionString -Path $AgentExePath
        if ($fv) { return $fv }
    }
    return $null
}

function Resolve-LatestDownloadUrl {
    Ensure-Tls12
    try {
        Write-Step "Resolving latest download link from API..."
        $resp = Invoke-WebRequest -Uri $AgentApiUrl -UseBasicParsing -ErrorAction Stop
        $raw  = $resp.Content.Trim()
        try { $obj = $raw | ConvertFrom-Json; foreach($k in 'url','download_link','link'){ if ($obj.$k){ return [string]$obj.$k } } } catch {}
        if ($raw -match '^https?://') { return $raw }
        Write-Err "API returned unrecognized format."; return $null
    } catch { Write-Err ("Failed to resolve latest link: {0}" -f $_.Exception.Message); return $null }
    finally { Restore-Tls }
}

function Parse-VersionFromUrl {
    param([string]$Url)
    if ($Url -match "/agents/([0-9]+\.[0-9]+\.[0-9]+)") { return $Matches[1] }
    return $null
}

function Download-File {
    param([string]$Url,[string]$OutFile)
    Ensure-Tls12
    try { Write-Step "Downloading $Url"; Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -ErrorAction Stop; Write-Ok ("Downloaded to {0}" -f $OutFile); return $true }
    catch { Write-Err ("Download failed: {0}" -f $_.Exception.Message); return $false }
    finally { Restore-Tls }
}

function Stop-AgentServices {
    foreach ($n in $ServiceNames) {
        try { $svc = Get-Service -Name $n -ErrorAction SilentlyContinue; if ($svc){ if ($svc.Status -ne 'Stopped'){ Stop-Service -Name $n -Force -ErrorAction SilentlyContinue }; $svc.WaitForStatus('Stopped','00:00:25') | Out-Null } } catch { }
    }
    foreach ($n in $ServiceNames) { $s=Get-Service -Name $n -ErrorAction SilentlyContinue; if ($s -and $s.Status -ne 'Stopped'){ Write-Err ("Service did not stop: {0}" -f $n); return $false } }
    return $true
}
function Start-AgentServices {
    foreach ($n in $ServiceNames) { try { Start-Service -Name $n -ErrorAction SilentlyContinue } catch { } }
    foreach ($n in $ServiceNames) { try { $s=Get-Service -Name $n -ErrorAction SilentlyContinue; if ($s){ $s.WaitForStatus('Running','00:00:25') | Out-Null } } catch { }; $s2=Get-Service -Name $n -ErrorAction SilentlyContinue; if ($s2 -and $s2.Status -ne 'Running'){ Write-Err ("Service did not start: {0}" -f $n); return $false } }
    return $true
}
function Prompt-YesNo { param([string]$Message) $ans = Read-Host $Message; return ($ans -match '^(y|yes)$') }

# ---------------- Main ----------------
Write-Host "  ConnectSecure Agent Update Tool" -ForegroundColor White
Write-Host "==========================================================" -ForegroundColor DarkGray

$installedVersionStr = Get-InstalledAgentVersion
if ($installedVersionStr) { Write-Info ("Installed version: {0}" -f $installedVersionStr) } else { Write-Info "Installed version: (not installed)" }

$dlUrl = Resolve-LatestDownloadUrl
if (-not $dlUrl) { if (-not $Quiet) { Read-Host "Press ENTER to exit" | Out-Null }; exit 20 }

$serverVersionStr = Parse-VersionFromUrl -Url $dlUrl
if ($serverVersionStr) { Write-Info ("Server version (from URL): {0}" -f $serverVersionStr) } else { Write-Warn "Could not parse version from URL; will treat as newer." }

# Compare before download
$updateNeeded = $true
try {
    if ($installedVersionStr -and $serverVersionStr) { $updateNeeded = ([version]$serverVersionStr -gt [version]$installedVersionStr) }
    elseif (-not $installedVersionStr) { $updateNeeded = $true }
} catch { $updateNeeded = $true }

if (-not $updateNeeded) {
    Write-Ok "Already up to date. No update needed."
    exit 0
}

if (-not $ForceUpdate) {
    $pv = if ($serverVersionStr) { $serverVersionStr } else { "(unknown)" }
    if (-not (Prompt-YesNo -Message ("New version available ({0}). Install now? (Y/N)" -f $pv))) {
        Write-Warn "User declined update. No changes made."
        exit 0
    }
} else { Write-Info "ForceUpdate requested; proceeding without prompt." }

# Build safe filename (ignore query string)
try { $uri = [uri]$dlUrl; $safeName = [IO.Path]::GetFileName($uri.AbsolutePath) } catch { $safeName = "cybercnsagent.exe" }
if (-not $safeName -or $safeName -eq '') { $safeName = "cybercnsagent.exe" }

# Download to temp
$tempDir = Join-Path $env:TEMP ("CS-AgentUpdate-" + (Get-Date -Format yyyyMMdd_HHmmss))
New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
$tempExe = Join-Path $tempDir $safeName

if (-not (Download-File -Url $dlUrl -OutFile $tempExe)) { if (-not $Quiet) { Read-Host "Press ENTER to exit" | Out-Null }; try{Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue}catch{}; exit 20 }

# Stop services
if (-not (Stop-AgentServices)) { try{Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue}catch{}; exit 30 }

# Ensure target directory exists
$exeDir = Split-Path -Parent $AgentExePath
if (-not (Test-Path -LiteralPath $exeDir)) { try { New-Item -Path $exeDir -ItemType Directory -Force | Out-Null } catch { } }

# Backup and force copy
try {
    if (Test-Path -LiteralPath $AgentExePath) {
        $bak = "$AgentExePath.bak_{0}" -f (Get-Date -Format yyyyMMdd_HHmmss)
        Copy-Item -LiteralPath $AgentExePath -Destination $bak -Force -ErrorAction SilentlyContinue
    }
    Copy-Item -LiteralPath $tempExe -Destination $AgentExePath -Force
} catch {
    Write-Err ("Failed to replace EXE: {0}" -f $_.Exception.Message)
    try{Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue}catch{}
    exit 40
}

# Start services
if (-not (Start-AgentServices)) { try{Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue}catch{}; exit 50 }

Start-Sleep -Seconds 2

# Verify
$newVersionStr = Get-InstalledAgentVersion
if ($newVersionStr) { Write-Ok ("Installed version is now: {0}" -f $newVersionStr) } else { Write-Warn "Could not read installed version after update." }

try{Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue}catch{}

# Exit code
try {
    if ($serverVersionStr -and $newVersionStr) {
        if ([version]$newVersionStr -ge [version]$serverVersionStr) { exit 10 } else { exit 50 }
    } else {
        if (Test-Path -LiteralPath $AgentExePath) { exit 10 } else { exit 50 }
    }
} catch { exit 10 }
