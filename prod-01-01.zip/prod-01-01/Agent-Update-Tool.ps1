# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info\Agent-Update"

$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Warning "Failed to load Functions-Common.ps1 : $_"
}
# ---------- Fallbacks if common functions are unavailable ----------
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        [CmdletBinding()]
        param([string[]]$AdditionalNotes)
        try {
            $exportRoot = if ($script:ExportRoot) { $script:ExportRoot } elseif ($global:ExportRoot) { $global:ExportRoot } else { "C:\CS-Toolbox-TEMP\Collected-Info\Agent-Update" }
            $latest = $null
            if (Test-Path $exportRoot) {
                $latest = Get-ChildItem -Path $exportRoot -Filter "Agent-Update_*.json" -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            }
            Write-Host ""
            Write-Host "====== Agent Update Summary ======" -ForegroundColor Cyan
            if ($latest) { Write-Host (" Summary JSON : {0}" -f $latest.FullName) } else { Write-Host " Summary JSON : (not found)" }
            if ($AdditionalNotes) { $AdditionalNotes | ForEach-Object { Write-Host (" {0}" -f $_) } }
            Write-Host "==================================" -ForegroundColor Cyan
            Write-Host ""
        } catch {
            Write-Warning "Fallback Write-SessionSummary failed: $_"
        }
    }
}

if (-not (Get-Command Pause-Script -ErrorAction SilentlyContinue)) {
    function Pause-Script {
        param([string]$Message = "Press ENTER to continue...")
        Write-Host $Message -ForegroundColor Yellow
        try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Read-Host | Out-Null }
    }
}

if (-not (Get-Command Return-ToAgentMenu -ErrorAction SilentlyContinue)) {
    function Return-ToAgentMenu {
        [CmdletBinding()] param()
        $launcher = "C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1"
        if (Test-Path $launcher) {
            try { & $launcher } catch { Write-Warning "Unable to launch Agent Menu Tool at $launcher : $_" }
        } else {
            Write-Warning "Agent Menu Tool not found at $launcher"
        }
    }
}

if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        [CmdletBinding()]
        param([Parameter(Mandatory=$true)][string]$Path)
        try {
            if ([string]::IsNullOrWhiteSpace($Path)) { throw "Export path is empty." }
            if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
        } catch {
            Write-Warning "Failed to ensure export folder [$Path] : $_"
        }
    }
}
# -------------------------------------------------------------------


if (-not (Get-Command Pause-Script -ErrorAction SilentlyContinue)) {
    function Pause-Script {
        param([string]$Message = "Press ENTER to continue...")
        Write-Host $Message -ForegroundColor Yellow
        try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Read-Host | Out-Null }
    }
}

if (-not (Get-Command Return-ToAgentMenu -ErrorAction SilentlyContinue)) {
    function Return-ToAgentMenu {
        [CmdletBinding()] param()
        $launcher = "C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1"
        if (Test-Path $launcher) {
            try { & $launcher } catch { Write-Warning "Unable to launch Agent Menu Tool at $launcher : $_" }
        } else {
            Write-Warning "Agent Menu Tool not found at $launcher"
        }
    }
}

if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        [CmdletBinding()]
        param([Parameter(Mandatory=$true)][string]$Path)
        try {
            if ([string]::IsNullOrWhiteSpace($Path)) { throw "Export path is empty." }
            if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
        } catch {
            Write-Warning "Failed to ensure export folder [$Path] : $_"
        }
    }
}
# -------------------------------------------------------------------

$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info\Agent-Update"
Ensure-ExportFolder -Path $ExportRoot

# =============================================================================
# Agent-Update-Tool.ps1  (PS 5.1-safe)
# - Shows Installed ConnectSecure Version
# - Downloads latest agent -> C:\CS-Toolbox-TEMP\ , shows ConnectSecure Server Version
# - If server version is higher, prompt to install (prompt displays both)
# - Exports JSON summary to C:\CS-Toolbox-TEMP\Collected-Info\Agent-Update\
# - Returns to Agent Menu Tool in the same window (hardcoded path)
# =============================================================================

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = 'Continue'

# Paths & API
$AgentExePath  = "C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe"
$AgentFolder   = "C:\Program Files (x86)\CyberCNSAgent"
$ApiUrl        = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
$AgentMenuPath = "C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1"  # hardcoded return path

# Export & download locations
$ExportRoot  = "C:\CS-Toolbox-TEMP\Collected-Info\Agent-Update"
$null = New-Item -ItemType Directory -Path $ExportRoot -Force -ErrorAction SilentlyContinue | Out-Null
$CustomTemp = "C:\CS-Toolbox-TEMP"
$null = New-Item -ItemType Directory -Path $CustomTemp -Force -ErrorAction SilentlyContinue | Out-Null

$TimeStamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$SummaryJson = Join-Path $ExportRoot "Agent-Update_$TimeStamp.json"

# ---------------- Helpers (ASCII only) ----------------
function Write-Step([string]$msg) { Write-Host "[STEP] $msg"  -ForegroundColor Cyan }
function Write-Ok  ([string]$msg) { Write-Host "[OK]  $msg"   -ForegroundColor Green }
function Write-Warn([string]$msg) { Write-Host "[WARN] $msg"  -ForegroundColor Yellow }
function Write-Err ([string]$msg) { Write-Host "[ERR] $msg"   -ForegroundColor Red }

function Parse-AgentVersion {
    param([string]$Text)
    if (-not $Text) { return $null }
    $m = [regex]::Match($Text, '(\d+\.\d+\.\d+(?:\.\d+)?)')
    if ($m.Success) { return $m.Groups[1].Value }
    $tokens = $Text -split '\s+'
    $cand = $null
    foreach ($t in $tokens) { if ($t -match '^\d+(\.\d+){2,3}$') { $cand = $t } }
    return $cand
}

function Get-AgentVersionFromExe {
    param([string]$ExePath)
    if (-not (Test-Path $ExePath)) { return $null }
    try { Parse-AgentVersion (& $ExePath -v 2>&1) } catch { $null }
}

function Get-LatestAgentLink {
    try {
        Write-Step "Fetching latest agent download link..."
        $link = Invoke-RestMethod -Method GET -Uri $ApiUrl -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($link)) { throw "Empty link from API" }
        Write-Ok "Latest agent link acquired."
        return [string]$link
    } catch {
        Write-Err "Failed to fetch agent link: $($_.Exception.Message)"
        return $null
    }
}

function Download-File {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][string]$OutFile
    )
    try {
        Write-Step "Downloading agent installer..."
        Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
        Unblock-File -Path $OutFile -ErrorAction SilentlyContinue
        Write-Ok "Downloaded: $OutFile"
        return $true
    } catch {
        Write-Err "Download failed: $($_.Exception.Message)"
        return $false
    }
}

function Get-FileSHA256 { param([string]$Path) try { (Get-FileHash -Path $Path -Algorithm SHA256).Hash } catch { $null } }

function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Stop-AgentServices {
    Write-Step "Stopping CyberCNS services..."
    $names = @('cybercnsagent','CyberCNSAgent','cybercnsagentmonitor','ConnectSecureAgentMonitor')
    foreach ($n in $names) {
        try {
            if (Get-Service -Name $n -ErrorAction SilentlyContinue) {
                Stop-Service -Name $n -Force -ErrorAction SilentlyContinue
                Start-Sleep -Milliseconds 800
            }
        } catch { }
    }
    $states = @()
    foreach ($n in $names) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc) { $states += [pscustomobject]@{ Name=$n; Status=$svc.Status } }
    }
    if ($states.Count -gt 0) { $states | Format-Table -AutoSize | Out-String | Write-Host }
}

function Start-AgentServices {
    Write-Step "Starting CyberCNS services..."
    $names = @('cybercnsagent','CyberCNSAgent','cybercnsagentmonitor','ConnectSecureAgentMonitor')
    foreach ($n in $names) {
        try {
            if (Get-Service -Name $n -ErrorAction SilentlyContinue) {
                Start-Service -Name $n -ErrorAction SilentlyContinue
                Start-Sleep -Milliseconds 800
            }
        } catch { }
    }
    $states = @()
    foreach ($n in $names) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc) { $states += [pscustomobject]@{ Name=$n; Status=$svc.Status } }
    }
    if ($states.Count -gt 0) { $states | Format-Table -AutoSize | Out-String | Write-Host }
}

function Replace-AgentExe {
    param([string]$NewExe)
    if (-not (Test-Path $NewExe)) { Write-Err "Replacement EXE not found: $NewExe"; return $false }
    if (-not (Test-IsAdmin))      { Write-Err "Administrator rights required for Program Files (x86)."; [void](Read-Host "Press ENTER to continue..."); return $false }
    try {
        if (-not (Test-Path $AgentFolder)) { New-Item -ItemType Directory -Path $AgentFolder -Force | Out-Null }
        if (Test-Path $AgentExePath) {
            $backup = "$AgentExePath.bak_$TimeStamp"
            Write-Step "Backing up current EXE to: $backup"
            Copy-Item -LiteralPath $AgentExePath -Destination $backup -Force
        }
        Write-Step "Replacing agent executable..."
        Copy-Item -LiteralPath $NewExe -Destination $AgentExePath -Force
        Unblock-File -Path $AgentExePath -ErrorAction SilentlyContinue
        Write-Ok "Agent executable replaced."
        return $true
    } catch {
        Write-Err "Failed to replace agent EXE: $($_.Exception.Message)"
        return $false
    }
}

# Direct return-to-menu (bypass Launch-Tool)
function Return-ToAgentMenu {
    $path = "C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1"
    if (Test-Path -LiteralPath $path) {
        try { Set-Location -Path (Split-Path -Parent $path) -ErrorAction SilentlyContinue } catch { }
        & $path
    } else {
        Write-Warn "Agent Menu Tool not found at: $path"
    }
}

# ---------------- UI (Subtitle-safe) ----------------
$subtitle = "Installed vs Server Version (prompt on newer build)"
$sh = Get-Command Show-Header -ErrorAction SilentlyContinue
if ($sh -and $sh.Parameters.ContainsKey('Subtitle')) {
    Show-Header -Title "CyberCNS Agent Update Tool" -Subtitle $subtitle
} else {
    Show-Header -Title "CyberCNS Agent Update Tool"
    Write-Host $subtitle -ForegroundColor Gray
    Write-Host ""
}

# 1) Installed version
$installedVersion = Get-AgentVersionFromExe -ExePath $AgentExePath
$installedVersionDisplay = if ([string]::IsNullOrWhiteSpace($installedVersion)) { "(not detected)" } else { $installedVersion }
Write-Host ("Installed ConnectSecure Version  : {0}" -f $installedVersionDisplay) -ForegroundColor White

# 2) Download to custom folder and read server version
$latestLink = Get-LatestAgentLink
if (-not $latestLink) {
    Pause-Script "Press ENTER to Return to Agent Menu Tool"
    Return-ToAgentMenu
    return
}

$tempExe = Join-Path $CustomTemp ("cybercnsagent_latest_{0}.exe" -f $TimeStamp)
if (-not (Download-File -Url $latestLink -OutFile $tempExe)) {
    Pause-Script "Press ENTER to Return to Agent Menu Tool"
    Return-ToAgentMenu
    return
}

$downloadHash  = Get-FileSHA256 -Path $tempExe
$serverVersion = Get-AgentVersionFromExe -ExePath $tempExe
$serverVersionDisplay = if ([string]::IsNullOrWhiteSpace($serverVersion)) { "(unreadable)" } else { $serverVersion }
Write-Host ("ConnectSecure Server Version     : {0}" -f $serverVersionDisplay) -ForegroundColor White
Write-Host ""

# 3) Prompt only if server > installed
$shouldPrompt = $true
if ($installedVersion -and $serverVersion) {
    try {
        if ([version]$installedVersion -ge [version]$serverVersion) {
            Write-Ok "Already up to date. No update needed."
            $shouldPrompt = $false
        }
    } catch {
        Write-Warn "Version compare failed; will prompt to proceed."
    }
} elseif (-not $serverVersion) {
    Write-Warn "Server version could not be parsed; will prompt before replacing."
}

$updated = $false
$newInstalledVersion = $installedVersion

if ($shouldPrompt) {
    Write-Host "Installed ConnectSecure Version : $installedVersionDisplay" -ForegroundColor Gray
    Write-Host "ConnectSecure Server Version   : $serverVersionDisplay"    -ForegroundColor Gray
    $ans = Read-Host "Install the newer server version? (Y/N)"
    if ($ans -in @('y','Y')) {
        Stop-AgentServices
        if (Replace-AgentExe -NewExe $tempExe) {
            Start-AgentServices
            Start-Sleep -Seconds 2
            $newInstalledVersion = Get-AgentVersionFromExe -ExePath $AgentExePath
            if ($newInstalledVersion) {
                Write-Ok "Post-update Installed ConnectSecure Version: $newInstalledVersion"
                $updated = $true
            } else {
                Write-Warn "Could not read installed version after replacement."
            }
        } else {
            Write-Err "Update failed during EXE replacement."
        }
    } else {
        Write-Warn "User declined update. No changes made."
    }
}

# 4) Export summary
$summary = [ordered]@{
    Timestamp           = (Get-Date).ToString("s")
    Hostname            = $env:COMPUTERNAME
    InstalledVersionOld = $installedVersion
    ServerVersion       = $serverVersion
    InstalledVersionNew = $newInstalledVersion
    DownloadUrl         = $latestLink
    DownloadPath        = $tempExe
    DownloadSHA256      = $downloadHash
    AgentExePath        = $AgentExePath
    Updated             = $updated
}
try {
    $summary | ConvertTo-Json -Depth 5 | Set-Content -Path $SummaryJson -Encoding UTF8
    Write-Ok "Summary written: $SummaryJson"
} catch {
    Write-Warn "Failed to write summary: $($_.Exception.Message)"
}

# 5) Cleanup downloaded installer if updated
try {
    if ($updated -and (Test-Path $tempExe)) {
        Remove-Item -LiteralPath $tempExe -Force -ErrorAction SilentlyContinue
    }
} catch { }

Write-SessionSummary -AdditionalNotes @(
    "Installed(old): $installedVersionDisplay",
    "Server: $serverVersionDisplay",
    "Installed(new): $newInstalledVersion",
    "Updated: $updated",
    "SHA256: $downloadHash"
)

# 6) Return to Agent Menu Tool (same window, hardcoded path)
Pause-Script "Press ENTER to Return to Agent Menu Tool"
Return-ToAgentMenu
return

# Fallback: Ensure-ExportFolder if common isn't loaded
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory=$false)][string]$Path = "C:\CS-Toolbox-TEMP\Collected-Info"
        )
        try {
            if (-not (Test-Path $Path)) {
                New-Item -Path $Path -ItemType Directory -Force | Out-Null
            }
        } catch {
            Write-Warning "Failed to create export folder $Path : $_"
        }
    }
}