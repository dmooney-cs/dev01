<# ====================================================
  Agent-Log-Review.ps1  (v6b - HTML export, PS 5.1 compatible, no ternary)
  - Collects logs
  - Per-file analysis (counts + recurring patterns)
  - Builds a single HTML report (index.html) with collapsible sections and wrapped text
  - Opens the HTML in the default browser
====================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables (no param block to avoid placement issues) ----
$WrapAtChars            = 120    # visual wrap width (HTML also wraps)
$ContextBefore          = 3      # lines before an error line
$ContextAfter           = 3      # lines after an error line
$MaxMatchesPerPattern   = 10     # max contexts kept per unique pattern (per file)
$LargeFileContextMB     = 25     # above this size, still analyze counts but limit contexts to first 3 matches

# -------- Common bootstrap (safe / back-compat) --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try { . $commonPath } catch { Write-Verbose "Functions-Common load failed: $($_.Exception.Message)" }
}
if (-not $global:CS_TempRoot -or [string]::IsNullOrWhiteSpace($global:CS_TempRoot)) {
    $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP'
}

# ---- Minimal helpers if missing ----
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = 'ConnectSecure Technicians Toolbox')
        Write-Host ''
        Write-Host (' ' + $Title) -ForegroundColor Cyan
        Write-Host ('=' * 58)
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        $hostName = $env:COMPUTERNAME
        $userName = "$env:USERDOMAIN\$env:USERNAME"
        Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
        Write-Host ('=' * 58)
        Write-Host ''
    }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Write-Err  -ErrorAction SilentlyContinue)) { function Write-Err  { param([string]$Msg) Write-Host ("[ERROR] {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Red } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

# -------- Folder picker (COM Shell; no STA required) --------
function Select-Folder {
    param([string]$Description = 'Select a folder',[string]$InitialDirectory = 'C:\')
    try {
        $shell = New-Object -ComObject Shell.Application
        $folder = $shell.BrowseForFolder(0, $Description, 0, $InitialDirectory)
        if ($folder) { return $folder.Self.Path }
    } catch { Write-Warn ("Folder picker unavailable: {0}" -f $_.Exception.Message) }
    return $null
}

# -------- HTML helpers --------
function New-HtmlBuilder { return New-Object System.Text.StringBuilder }
function Html-Append { param([Parameter(Mandatory)][System.Text.StringBuilder]$b,[Parameter(Mandatory)][string]$s) [void]$b.AppendLine($s) }
function Html-Escape { param([string]$s) return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }

$Global:_HtmlCss = @"
<style>
body { font-family: Segoe UI, Roboto, Arial, sans-serif; margin: 20px; }
h1 { font-size: 22px; margin-bottom: 8px; }
h2 { font-size: 18px; margin-top: 24px; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
h3 { font-size: 16px; margin-top: 16px; }
.summary { display: grid; grid-template-columns: repeat(3, minmax(220px, 1fr)); gap: 8px; margin: 8px 0 16px 0; }
.kv { background: #f7f7f7; border: 1px solid #eee; border-radius: 8px; padding: 8px 10px; }
.kv span.k { color: #555; }
.kv span.v { font-weight: 600; }
table { border-collapse: collapse; width: 100%; margin: 8px 0 16px 0; }
th, td { border: 1px solid #e5e5e5; padding: 6px 8px; text-align: left; vertical-align: top; }
th { background: #fafafa; }
pre { white-space: pre-wrap; word-break: break-word; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; background: #fbfbfb; border: 1px solid #eee; padding: 8px; border-radius: 6px; }
details { border: 1px solid #e5e5e5; border-radius: 8px; padding: 6px 10px; background: #fff; margin: 8px 0; }
details > summary { cursor: pointer; font-weight: 600; }
.badge { display: inline-block; padding: 2px 6px; border-radius: 999px; font-size: 12px; margin-right: 6px; }
.badge-ctx { background:#e8f2ff; color:#084298; }
.file-card { border: 1px solid #ddd; border-radius: 10px; padding: 10px 12px; margin: 14px 0; }
small { color:#888; }
button { margin: 0 6px 8px 0; }
</style>
<script>
function toggleAll(open) {
  var els = document.querySelectorAll('details');
  for (var i=0;i<els.length;i++) { els[i].open = open; }
}
</script>
"@

# -------- Analysis core (per file with contexts) --------
function Analyze-File {
    param([Parameter(Mandatory)][string]$FilePath)

    $levelRegex   = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
    $stampRegexes = @('\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?','\b\d{2}:\d{2}:\d{2}\b')
    $guidRegex    = '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b'
    $hexRegex     = '\b0x[0-9A-Fa-f]+\b'

    $countsByPattern   = @{}
    $countsByLevel     = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
    $contextsByPattern = @{}  # pattern -> list[hashtable {LineNumber:int; Context:string}]

    $file = Get-Item -LiteralPath $FilePath -ErrorAction Stop
    $limitContexts = $false
    if ($file.Length -gt ($LargeFileContextMB * 1MB)) { $limitContexts = $true }

    $lines = @()
    try { $lines = Get-Content -LiteralPath $FilePath -ErrorAction SilentlyContinue } catch { $lines = @() }
    $totalLines = $lines.Count

    for ($i=0; $i -lt $totalLines; $i++) {
        $line = [string]$lines[$i]
        if (-not $line) { continue }
        if ($line -match $levelRegex) {
            $upper = $Matches[1].ToUpperInvariant()
            switch -Regex ($upper) {
                '^ERROR$'        { $countsByLevel.ERROR++ }
                '^FATAL$'        { $countsByLevel.FATAL++ }
                '^EXCEPTION$'    { $countsByLevel.EXCEPTION++ }
                '^WARN$'         { $countsByLevel.WARN++ }
                '^WARNING$'      { $countsByLevel.WARNING++ }
                '^FAIL(ED)?$'    { $countsByLevel.FAIL++ }
                '^TIMEOUT$'      { $countsByLevel.TIMEOUT++ }
                '^UNAUTHORIZED$' { $countsByLevel.UNAUTHORIZED++ }
                'ACCESS DENIED'  { $countsByLevel.ACCESSDENIED++ }
            }
            # Normalize the pattern
            $norm = $line
            foreach ($rx in $stampRegexes) { $norm = ($norm -replace $rx, '') }
            $norm = $norm -replace $guidRegex, '{GUID}'
            $norm = $norm -replace $hexRegex, '{HEX}'
            $norm = $norm -replace '\[[^\]]+\]', ''
            $norm = $norm -replace '\b\d+\b', '#'
            $norm = $norm -replace '\s+', ' '
            $norm = $norm.Trim()
            if ($norm.Length -gt 200) { $norm = $norm.Substring(0,200) }

            if ($countsByPattern.ContainsKey($norm)) { $countsByPattern[$norm]++ } else { $countsByPattern[$norm] = 1 }

            # Ensure list init
            if (-not $contextsByPattern.ContainsKey($norm)) { $contextsByPattern[$norm] = New-Object System.Collections.Generic.List[object] }

            # Decide max contexts (PowerShell 5.1 lacks ternary operator)
            $maxCtx = $MaxMatchesPerPattern
            if ($limitContexts) { $maxCtx = [Math]::Min($MaxMatchesPerPattern, 3) }

            if ($contextsByPattern[$norm].Count -lt $maxCtx) {
                $start = [Math]::Max(0, $i - $ContextBefore)
                $end   = [Math]::Min($totalLines - 1, $i + $ContextAfter)

                # Extend to include stack/indented lines
                $k = $end + 1
                while ($k -lt $totalLines) {
                    $next = [string]$lines[$k]
                    if ($null -eq $next -or $next -eq '') { $k++; break }
                    if ($next -match '^\s') { $k++ } else { break }
                }
                $end = [Math]::Min($totalLines - 1, $k-1)

                $ctx = New-Object System.Text.StringBuilder
                for ($p=$start; $p -le $end; $p++) {
                    $prefix = if ($p -eq $i) { '>> ' } else { '   ' }
                    $ln = ("{0,5}: {1}{2}" -f ($p+1), $prefix, $lines[$p])
                    [void]$ctx.AppendLine($ln)
                }
                $contextsByPattern[$norm].Add(@{ LineNumber = ($i+1); Context = $ctx.ToString() })
            }
        }
    }

    # Build a result object
    [PSCustomObject]@{
        FilePath         = $FilePath
        TotalLines       = $totalLines
        CountsByLevel    = $countsByLevel
        CountsByPattern  = $countsByPattern
        ContextsByPattern= $contextsByPattern
        LimitedContexts  = $limitContexts
    }
}

# -------- HTML rendering --------
function Render-FileToHtml {
    param([Parameter(Mandatory)][System.Text.StringBuilder]$b, [Parameter(Mandatory)]$result)

    $fileName = Split-Path $result.FilePath -Leaf
    $fileId   = ([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($result.FilePath)) -replace '[^A-Za-z0-9]','')
    Html-Append $b ('<div class="file-card" id="file-' + $fileId + '">')
    Html-Append $b ('<h2>' + (Html-Escape $fileName) + '</h2>')
    Html-Append $b ('<div class="summary">')
    Html-Append $b ('  <div class="kv"><span class="k">Total lines:</span> <span class="v">' + $result.TotalLines + '</span></div>')
    $lvl = $result.CountsByLevel
    foreach ($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')) {
        Html-Append $b ('  <div class="kv"><span class="k">' + $k + ':</span> <span class="v">' + $lvl[$k] + '</span></div>')
    }
    Html-Append $b ('</div>')

    if ($result.LimitedContexts) {
        Html-Append $b ('<small>Note: file > ' + $LargeFileContextMB + ' MB — limiting number of captured contexts per pattern.</small>')
    }

    # Table of top patterns
    $rows = $result.CountsByPattern.GetEnumerator() | Sort-Object Value -Descending
    if ($rows) {
        Html-Append $b '<table><thead><tr><th style="width:70%">Recurring message (normalized)</th><th>Count</th></tr></thead><tbody>'
        foreach ($entry in $rows) {
            Html-Append $b ('<tr><td>' + (Html-Escape $entry.Key) + '</td><td>' + $entry.Value + '</td></tr>')
        }
        Html-Append $b '</tbody></table>'

        # Context sections
        foreach ($entry in $rows) {
            $pattern = $entry.Key; $count = $entry.Value
            $examples = $result.ContextsByPattern[$pattern]
            if ($examples -and $examples.Count -gt 0) {
                Html-Append $b ('<details><summary><span class="badge badge-ctx">contexts</span>' + (Html-Escape $pattern) + ' &nbsp;<small>(' + $examples.Count + ' example(s) of ' + $count + ')</small></summary>')
                $exIdx = 1
                foreach ($ex in $examples) {
                    $ctx = [string]$ex.Context
                    Html-Append $b ('<h3>Example ' + $exIdx + ' — at line ' + $ex.LineNumber + '</h3>')
                    Html-Append $b ('<pre>' + (Html-Escape $ctx) + '</pre>')
                    $exIdx++
                }
                Html-Append $b '</details>'
            }
        }
    } else {
        Html-Append $b '<p>No error/warning lines detected.</p>';
    }
    Html-Append $b '</div>'
}

# -------- Collection + HTML generation --------
function Collect-And-Report {
    param([Parameter(Mandatory)][string[]]$Roots)

    $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
    Ensure-Folder $outDir

    $timestamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
    $collectDir = Join-Path $outDir ('Collect_' + $timestamp)
    Ensure-Folder $collectDir

    $patterns = @('*.log','*.txt','*.json','*.evtx','*.zip','*.gz')
    $foundAny = $false

    foreach ($root in ($Roots | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -Unique)) {
        Write-Info ("Scanning {0} ..." -f $root)
        $safeLeaf = (Split-Path $root -Leaf); if (-not $safeLeaf) { $safeLeaf = ($root -replace '[:\\\/]','_') }
        $dest = Join-Path $collectDir ($safeLeaf -replace '[^\w\.-]','_')
        Ensure-Folder $dest

        try {
            $items = Get-ChildItem -Path (Join-Path $root '*') -Recurse -File -Include $patterns -ErrorAction SilentlyContinue
            if ($items -and $items.Count -gt 0) {
                $foundAny = $true
                $i=0; foreach ($f in $items) {
                    $i++; if ($i % 50 -eq 0) { Write-Info (" Copying files... {0}/{1}" -f $i, $items.Count) }
                    $relative = try { $f.FullName.Substring($root.Length).TrimStart('\') } catch { $f.Name }
                    $target   = Join-Path $dest $relative
                    Ensure-Folder (Split-Path $target -Parent)
                    Copy-Item -LiteralPath $f.FullName -Destination $target -Force -ErrorAction SilentlyContinue
                }
                Write-OK ("Copied {0} files from {1}" -f $items.Count, $root)
            } else { Write-Warn ("No matching files found under {0}" -f $root) }
        } catch { Write-Warn ("Scan error on {0}: {1}" -f $root, $_.Exception.Message) }
    }

    if (-not $foundAny) {
        Write-Warn 'No logs found in selected locations.'
        New-Item -ItemType File -Path (Join-Path $collectDir 'NO_LOGS_FOUND.txt') -Force | Out-Null
    } else {
        Write-OK ('Collected logs to: {0}' -f $collectDir)
    }

    # Build HTML report
    $htmlPath = Join-Path $collectDir 'index.html'
    $b = New-HtmlBuilder
    Html-Append $b '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">'
    Html-Append $b '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
    Html-Append $b '<title>Agent Log Review - Report</title>'
    Html-Append $b $Global:_HtmlCss
    Html-Append $b '</head><body>'
    Html-Append $b '<h1>ConnectSecure — Agent Log Review</h1>'
    Html-Append $b ('<div class="summary"><div class="kv"><span class="k">Generated:</span> <span class="v">' + (Get-Date) + '</span></div>')
    Html-Append $b ('<div class="kv"><span class="k">Host:</span> <span class="v">' + $env:COMPUTERNAME + '</span></div>')
    Html-Append $b ('<div class="kv"><span class="k">User:</span> <span class="v">' + $env:USERDOMAIN + '\' + $env:USERNAME + '</span></div></div>')
    Html-Append $b '<div><button onclick="toggleAll(true)">Expand all</button> <button onclick="toggleAll(false)">Collapse all</button></div>'

    $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.log', '.txt', '.json' }
    foreach ($tf in $textFiles) {
        Write-Info ("Analyzing " + $tf.FullName)
        $res = Analyze-File -FilePath $tf.FullName
        Render-FileToHtml -b $b -result $res

        # Also write a CSV per file
        $csvPath = Join-Path $collectDir ((Split-Path $tf.FullName -Leaf) + '_ErrorSummary.csv')
        $res.CountsByPattern.GetEnumerator() | Sort-Object -Property Value -Descending | 
            Select-Object @{n='Pattern';e={$_.Key}}, @{n='Count';e={$_.Value}} | 
            Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    }

    Html-Append $b '</body></html>'
    $null = $b.ToString() | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-OK ("Wrote HTML report: {0}" -f $htmlPath)

    try { Start-Process $htmlPath } catch { Write-Warn ("Could not open browser: {0}" -f $_.Exception.Message) }

    return $collectDir
}

# -------- Main --------
function Start-AgentLogReview {
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' [1] Local Agent ConnectSecure Logs' -ForegroundColor White
    Write-Host '     - Scans: C:\Program Files (x86)\CyberCNSAgent\logs' -ForegroundColor DarkGray
    Write-Host ' [2] Specify custom scan directory...' -ForegroundColor White
    Write-Host ' [Q] Quit' -ForegroundColor White
    Write-Host ''
    $choice = Read-Host 'Select an option (1/2/Q)'
    switch ($choice.ToUpper()) {
        '1' {
            $defaultPath = 'C:\Program Files (x86)\CyberCNSAgent\logs'
            if (-not (Test-Path -LiteralPath $defaultPath)) { Write-Warn ("Default path not found: {0}" -f $defaultPath) }
            $dir = Collect-And-Report -Roots @($defaultPath)
            Write-Host ''; Write-Host (" Results in: {0}" -f $dir) -ForegroundColor Gray
        }
        '2' {
            $picked = Select-Folder -Description 'Choose agent logs folder to scan' -InitialDirectory 'C:\Program Files (x86)\CyberCNSAgent\logs'
            if (-not $picked) { $picked = Read-Host 'No folder picked. Enter a folder path (or press Enter to cancel)' }
            if ($picked -and (Test-Path -LiteralPath $picked)) {
                $dir = Collect-And-Report -Roots @($picked)
                Write-Host ''; Write-Host (" Results in: {0}" -f $dir) -ForegroundColor Gray
            } else { Write-Warn 'No valid folder provided. Nothing to do.' }
        }
        'Q' { return }
        Default { Write-Warn 'Invalid choice.' }
    }
    Write-Host ''
    Read-Host 'Press Enter to return...'
}

Start-AgentLogReview
