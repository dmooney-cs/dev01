# -------------------------------------------------------------------------------------------------
# ConnectSecure Technicians Toolbox - Browser Extensions Details (Standalone)
# PS 5.1-safe, ASCII-only dividers, exports JSON/CSV per-table
# - Lists browser detection first, shows support + counts, then per-browser sections
# -------------------------------------------------------------------------------------------------

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot    = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot    = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportBrows   = Join-Path $ExportRoot 'BrowserExtensions'
$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = $ExportBrows   # keep extension exports together

# -------------------------------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolders {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportBrows
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title = "OSQuery - Browser Extensions")
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $HostName = $env:COMPUTERNAME
    $UserName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $HostName, $UserName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# Console utilities
function Get-WindowWidth {
    try {
        $raw = $Host.UI.RawUI
        if ($raw -and $raw.BufferSize.Width -gt 0) { return $raw.BufferSize.Width }
        if ($raw -and $raw.WindowSize.Width -gt 0) { return $raw.WindowSize.Width }
        return 120
    } catch { return 120 }
}

function Trunc-Text {
    param([string]$Text, [int]$MaxLen)
    if ($null -eq $Text) { return "" }
    $s = [string]$Text
    if ($MaxLen -le 1) { return ($s.Substring(0, [Math]::Min(1, $s.Length))) }
    if ($s.Length -le $MaxLen) { return $s }
    return $s.Substring(0, $MaxLen - 3) + '...'
}

function Scale-Widths {
    param([int[]]$Desired)
    $win = Get-WindowWidth
    $gutter = 3
    $rightMargin = 2
    $minCol = 8

    $desiredSum = ($Desired | Measure-Object -Sum).Sum
    $full = $desiredSum + (($Desired.Count - 1) * $gutter)

    if ($full -le ($win - $rightMargin)) { return $Desired }

    $target = [math]::Max(($Desired.Count * $minCol), ($win - $rightMargin - (($Desired.Count - 1) * $gutter)))
    $scale  = $target / [double][Math]::Max(1, $desiredSum)

    $scaled = @()
    foreach ($d in $Desired) {
        $w = [int][math]::Floor($d * $scale)
        if ($w -lt $minCol) { $w = $minCol }
        $scaled += $w
    }

    $sum = ($scaled | Measure-Object -Sum).Sum + (($scaled.Count - 1) * $gutter)
    while ($sum -gt ($win - $rightMargin)) {
        $maxVal = ($scaled | Sort-Object -Descending | Select-Object -First 1)
        $i = [Array]::IndexOf($scaled, $maxVal)
        if ($i -ge 0 -and $scaled[$i] -gt $minCol) { $scaled[$i]-- } else { break }
        $sum = ($scaled | Measure-Object -Sum).Sum + (($scaled.Count - 1) * $gutter)
    }
    return $scaled
}

# Display helper (kept in case we later want block prints)
function Write-LabelLine {
    param([string]$Label, [string]$Value, [int]$LabelWidth = 12)
    $lbl = ($Label + ":").PadRight($LabelWidth)
    Write-Host ("{0} {1}" -f $lbl, $Value) -ForegroundColor Gray
}

# Normalize any variable to an array (never $null)
function As-Array {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value)
}

# -------------------------------------------------------------------------------------------------
# OSQuery plumbing
# -------------------------------------------------------------------------------------------------
function Initialize-OsqOutput {
    Ensure-ExportFolders
    Ensure-Directory -Path $Global:OsqOutRoot
}

function Test-OsqueryPresent {
    if (-not (Test-Path $Global:OsqBinPath)) {
        Write-Host ""
        Write-Host "osqueryi.exe not found:" -ForegroundColor Red
        Write-Host "  $Global:OsqBinPath" -ForegroundColor Yellow
        Write-Host "This tool requires ConnectSecure's osquery installation." -ForegroundColor Yellow
        Pause-Script "Press any key to exit..."
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory=$true)][string]$Sql,
        [Parameter(Mandatory=$true)][string]$BaseName
    )
    Initialize-OsqOutput

    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.json')
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.csv')

    Write-Host ""
    Write-Host "Running osquery query:" -ForegroundColor Cyan
    Write-Host "  $Sql" -ForegroundColor DarkGray

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $Global:OsqBinPath
    $psi.Arguments = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()

    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stderr -and $stderr.Trim().Length -gt 0) {
        Write-Host "osquery stderr:" -ForegroundColor Yellow
        Write-Host "  $stderr" -ForegroundColor DarkYellow
    }

    if (-not $stdout) {
        Write-Host "No output received from osquery." -ForegroundColor Red
        return @()
    }

    try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    try {
        if (@($objs).Count -gt 0) {
            $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
            Write-Host ""
            Write-Host "Saved:" -ForegroundColor Green
            Write-Host "  JSON: $jsonPath" -ForegroundColor Green
            Write-Host "  CSV : $csvPath"  -ForegroundColor Green
        } else {
            Write-Host "No rows returned from query." -ForegroundColor DarkCyan
            Write-Host "  JSON saved: $jsonPath" -ForegroundColor DarkCyan
        }
    } catch {}

    return $objs
}

# Check if an osquery table exists in this build
function Test-OsqTableAvailable {
    param([Parameter(Mandatory)][string]$TableName)
    # osquery table registry
    $sql = "SELECT name FROM osquery_registry WHERE registry='table' AND name='$TableName' LIMIT 1;"
    $rows = Invoke-OsqueryJson -Sql $sql -BaseName ("OSQ_TABLECHECK_" + $TableName)
    return (@($rows).Count -gt 0)
}

# -------------------------------------------------------------------------------------------------
# Browser detection (best-effort file presence + user-data dirs)
# -------------------------------------------------------------------------------------------------
function Detect-Browsers {
    $edgeExe1   = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
    $edgeExe2   = 'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
    $chromeExe1 = 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
    $chromeExe2 = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
    $ffExe1     = 'C:\Program Files\Mozilla Firefox\firefox.exe'
    $ffExe2     = 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'

    $edgeData   = Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data'
    $chromeData = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
    $ffProfiles = Join-Path $env:APPDATA 'Mozilla\Firefox\profiles.ini'

    $hasEdge   = (Test-Path $edgeExe1) -or (Test-Path $edgeExe2) -or (Test-Path $edgeData)
    $hasChrome = (Test-Path $chromeExe1) -or (Test-Path $chromeExe2) -or (Test-Path $chromeData)
    $hasFF     = (Test-Path $ffExe1) -or (Test-Path $ffExe2) -or (Test-Path $ffProfiles)

    [PSCustomObject]@{
        Edge   = [bool]$hasEdge
        Chrome = [bool]$hasChrome
        Firefox= [bool]$hasFF
    }
}

# -------------------------------------------------------------------------------------------------
# Renderers
# -------------------------------------------------------------------------------------------------
function Render-ExtensionsTable {
    param([Parameter(Mandatory)][object[]]$Items)

    if (-not $Items -or @($Items).Count -eq 0) {
        Write-Host "  (no extensions returned)" -ForegroundColor Yellow
        return
    }

    # Browser(8), Name(36), Version(16), User SID(18), ID(28)
    $W = Scale-Widths @(8,36,16,18,28)

    $Items |
      Select-Object browser, name, version, user_sid, id |
      Sort-Object name |
      Format-Table -Property `
        @{Label='Browser';  Expression={ Trunc-Text $_.browser  $W[0] }; Width=$W[0]}, `
        @{Label='Name';     Expression={ Trunc-Text $_.name     $W[1] }; Width=$W[1]}, `
        @{Label='Version';  Expression={ Trunc-Text $_.version  $W[2] }; Width=$W[2]}, `
        @{Label='User SID'; Expression={ Trunc-Text $_.user_sid $W[3] }; Width=$W[3]}, `
        @{Label='ID';       Expression={ Trunc-Text $_.id       $W[4] }; Width=$W[4]} `
    | Out-Host
}

function Divider {
    param([string]$Text)
    $win = Get-WindowWidth
    $prefix = "== $Text "
    if ($prefix.Length -gt $win) { $prefix = $prefix.Substring(0, [Math]::Max(0, $win-1)) }
    $bar = $prefix + ("=" * [Math]::Max(0, $win - $prefix.Length))
    Write-Host $bar -ForegroundColor Cyan
}

# -------------------------------------------------------------------------------------------------
# Main logic
# -------------------------------------------------------------------------------------------------
Show-Header "OSQuery - Browser Extensions"
if (-not (Test-OsqueryPresent)) { return }

# osquery table support checks
$edgeTableSupported = Test-OsqTableAvailable -TableName 'edge_extensions'
$chrTableSupported  = Test-OsqTableAvailable -TableName 'chrome_extensions'
$ffTableSupported   = Test-OsqTableAvailable -TableName 'firefox_addons'

# Queries
$qEdge = @'
SELECT uid AS user_sid, name, version, description, persistent, path, identifier AS id
FROM edge_extensions;
'@

$qChr = @'
SELECT uid AS user_sid, name, version, description, persistent, path, identifier AS id
FROM chrome_extensions;
'@

$qFf = @'
SELECT uid AS user_sid, name, version, description, '' AS persistent, path, identifier AS id
FROM firefox_addons;
'@

# Detect browsers (file-system heuristics)
$det = Detect-Browsers

# Run osquery for each table *only if supported*
$edge = @()
if ($edgeTableSupported) {
    $e = Invoke-OsqueryJson -Sql $qEdge -BaseName 'OSQ_Edge_Extensions'
    $edge = As-Array $e
    if (@($edge).Count -gt 0) {
        $edge | ForEach-Object {
            $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Edge' -Force
        }
    }
}

$chr = @()
if ($chrTableSupported) {
    $c = Invoke-OsqueryJson -Sql $qChr -BaseName 'OSQ_Chrome_Extensions'
    $chr = As-Array $c
    if (@($chr).Count -gt 0) {
        $chr | ForEach-Object {
            $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Chrome' -Force
        }
    }
}

$ff = @()
if ($ffTableSupported) {
    $f = Invoke-OsqueryJson -Sql $qFf -BaseName 'OSQ_Firefox_Addons'
    $ff = As-Array $f
    if (@($ff).Count -gt 0) {
        $ff | ForEach-Object {
            $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Firefox' -Force
        }
    }
}

# Summary header
Write-Host ""
Write-Host "Browser Detection Summary" -ForegroundColor White
$lineLen = [Math]::Max(20, ($(Get-WindowWidth) - 2))
Write-Host ("-" * $lineLen) -ForegroundColor DarkGray

Write-Host (" Edge    Detected: {0}    Supported: {1}    Extensions: {2}" -f ($det.Edge -as [bool]),   ($edgeTableSupported -as [bool]), @($edge).Count) -ForegroundColor Gray
Write-Host (" Chrome  Detected: {0}    Supported: {1}    Extensions: {2}" -f ($det.Chrome -as [bool]), ($chrTableSupported -as [bool]),  @($chr).Count)  -ForegroundColor Gray
Write-Host (" Firefox Detected: {0}    Supported: {1}    Extensions: {2}" -f ($det.Firefox -as [bool]),($ffTableSupported -as [bool]),   @($ff).Count)   -ForegroundColor Gray

Write-Host ""

# Per-browser sections with clear dividers
Divider "Microsoft Edge"
if (-not $edgeTableSupported) {
    Write-Host "  The osquery table 'edge_extensions' is not supported on this build." -ForegroundColor Yellow
} elseif (@($edge).Count -eq 0) {
    Write-Host "  (no Edge extensions returned)" -ForegroundColor Yellow
} else {
    Render-ExtensionsTable -Items $edge
}
Write-Host ""

Divider "Google Chrome"
if (-not $chrTableSupported) {
    Write-Host "  The osquery table 'chrome_extensions' is not supported on this build." -ForegroundColor Yellow
} elseif (@($chr).Count -eq 0) {
    Write-Host "  (no Chrome extensions returned)" -ForegroundColor Yellow
} else {
    Render-ExtensionsTable -Items $chr
}
Write-Host ""

Divider "Mozilla Firefox"
if (-not $ffTableSupported) {
    Write-Host "  The osquery table 'firefox_addons' is not supported on this build." -ForegroundColor Yellow
} elseif (@($ff).Count -eq 0) {
    Write-Host "  (no Firefox addons returned)" -ForegroundColor Yellow
} else {
    Render-ExtensionsTable -Items $ff
}
Write-Host ""

Pause-Script "Press any key to close..."
