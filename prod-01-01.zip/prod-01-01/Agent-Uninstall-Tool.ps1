<#
.SYNOPSIS
  ConnectSecure Agent Uninstall Tool + Deep Clean Scan (Merged) + FINAL folder enforcement

.DESCRIPTION
  Flow:
    1) Run uninstall flow first (cybercnsagent.exe -r, then uninstall.bat or embedded fallback)
    2) If services and/or agent folder still exist, run Deep Clean Scan
    3) ALWAYS perform a FINAL forced delete attempt of:
         C:\Program Files (x86)\CyberCNSAgent
       (even if earlier steps reported success)

  Switches:
    -Quiet      : suppress chatter; prints only "Removed" or "Not removed" at end
    -ExportOnly : export JSON plan to C:\CS-Toolbox-TEMP\Collected-Info and exit
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Quiet,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ProgressPreference = 'SilentlyContinue'

# ====================== Setup / Logging ======================
$hostname  = $env:COMPUTERNAME
$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}

function New-UniquePath {
    param([Parameter(Mandatory)] [string]$BasePath)
    if (-not (Test-Path -LiteralPath $BasePath)) { return $BasePath }
    $dir  = [IO.Path]::GetDirectoryName($BasePath)
    $name = [IO.Path]::GetFileNameWithoutExtension($BasePath)
    $ext  = [IO.Path]::GetExtension($BasePath)
    for ($i=1; $i -le 999; $i++) {
        $candidate = Join-Path $dir ("{0}-{1:D3}{2}" -f $name, $i, $ext)
        if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    throw "Unable to allocate a unique log path for $BasePath"
}

$stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$baseLog        = Join-Path $exportDir "$hostname-AgentUninstall-DeepClean-$stamp.log"
$baseTranscript = Join-Path $exportDir "$hostname-AgentUninstall-DeepClean-$stamp.transcript.txt"

$logFile        = New-UniquePath -BasePath $baseLog
$transcriptFile = New-UniquePath -BasePath $baseTranscript

try { "" | Out-File -FilePath $logFile -Encoding UTF8 -Force } catch {}

$prev = @{
  EAP  = $ErrorActionPreference
  W    = $WarningPreference
  V    = $VerbosePreference
  I    = $InformationPreference
  P    = $ProgressPreference
}

if ($Quiet) {
  $ErrorActionPreference   = 'SilentlyContinue'
  $WarningPreference       = 'SilentlyContinue'
  $VerbosePreference       = 'SilentlyContinue'
  $InformationPreference   = 'SilentlyContinue'
  $ProgressPreference      = 'SilentlyContinue'
} else {
  $ErrorActionPreference = 'Stop'
  try { Start-Transcript -Path $transcriptFile -Append | Out-Null } catch {}
}

function Add-ContentSafe {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Value)
    for ($i=0; $i -lt 3; $i++) {
        try {
            Add-Content -LiteralPath $Path -Value $Value -Encoding UTF8
            return
        } catch {
            Start-Sleep -Milliseconds 200
            if ($i -eq 2) { throw }
        }
    }
}

function Write-Log {
  param([string]$m, [string]$Level = 'INFO')
  $line = "{0} [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $m
  try { Add-ContentSafe -Path $logFile -Value $line } catch {}
  if (-not $Quiet) { Write-Host $line }
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ====================== Constants ============================
$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"

# EXACT embedded uninstall.bat copy (used if local uninstall.bat is missing/unreadable)
$EmbeddedUninstallBat = @'
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor
timeout /T 5 > nul
sc stop CyberCNSAgent
timeout /T 5 > nul
sc delete CyberCNSAgent
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F
taskkill /IM nmap.exe /F
taskkill /IM cyberutilities.exe /F
CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f

rmdir CyberCNSAgent /s /q
'@

# ====================== ExportOnly ============================
if ($ExportOnly) {
    $plan = [ordered]@{
        Script      = 'Agent-Uninstall-DeepClean-Merged.ps1'
        Timestamp   = (Get-Date).ToString('o')
        ExportDir   = $exportDir
        LogFile     = $logFile
        Transcript  = $transcriptFile
        Steps       = @(
            'Run uninstall flow first (cybercnsagent.exe -r, uninstall.bat or embedded fallback)',
            'If services/folder remain: deep clean scan',
            'ALWAYS final-force-delete AgentDir at end'
        )
        Targets     = @{
            AgentDir  = $AgentDir
            Services  = @('CyberCNSAgent','CyberCNSAgentMonitor','ConnectSecureAgentMonitor')
        }
    }
    $outPath = Join-Path $exportDir 'agent-uninstall-deepclean-export.json'
    $plan | ConvertTo-Json -Depth 7 | Set-Content -Path $outPath -Encoding UTF8
    Write-Host "Exported: $outPath"
    exit 0
}

# ====================== State helpers ============================
function Any-ServicePresent {
    $names = @('CyberCNSAgent','CyberCNSAgentMonitor','ConnectSecureAgentMonitor')
    foreach ($n in $names) {
        if (Get-Service -Name $n -ErrorAction SilentlyContinue) { return $true }
    }
    return $false
}

function Current-State {
    [PSCustomObject]@{
        ServicesPresent = (Any-ServicePresent)
        AgentDirExists  = (Test-Path -LiteralPath $AgentDir)
    }
}

function Invoke-Exe {
    param([Parameter(Mandatory=$true)][string]$FilePath, [string[]]$Args = @())
    if ($Quiet) { & $FilePath @Args > $null 2>&1 } else { & $FilePath @Args }
}

# ====================== Uninstall tool logic ======================
function Run-Uninstall {
    Write-Log "Starting uninstall process..."

    $agentExe = Join-Path $AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        Write-Log "Triggering uninstall via cybercnsagent.exe -r"
        try { Invoke-Exe -FilePath $agentExe -Args @('-r') } catch { Write-Log ("cybercnsagent.exe -r failed: {0}" -f $_.Exception.Message) "WARN" }
        Start-Sleep -Seconds 5
    } else {
        Write-Log "Agent EXE not found, skipping -r" "WARN"
    }

    $useLocal = $false
    if (Test-Path -LiteralPath $UninstallBatPath) {
        try { $null = Get-Content -LiteralPath $UninstallBatPath -Raw -ErrorAction Stop; $useLocal = $true } catch { $useLocal = $false }
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        if ($useLocal) {
            Write-Log "Using LOCAL uninstall.bat: $UninstallBatPath"
            if ($Quiet) {
                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName = $env:ComSpec
                $psi.Arguments = "/c `"$UninstallBatPath`""
                $psi.UseShellExecute = $false
                $psi.CreateNoWindow = $true
                $psi.RedirectStandardOutput = $true
                $psi.RedirectStandardError  = $true
                $p = [System.Diagnostics.Process]::Start($psi)
                $p.WaitForExit()
                $null = $p.StandardOutput.ReadToEnd()
                $null = $p.StandardError.ReadToEnd()
            } else {
                & $env:ComSpec /c "`"$UninstallBatPath`""
            }
        } else {
            Write-Log "Local uninstall.bat missing/unreadable; using EMBEDDED uninstall.bat copy" "WARN"
            $EmbeddedUninstallBat | Out-File -FilePath $tempBat -Encoding ASCII -Force
            Write-Log "Executing embedded uninstall script..."
            if ($Quiet) {
                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName = $env:ComSpec
                $psi.Arguments = "/c `"$tempBat`""
                $psi.UseShellExecute = $false
                $psi.CreateNoWindow = $true
                $psi.RedirectStandardOutput = $true
                $psi.RedirectStandardError  = $true
                $p = [System.Diagnostics.Process]::Start($psi)
                $p.WaitForExit()
                $null = $p.StandardOutput.ReadToEnd()
                $null = $p.StandardError.ReadToEnd()
            } else {
                & $env:ComSpec /c "`"$tempBat`""
            }
        }
    } catch {
        Write-Log ("Failed to execute uninstall script: {0}" -f $_.Exception.Message) "WARN"
    } finally {
        try { Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue } catch {}
    }

    Write-Log "Uninstall process completed." "OK"
}

# ====================== Deep clean scan helpers ======================
function Find-HandleExe {
    $candidates = @()
    try { if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot 'handle.exe') } } catch {}
    $candidates += 'C:\CS-Toolbox-TEMP\Launchers\handle.exe'
    $candidates += 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\ETC\handle.exe'
    foreach ($p in $candidates) { if (Test-Path -LiteralPath $p) { return $p } }
    $cmd = Get-Command handle.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return $cmd.Source }
    return $null
}

function Force-Remove-ServiceHard {
    param([Parameter(Mandatory)][string]$ServiceName)

    Write-Log ("FORCE service removal: {0}" -f $ServiceName)

    try { sc.exe stop $ServiceName | Out-Null } catch {}

    for ($w = 1; $w -le 10; $w++) {
        Start-Sleep -Seconds 1
        $cur = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue
        if (-not $cur -or $cur.State -eq 'Stopped') { break }
    }

    try {
        $cur = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue
        if ($cur -and $cur.ProcessId -and [int]$cur.ProcessId -gt 0) {
            Write-Log ("Killing service PID {0} for {1}" -f $cur.ProcessId, $ServiceName) "WARN"
            Stop-Process -Id ([int]$cur.ProcessId) -Force -ErrorAction SilentlyContinue
        }
    } catch {}

    for ($i = 1; $i -le 3; $i++) {
        try {
            Write-Log ("sc delete {0} (attempt {1})" -f $ServiceName, $i)
            sc.exe delete $ServiceName | Out-Null
        } catch {}
        Start-Sleep -Seconds 1
        $still = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue
        if (-not $still) { return }
    }

    $still = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue
    if ($still) {
        Write-Log ("Service still present after sc delete; removing registry key HKLM:\SYSTEM\CCS\Services\{0}" -f $ServiceName) "WARN"
        $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
        try {
            if (Test-Path -LiteralPath $svcKey) {
                Remove-Item -LiteralPath $svcKey -Recurse -Force -ErrorAction Stop
                Write-Log ("Deleted registry key: {0}" -f $svcKey) "OK"
            }
        } catch {
            Write-Log ("Registry key removal failed for {0}: {1}" -f $ServiceName, $_.Exception.Message) "ERROR"
        }

        Start-Sleep -Seconds 1
        $still2 = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue
        if ($still2) {
            $stamp2 = Get-Date -Format 'yyyyMMdd_HHmmss'
            $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
            $cmd = "cmd.exe /c sc stop `"$ServiceName`" & sc delete `"$ServiceName`" & reg delete `"HKLM\System\CurrentControlSet\Services\$ServiceName`" /f"
            $name = "ForceDeleteService_${ServiceName}_$stamp2"
            try {
                New-Item -Path $runOnceKey -Force | Out-Null
                New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null
                Write-Log ("Staged RunOnce forced service removal: {0}" -f $ServiceName) "WARN"
            } catch {
                Write-Log ("Failed to stage RunOnce for {0}: {1}" -f $ServiceName, $_.Exception.Message) "ERROR"
            }
        }
    }
}

function Final-Force-RemoveFolder {
    param([Parameter(Mandatory)][string]$Path)

    Write-Log ("FINAL folder enforcement for: {0}" -f $Path) "WARN"

    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Log "Folder does not exist; nothing to remove." "OK"
        return
    }

    # Kill anything running from folder (best effort)
    try {
        Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $exe = $_.MainModule.FileName
                if ($exe -and $exe.StartsWith($Path, [StringComparison]::OrdinalIgnoreCase)) {
                    Write-Log ("Stopping process: {0} (PID {1})" -f $_.Name, $_.Id) "WARN"
                    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    } catch {}

    # Optional handle.exe locker kill
    $handleExe = Find-HandleExe
    if ($handleExe) {
        try {
            $out = & $handleExe -accepteula -nobanner "$Path" 2>$null
            $pids = New-Object System.Collections.Generic.HashSet[int]
            foreach ($line in $out) {
                if ($line -match '\spid:\s*(\d+)\s') { [void]$pids.Add([int]$Matches[1]) }
            }
            foreach ($pid in ($pids | Sort-Object)) {
                try { Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue } catch {}
            }
            Start-Sleep -Seconds 1
        } catch {}
    }

    # Takeown/icacls
    try {
        cmd.exe /c "takeown /f `"$Path`" /r /d y" | Out-Null
        cmd.exe /c "icacls `"$Path`" /grant *S-1-5-32-544:F /t /c" | Out-Null
    } catch {}

    # Delete retries
    for ($i=1; $i -le 5; $i++) {
        try {
            Write-Log ("Final delete attempt {0}: Remove-Item -Recurse -Force" -f $i) "WARN"
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            break
        } catch {
            Write-Log ("Final delete attempt {0} failed: {1}" -f $i, $_.Exception.Message) "WARN"
            Start-Sleep -Seconds 2
        }
    }

    # Robocopy purge fallback
    if (Test-Path -LiteralPath $Path) {
        try {
            Write-Log "Final fallback: robocopy mirror-purge..." "WARN"
            $empty = Join-Path $env:TEMP ("empty_" + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $empty -Force | Out-Null
            cmd.exe /c "robocopy `"$empty`" `"$Path`" /MIR /R:1 /W:1 /NFL /NDL /NJH /NJS" | Out-Null
            Remove-Item -LiteralPath $empty -Recurse -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
        } catch {}
    }

    # If still there, stage delete on reboot
    if (Test-Path -LiteralPath $Path) {
        try {
            $stamp3 = Get-Date -Format 'yyyyMMdd_HHmmss'
            $staged = $Path + "_DELETE_ME_" + $stamp3
            Write-Log ("Still locked. Renaming folder to stage deletion: {0}" -f $staged) "WARN"
            Rename-Item -LiteralPath $Path -NewName (Split-Path -Leaf $staged) -ErrorAction Stop

            $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
            $cmd = "cmd.exe /c rd /s /q `"$staged`""
            $name = "FinalDeleteCyberCNSAgent_$stamp3"
            New-Item -Path $runOnceKey -Force | Out-Null
            New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null
            Write-Log "Staged RunOnce final folder deletion (reboot recommended)." "WARN"
        } catch {
            Write-Log ("Final stage-delete-on-reboot failed: {0}" -f $_.Exception.Message) "ERROR"
        }
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Log "FINAL folder enforcement: folder removed." "OK"
    } else {
        Write-Log "FINAL folder enforcement: folder still present (reboot likely required)." "WARN"
    }
}

function Run-DeepClean {
    Write-Log "Deep clean scan starting..." "WARN"

    foreach ($svc in @('CyberCNSAgent','CyberCNSAgentMonitor','ConnectSecureAgentMonitor')) {
        Force-Remove-ServiceHard -ServiceName $svc
    }

    if (-not (Test-Path -LiteralPath $AgentDir)) {
        Write-Log "Agent folder not present; deep clean completed after service removal." "OK"
        return
    }

    try {
        Write-Log "Disabling scheduled tasks referencing agent folder..."
        $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue
        foreach ($t in $tasks) {
            try {
                $actionsText = ($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
                if ($actionsText -and $actionsText -like "*$AgentDir*") {
                    Write-Log ("Disabling task: {0}{1}" -f $t.TaskPath, $t.TaskName) "WARN"
                    Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
                    Stop-ScheduledTask    -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
                }
            } catch {}
        }
    } catch {}

    try {
        Write-Log "Killing common CyberCNS processes..."
        Get-Process -Name 'cybercns*' -ErrorAction SilentlyContinue | ForEach-Object {
            try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
        }
        cmd.exe /c 'taskkill /f /im CyberCNSAgent.exe >nul 2>&1' | Out-Null
        cmd.exe /c 'taskkill /f /im CyberCNS*.exe >nul 2>&1' | Out-Null
        cmd.exe /c 'taskkill /f /im cybercns*.exe >nul 2>&1' | Out-Null
    } catch {}

    try {
        Write-Log "Killing processes running from agent folder..."
        Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $exe = $_.MainModule.FileName
                if ($exe -and $exe.StartsWith($AgentDir, [StringComparison]::OrdinalIgnoreCase)) {
                    Write-Log ("Stopping process: {0} (PID {1})" -f $_.Name, $_.Id) "WARN"
                    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    } catch {}

    $handleExe = Find-HandleExe
    if ($handleExe) {
        try {
            Write-Log ("handle.exe found at: {0}" -f $handleExe)
            $out = & $handleExe -accepteula -nobanner "$AgentDir" 2>$null
            $pids = New-Object System.Collections.Generic.HashSet[int]
            foreach ($line in $out) {
                if ($line -match '\spid:\s*(\d+)\s') { [void]$pids.Add([int]$Matches[1]) }
            }
            if ($pids.Count -gt 0) {
                Write-Log ("Locking PIDs: {0}" -f (($pids | Sort-Object) -join ', ')) "WARN"
                foreach ($pid in ($pids | Sort-Object)) {
                    try { Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue } catch {}
                }
                Start-Sleep -Seconds 2
            }
        } catch {}
    } else {
        Write-Log "handle.exe not found (optional)." "WARN"
    }

    try {
        Write-Log "Taking ownership + granting Administrators full control..."
        cmd.exe /c "takeown /f `"$AgentDir`" /r /d y" | Out-Null
        cmd.exe /c "icacls `"$AgentDir`" /grant *S-1-5-32-544:F /t /c" | Out-Null
    } catch {}

    $deleted = $false
    for ($i = 1; $i -le 5; $i++) {
        try {
            Write-Log ("Attempt {0}: Remove-Item -Recurse -Force" -f $i)
            Remove-Item -LiteralPath $AgentDir -Recurse -Force -ErrorAction Stop
            $deleted = $true
            break
        } catch {
            Write-Log ("Attempt {0} failed: {1}" -f $i, $_.Exception.Message) "WARN"
            Start-Sleep -Seconds 2
        }
    }

    if (-not $deleted -and (Test-Path -LiteralPath $AgentDir)) {
        try {
            Write-Log "Fallback: robocopy mirror-purge..." "WARN"
            $empty = Join-Path $env:TEMP ("empty_" + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $empty -Force | Out-Null
            cmd.exe /c "robocopy `"$empty`" `"$AgentDir`" /MIR /R:1 /W:1 /NFL /NDL /NJH /NJS" | Out-Null
            Remove-Item -LiteralPath $empty -Recurse -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $AgentDir -Recurse -Force -ErrorAction SilentlyContinue
        } catch {}
    }

    Write-Log "Deep clean scan completed." "OK"
}

# ====================== Flow ================================
$exitCode = 0
try {
    if (-not (Test-Admin)) { throw "This script must be run as Administrator." }

    $start = Current-State
    Write-Log ("Initial state: ServicesPresent={0} AgentDirExists={1}" -f $start.ServicesPresent, $start.AgentDirExists)

    $proceed = $true
    if (-not $Quiet) {
        if (-not ($start.ServicesPresent -or $start.AgentDirExists)) {
            Write-Log "Nothing detected to uninstall."
        } else {
            $ans = Read-Host "Uninstall ConnectSecure now?  (Press Enter to start, or type N to cancel)"
            $proceed = ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y')
        }
    }

    $uninstallAttempted = $false
    if ($proceed -and ($start.ServicesPresent -or $start.AgentDirExists)) {
        $uninstallAttempted = $true
        Run-Uninstall
    } elseif (-not $Quiet) {
        Write-Log "Uninstall cancelled by user." "WARN"
    }

    $mid = Current-State
    Write-Log ("Post-uninstall state: ServicesPresent={0} AgentDirExists={1}" -f $mid.ServicesPresent, $mid.AgentDirExists)

    if ($mid.ServicesPresent -or $mid.AgentDirExists) {
        Run-DeepClean
    } else {
        Write-Log "No deep clean required (services and folder already removed)." "OK"
    }

    # ALWAYS enforce folder removal at end (your requirement)
    Final-Force-RemoveFolder -Path $AgentDir

    $final = Current-State
    Write-Log ("Final state: ServicesPresent={0} AgentDirExists={1}" -f $final.ServicesPresent, $final.AgentDirExists)

    $removed = (-not $final.ServicesPresent) -and (-not $final.AgentDirExists)

    if (-not $Quiet -and $uninstallAttempted) {
        Write-Host ""
        Write-Host "ConnectSecure Agent removal is still required from the portal if agents are removed directly from endpoints. This is not required if you are reinstalling." -ForegroundColor Yellow
        [void](Read-Host "Press Enter to acknowledge")
    }

    if ($Quiet) {
        if ($removed) { Write-Output "Removed" } else { Write-Output "Not removed" }
    } else {
        if ($removed) { Write-Host "[OK] Application removed." -ForegroundColor Green }
        else { Write-Host "[WARN] Application still present or partially removed. A reboot may be required." -ForegroundColor Yellow }
        Write-Host ("Custom log: {0}" -f $logFile) -ForegroundColor DarkGray
        Write-Host ("Transcript:  {0}" -f $transcriptFile) -ForegroundColor DarkGray
        Read-Host -Prompt "Press Enter to exit" | Out-Null
    }

    if (-not $removed) { $exitCode = 2 }
}
catch {
    $exitCode = 1
    if ($Quiet) {
        Write-Output "Not removed"
        try { Add-ContentSafe -Path $logFile -Value ("{0} [ERROR] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $_.Exception.Message) } catch {}
    } else {
        Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Host ("Custom log: {0}" -f $logFile) -ForegroundColor DarkGray
        Write-Host ("Transcript:  {0}" -f $transcriptFile) -ForegroundColor DarkGray
        Read-Host -Prompt "Press Enter to exit" | Out-Null
    }
}
finally {
    if (-not $Quiet) { try { Stop-Transcript | Out-Null } catch {} }
    $ErrorActionPreference   = $prev.EAP
    $WarningPreference       = $prev.W
    $VerbosePreference       = $prev.V
    $InformationPreference   = $prev.I
    $ProgressPreference      = $prev.P
    exit $exitCode
}
```
