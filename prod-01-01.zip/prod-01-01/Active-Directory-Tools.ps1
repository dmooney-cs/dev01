<# ===============================================================
  Active-Directory-Tools.ps1  (hard-coded, looping menu)
  Options:
    [1] Users       - AD-Users.ps1
    [2] Computers   - AD-Computers.ps1
    [3] OUs         - AD-OU.ps1
    [4] GPOs        - AD-GPO.ps1
    [5] Run ALL (1..4)
    [Q] Return to Toolbox Menu (same window)

  Logs (stdout+stderr combined):
    C:\CS-Toolbox-TEMP\Collected-Info\AD\Runner-Logs\<timestamp>-<script>.log

  Switches:
    -All    : Run ALL AD scripts (1..4) non-interactively, then exit.
    -Quiet  : Reduce wrapper/menu chatter (best used with -All).
=============================================================== #>

#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$All,
    [switch]$Quiet
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- Hard-coded paths ----
$BaseDir    = 'C:\CS-Toolbox-TEMP\prod-01-01'
$Launcher   = Join-Path $BaseDir 'CS-Toolbox-Launcher.ps1'
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
$LogRoot    = Join-Path $ExportRoot 'Runner-Logs'

# ---- Ensure folders exist ----
foreach ($p in @($ExportRoot, $LogRoot)) {
    if (-not (Test-Path -LiteralPath $p)) {
        New-Item -ItemType Directory -Path $p -Force | Out-Null
    }
}

# ---- Hard-coded script list ----
$SCRIPTS = @(
    @{ Label = 'Users';     Path = Join-Path $BaseDir 'AD-Users.ps1'     },
    @{ Label = 'Computers'; Path = Join-Path $BaseDir 'AD-Computers.ps1' },
    @{ Label = 'OUs';       Path = Join-Path $BaseDir 'AD-OU.ps1'        },
    @{ Label = 'GPOs';      Path = Join-Path $BaseDir 'AD-GPO.ps1'       }
)

function New-LogFile([string]$scriptPath) {
    $name  = [IO.Path]::GetFileNameWithoutExtension($scriptPath)
    $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $safe  = ($name -replace '[^\w\.\-]+','_')
    return (Join-Path $LogRoot "$stamp-$safe.log")
}

function Invoke-One([string]$path, [string]$label) {
    if (-not (Test-Path -LiteralPath $path)) {
        if (-not $Quiet) {
            Write-Host ("[ERROR] Script not found: {0}" -f $path) -ForegroundColor Red
        }
        return 127
    }

    $log = New-LogFile $path

    if (-not $Quiet) {
        Write-Host ""
        Write-Host ("-- Running AD-{0}" -f $label) -ForegroundColor Cyan
        Write-Host ("   Path: {0}" -f $path)
        Write-Host ("   Log : {0}" -f $log)
        Write-Host ""
    }

    # Run the script and log both stdout and stderr
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $path 2>&1 |
        Tee-Object -FilePath $log -Append | Out-Host

    $rc = $LASTEXITCODE
    if ($rc -eq $null) { $rc = 0 }

    if (-not $Quiet) {
        if ($rc -eq 0) {
            Write-Host ("[OK] AD-{0} completed (ExitCode={1})" -f $label, $rc) -ForegroundColor Green
        } else {
            Write-Host ("[FAIL] AD-{0} exited with code {1}" -f $label, $rc) -ForegroundColor Red
            Write-Host ("       See log: {0}" -f $log)
        }
    }
    return $rc
}

function Run-All {
    if (-not $Quiet) {
        Write-Host ""
        Write-Host "== Running ALL AD scripts in order ==" -ForegroundColor Cyan
    }

    $fail = 0
    foreach ($item in $SCRIPTS) {
        $rc = Invoke-One -path $item.Path -label $item.Label
        if ($rc -ne 0) { $fail++ }
    }

    if (-not $Quiet) {
        if ($fail -eq 0) {
            Write-Host ""
            Write-Host "ALL scripts completed successfully." -ForegroundColor Green
        } else {
            Write-Host ""
            Write-Host ("ALL completed with {0} failure(s). Check logs: {1}" -f $fail, $LogRoot) -ForegroundColor Yellow
        }
    }

    if ($fail -eq 0) { return 0 } else { return 1 }
}

function Show-Banner {
    if ($Quiet) { return }

    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $isAdmin  = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    Write-Host " Active Directory Tools" -ForegroundColor Cyan
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin)
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Menu {
    if ($Quiet) { return }

    Write-Host (" [1] Users       - AD-Users.ps1")
    Write-Host (" [2] Computers   - AD-Computers.ps1")
    Write-Host (" [3] OUs         - AD-OU.ps1")
    Write-Host (" [4] GPOs        - AD-GPO.ps1")
    Write-Host ""
    Write-Host (" [5] Run ALL (1..4)")
    Write-Host (" [Q] Return to Toolbox Menu")
    Write-Host ""
}

function Read-Choice {
    while ($true) {
        $raw = Read-Host -Prompt "Enter your choice (1-5 or Q)"
        if ($raw -match '^[1-5qQ]$') { return $raw }
        if (-not $Quiet) {
            Write-Host "Invalid choice. Enter 1..5 or Q." -ForegroundColor Yellow
        }
    }
}

# ---------------- NON-INTERACTIVE SWITCH HANDLING ----------------
if ($All) {
    if (-not $Quiet) {
        Show-Banner
        Write-Host "Running ALL Active Directory tools (-All)..." -ForegroundColor Cyan
    }

    $code = Run-All

    if (-not $Quiet) {
        Write-Host ""
        Write-Host ("Completed -All run with exit code {0}" -f $code)
    }

    exit $code
}

# ---------------- MAIN LOOP (INTERACTIVE) ----------------
while ($true) {
    Show-Banner
    Show-Menu
    $choice = Read-Choice

    switch ($choice) {
        '1' { [void](Invoke-One -path $SCRIPTS[0].Path -label $SCRIPTS[0].Label) }
        '2' { [void](Invoke-One -path $SCRIPTS[1].Path -label $SCRIPTS[1].Label) }
        '3' { [void](Invoke-One -path $SCRIPTS[2].Path -label $SCRIPTS[2].Label) }
        '4' { [void](Invoke-One -path $SCRIPTS[3].Path -label $SCRIPTS[3].Label) }
        '5' { [void](Run-All) }
        'q' { 
            if (-not (Test-Path -LiteralPath $Launcher)) {
                if (-not $Quiet) {
                    Write-Host ("[ERROR] Launcher not found: {0}" -f $Launcher) -ForegroundColor Red
                    try { Read-Host -Prompt "Press Enter to return to the menu" | Out-Null } catch {}
                }
                continue
            }
            Clear-Host
            & $Launcher
            break
        }
        'Q' { 
            if (-not (Test-Path -LiteralPath $Launcher)) {
                if (-not $Quiet) {
                    Write-Host ("[ERROR] Launcher not found: {0}" -f $Launcher) -ForegroundColor Red
                    try { Read-Host -Prompt "Press Enter to return to the menu" | Out-Null } catch {}
                }
                continue
            }
            Clear-Host
            & $Launcher
            break
        }
        default {
            if (-not $Quiet) {
                Write-Host "Unexpected selection." -ForegroundColor Red
            }
        }
    }

    # Pause and return to menu after any run (1..5)
    if (-not $Quiet) {
        try { Read-Host -Prompt "Press Enter to return to the menu" | Out-Null } catch {}
    }
}
