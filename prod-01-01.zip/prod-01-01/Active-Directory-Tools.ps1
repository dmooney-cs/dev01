<# ===============================================================
  Active-Directory-Tools.ps1
  - Hard-coded to: C:\CS-Toolbox-TEMP\prod-01-01
  - Targets these four scripts (if present, in this order):
      1) AD-Users.ps1
      2) AD-Computers.ps1
      3) AD-OU.ps1
      4) AD-GPO.ps1
    If any are missing, it will fall back to all AD-*.ps1 discovered.
  - Option 5 runs ALL target scripts
  - Ensures export/log directories exist
  - Logs each run to:
      C:\CS-Toolbox-TEMP\Collected-Info\AD\Runner-Logs\<timestamp>-<script>.log
=============================================================== #>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -------- Hard-coded paths --------
$BaseDir    = 'C:\CS-Toolbox-TEMP\prod-01-01'
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
$LogRoot    = Join-Path $ExportRoot 'Runner-Logs'

# -------- Ensure export/log folders --------
try {
    foreach ($p in @($ExportRoot, $LogRoot)) {
        if (-not (Test-Path -LiteralPath $p)) {
            New-Item -ItemType Directory -Path $p -Force | Out-Null
        }
    }
} catch {
    Write-Host "[ERROR] Failed to ensure export/log folders: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

function Get-TargetScripts {
    if (-not (Test-Path -LiteralPath $BaseDir)) {
        throw "Base folder not found: $BaseDir"
    }

    # Preferred, pinned order
    $preferred = @(
        'AD-Users.ps1',
        'AD-Computers.ps1',
        'AD-OU.ps1',
        'AD-GPO.ps1'
    )

    $existingPreferred = @()
    foreach ($name in $preferred) {
        $full = Join-Path $BaseDir $name
        if (Test-Path -LiteralPath $full) {
            $existingPreferred += (Get-Item -LiteralPath $full)
        }
    }

    if ($existingPreferred.Count -eq 4) {
        return $existingPreferred
    }

    # Fallback to anything AD-*.ps1 (sorted) if some preferred are missing
    $discovered = Get-ChildItem -LiteralPath $BaseDir -Filter 'AD-*.ps1' -File | Sort-Object Name
    if (-not $discovered) {
        throw "No scripts matching 'AD-*.ps1' found in $BaseDir"
    }
    # Keep the first four as menu singles; ALL will still run the full discovered set.
    return $discovered
}

function New-LogFile([string]$scriptName) {
    $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $safe  = ($scriptName -replace '[^\w\.\-]+','_')
    return (Join-Path $LogRoot "$stamp-$safe.log")
}

function Invoke-ADScript([System.IO.FileInfo]$Script) {
    $log = New-LogFile $Script.Name
    Write-Host ""
    Write-Host ("-- Running {0}" -f $Script.Name) -ForegroundColor Cyan
    Write-Host ("   Path: {0}" -f $Script.FullName)
    Write-Host ("   Log : {0}" -f $log)
    Write-Host ""

    $psArgs = @(
        '-NoProfile',
        '-ExecutionPolicy','Bypass',
        '-File', $Script.FullName
    )

    $exe = 'powershell.exe'
    $proc = Start-Process -FilePath $exe -ArgumentList $psArgs `
        -WorkingDirectory $BaseDir `
        -RedirectStandardOutput $log `
        -RedirectStandardError  $log `
        -PassThru -WindowStyle Hidden

    $null = $proc.WaitForExit()
    $rc = $proc.ExitCode

    if ($rc -eq 0) {
        Write-Host ("[OK] {0} completed (ExitCode={1})" -f $Script.Name, $rc) -ForegroundColor Green
    } else {
        Write-Host ("[FAIL] {0} exited with code {1}" -f $Script.Name, $rc) -ForegroundColor Red
        Write-Host ("       See log: {0}" -f $log)
    }
    return $rc
}

function Show-Banner {
    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $isAdmin  = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    Write-Host " Active Directory Tools" -ForegroundColor Cyan
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin)
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Menu([System.IO.FileInfo[]]$Singles, [int]$totalCount) {
    # Menu text kept ASCII-only to avoid encoding weirdness
    Write-Host " [1] $($Singles[0].BaseName) - Run this script" -ForegroundColor White
    if ($Singles.Count -ge 2) { Write-Host " [2] $($Singles[1].BaseName) - Run this script" -ForegroundColor White }
    if ($Singles.Count -ge 3) { Write-Host " [3] $($Singles[2].BaseName) - Run this script" -ForegroundColor White }
    if ($Singles.Count -ge 4) { Write-Host " [4] $($Singles[3].BaseName) - Run this script" -ForegroundColor White }

    $runAllIndex = [Math]::Min(4, $Singles.Count) + 1
    Write-Host ""
    Write-Host (" [{0}] Run ALL AD scripts ({1} total)" -f $runAllIndex, $totalCount) -ForegroundColor Yellow
    Write-Host " [0] Quit" -ForegroundColor DarkGray
    Write-Host ""
}

function Read-Choice([int]$maxSingles) {
    $allIndex = $maxSingles + 1
    while ($true) {
        $raw = Read-Host -Prompt ("Enter your choice [0-{0}] (where {0} runs ALL)" -f $allIndex)
        if ($raw -match '^\d+$') {
            $n = [int]$raw
            if ($n -ge 0 -and $n -le $allIndex) { return $n }
        }
        Write-Host "Invalid choice. Enter a number from 0 to $allIndex." -ForegroundColor Yellow
    }
}

# ---------------- MAIN ----------------
try {
    $allScripts = Get-TargetScripts
    # Menu singles are the first up to four
    $singles = $allScripts | Select-Object -First 4

    Show-Banner
    Show-Menu -Singles $singles -totalCount $allScripts.Count

    $maxSingles = $singles.Count
    $choice = Read-Choice -maxSingles $maxSingles

    if ($choice -eq 0) {
        Write-Host "Goodbye."
        exit 0
    }

    if ($choice -eq ($maxSingles + 1)) {
        Write-Host ""
        Write-Host "== Running ALL AD scripts in order ==" -ForegroundColor Cyan
        $fail = 0
        foreach ($s in $allScripts) {
            $rc = Invoke-ADScript -Script $s
            if ($rc -ne 0) { $fail++ }
        }
        if ($fail -eq 0) {
            Write-Host ""
            Write-Host "ALL scripts completed successfully." -ForegroundColor Green
            exit 0
        } else {
            Write-Host ""
            Write-Host ("ALL completed with {0} failure(s). Check logs: {1}" -f $fail, $LogRoot) -ForegroundColor Yellow
            exit 1
        }
    } else {
        $target = $singles[$choice - 1]
        [void](Invoke-ADScript -Script $target)
        exit 0
    }

} catch {
    Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 99
}
