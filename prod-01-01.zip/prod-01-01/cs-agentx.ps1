[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------
# Console state capture / restore
# ------------------------------------------------------------
function Get-ConsoleState {
    # Some hosts may not support UI properties; protect with try/catch.
    $state = [ordered]@{
        HasUI = $false
        ForegroundColor = $null
        BackgroundColor = $null
        WindowTitle     = $null
    }

    try {
        if ($Host -and $Host.UI -and $Host.UI.RawUI) {
            $raw = $Host.UI.RawUI
            $state.HasUI = $true
            $state.ForegroundColor = $raw.ForegroundColor
            $state.BackgroundColor = $raw.BackgroundColor
            $state.WindowTitle     = $raw.WindowTitle
        }
    } catch { }

    return [pscustomobject]$state
}

function Restore-ConsoleState {
    param(
        [Parameter(Mandatory)]
        $State
    )

    try {
        if ($State.HasUI -and $Host -and $Host.UI -and $Host.UI.RawUI) {
            $raw = $Host.UI.RawUI

            if ($null -ne $State.ForegroundColor) { $raw.ForegroundColor = $State.ForegroundColor }
            if ($null -ne $State.BackgroundColor) { $raw.BackgroundColor = $State.BackgroundColor }
            if ($null -ne $State.WindowTitle)     { $raw.WindowTitle     = $State.WindowTitle }
        }
    } catch { }
}

# Capture console state at script start (only matters for interactive mode)
$ConsoleState = Get-ConsoleState

# ------------------------------------------------------------
# Config
# ------------------------------------------------------------
$ExePath        = 'C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe'
$AgentOutputTxt = 'C:\Program Files (x86)\CyberCNSAgent\output.txt'
$LauncherPath   = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

$CollectedRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Agentx'
$null = New-Item -ItemType Directory -Path $CollectedRoot -Force

$RunStamp      = Get-Date -Format 'yyyyMMdd_HHmmss'
$CmdOutputPath = Join-Path $CollectedRoot ("Agentx_CommandOutput_{0}.txt" -f $RunStamp)
$MetaPath      = Join-Path $CollectedRoot ("Agentx_RunInfo_{0}.txt" -f $RunStamp)
$CopiedTxtPath = Join-Path $CollectedRoot ("output_{0}.txt" -f $RunStamp)

$RawStdOut = Join-Path $CollectedRoot ("Agentx_RAW_stdout_{0}.txt" -f $RunStamp)
$RawStdErr = Join-Path $CollectedRoot ("Agentx_RAW_stderr_{0}.txt" -f $RunStamp)

function Write-UiLine {
    param([string]$Text)
    if (-not $Silent -and -not $ExportOnly) { Write-Host $Text }
}

function Get-CleanScreenLine {
    param([string]$Line)

    if ($null -eq $Line) { return $Line }

    $Line = $Line -replace ([char]0x2713), '[OK]'
    $Line = $Line -replace ([char]0x2714), '[OK]'
    $Line = $Line -replace ([char]0x2717), '[X]'
    $Line = $Line -replace ([char]0x2718), '[X]'
    $Line = $Line -replace 'Γ£ô', '[OK]'
    $Line = $Line -replace 'âœ“', '[OK]'

    return $Line
}

# ------------------------------------------------------------
# Validate
# ------------------------------------------------------------
if (-not (Test-Path -LiteralPath $ExePath -PathType Leaf)) {
    $msg = "CyberCNS agent executable not found: $ExePath"
    $msg | Out-File -FilePath $CmdOutputPath -Encoding utf8 -Force
    throw $msg
}

# ------------------------------------------------------------
# Run Agent -x
# ------------------------------------------------------------
Write-UiLine "Running: `"$ExePath`" -x"
Write-UiLine "Writing output to: $CmdOutputPath"
Write-UiLine ""

$start = Get-Date

@(
    "RunStamp:  $RunStamp"
    "StartTime: $($start.ToString('o'))"
    "ExePath:   $ExePath"
    "Args:      -x"
    "Machine:   $env:COMPUTERNAME"
    "User:      $env:USERNAME"
    ""
) | Out-File -FilePath $CmdOutputPath -Encoding utf8 -Force

Remove-Item -LiteralPath $RawStdOut, $RawStdErr -Force -ErrorAction SilentlyContinue

$exitCode = 1
try {
    $p = Start-Process -FilePath $ExePath `
        -ArgumentList @('-x') `
        -NoNewWindow `
        -Wait `
        -PassThru `
        -RedirectStandardOutput $RawStdOut `
        -RedirectStandardError  $RawStdErr

    $exitCode = $p.ExitCode
} catch {
    $exitCode = 1
}

if (Test-Path $RawStdOut) {
    Get-Content $RawStdOut -Encoding utf8 | Out-File $CmdOutputPath -Append -Encoding utf8
}

if (Test-Path $RawStdErr) {
    $err = Get-Content $RawStdErr -Encoding utf8
    if ($err -match '\S') {
        "" | Out-File $CmdOutputPath -Append
        "----- STDERR -----" | Out-File $CmdOutputPath -Append
        $err | Out-File $CmdOutputPath -Append
    }
}

$end = Get-Date

"" | Out-File $CmdOutputPath -Append
"----" | Out-File $CmdOutputPath -Append
("EndTime:  {0}" -f $end.ToString('o')) | Out-File $CmdOutputPath -Append
("ExitCode: {0}" -f $exitCode)          | Out-File $CmdOutputPath -Append

# ------------------------------------------------------------
# Copy output.txt if present
# ------------------------------------------------------------
if (Test-Path -LiteralPath $AgentOutputTxt) {
    Copy-Item $AgentOutputTxt $CopiedTxtPath -Force
    Write-UiLine ""
    Write-UiLine "Copied agent output.txt to: $CopiedTxtPath"
} else {
    Write-UiLine ""
    Write-UiLine "No agent output.txt found at: $AgentOutputTxt"
}

# ------------------------------------------------------------
# Save run info
# ------------------------------------------------------------
@(
    "RunStamp:      $RunStamp"
    "StartTime:     $($start.ToString('o'))"
    "EndTime:       $($end.ToString('o'))"
    "ExitCode:      $exitCode"
    "CmdOutputPath: $CmdOutputPath"
    "CollectedRoot: $CollectedRoot"
) | Out-File -FilePath $MetaPath -Encoding utf8 -Force

# ------------------------------------------------------------
# Display + Return to Launcher
# ------------------------------------------------------------
if (-not $Silent -and -not $ExportOnly) {

    Write-Host ""
    Write-Host "================= Command Output ================="
    Write-Host ""

    $lines = Get-Content -LiteralPath $CmdOutputPath -Encoding utf8 -ErrorAction SilentlyContinue
    foreach ($l in $lines) {
        Write-Host (Get-CleanScreenLine $l)
    }

    Write-Host ""
    Write-Host "Saved command output: $CmdOutputPath"
    Write-Host "Saved run info:       $MetaPath"
    Write-Host ("Exit code: {0}" -f $exitCode)
    Write-Host ""
    Write-Host "Press Enter to return to CS Toolbox..."

    [void](Read-Host)

    # Restore whatever the launcher had set (colors/title), THEN clear and relaunch
    Restore-ConsoleState -State $ConsoleState
    Clear-Host

    if (Test-Path $LauncherPath) {
        & $LauncherPath
    }
}

exit $exitCode