#requires -version 5.1
#requires -version 5.1
# ---- Standard output directory bootstrap----
$CS_OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
New-Item -Path $CS_OutRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null

# If the script already has -OutPath, only set a default when it's not provided.
# Set this file name per script (examples below).
if (-not (Get-Variable OutPath -Scope Script -ErrorAction SilentlyContinue)) {
    # Script doesn't declare $OutPath: create it now with a default name.
    $Script:OutPath = Join-Path $CS_OutRoot 'AD-Computers_data.json'
}
elseif (-not $PSBoundParameters.ContainsKey('OutPath') -or [string]::IsNullOrWhiteSpace($OutPath)) {
    # Script declares -OutPath but caller didn't pass it: set default.
    $Script:OutPath = Join-Path $CS_OutRoot 'AD-Computers_data.json'
}

# Ensure the parent folder of the final path exists (covers custom -OutPath values too)
$__parent = Split-Path -Parent $OutPath
if ($__parent) { New-Item -Path $__parent -ItemType Directory -Force -ErrorAction Stop | Out-Null }
# ---- end standard block ----

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

function Write-ResultJson {
    param([hashtable]$Payload, [string]$Path)

    # Ensure parent folder exists
    $dir = Split-Path -Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    $Payload | ConvertTo-Json -Depth 5 -Compress |
        Out-File -FilePath $Path -Encoding UTF8

    try { $resolved = (Resolve-Path -Path $Path).Path } catch { $resolved = $Path }
    Write-Host ""
    Write-Host "JSON saved to: $resolved" -ForegroundColor Cyan
}

try {
    # Require RSAT/ActiveDirectory
    try { Import-Module ActiveDirectory -ErrorAction Stop } catch { throw "ActiveDirectory module not found. Install RSAT/AD tools." }

    $properties = @(
        "Name","DNSHostName","OperatingSystem","OperatingSystemVersion",
        "DistinguishedName","SamAccountName","Enabled","LastLogonTimestamp","LastLogonDate","Created","Modified",
        "LockedOut","PasswordExpired","PasswordLastSet","PasswordNeverExpires","PasswordNotRequired"
    )

    # Context for header
    $domain = (Get-ADDomain).DNSRoot
    $forest = (Get-ADForest).Name

    # Enumerate computers
    $adComputers = foreach ($comp in Get-ADComputer -Filter '*' -Properties $properties) {
        if ($null -eq $comp) { continue }

        # Safe formatting helpers
        $llts = ""
        if (($null -ne $comp.LastLogonTimestamp) -and ($comp.LastLogonTimestamp -ne 0)) {
            $llts = [datetime]::FromFileTime($comp.LastLogonTimestamp).ToString("dd-MM-yyyy HH:mm:ss")
        }

        $lld = ""
        if ($null -ne $comp.LastLogonDate -and $comp.LastLogonDate -ne "") {
            $lld = ($comp.LastLogonDate).ToString("dd-MM-yyyy HH:mm:ss")
        }

        $pls = ""
        if ($null -ne $comp.PasswordLastSet -and $comp.PasswordLastSet -ne "") {
            $pls = ($comp.PasswordLastSet).ToString("dd-MM-yyyy HH:mm:ss")
        }

        [pscustomobject][ordered]@{
            name                   = $comp.Name
            domain                 = $domain
            dnsHostName            = if ($null -eq $comp.DNSHostName) { "" } else { $comp.DNSHostName }
            osname                 = $comp.OperatingSystem
            OperatingSystemVersion = $comp.OperatingSystemVersion
            lastLogonTimestamp     = $llts
            lastLogonDate          = $lld
            distinguishedName      = $comp.DistinguishedName
            samAccountName         = $comp.SamAccountName
            enabled                = $comp.Enabled
            whenCreated            = ($comp.Created).ToString("dd-MM-yyyy HH:mm:ss")
            whenModified           = ($comp.Modified).ToString("dd-MM-yyyy HH:mm:ss")
            lockedOut              = $comp.LockedOut
            passwordExpired        = $comp.PasswordExpired
            passwordLastSet        = $pls
            passwordNeverExpires   = $comp.PasswordNeverExpires
            passwordNotRequired    = $comp.PasswordNotRequired
        }
    }

    $count = ($adComputers | Measure-Object).Count

    # On-screen summary + table (include DN path for clarity)
    Write-Host ""
    Write-Host ("Discovered {0} computer account(s)  |  Domain: {1}  |  Forest: {2}" -f $count, $domain, $forest) -ForegroundColor Green

    $adComputers |
        Select-Object name, dnsHostName, osname, OperatingSystemVersion, enabled, lastLogonDate, distinguishedName |
        Sort-Object osname, name |
        Format-Table -Wrap -AutoSize

    # Persist and echo path
    $payloadOk = @{
        status = $true
        domain = $domain
        forest = $forest
        count  = $count
        data   = $adComputers
    }
    Write-ResultJson -Payload $payloadOk -Path $OutPath
}
catch {
    $err = $_
    Write-Warning $err.Exception.Message

    $payloadFail = @{
        status     = $false
        msg        = $err.Exception.Message
        stackTrace = ($err | Out-String)
    }

    try {
        Write-ResultJson -Payload $payloadFail -Path $OutPath
    } catch {
        Write-Host ""
        Write-Host "Failed to write JSON to: $OutPath" -ForegroundColor Red
        Write-Host ($payloadFail | ConvertTo-Json -Depth 5) -ForegroundColor Yellow
    }
}