#requires -version 5.1
[CmdletBinding()]
param(
  [string]$Endpoint = 'http://10.0.0.238:9000',
  [string]$Bucket   = 'cs-test-bucket',
  [string]$Region   = 'us-east-1',

  [string]$ScanPath = 'C:\CS-Toolbox-TEMP\ZIP',

  [string]$Ticket,     # used ONLY to fill missing tickets (no prompting if supplied)
  [string]$Company,

  [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------------
# Logging
# ---------------------------
$LogRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$LogPath = Join-Path $LogRoot 'secure-upload.log'
New-Item -ItemType Directory -Path $LogRoot -Force | Out-Null

function Write-LogLine {
  param([string]$Level,[string]$Message)
  $line = "[{0}] {1} {2}" -f $Level, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
  Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8

  if (-not $ExportOnly) {
    switch ($Level) {
      'ERROR' { Write-Host $line -ForegroundColor Red }
      'WARN'  { Write-Host $line -ForegroundColor Yellow }
      'OK'    { Write-Host $line -ForegroundColor Green }
      default { Write-Host $line -ForegroundColor Gray }
    }
  }
}

function Fail([string]$Message) {
  Write-LogLine 'ERROR' $Message
  throw $Message
}

# ---------------------------
# Helpers
# ---------------------------
function Test-EndpointReachable([string]$Url) {
  try { $u = [Uri]$Url } catch { return $false }

  $hostName = $u.Host
  $port = if ($u.IsDefaultPort) { if ($u.Scheme -eq 'https') { 443 } else { 80 } } else { $u.Port }

  try {
    $client = New-Object System.Net.Sockets.TcpClient
    $iar = $client.BeginConnect($hostName, $port, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds(2))
    if ($ok -and $client.Connected) { $client.EndConnect($iar) | Out-Null; $client.Close(); return $true }
    $client.Close()
    return $false
  } catch { return $false }
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N2} {1}" -f $size, $u) }
  }
  return ("{0:N2} PB" -f ($bytes / [math]::Pow(2,50)))
}

# Ticket rule:
# any number sequence AFTER _YYYYMMDD_HHMMSS_ is the ticket (first digit run after timestamp)
function Get-TicketFromFileName([string]$Name) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)
  $m = [regex]::Match($base, '_\d{8}_\d{6}_[^0-9]*?(\d+)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}

function Resolve-Creds {
  # REQUIRED: only use these env vars (no prompting)
  $ak = $env:AWS_ACCESS_KEY_ID
  $sk = $env:AWS_SECRET_ACCESS_KEY

  if ([string]::IsNullOrWhiteSpace($ak) -or [string]::IsNullOrWhiteSpace($sk)) {
    Fail "Missing required environment variables AWS_ACCESS_KEY_ID and/or AWS_SECRET_ACCESS_KEY. Secure upload cannot continue."
  }

  return @{ AccessKey=$ak; SecretKey=$sk }
}

function HmacSHA256([byte[]]$key,[byte[]]$data){
  $h = New-Object System.Security.Cryptography.HMACSHA256(,$key)
  try { return $h.ComputeHash($data) } finally { $h.Dispose() }
}
function SHA256Hex([byte[]]$data){
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $hash = $sha.ComputeHash($data)
    return ([BitConverter]::ToString($hash) -replace '-','').ToLowerInvariant()
  } finally { $sha.Dispose() }
}
function ToHexLower([byte[]]$b){ return ([BitConverter]::ToString($b) -replace '-','').ToLowerInvariant() }

function Get-AwsV4Signature {
  param(
    [Parameter(Mandatory)][string]$Method,
    [Parameter(Mandatory)][Uri]$EndpointUri,
    [Parameter(Mandatory)][string]$Bucket,
    [Parameter(Mandatory)][string]$ObjectKey,
    [Parameter(Mandatory)][string]$Region,
    [Parameter(Mandatory)][string]$AccessKey,
    [Parameter(Mandatory)][string]$SecretKey,
    [Parameter(Mandatory)][string]$PayloadHashHex,
    [Parameter(Mandatory)][string]$AmzDate,
    [Parameter(Mandatory)][string]$DateStamp
  )

  # Path-style canonical URI (MinIO supports this well)
  $canonicalUri = "/$Bucket/$ObjectKey"

  $hostHeader = if ($EndpointUri.IsDefaultPort) { $EndpointUri.Host } else { "{0}:{1}" -f $EndpointUri.Host, $EndpointUri.Port }

  $canonicalHeaders = "host:$hostHeader`n" +
                      "x-amz-content-sha256:$PayloadHashHex`n" +
                      "x-amz-date:$AmzDate`n"
  $signedHeaders = "host;x-amz-content-sha256;x-amz-date"

  $canonicalRequest = ($Method.ToUpper(), $canonicalUri, "", $canonicalHeaders, $signedHeaders, $PayloadHashHex) -join "`n"
  $canonicalRequestHash = SHA256Hex([Text.Encoding]::UTF8.GetBytes($canonicalRequest))

  $service = "s3"
  $credentialScope = "$DateStamp/$Region/$service/aws4_request"
  $stringToSign = ("AWS4-HMAC-SHA256", $AmzDate, $credentialScope, $canonicalRequestHash) -join "`n"

  $kSecret  = [Text.Encoding]::UTF8.GetBytes("AWS4$SecretKey")
  $kDate    = HmacSHA256 $kSecret  ([Text.Encoding]::UTF8.GetBytes($DateStamp))
  $kRegion  = HmacSHA256 $kDate    ([Text.Encoding]::UTF8.GetBytes($Region))
  $kService = HmacSHA256 $kRegion  ([Text.Encoding]::UTF8.GetBytes($service))
  $kSign    = HmacSHA256 $kService ([Text.Encoding]::UTF8.GetBytes("aws4_request"))

  $sigBytes = HmacSHA256 $kSign ([Text.Encoding]::UTF8.GetBytes($stringToSign))
  $signature = ToHexLower $sigBytes

  $authHeader = "AWS4-HMAC-SHA256 Credential=$AccessKey/$credentialScope, SignedHeaders=$signedHeaders, Signature=$signature"

  return @{
    Host = $hostHeader
    Authorization = $authHeader
  }
}

function Upload-FileMinio {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][Uri]$EndpointUri,
    [Parameter(Mandatory)][string]$Bucket,
    [Parameter(Mandatory)][string]$Region,
    [Parameter(Mandatory)][string]$AccessKey,
    [Parameter(Mandatory)][string]$SecretKey,
    [Parameter(Mandatory)][string]$ObjectKey
  )

  $bytes = [System.IO.File]::ReadAllBytes($FilePath)
  $payloadHash = SHA256Hex($bytes)

  $now = [DateTime]::UtcNow
  $amzDate   = $now.ToString("yyyyMMddTHHmmssZ")
  $dateStamp = $now.ToString("yyyyMMdd")

  $sig = Get-AwsV4Signature -Method "PUT" -EndpointUri $EndpointUri -Bucket $Bucket -ObjectKey $ObjectKey `
                            -Region $Region -AccessKey $AccessKey -SecretKey $SecretKey `
                            -PayloadHashHex $payloadHash -AmzDate $amzDate -DateStamp $dateStamp

  $hostPart = if ($EndpointUri.IsDefaultPort) { $EndpointUri.Host } else { "{0}:{1}" -f $EndpointUri.Host, $EndpointUri.Port }
  $url = "{0}://{1}/{2}/{3}" -f $EndpointUri.Scheme, $hostPart, $Bucket, $ObjectKey

  $headers = @{
    "Host" = $sig.Host
    "x-amz-date" = $amzDate
    "x-amz-content-sha256" = $payloadHash
    "Authorization" = $sig.Authorization
  }

  $resp = Invoke-WebRequest -Uri $url -Method Put -Headers $headers -Body $bytes -TimeoutSec 120 -UseBasicParsing
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Upload failed HTTP $($resp.StatusCode) $($resp.StatusDescription)"
  }
}

function Sanitize-ForKey([string]$s){
  if ([string]::IsNullOrWhiteSpace($s)) { return $null }
  $t = $s.Trim() -replace '[^\w\-\.]','-'
  $t = $t -replace '-{2,}','-'
  return $t.Trim('-')
}

# ---------------------------
# MAIN
# ---------------------------
try {
  Write-Host ""
  Write-Host "============================================================" -ForegroundColor Cyan
  Write-Host "  ConnectSecure - Secure File Upload (MinIO PUT Test) v1.7" -ForegroundColor Cyan
  Write-Host "============================================================" -ForegroundColor Cyan
  Write-Host ""

  # Optional: wrapper can provide these
  $singleBundle = $env:CS_SECURE_UPLOAD_BUNDLE
  if ([string]::IsNullOrWhiteSpace($Company)) { $Company = $env:CS_SECURE_UPLOAD_COMPANY }
  if ([string]::IsNullOrWhiteSpace($Ticket))  { $Ticket  = $env:CS_SECURE_UPLOAD_TICKET }

  $endpointUri = [Uri]$Endpoint

  if (Test-EndpointReachable -Url $Endpoint) {
    Write-Host ("Endpoint Reachable: OK ({0}:{1})" -f $endpointUri.Host, $endpointUri.Port) -ForegroundColor Green
  } else {
    Write-Host ("Endpoint Reachable: FAIL ({0}:{1})" -f $endpointUri.Host, $endpointUri.Port) -ForegroundColor Red
  }

  Write-Host ("Endpoint: {0}" -f $Endpoint)
  Write-Host ("Bucket  : {0}" -f $Bucket)
  Write-Host ("Region  : {0}" -f $Region)
  Write-Host ""

  if (-not [string]::IsNullOrWhiteSpace($singleBundle)) {
    Write-Host "Scanning: (single bundle handoff)" -ForegroundColor Gray
  } else {
    Write-Host ("Scanning: {0}" -f $ScanPath) -ForegroundColor Gray
  }
  Write-Host ""

  # ONLY .csb files
  $files = @()
  if (-not [string]::IsNullOrWhiteSpace($singleBundle)) {
    if (-not (Test-Path -LiteralPath $singleBundle)) { Fail "CS_SECURE_UPLOAD_BUNDLE was set but file not found: $singleBundle" }
    if ([System.IO.Path]::GetExtension($singleBundle).ToLowerInvariant() -ne '.csb') {
      Fail "CS_SECURE_UPLOAD_BUNDLE must point to a .csb file. Got: $singleBundle"
    }
    $files = @(Get-Item -LiteralPath $singleBundle -ErrorAction Stop)
  } else {
    if (-not (Test-Path -LiteralPath $ScanPath)) { Fail "Scan path not found: $ScanPath" }
    $files = @(Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.csb' -ErrorAction Stop)
  }

  if ($files.Count -eq 0) {
    Write-Host "No .csb files found to upload." -ForegroundColor Yellow
    Write-LogLine 'ERROR' "No .csb files found to upload."
    exit 1
  }

  Write-Host "Detected .csb files:" -ForegroundColor Yellow
  foreach ($f in $files) { Write-Host ("  - {0}" -f $f.Name) }
  Write-Host ""

  $totalBytes = ($files | Measure-Object -Property Length -Sum).Sum
  if ($null -eq $totalBytes) { $totalBytes = 0 }

  Write-Host ("Total files: {0}" -f $files.Count)
  Write-Host ("Total size : {0}" -f (Get-SizeHuman ([long]$totalBytes)))
  Write-Host ""

  # Per-file ticket map (do NOT require tickets to match)
  $det = foreach ($f in $files) {
    [pscustomobject]@{
      Name   = $f.Name
      Full   = $f.FullName
      Bytes  = $f.Length
      Ticket = (Get-TicketFromFileName -Name $f.Name)
    }
  }

  # Only ask if ANY missing a ticket. If Ticket param provided, use it for missing.
  $missing = @($det | Where-Object { [string]::IsNullOrWhiteSpace($_.Ticket) })
  if ($missing.Count -gt 0) {

    if (-not [string]::IsNullOrWhiteSpace($Ticket)) {
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      if (-not $ExportOnly) {
        Write-Host ("Applied provided ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count) -ForegroundColor Green
        Write-Host ""
      }
    } else {
      if ($ExportOnly) { Fail "Ticket missing for one or more .csb files, and no -Ticket provided." }

      Write-Host "Ticket detection results (missing found):" -ForegroundColor Yellow
      foreach ($r in $det) {
        $t = if ($r.Ticket) { $r.Ticket } else { "(none)" }
        Write-Host ("  {0}  ->  {1}" -f $r.Name, $t)
      }
      Write-Host ""

      do { $Ticket = (Read-Host "Enter ticket number for missing file(s)").Trim() }
      while ([string]::IsNullOrWhiteSpace($Ticket))

      foreach ($m in $missing) { $m.Ticket = $Ticket }

      Write-Host ("Applied entered ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count) -ForegroundColor Green
      Write-Host ""
    }
  }

  # Confirm upload (interactive only)
  if (-not $ExportOnly) {
    $confirm = (Read-Host "Upload ALL listed .csb files now? (Y/N)").Trim().ToUpperInvariant()
    if ($confirm -ne 'Y') {
      Write-LogLine 'WARN' "User cancelled upload."
      exit 0
    }
  }

  # Credentials (AWS_* only)
  $creds = Resolve-Creds
  $ak = $creds.AccessKey
  $sk = $creds.SecretKey

  $companyKey = Sanitize-ForKey $Company

  $failed = 0
  $uploaded = @()

  foreach ($r in $det) {
    try {
      if ([string]::IsNullOrWhiteSpace($r.Ticket)) { throw "Internal error: ticket still missing for $($r.Name)" }

      $safeName = ($r.Name -replace '[^\w\-\.\(\)\s]','_')
      $safeName = ($safeName -replace '\s+','_')

      # per-file ticket folder (tickets may differ across csb files)
      $prefix = if ($companyKey) { "$companyKey/$($r.Ticket)" } else { "$($r.Ticket)" }
      $objKey = "$prefix/$safeName"

      Write-LogLine 'INFO' ("Uploading: {0} -> s3://{1}/{2}" -f $r.Name, $Bucket, $objKey)
      Upload-FileMinio -FilePath $r.Full -EndpointUri ([Uri]$Endpoint) -Bucket $Bucket -Region $Region `
                       -AccessKey $ak -SecretKey $sk -ObjectKey $objKey

      Write-LogLine 'OK' ("Uploaded OK: {0}" -f $r.Name)
      $uploaded += [pscustomobject]@{ name=$r.Name; ticket=$r.Ticket; objectKey=$objKey; bytes=$r.Bytes }
    } catch {
      $failed++
      Write-LogLine 'ERROR' ("Upload FAILED: {0} :: {1}" -f $r.Name, $_.Exception.Message)
    }
  }

  if ($ExportOnly) {
    $summary = [pscustomobject]@{
      endpoint   = $Endpoint
      bucket     = $Bucket
      region     = $Region
      scanPath   = $ScanPath
      company    = $Company
      totalFiles = $det.Count
      totalBytes = [long]$totalBytes
      failed     = $failed
      uploaded   = $uploaded
      logPath    = $LogPath
      timestamp  = (Get-Date).ToString('s')
    }
    $jsonPath = Join-Path $LogRoot ("secure-upload-export_{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    ($summary | ConvertTo-Json -Depth 6) | Out-File -LiteralPath $jsonPath -Encoding UTF8
  }

  if ($failed -gt 0) {
    if (-not $ExportOnly) {
      Write-Host ""
      Write-Host "UPLOAD FAILED ($failed failure(s)). See log:" -ForegroundColor Red
      Write-Host "  $LogPath" -ForegroundColor Yellow
      Write-Host ""
    }
    exit 1
  }

  if (-not $ExportOnly) {
    Write-Host ""
    Write-Host "UPLOAD SUCCESS. All .csb files uploaded." -ForegroundColor Green
    Write-Host ""
  }
  exit 0
}
catch {
  Write-LogLine 'ERROR' $_.Exception.Message
  if (-not $ExportOnly) {
    Write-Host ""
    Write-Host "UPLOAD FAILED. See log:" -ForegroundColor Red
    Write-Host "  $LogPath" -ForegroundColor Yellow
    Write-Host ""
  }
  exit 1
}
