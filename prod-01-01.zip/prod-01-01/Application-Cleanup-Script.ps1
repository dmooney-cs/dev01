#Requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# =====================================================================
#  Application-Cleanup-Script.ps1  (vNext - Hardened logging)
#   - ALL logs:
#       C:\CS-Toolbox-TEMP\Collected-Info\AppCleanup
#   - Prompts include: "press enter after making selection"
#   - Fix: Write-Log no longer throws on empty strings
# =====================================================================

# ---------- Export / Log Root ----------
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AppCleanup'
if (-not (Test-Path -LiteralPath $ExportRoot)) {
    New-Item -ItemType Directory -Path $ExportRoot -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogPath = Join-Path $ExportRoot ("Application-Cleanup-Log_{0}.txt" -f $timestamp)

"============================================================" | Out-File -LiteralPath $script:LogPath -Encoding UTF8 -Force
"Application Cleanup Script Log - Started $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Add-Content -LiteralPath $script:LogPath
"Log file: $script:LogPath" | Add-Content -LiteralPath $script:LogPath
"Export root: $ExportRoot" | Add-Content -LiteralPath $script:LogPath
"============================================================" | Add-Content -LiteralPath $script:LogPath

function Write-Ui {
    param(
        [Parameter(Mandatory)][string]$Message,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Gray
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Blank {
    # Blank line to screen + log
    Write-Host ""
    Add-Content -LiteralPath $script:LogPath -Value ""
}

function Write-Log {
    [CmdletBinding()]
    param(
        [Parameter()][AllowEmptyString()][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','STEP','DEBUG')][string]$Level = 'INFO',
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Gray
    )

    # Never throw for empty strings; treat as a blank line
    if ($null -eq $Message -or $Message.Trim().Length -eq 0) {
        Write-Blank
        return
    }

    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[{0}] [{1}] {2}" -f $ts, $Level, $Message

    Write-Ui -Message $Message -Color $Color
    Add-Content -LiteralPath $script:LogPath -Value $line
}

function Show-Header {
    param([Parameter(Mandatory)][string]$Title)
    Write-Log '============================================================' 'STEP' 'Cyan'
    Write-Log ("  {0}" -f $Title) 'STEP' 'Cyan'
    Write-Log '============================================================' 'STEP' 'Cyan'
}

function Read-Choice {
    param(
        [Parameter(Mandatory)][string]$Prompt,
        [Parameter(Mandatory)][string[]]$ValidInputs
    )

    while ($true) {
        Write-Blank
        $p = "{0} (press enter after making selection)" -f $Prompt
        $inputVal = Read-Host $p

        if ($ValidInputs -contains $inputVal) {
            Write-Log ("User input for '{0}': {1}" -f $Prompt, $inputVal) 'DEBUG' 'DarkGray'
            return $inputVal
        }

        Write-Log ("Invalid input '{0}'. Valid options: {1}" -f $inputVal, ($ValidInputs -join ', ')) 'WARN' 'Yellow'
        Write-Ui ("Invalid input. Valid options: {0}" -f ($ValidInputs -join ', ')) 'Yellow'
    }
}

function Read-FreeText {
    param([Parameter(Mandatory)][string]$Prompt)
    $p = "{0} (press enter after making selection)" -f $Prompt
    $val = Read-Host $p
    Write-Log ("User input for '{0}': {1}" -f $Prompt, $val) 'DEBUG' 'DarkGray'
    return $val
}

function Show-LiabilityWarning {
    [CmdletBinding()]
    param([string]$Context = 'General')

    $header = switch ($Context) {
        'StartupPrompt'  { 'IMPORTANT NOTICE – Application Removal Tool' }
        'PreUninstall'   { 'IMPORTANT NOTICE – Application Uninstall' }
        'DeleteFiles'    { 'IMPORTANT NOTICE – File/Folder Deletion' }
        'DeleteRegistry' { 'IMPORTANT NOTICE – Registry Key Deletion' }
        default          { 'IMPORTANT NOTICE' }
    }

    Write-Log $header 'WARN' 'Yellow'

    $lines = @(
        'This tool can permanently uninstall software and delete files and registry keys.',
        'It is intended for use by qualified ConnectSecure partners/technicians only.',
        'By continuing, you confirm that you:',
        '  - Have verified you are targeting the correct system and application(s),',
        '  - Have taken appropriate backups or snapshots, and',
        '  - Accept all risk, including data loss, downtime, or misconfiguration.',
        'ConnectSecure and its affiliates accept NO responsibility or liability for any',
        'impact resulting from the execution or misuse of this tool. You, as the partner',
        'or user executing these commands, are fully responsible for the outcome.'
    )
    foreach ($l in $lines) { Write-Log $l 'WARN' 'Yellow' }

    if ($Context -eq 'StartupPrompt') {
        return (Read-Choice -Prompt "Type Y to confirm you understand and accept these risks, or N to exit (Y/N)" -ValidInputs @('Y','N'))
    }
}

function Get-UninstallRegistryItems {
    [CmdletBinding()]
    param()

    Write-Log "Collecting uninstall registry items..." 'INFO' 'Gray'

    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    $items = @()

    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) {
            Write-Log "Uninstall key path not found: $path" 'DEBUG' 'DarkGray'
            continue
        }

        Get-ChildItem -LiteralPath $path | ForEach-Object {
            $keyPath = $_.PSPath
            try { $props = Get-ItemProperty -LiteralPath $keyPath -ErrorAction Stop }
            catch {
                Write-Log ("Failed to read uninstall key: {0} - {1}" -f $keyPath, $_.Exception.Message) 'WARN' 'Yellow'
                return
            }

            $nameProp = $props.PSObject.Properties['DisplayName']
            if (-not $nameProp -or -not $nameProp.Value) { return }
            $name = [string]$nameProp.Value

            $verProp    = $props.PSObject.Properties['DisplayVersion']
            $pubProp    = $props.PSObject.Properties['Publisher']
            $locProp    = $props.PSObject.Properties['InstallLocation']
            $uninstProp = $props.PSObject.Properties['UninstallString']

            $ver    = if ($verProp)    { [string]$verProp.Value }    else { $null }
            $pub    = if ($pubProp)    { [string]$pubProp.Value }    else { $null }
            $loc    = if ($locProp)    { [string]$locProp.Value }    else { $null }
            $uninst = if ($uninstProp) { [string]$uninstProp.Value } else { $null }

            $key = $_.PSChildName

            $isGuidPattern = '^\{?[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}?$'
            $isGuidKey     = $false
            if ($key -and ($key -match $isGuidPattern)) { $isGuidKey = $true }

            $isMsi = $false
            if ($isGuidKey -or ($uninst -and ($uninst -match 'msiexec\.exe'))) { $isMsi = $true }

            $productCode = $null
            if ($isGuidKey) { $productCode = $key }
            elseif ($uninst -and ($uninst -match '\{[0-9A-Fa-f-]{36}\}')) { $productCode = $matches[0] }

            $items += [PSCustomObject]@{
                Name            = $name
                DisplayName     = $name
                DisplayVersion  = $ver
                Publisher       = $pub
                InstallLocation = $loc
                UninstallString = $uninst
                ProductCode     = $productCode
                IsMsi           = $isMsi
                RegistryPath    = $keyPath
                RegistryKey     = $key
            }
        }
    }

    Write-Log ("Found {0} uninstall entries." -f $items.Count) 'INFO' 'Gray'
    return $items
}

function Get-AppSelectionFromAll {
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject[]]$Apps)

    $apps = @($Apps | Sort-Object Name)
    if ($apps.Count -eq 0) { Write-Log "No installed applications found." 'WARN' 'Yellow'; return $null }

    Show-Header "All installed applications"
    Write-Log ("Listing {0} applications." -f $apps.Count) 'INFO' 'Gray'
    Write-Blank

    $index = 1
    foreach ($app in $apps) {
        $ver = if ($app.DisplayVersion) { $app.DisplayVersion } else { 'N/A' }
        $pub = if ($app.Publisher)      { $app.Publisher }      else { 'N/A' }

        Write-Log ("[{0}] {1}" -f $index, $app.Name) 'INFO' 'White'
        Write-Log ("     Version  : {0}" -f $ver) 'INFO' 'DarkGray'
        Write-Log ("     Publisher: {0}" -f $pub) 'INFO' 'DarkGray'
        if ($app.ProductCode) { Write-Log ("     Product  : {0}" -f $app.ProductCode) 'DEBUG' 'DarkGray' }
        elseif ($app.UninstallString) { Write-Log ("     Uninst   : {0}" -f $app.UninstallString) 'DEBUG' 'DarkGray' }
        Write-Blank
        $index++
    }

    $valid = @('Q'); for ($i=1; $i -le $apps.Count; $i++) { $valid += $i.ToString() }
    $choice = Read-Choice -Prompt "Select application number or Q to go back" -ValidInputs $valid
    if ($choice -eq 'Q') { Write-Log "User returned to main menu from list-all view." 'INFO' 'Gray'; return $null }

    $selected = $apps[[int]$choice - 1]
    Write-Log ("User selected application from full list: {0}" -f $selected.Name) 'INFO' 'Green'
    return $selected
}

function Get-AppSelectionFromSearch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][psobject[]]$Apps,
        [Parameter(Mandatory)][string]$SearchTerm
    )

    $matches = @($Apps | Where-Object { $_.Name -like ("*" + $SearchTerm + "*") } | Sort-Object Name)
    if ($matches.Count -eq 0) { Write-Log ("No applications matched search term '{0}'." -f $SearchTerm) 'WARN' 'Yellow'; return $null }

    Show-Header ("Matches for '{0}'" -f $SearchTerm)
    Write-Log ("Search term '{0}' returned {1} matches." -f $SearchTerm, $matches.Count) 'INFO' 'Gray'
    Write-Blank

    $index = 1
    foreach ($app in $matches) {
        $ver = if ($app.DisplayVersion) { $app.DisplayVersion } else { 'N/A' }
        $pub = if ($app.Publisher)      { $app.Publisher }      else { 'N/A' }

        Write-Log ("[{0}] {1}" -f $index, $app.Name) 'INFO' 'White'
        Write-Log ("     Version  : {0}" -f $ver) 'INFO' 'DarkGray'
        Write-Log ("     Publisher: {0}" -f $pub) 'INFO' 'DarkGray'
        if ($app.ProductCode) { Write-Log ("     Product  : {0}" -f $app.ProductCode) 'DEBUG' 'DarkGray' }
        elseif ($app.UninstallString) { Write-Log ("     Uninst   : {0}" -f $app.UninstallString) 'DEBUG' 'DarkGray' }
        Write-Blank
        $index++
    }

    $valid = @('Q'); for ($i=1; $i -le $matches.Count; $i++) { $valid += $i.ToString() }
    $choice = Read-Choice -Prompt "Select application number or Q to go back" -ValidInputs $valid
    if ($choice -eq 'Q') { Write-Log "User returned to main menu from search view." 'INFO' 'Gray'; return $null }

    $selected = $matches[[int]$choice - 1]
    Write-Log ("User selected application from search: {0}" -f $selected.Name) 'INFO' 'Green'
    return $selected
}

function Select-AppInteractive {
    [CmdletBinding()] param()

    $apps = @(Get-UninstallRegistryItems)
    if ($apps.Count -eq 0) { Write-Log "No installed applications found to select from." 'WARN' 'Yellow'; return $null }

    while ($true) {
        Show-Header "Application Selection Menu"
        Write-Log "1) List ALL installed applications" 'INFO' 'White'
        Write-Log "2) Search for application by name"  'INFO' 'White'
        Write-Log "Q) Quit"                            'INFO' 'White'

        $choice = Read-Choice -Prompt "Select option (1/2/Q)" -ValidInputs @('1','2','Q')
        switch ($choice) {
            '1' { $sel = Get-AppSelectionFromAll -Apps $apps; if ($sel) { return $sel } }
            '2' {
                $search = Read-FreeText -Prompt "Enter part of the application name to search for"
                if ([string]::IsNullOrWhiteSpace($search)) { Write-Log "Empty search term entered; returning to menu." 'WARN' 'Yellow' }
                else { $sel = Get-AppSelectionFromSearch -Apps $apps -SearchTerm $search; if ($sel) { return $sel } }
            }
            'Q' { Write-Log "User chose to quit from main menu." 'INFO' 'Gray'; return $null }
        }
    }
}

function Stop-AppServices {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$AppName)

    Show-Header ("Step 1: Stopping services related to '{0}'" -f $AppName)

    $services = @(Get-Service -ErrorAction SilentlyContinue | Where-Object {
        $_.DisplayName -like ("*" + $AppName + "*") -or $_.Name -like ("*" + $AppName + "*")
    })

    if ($services.Count -eq 0) { Write-Log ("No services found matching '{0}'." -f $AppName) 'INFO' 'Gray'; return }

    Write-Log ("Found {0} matching service(s)." -f $services.Count) 'INFO' 'Gray'

    foreach ($svc in $services) {
        Write-Log ("Stopping service: {0} ({1}) - Status: {2}" -f $svc.DisplayName, $svc.Name, $svc.Status) 'INFO' 'Gray'
        if ($svc.Status -ne 'Stopped') {
            try {
                Stop-Service -Name $svc.Name -Force -ErrorAction Stop
                $svc.WaitForStatus('Stopped', (New-TimeSpan -Seconds 30))
                Write-Log ("Service stopped: {0}" -f $svc.Name) 'INFO' 'Green'
            } catch {
                Write-Log ("Failed to stop service {0}: {1}" -f $svc.Name, $_.Exception.Message) 'ERROR' 'Red'
            }
        } else {
            Write-Log ("Service already stopped: {0}" -f $svc.Name) 'INFO' 'DarkGray'
        }
    }
}

function Invoke-AppUninstall {
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject]$App)

    Show-Header ("Step 2: Running uninstall for '{0}'" -f $App.Name)
    Show-LiabilityWarning -Context 'PreUninstall' | Out-Null

    if ($App.ProductCode -and $App.IsMsi) {
        Write-Log ("Detected MSI ProductCode: {0}" -f $App.ProductCode) 'INFO' 'Gray'
        $args = "/x$($App.ProductCode) /qn /norestart"
        Write-Log ("Running: msiexec.exe {0}" -f $args) 'INFO' 'Gray'
        try {
            $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $args -Wait -PassThru -ErrorAction Stop
            Write-Log ("msiexec exit code: {0}" -f $proc.ExitCode) 'INFO' 'Gray'
        } catch {
            Write-Log ("Uninstall failed for {0}: {1}" -f $App.Name, $_.Exception.Message) 'ERROR' 'Red'
        }
        return
    }

    if ($App.UninstallString) {
        Write-Log "No MSI ProductCode, falling back to stored UninstallString." 'INFO' 'Gray'
        Write-Log ("UninstallString: {0}" -f $App.UninstallString) 'DEBUG' 'DarkGray'

        $un = $App.UninstallString.Trim()
        $exe = $un
        $args = ''

        if ($un.StartsWith('"')) {
            $secondQuote = $un.IndexOf('"', 1)
            if ($secondQuote -gt 0) {
                $exe = $un.Substring(1, $secondQuote - 1)
                if ($un.Length -gt ($secondQuote + 1)) { $args = $un.Substring($secondQuote + 1).Trim() }
            }
        } else {
            $firstSpace = $un.IndexOf(' ')
            if ($firstSpace -gt 0) {
                $exe = $un.Substring(0, $firstSpace)
                $args = $un.Substring($firstSpace + 1).Trim()
            }
        }

        Write-Log ("Executing uninstall: exe={0} args={1}" -f $exe, $args) 'INFO' 'Gray'
        try {
            if ($args) { Start-Process -FilePath $exe -ArgumentList $args -Wait -ErrorAction Stop }
            else { Start-Process -FilePath $exe -Wait -ErrorAction Stop }
            Write-Log ("Uninstall command completed for {0}." -f $App.Name) 'INFO' 'Green'
        } catch {
            Write-Log ("Uninstall command failed for {0}: {1}" -f $App.Name, $_.Exception.Message) 'ERROR' 'Red'
        }
        return
    }

    Write-Log ("No uninstall information found for application {0}." -f $App.Name) 'WARN' 'Yellow'
}

function Remove-AppFiles {
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject]$App)

    Show-Header "Step 3: Removing leftover files"
    Show-LiabilityWarning -Context 'DeleteFiles' | Out-Null

    $basePath = $null
    if ($App.InstallLocation -and (Test-Path -LiteralPath $App.InstallLocation)) { $basePath = $App.InstallLocation }
    else {
        $guess = Join-Path "C:\Program Files (x86)" $App.Name
        if (Test-Path -LiteralPath $guess) { $basePath = $guess }
    }

    if (-not $basePath) { Write-Log ("No valid installation path found to remove for {0}." -f $App.Name) 'WARN' 'Yellow'; return }

    Write-Log ("Detected install/leftover path: {0}" -f $basePath) 'INFO' 'Gray'
    $confirm = Read-Choice -Prompt "Delete this folder and ALL contents? (Y/N)" -ValidInputs @('Y','N')
    if ($confirm -ne 'Y') { Write-Log ("User declined deletion of folder: {0}" -f $basePath) 'INFO' 'Yellow'; return }

    Write-Log ("User confirmed deletion of folder: {0}" -f $basePath) 'INFO' 'Gray'

    try {
        $items = @(Get-ChildItem -LiteralPath $basePath -Recurse -Force -ErrorAction SilentlyContinue)
        Write-Log ("Listing {0} item(s) scheduled for deletion under: {1}" -f $items.Count, $basePath) 'INFO' 'Gray'
        foreach ($it in $items) { Write-Log ("Deleting: {0}" -f $it.FullName) 'DEBUG' 'DarkGray' }
    } catch {
        Write-Log ("Failed to enumerate files under {0} before deletion: {1}" -f $basePath, $_.Exception.Message) 'WARN' 'Yellow'
    }

    try {
        Remove-Item -LiteralPath $basePath -Recurse -Force -ErrorAction Stop
        Write-Log ("Folder removed: {0}" -f $basePath) 'INFO' 'Green'
    } catch {
        Write-Log ("Failed to remove folder {0}: {1}" -f $basePath, $_.Exception.Message) 'ERROR' 'Red'
    }
}

function Remove-AppRegistryKey {
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject]$App)

    Show-Header "Step 4: Removing uninstall registry key (optional)"
    Show-LiabilityWarning -Context 'DeleteRegistry' | Out-Null

    $targets = @()
    if ($App.ProductCode) {
        $codeNoBraces = $App.ProductCode.Trim('{}')
        $targets += ('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{0}' -f $codeNoBraces)
        $targets += ('HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{0}' -f $codeNoBraces)
    }
    if ($targets.Count -eq 0) {
        if ($App.RegistryPath) { $targets += $App.RegistryPath }
        else { Write-Log ("No registry key identified for app {0}." -f $App.Name) 'WARN' 'Yellow'; return }
    }

    foreach ($path in $targets) {
        if (Test-Path -LiteralPath $path) {
            Write-Log ("Found uninstall registry key: {0}" -f $path) 'INFO' 'Gray'
            $ans = Read-Choice -Prompt "Remove this registry key? (Y/N)" -ValidInputs @('Y','N')
            if ($ans -eq 'Y') {
                try {
                    Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop
                    Write-Log ("Registry key removed: {0}" -f $path) 'INFO' 'Green'
                } catch {
                    Write-Log ("Failed to remove registry key {0}: {1}" -f $path, $_.Exception.Message) 'ERROR' 'Red'
                }
            } else {
                Write-Log ("User skipped registry key removal: {0}" -f $path) 'INFO' 'Yellow'
            }
        } else {
            Write-Log ("Registry key path not found (skipped): {0}" -f $path) 'DEBUG' 'DarkGray'
        }
    }
}

function Confirm-AppRemoved {
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject]$App)

    Show-Header "Step 5: Confirming removal"

    $stillThere = @(Get-UninstallRegistryItems | Where-Object { $_.Name -eq $App.Name })
    if ($stillThere.Count -gt 0) {
        Write-Log ("Application still present in uninstall registry entries for {0}:" -f $App.Name) 'WARN' 'Yellow'
        foreach ($item in $stillThere) { Write-Log ("  - {0}  (Version: {1})" -f $item.Name, $item.DisplayVersion) 'WARN' 'Yellow' }
    } else {
        Write-Log ("No registry uninstall entries remain for application {0}." -f $App.Name) 'INFO' 'Green'
    }

    Write-Blank
    $doWmi = Read-Choice -Prompt "Also check Win32_Product (may be slow)? (Y/N)" -ValidInputs @('Y','N')
    if ($doWmi -ne 'Y') { Write-Log "User skipped Win32_Product verification." 'INFO' 'Gray'; return }

    Write-Log "Running Win32_Product verification..." 'INFO' 'Gray'
    try {
        $wmi = @(Get-WmiObject -Class Win32_Product -ErrorAction Stop | Where-Object { $_.Name -like ("*" + $App.Name + "*") })
        if ($wmi.Count -gt 0) {
            Write-Log ("Win32_Product still reports matching entries for {0}:" -f $App.Name) 'WARN' 'Yellow'
            foreach ($w in $wmi) { Write-Log ("  - {0}  (Version: {1})" -f $w.Name, $w.Version) 'WARN' 'Yellow' }
        } else {
            Write-Log ("Win32_Product reports no matching entries for {0}." -f $App.Name) 'INFO' 'Green'
        }
    } catch {
        Write-Log ("Win32_Product check failed: {0}" -f $_.Exception.Message) 'ERROR' 'Red'
    }
}

# ---------------- MAIN ----------------
Clear-Host
Show-Header "Application Search & Clean Uninstaller"
Write-Log "Script started." 'INFO' 'Gray'
Write-Log ("Logging to: {0}" -f $script:LogPath) 'INFO' 'Gray'
Write-Blank

$startupConsent = Show-LiabilityWarning -Context 'StartupPrompt'
if ($startupConsent -ne 'Y') {
    Write-Log "User declined startup liability warning. Exiting." 'WARN' 'Yellow'
    Write-Blank
    Write-Log ("Log written to: {0}" -f $script:LogPath) 'INFO' 'Cyan'
    return
}

$app = Select-AppInteractive
if (-not $app) {
    Write-Log "No application selected from main menu. Exiting." 'WARN' 'Yellow'
    Write-Blank
    Write-Log ("Log written to: {0}" -f $script:LogPath) 'INFO' 'Cyan'
    return
}

Show-Header "Selected Application"
Write-Log ("Name     : {0}" -f $app.Name) 'INFO' 'White'
Write-Log ("Version  : {0}" -f ($app.DisplayVersion  -as [string])) 'INFO' 'White'
Write-Log ("Publisher: {0}" -f ($app.Publisher       -as [string])) 'INFO' 'White'
Write-Log ("Location : {0}" -f ($app.InstallLocation -as [string])) 'INFO' 'White'
Write-Log ("Product  : {0}" -f ($app.ProductCode     -as [string])) 'INFO' 'White'

Write-Blank
$proceed = Read-Choice -Prompt "Proceed with FULL removal steps for this application? (Y/N)" -ValidInputs @('Y','N')
if ($proceed -ne 'Y') {
    Write-Log "User cancelled full removal steps." 'WARN' 'Yellow'
    Write-Blank
    Write-Log ("Log written to: {0}" -f $script:LogPath) 'INFO' 'Cyan'
    return
}

Write-Log ("Beginning removal sequence for application: {0}" -f $app.Name) 'STEP' 'Cyan'

Stop-AppServices      -AppName $app.Name
Invoke-AppUninstall   -App $app
Remove-AppFiles       -App $app
Remove-AppRegistryKey -App $app
Confirm-AppRemoved    -App $app

Write-Blank
Write-Log ("All steps completed for application: {0}" -f $app.Name) 'STEP' 'Cyan'
Write-Log "Script completed." 'INFO' 'Gray'
Write-Blank
Write-Log ("All steps completed. Log written to: {0}" -f $script:LogPath) 'INFO' 'Cyan'