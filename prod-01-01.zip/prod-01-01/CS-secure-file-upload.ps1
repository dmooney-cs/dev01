#requires -version 5.1
[CmdletBinding()]
param(
  # ---------------------------
  # Azure Blob (container URL)
  # ---------------------------
  [string]$CsAzurePutBaseUrl = 'https://cssupport1.blob.core.windows.net/uploadlogs',

  # Optional extra headers: "Header1=Value1;Header2=Value2"
  [string]$CsAzurePutHeaders,

  # ---------------------------
  # Encrypted SAS blob source (GitHub raw URL)
  # NOTE: Script will NOT print or log this URL.
  # Private repos typically require env var CS_GITHUB_TOKEN.
  # ---------------------------
  [string]$SasBlobUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/secureupload_sas_blob.json',

  # ---------------------------
  # Inputs
  # ---------------------------
  [string]$ScanPath = 'C:\CS-Toolbox-TEMP\ZIP',

  [Alias('t')]
  [string]$Ticket,     # used ONLY to fill missing tickets

  [string]$Company,

  # ---------------------------
  # Controls
  # ---------------------------
  [switch]$Zip,        # also include .zip files in upload set (in addition to .csb)
  [switch]$Silent,     # no prompts; minimal/no console output (still logs)
  [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Silent -or $ExportOnly) {
  $global:ProgressPreference    = 'SilentlyContinue'
  $global:VerbosePreference     = 'SilentlyContinue'
  $global:InformationPreference = 'SilentlyContinue'
  $global:WarningPreference     = 'SilentlyContinue'
  $global:DebugPreference       = 'SilentlyContinue'
  $global:ConfirmPreference     = 'None'
}

# ---------------------------
# Logging (file always)
# ---------------------------
$script:LogRootBase = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:LogRoot     = Join-Path $script:LogRootBase 'SecureUploadLog'
New-Item -ItemType Directory -Path $script:LogRoot -Force | Out-Null

$script:RunStamp     = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogPath      = Join-Path $script:LogRoot ("SecureUpload_{0}.log" -f $script:RunStamp)  # temp until finalized
$script:LogFinalized = $false

function Sanitize-FileToken([string]$s, [string]$fallback) {
  if ([string]::IsNullOrWhiteSpace($s)) { return $fallback }
  $t = $s.Trim()
  $t = ($t -replace '[^A-Za-z0-9\.\-_]','_')
  $t = ($t -replace '_{2,}','_').Trim('_')
  if ([string]::IsNullOrWhiteSpace($t)) { return $fallback }
  return $t
}

function Finalize-LogPath {
  param(
    [Parameter(Mandatory)][string]$DestinationTag,
    [string]$CompanyTag,
    [string]$TicketTag
  )
  if ($script:LogFinalized) { return }

  $dest  = Sanitize-FileToken $DestinationTag 'Azure'
  $comp  = Sanitize-FileToken $CompanyTag     'UnknownCompany'
  $tick  = Sanitize-FileToken $TicketTag      'Mixed'

  $finalName = "SecureUpload_{0}_{1}_{2}_{3}.log" -f $script:RunStamp, $dest, $comp, $tick
  $finalPath = Join-Path $script:LogRoot $finalName

  try {
    if ($script:LogPath -ne $finalPath) {
      if (Test-Path -LiteralPath $finalPath) { Remove-Item -LiteralPath $finalPath -Force -ErrorAction SilentlyContinue }
      Move-Item -LiteralPath $script:LogPath -Destination $finalPath -Force
      $script:LogPath = $finalPath
    }
  } catch {
    # keep temp path if rename fails
  }

  $script:LogFinalized = $true
}

function Write-LogLine {
  param(
    [string]$Level,
    [string]$Message,
    [switch]$NoConsole  # log only; do not show on screen
  )

  $line = "[{0}] {1} {2}" -f $Level, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8

  if (-not ($Silent -or $ExportOnly) -and -not $NoConsole) {
    switch ($Level) {
      'ERROR' { Write-Host $line -ForegroundColor Red }
      'WARN'  { Write-Host $line -ForegroundColor Yellow }
      'OK'    { Write-Host $line -ForegroundColor Green }
      default { Write-Host $line -ForegroundColor Gray }
    }
  }
}
function Fail([string]$Message) { Write-LogLine 'ERROR' $Message; throw $Message }

# ---------------------------
# Redaction (prevents SAS/token leaks in errors/logs)
# ---------------------------
function Sanitize-ErrorMessage([string]$s) {
  if ([string]::IsNullOrWhiteSpace($s)) { return $s }

  # Redact query strings (covers SAS in URLs)
  $s = [regex]::Replace($s, '\?[^ \r\n]+', '?REDACTED')

  # Redact common SAS fields if present without a URL
  $s = [regex]::Replace($s, '(?i)\b(sig|sp|se|st|spr|sv|sr)=([^&\s]+)', '$1=REDACTED')

  return $s
}

# ---------------------------
# Helpers
# ---------------------------
function Invoke-RetrySilent {
  param([Parameter(Mandatory)][scriptblock]$Action,[int]$Attempts=3,[int]$PauseSeconds=1)
  $last = $null
  for ($i=1; $i -le $Attempts; $i++) {
    try { & $Action; return $true }
    catch {
      $last = $_
      if ($i -lt $Attempts) { Start-Sleep -Seconds $PauseSeconds }
    }
  }
  if ($last) { throw $last.Exception }
  return $false
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N2} {1}" -f $size, $u) }
  }
  return ("{0:N2} PB" -f ($bytes / [math]::Pow(2,50)))
}

function Get-TicketFromFileName([string]$Name) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)
  $m = [regex]::Match($base, '_\d{8}_\d{6}_[^0-9]*?(\d+)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}

function Parse-HeaderStringToHashtable([string]$s) {
  $h = @{}
  if ([string]::IsNullOrWhiteSpace($s)) { return $h }
  $pairs = $s.Split(';') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
  foreach ($p in $pairs) {
    $idx = $p.IndexOf('=')
    if ($idx -gt 0) {
      $k = $p.Substring(0,$idx).Trim()
      $v = $p.Substring($idx+1).Trim()
      if ($k) { $h[$k] = $v }
    }
  }
  return $h
}

function Get-FileMD5 {
  param([Parameter(Mandatory)][string]$Path)
  $md5 = [System.Security.Cryptography.MD5]::Create()
  $fs = $null
  try {
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    $hashBytes = $md5.ComputeHash($fs)
    $hex = ([BitConverter]::ToString($hashBytes) -replace '-','').ToLowerInvariant()
    $b64 = [Convert]::ToBase64String($hashBytes)
    return @{ Hex = $hex; Base64 = $b64 }
  } finally {
    if ($fs) { $fs.Dispose() }
    $md5.Dispose()
  }
}

function Sanitize-ForKey([string]$s){
  if ([string]::IsNullOrWhiteSpace($s)) { return $null }
  $t = $s.Trim() -replace '[^\w\-\.]','-'
  $t = $t -replace '-{2,}','-'
  return $t.Trim('-')
}
function Sanitize-FileForKey([string]$name) {
  $safeName = ($name -replace '[^\w\-\.\(\)\s]','_')
  $safeName = ($safeName -replace '\s+','_')
  return $safeName
}

# ---------------------------
# NEW: Timed Y/N prompt (10s) for opening HTML helper
# ---------------------------
function Prompt-YesNoTimeout {
  param(
    [Parameter(Mandatory)][string]$Prompt,
    [int]$TimeoutSeconds = 10
  )
  if ($Silent -or $ExportOnly) { return $false }

  Write-Host ""
  Write-Host $Prompt -ForegroundColor Yellow
  Write-Host ("(Auto-closes in {0} seconds if Y/N not pressed.)" -f $TimeoutSeconds) -ForegroundColor DarkGray
  Write-Host "Press Y or N (press Enter after selection)..." -ForegroundColor Yellow

  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while ((Get-Date) -lt $deadline) {
    try {
      if ([Console]::KeyAvailable) {
        $k = [Console]::ReadKey($true)
        if ($k.Key -eq 'Y') { return $true }
        if ($k.Key -eq 'N') { return $false }
      }
    } catch {
      break
    }
    Start-Sleep -Milliseconds 100
  }
  return $false
}

function HtmlEncode {
  param([string]$s)
  if ($null -eq $s) { return '' }
  $s = $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;'
  $s = $s -replace '"','&quot;' -replace "'","&#39;"
  return $s
}

function Open-UploadFailureHtmlHelper {
  param(
    [Parameter(Mandatory)][object[]]$FailedRows
  )
  if ($Silent -or $ExportOnly) { return }
  if (-not $FailedRows -or $FailedRows.Count -eq 0) { return }

  $firstPath = $FailedRows[0].Full
  $outDir = Split-Path -Parent $firstPath
  if (-not (Test-Path -LiteralPath $outDir)) { $outDir = $ScanPath }
  if (-not (Test-Path -LiteralPath $outDir)) { return }

  $lis = ($FailedRows | ForEach-Object {
    "<li><b>File:</b> <code>$(HtmlEncode $_.Name)</code><br/><b>Path:</b> <code>$(HtmlEncode $_.Full)</code></li>"
  }) -join "`r`n"

  $outHref = ($outDir -replace '\\','/')

  $html = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>ConnectSecure - Upload Failed Helper</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif;background:#0f172a;color:#e5e7eb;margin:0}
  .wrap{max-width:980px;margin:0 auto;padding:26px 18px}
  .card{background:#111827;border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:18px}
  h1{margin:0 0 10px;font-size:1.4rem}
  .muted{color:#9ca3af}
  code{font-family:Consolas,ui-monospace,Menlo,monospace;font-size:13px;word-break:break-all}
  a{color:#60a5fa;text-decoration:none} a:hover{text-decoration:underline}
  .btn{display:inline-block;margin-top:12px;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.18);background:#0b1020;color:#e5e7eb;text-decoration:none;font-weight:700}
  ul{margin:10px 0 0 20px}
  li{margin:10px 0}
</style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Upload Not Successful</h1>
      <p class="muted">Attach the file(s) below to the ConnectSecure support case.</p>
      <a class="btn" href="file:///$outHref" target="_blank" rel="noopener">Open output folder</a>
      <p class="muted" style="margin-top:12px">Folder path: <code>$(HtmlEncode $outDir)</code></p>
      <ul>
        $lis
      </ul>
    </div>
  </div>
</body>
</html>
"@

  $helperPath = Join-Path $outDir ("Upload_Failed_Helper_{0}.html" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
  try {
    $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($helperPath, $html, $Utf8NoBom)
    Start-Process $helperPath | Out-Null
    Write-LogLine 'INFO' ("Opened HTML helper: {0}" -f $helperPath)
  } catch {
    Write-LogLine 'WARN' ("Failed to open HTML helper: {0}" -f $_.Exception.Message)
  }
}

# ---------------------------
# Show files + sizes (NO countdown; upload starts immediately after display)
# ---------------------------
function Show-UploadPlan {
  param([Parameter(Mandatory)]$Det)

  Write-Host ""
  Write-Host "Detected upload files:" -ForegroundColor Yellow

  $rows = $Det | ForEach-Object {
    [pscustomobject]@{
      Name   = $_.Name
      Ticket = $_.Ticket
      Size   = (Get-SizeHuman ([long]$_.Bytes))
    }
  }

  $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-Host $_.TrimEnd() }

  $totalBytes = ($Det | Measure-Object -Property Bytes -Sum).Sum
  if ($null -eq $totalBytes) { $totalBytes = 0 }

  Write-Host ("Total files: {0}" -f $Det.Count)
  Write-Host ("Total size : {0}" -f (Get-SizeHuman ([long]$totalBytes)))
  Write-Host ""
}

# ---------------------------
# Fetch encrypted SAS blob (memory only)
#   - DOES NOT print/log the URL
#   - Supports private GitHub via env var CS_GITHUB_TOKEN
#   - More tolerant parsing to handle leading junk/HTML
# ---------------------------
function Get-SasBlobFromGitHub {
  param([Parameter(Mandatory)][string]$Url)

  if ([string]::IsNullOrWhiteSpace($Url)) { throw "SasBlobUrl is empty." }

  $headers = @{
    'User-Agent' = 'CS-SecureUpload'
    'Accept'     = 'application/json'
  }

  $ghToken = $env:CS_GITHUB_TOKEN
  if (-not [string]::IsNullOrWhiteSpace($ghToken)) {
    $headers['Authorization'] = "token $ghToken"
  }

  $resp = Invoke-WebRequest -Uri $Url -Headers $headers -UseBasicParsing -TimeoutSec 30
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Failed to obtain SAS blob (HTTP $($resp.StatusCode))."
  }

  $raw = $resp.Content
  if ([string]::IsNullOrWhiteSpace($raw)) {
    throw "Failed to obtain SAS blob (empty response)."
  }

  $json = $raw.Trim()
  $json = $json.TrimStart([char]0xFEFF)

  $brace = $json.IndexOf('{')
  if ($brace -gt 0) { $json = $json.Substring($brace) }

  if (-not $json.TrimStart().StartsWith('{')) {
    throw "Failed to obtain SAS blob (response was not JSON; likely auth/permissions)."
  }

  $obj = $json | ConvertFrom-Json -ErrorAction Stop
  if ($null -eq $obj.encParts -or $null -eq $obj.ivParts) { throw "SAS blob JSON missing encParts/ivParts." }

  $encB64 = ($obj.encParts -join '')
  $ivB64  = ($obj.ivParts  -join '')

  if ([string]::IsNullOrWhiteSpace($encB64) -or [string]::IsNullOrWhiteSpace($ivB64)) {
    throw "SAS blob enc/iv parts empty."
  }

  return @{ EncB64 = $encB64; IvB64 = $ivB64 }
}

# ---------------------------
# SAS decrypt (Hardened)
#   - Double-encrypted outer->inner
#   - Keys stored as XOR-obfuscated byte chunks (no strings)
# ---------------------------
function New-AesManaged([byte[]]$Key,[byte[]]$IV) {
  $aes = New-Object System.Security.Cryptography.AesManaged
  $aes.Mode      = [System.Security.Cryptography.CipherMode]::CBC
  $aes.Padding   = [System.Security.Cryptography.PaddingMode]::PKCS7
  $aes.KeySize   = 256
  $aes.BlockSize = 128
  $aes.Key = $Key
  $aes.IV  = $IV
  return $aes
}

function Get-EmbeddedAzureSasToken {
  param(
    [Parameter(Mandatory)][string]$OuterEncB64,
    [Parameter(Mandatory)][string]$OuterIvB64
  )

  $xor = 0xAA

  $kOuter1 = [byte[]](110,47,252,120,194,205,133,122)
  $kOuter2 = [byte[]](201,215,116,202,199,174,55,158)
  $kOuter3 = [byte[]](23,22,211,214,187,194,34,40)
  $kOuter4 = [byte[]](174,132,194,163,105,167,163,27)

  $kInner1 = [byte[]](221,27,108,249,71,12,251,240)
  $kInner2 = [byte[]](16,46,204,248,73,120,219,221)
  $kInner3 = [byte[]](228,139,115,57,163,169,52,161)
  $kInner4 = [byte[]](83,186,86,173,198,81,136,67)

  $outerKeyX = New-Object byte[] 32
  $innerKeyX = New-Object byte[] 32
  [Array]::Copy($kOuter1, 0, $outerKeyX, 0, 8)
  [Array]::Copy($kOuter2, 0, $outerKeyX, 8, 8)
  [Array]::Copy($kOuter3, 0, $outerKeyX, 16, 8)
  [Array]::Copy($kOuter4, 0, $outerKeyX, 24, 8)

  [Array]::Copy($kInner1, 0, $innerKeyX, 0, 8)
  [Array]::Copy($kInner2, 0, $innerKeyX, 8, 8)
  [Array]::Copy($kInner3, 0, $innerKeyX, 16, 8)
  [Array]::Copy($kInner4, 0, $innerKeyX, 24, 8)

  for ($i=0; $i -lt 32; $i++) {
    $outerKeyX[$i] = [byte]($outerKeyX[$i] -bxor $xor)
    $innerKeyX[$i] = [byte]($innerKeyX[$i] -bxor $xor)
  }

  $outerCipher = [Convert]::FromBase64String($OuterEncB64)
  $outerIv     = [Convert]::FromBase64String($OuterIvB64)

  $outerPlain = $null
  $aesOuter = $null
  $aesInner = $null

  try {
    $aesOuter = New-AesManaged -Key $outerKeyX -IV $outerIv
    $decOuter = $aesOuter.CreateDecryptor()
    $outerPlain = $decOuter.TransformFinalBlock($outerCipher, 0, $outerCipher.Length)
    if ($outerPlain.Length -lt 17) { throw "Outer payload too short." }

    $innerIv = New-Object byte[] 16
    [Array]::Copy($outerPlain, 0, $innerIv, 0, 16)

    $innerCipherLen = $outerPlain.Length - 16
    $innerCipher = New-Object byte[] $innerCipherLen
    [Array]::Copy($outerPlain, 16, $innerCipher, 0, $innerCipherLen)

    $aesInner = New-AesManaged -Key $innerKeyX -IV $innerIv
    $decInner = $aesInner.CreateDecryptor()
    $plainBytes = $decInner.TransformFinalBlock($innerCipher, 0, $innerCipher.Length)
    $token = [Text.Encoding]::UTF8.GetString($plainBytes)

    $token = $token.Trim()
    if ($token.StartsWith('?')) { $token = $token.TrimStart('?') }
    return $token
  }
  finally {
    if ($outerPlain) { [Array]::Clear($outerPlain, 0, $outerPlain.Length) }
    if ($outerCipher) { [Array]::Clear($outerCipher, 0, $outerCipher.Length) }
    if ($outerIv) { [Array]::Clear($outerIv, 0, $outerIv.Length) }
    if ($outerKeyX) { [Array]::Clear($outerKeyX, 0, $outerKeyX.Length) }
    if ($innerKeyX) { [Array]::Clear($innerKeyX, 0, $innerKeyX.Length) }

    if ($aesOuter) { $aesOuter.Dispose() }
    if ($aesInner) { $aesInner.Dispose() }

    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
  }
}

# ---------------------------
# Azure upload (Put Blob) with MD5 integrity header
# ---------------------------
function Upload-FileAzureBlobSasPut {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][string]$ContainerBaseUrl,
    [Parameter(Mandatory)][string]$ObjectKey,
    [Parameter(Mandatory)][string]$SasToken,
    [hashtable]$ExtraHeaders,
    [Parameter(Mandatory)][string]$ContentMd5Base64
  )

  $base = $ContainerBaseUrl.TrimEnd('/')
  $key  = $ObjectKey.TrimStart('/')

  $sas = $SasToken.Trim()
  if ($sas.StartsWith('?')) { $sas = $sas.TrimStart('?') }
  if ([string]::IsNullOrWhiteSpace($sas)) { throw "Azure SAS token missing." }

  $url = "$base/$key`?$sas"

  $headers = @{}
  $headers['x-ms-blob-type'] = 'BlockBlob'
  $headers['Content-MD5']    = $ContentMd5Base64

  if ($ExtraHeaders) {
    foreach ($k in $ExtraHeaders.Keys) { $headers[$k] = $ExtraHeaders[$k] }
  }

  $resp = Invoke-WebRequest -Uri $url -Method Put -Headers $headers -InFile $FilePath -TimeoutSec 120 -UseBasicParsing
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Azure PUT failed HTTP $($resp.StatusCode) $($resp.StatusDescription)"
  }
}

# ---------------------------
# MAIN
# ---------------------------
try {
  # Env overrides (base URL / headers)
  if (-not [string]::IsNullOrWhiteSpace($env:CS_AZURE_PUT_BASEURL)) { $CsAzurePutBaseUrl = $env:CS_AZURE_PUT_BASEURL }
  if ([string]::IsNullOrWhiteSpace($CsAzurePutHeaders))            { $CsAzurePutHeaders = $env:CS_AZURE_PUT_HEADERS }

  # Optional env handoff (company/ticket)
  if ([string]::IsNullOrWhiteSpace($Company)) { $Company = $env:CS_SECURE_UPLOAD_COMPANY }
  if ([string]::IsNullOrWhiteSpace($Ticket))  { $Ticket  = $env:CS_SECURE_UPLOAD_TICKET }

  if ([string]::IsNullOrWhiteSpace($CsAzurePutBaseUrl)) { Fail "CsAzurePutBaseUrl is empty." }

  # Discover upload files
  $files = @()
  $singleBundle = $env:CS_SECURE_UPLOAD_BUNDLE

  if (-not [string]::IsNullOrWhiteSpace($singleBundle)) {
    if (-not (Test-Path -LiteralPath $singleBundle)) { Fail "CS_SECURE_UPLOAD_BUNDLE was set but file not found." }
    $ext = [System.IO.Path]::GetExtension($singleBundle).ToLowerInvariant()
    if ($ext -ne '.csb' -and -not ($Zip -and $ext -eq '.zip')) {
      Fail "CS_SECURE_UPLOAD_BUNDLE must point to a .csb file (or .zip when -Zip is used)."
    }
    $files = @((Get-Item -LiteralPath $singleBundle -ErrorAction Stop))
  } else {
    if (-not (Test-Path -LiteralPath $ScanPath)) { Fail "Scan path not found: $ScanPath" }
    $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.csb' -ErrorAction Stop))
    if ($Zip) { $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.zip' -ErrorAction SilentlyContinue)) }
    $files = @($files | Sort-Object FullName -Unique)
  }

  if (@($files).Count -eq 0) { Write-LogLine 'ERROR' "No uploadable files found (.csb + optional .zip)."; exit 1 }

  # Per-file ticket map
  $det = @(
    foreach ($f in @($files)) {
      [pscustomobject]@{
        Name   = $f.Name
        Full   = $f.FullName
        Bytes  = $f.Length
        Ticket = (Get-TicketFromFileName -Name $f.Name)
      }
    }
  )

  # Fill missing tickets
  $missing = @($det | Where-Object { [string]::IsNullOrWhiteSpace($_.Ticket) })
  if ($missing.Count -gt 0) {
    if ([string]::IsNullOrWhiteSpace($Ticket) -and $Silent) {
      $Ticket = '99999'
      Write-LogLine 'WARN' "Ticket missing for one or more files; -Silent used with no -Ticket. Defaulting missing tickets to 99999."
    }
    if (-not [string]::IsNullOrWhiteSpace($Ticket)) {
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    } else {
      if ($ExportOnly) { Fail "Ticket missing for one or more files and no -Ticket provided." }
      do { $Ticket = (Read-Host "Enter ticket number for missing file(s) (press Enter after entry)").Trim() } while ([string]::IsNullOrWhiteSpace($Ticket))
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied entered ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    }
  }

  # Finalize log filename
  $companyTag = if ([string]::IsNullOrWhiteSpace($Company)) { 'UnknownCompany' } else { $Company }
  $uniqTickets = @($det | Select-Object -ExpandProperty Ticket -ErrorAction SilentlyContinue | Where-Object { $_ } | Sort-Object -Unique)
  $ticketTag   = if ($uniqTickets.Count -eq 1) { [string]$uniqTickets[0] } else { 'Mixed' }

  Finalize-LogPath -DestinationTag 'Azure' -CompanyTag $companyTag -TicketTag $ticketTag
  Write-LogLine 'INFO' ("Log file: {0}" -f $script:LogPath)

  # Show files + sizes (interactive only) then upload immediately (NO countdown)
  if (-not ($Silent -or $ExportOnly)) {
    Show-UploadPlan -Det $det
  }

  $extraHeaders = Parse-HeaderStringToHashtable $CsAzurePutHeaders
  $companyKey = Sanitize-ForKey $Company

  # Download encrypted SAS blob ONCE into memory (no file writes)
  $blob = $null
  try {
    $blob = Get-SasBlobFromGitHub -Url $SasBlobUrl
  } catch {
    $msg = Sanitize-ErrorMessage $_.Exception.Message
    Fail ("Failed to obtain SAS blob. {0} If repo is private, set env var CS_GITHUB_TOKEN." -f $msg)
  }

  $failed = 0
  $uploaded = @()
  $failedRows = @()

  foreach ($r in @($det)) {
    $safeName = Sanitize-FileForKey $r.Name
    $prefix = if ($companyKey) { "$companyKey/$($r.Ticket)" } else { "$($r.Ticket)" }
    $objKey = "$prefix/$safeName"

    $sasToken = $null
    try {
      $sasToken = Get-EmbeddedAzureSasToken -OuterEncB64 $blob.EncB64 -OuterIvB64 $blob.IvB64
      if ([string]::IsNullOrWhiteSpace($sasToken)) { throw "SAS token decrypt failed." }

      $md5 = Get-FileMD5 -Path $r.Full

      Write-LogLine 'INFO' ("Uploading (Azure): {0} -> {1}/{2}" -f $r.Name, $CsAzurePutBaseUrl.TrimEnd('/'), $objKey)

      # MD5: log-only (do not show on screen)
      Write-LogLine 'INFO' ("MD5 (local, hex)  : {0}" -f $md5.Hex) -NoConsole
      Write-LogLine 'INFO' ("MD5 (header, b64) : {0}" -f $md5.Base64) -NoConsole

      Invoke-RetrySilent -Attempts 3 -PauseSeconds 1 -Action {
        Upload-FileAzureBlobSasPut -FilePath $r.Full -ContainerBaseUrl $CsAzurePutBaseUrl -ObjectKey $objKey -SasToken $sasToken -ExtraHeaders $extraHeaders -ContentMd5Base64 $md5.Base64
      } | Out-Null

      Write-LogLine 'OK'  "Upload completed (HTTP 2xx)"
      Write-LogLine 'OK'  "Integrity verified: Content-MD5 validated by server during PUT"
      Write-LogLine 'OK'  ("Uploaded OK (Azure): {0}" -f $r.Name)

      $uploaded += [pscustomobject]@{
        name=$r.Name; ticket=$r.Ticket; objectKey=$objKey; bytes=$r.Bytes;
        destination="cs-azure-blob"; md5_hex=$md5.Hex; md5_b64=$md5.Base64
      }
    }
    catch {
      $failed++
      $failedRows += $r
      $msg = Sanitize-ErrorMessage $_.Exception.Message
      Write-LogLine 'ERROR' ("Upload FAILED (Azure): {0} :: {1}" -f $r.Name, $msg)
      Write-LogLine 'ERROR' "Integrity verification failed or upload rejected. (If Content-MD5 mismatched, server will reject the PUT.)"
    }
    finally {
      if ($sasToken) {
        $sasToken = $null
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
      }
    }
  }

  # Wipe blob from memory
  if ($blob) {
    $blob.EncB64 = $null
    $blob.IvB64  = $null
    $blob = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
  }

  # ExportOnly summary
  if ($ExportOnly) {
    $totalBytes = ($det | Measure-Object -Property Bytes -Sum).Sum
    if ($null -eq $totalBytes) { $totalBytes = 0 }

    $summary = [pscustomobject]@{
      csAzurePutBaseUrl = $CsAzurePutBaseUrl
      scanPath          = $ScanPath
      company           = $Company
      includeZip        = [bool]$Zip
      totalFiles        = $det.Count
      totalBytes        = [long]$totalBytes
      failed            = $failed
      destinationUsed   = "CS Azure Blob (primary-vault)"
      uploaded          = $uploaded
      logPath           = $script:LogPath
      timestamp         = (Get-Date).ToString('s')
    }
    $jsonPath = Join-Path $script:LogRoot ("secure-upload-export_{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    ($summary | ConvertTo-Json -Depth 7) | Out-File -LiteralPath $jsonPath -Encoding UTF8
  }

  # ---------------------------
  # NEW: Failure UX (interactive only)
  # ---------------------------
  if ($failed -gt 0) {
    if (-not ($Silent -or $ExportOnly)) {
      Write-Host ""
      Write-Host "UPLOAD NOT SUCCESSFUL" -ForegroundColor Red
      Write-Host ""
      Write-Host "Please attach the file(s) below to the ConnectSecure support case:" -ForegroundColor Yellow
      foreach ($fr in @($failedRows)) {
        Write-Host ("File : {0}" -f $fr.Name) -ForegroundColor White
        Write-Host ("Path : {0}" -f $fr.Full) -ForegroundColor White
        Write-Host ""
      }

      $open = Prompt-YesNoTimeout -Prompt "Open HTML helper now? (Y/N)" -TimeoutSeconds 10
      if ($open) {
        Open-UploadFailureHtmlHelper -FailedRows $failedRows
      }
    }

    exit 1
  }

  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD SUCCESS. All files uploaded." -ForegroundColor Green
    Write-Host ""
    Write-Host ("Destination used: CS Azure Blob (primary-vault)") -ForegroundColor Cyan
    Write-Host ""
    Write-Host ("Log file: {0}" -f $script:LogPath) -ForegroundColor Yellow
    Write-Host ""
  }

  exit 0
}
catch {
  $msg = Sanitize-ErrorMessage $_.Exception.Message
  Write-LogLine 'ERROR' $msg

  # NEW: In non-silent mode show a small failure header (no prompts here; prompts happen above when we have file list)
  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD FAILED. See log:" -ForegroundColor Red
    Write-Host ("  {0}" -f $script:LogPath) -ForegroundColor Yellow
    Write-Host ""
  }

  exit 1
}