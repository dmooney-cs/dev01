#requires -version 5.1
[CmdletBinding()]
param(
  # ---------------------------
  # Azure Blob (container URL)
  # ---------------------------
  [string]$CsAzurePutBaseUrl = 'https://csvault01.blob.core.windows.net/primary-vault',

  # Optional extra headers: "Header1=Value1;Header2=Value2"
  [string]$CsAzurePutHeaders,

  # ---------------------------
  # Inputs
  # ---------------------------
  [string]$ScanPath = 'C:\CS-Toolbox-TEMP\ZIP',

  [Alias('t')]
  [string]$Ticket,     # used ONLY to fill missing tickets

  [string]$Company,

  # ---------------------------
  # Controls
  # ---------------------------
  [switch]$Zip,        # also include .zip files in upload set (in addition to .csb)
  [switch]$Silent,     # no prompts; minimal/no console output (still logs)
  [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Silent -or $ExportOnly) {
  $global:ProgressPreference    = 'SilentlyContinue'
  $global:VerbosePreference     = 'SilentlyContinue'
  $global:InformationPreference = 'SilentlyContinue'
  $global:WarningPreference     = 'SilentlyContinue'
  $global:DebugPreference       = 'SilentlyContinue'
  $global:ConfirmPreference     = 'None'
}

# ---------------------------
# Logging (file always)
# ---------------------------
$script:LogRootBase = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:LogRoot     = Join-Path $script:LogRootBase 'SecureUploadLog'
New-Item -ItemType Directory -Path $script:LogRoot -Force | Out-Null

$script:RunStamp     = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogPath      = Join-Path $script:LogRoot ("SecureUpload_{0}.log" -f $script:RunStamp)  # temp until finalized
$script:LogFinalized = $false

function Sanitize-FileToken([string]$s, [string]$fallback) {
  if ([string]::IsNullOrWhiteSpace($s)) { return $fallback }
  $t = $s.Trim()
  $t = ($t -replace '[^A-Za-z0-9\.\-_]','_')
  $t = ($t -replace '_{2,}','_').Trim('_')
  if ([string]::IsNullOrWhiteSpace($t)) { return $fallback }
  return $t
}

function Finalize-LogPath {
  param(
    [Parameter(Mandatory)][string]$DestinationTag,
    [string]$CompanyTag,
    [string]$TicketTag
  )
  if ($script:LogFinalized) { return }

  $dest  = Sanitize-FileToken $DestinationTag 'Azure'
  $comp  = Sanitize-FileToken $CompanyTag     'UnknownCompany'
  $tick  = Sanitize-FileToken $TicketTag      'Mixed'

  $finalName = "SecureUpload_{0}_{1}_{2}_{3}.log" -f $script:RunStamp, $dest, $comp, $tick
  $finalPath = Join-Path $script:LogRoot $finalName

  try {
    if ($script:LogPath -ne $finalPath) {
      if (Test-Path -LiteralPath $finalPath) { Remove-Item -LiteralPath $finalPath -Force -ErrorAction SilentlyContinue }
      Move-Item -LiteralPath $script:LogPath -Destination $finalPath -Force
      $script:LogPath = $finalPath
    }
  } catch {
    # keep temp path if rename fails
  }

  $script:LogFinalized = $true
}

function Write-LogLine {
  param([string]$Level,[string]$Message)
  $line = "[{0}] {1} {2}" -f $Level, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8

  if (-not ($Silent -or $ExportOnly)) {
    switch ($Level) {
      'ERROR' { Write-Host $line -ForegroundColor Red }
      'WARN'  { Write-Host $line -ForegroundColor Yellow }
      'OK'    { Write-Host $line -ForegroundColor Green }
      default { Write-Host $line -ForegroundColor Gray }
    }
  }
}
function Fail([string]$Message) { Write-LogLine 'ERROR' $Message; throw $Message }

# ---------------------------
# Redaction (prevents SAS/token leaks in errors/logs)
# ---------------------------
function Sanitize-ErrorMessage([string]$s) {
  if ([string]::IsNullOrWhiteSpace($s)) { return $s }

  # Redact any query string that might include SAS: ?sp=...&sig=...
  # This also catches any URL that includes ?<anything>.
  $s = [regex]::Replace($s, '\?[^ \r\n]+', '?REDACTED')

  # Extra paranoia: if a raw SAS appears without a URL (rare), redact common fields
  $s = [regex]::Replace($s, '(?i)\b(sig|sp|se|st|spr|sv|sr)=([^&\s]+)', '$1=REDACTED')

  return $s
}

# ---------------------------
# Helpers
# ---------------------------
function Invoke-RetrySilent {
  param([Parameter(Mandatory)][scriptblock]$Action,[int]$Attempts=3,[int]$PauseSeconds=1)
  $last = $null
  for ($i=1; $i -le $Attempts; $i++) {
    try { & $Action; return $true }
    catch {
      $last = $_
      if ($i -lt $Attempts) { Start-Sleep -Seconds $PauseSeconds }
    }
  }
  if ($last) { throw $last.Exception }
  return $false
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N2} {1}" -f $size, $u) }
  }
  return ("{0:N2} PB" -f ($bytes / [math]::Pow(2,50)))
}

function Get-TicketFromFileName([string]$Name) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)
  $m = [regex]::Match($base, '_\d{8}_\d{6}_[^0-9]*?(\d+)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}

function Parse-HeaderStringToHashtable([string]$s) {
  $h = @{}
  if ([string]::IsNullOrWhiteSpace($s)) { return $h }
  $pairs = $s.Split(';') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
  foreach ($p in $pairs) {
    $idx = $p.IndexOf('=')
    if ($idx -gt 0) {
      $k = $p.Substring(0,$idx).Trim()
      $v = $p.Substring($idx+1).Trim()
      if ($k) { $h[$k] = $v }
    }
  }
  return $h
}

function Get-FileMD5 {
  param([Parameter(Mandatory)][string]$Path)
  $md5 = [System.Security.Cryptography.MD5]::Create()
  $fs = $null
  try {
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    $hashBytes = $md5.ComputeHash($fs)
    $hex = ([BitConverter]::ToString($hashBytes) -replace '-','').ToLowerInvariant()
    $b64 = [Convert]::ToBase64String($hashBytes)
    return @{ Hex = $hex; Base64 = $b64 }
  } finally {
    if ($fs) { $fs.Dispose() }
    $md5.Dispose()
  }
}

function Sanitize-ForKey([string]$s){
  if ([string]::IsNullOrWhiteSpace($s)) { return $null }
  $t = $s.Trim() -replace '[^\w\-\.]','-'
  $t = $t -replace '-{2,}','-'
  return $t.Trim('-')
}
function Sanitize-FileForKey([string]$name) {
  $safeName = ($name -replace '[^\w\-\.\(\)\s]','_')
  $safeName = ($safeName -replace '\s+','_')
  return $safeName
}

# ---------------------------
# Embedded SAS token (Hardened)
#   - Chunked ciphertext/IV
#   - Double-encrypted: outer decrypt -> inner decrypt
#   - Keys stored as XOR-obfuscated byte chunks (no strings)
# ---------------------------
function New-AesManaged([byte[]]$Key,[byte[]]$IV) {
  $aes = New-Object System.Security.Cryptography.AesManaged
  $aes.Mode      = [System.Security.Cryptography.CipherMode]::CBC
  $aes.Padding   = [System.Security.Cryptography.PaddingMode]::PKCS7
  $aes.KeySize   = 256
  $aes.BlockSize = 128
  $aes.Key = $Key
  $aes.IV  = $IV
  return $aes
}

function Get-EmbeddedAzureSasToken {
  # ---- CHUNKED OUTER CIPHERTEXT (Base64) ----
  $encParts = @(
    'ScK7zuiibNbf6ezSgWMaKetZBXQAnu8xdCcMydjeEP4AP9eYxdOwzGiDPAQ3t1JR',
    'dhH/mOa5KIaEAkuhLpf08NSYuaiacYXOCLg0mZS+G8eWmQAdlmFQdoqLiav9BrTy',
    'h7h0BS/r6p/bainD6zIrhVe2ibTYFpQniugJBMy+My9Uc+0ykUOQRSeDc5v8tWsc',
    'Ny5nu4ZNe4JACz9Jv0vSoFmVDqKHXNmPc7zC6HDf0CQ='
  )
  $encB64 = ($encParts -join '')

  # ---- CHUNKED OUTER IV (Base64) ----
  $ivParts = @(
    'CJz5PDjMdLiu/gkf+ko2gw=='
  )
  $ivB64 = ($ivParts -join '')

  # XOR constant
  $xor = 0xAA

  # ---- OUTER KEY (XOR-obfuscated bytes; 32 bytes total) ----
  $kOuter1 = [byte[]](110,47,252,120,194,205,133,122)
  $kOuter2 = [byte[]](201,215,116,202,199,174,55,158)
  $kOuter3 = [byte[]](23,22,211,214,187,194,34,40)
  $kOuter4 = [byte[]](174,132,194,163,105,167,163,27)

  # ---- INNER KEY (XOR-obfuscated bytes; 32 bytes total) ----
  $kInner1 = [byte[]](221,27,108,249,71,12,251,240)
  $kInner2 = [byte[]](16,46,204,248,73,120,219,221)
  $kInner3 = [byte[]](228,139,115,57,163,169,52,161)
  $kInner4 = [byte[]](83,186,86,173,198,81,136,67)

  # Reconstruct keys
  $outerKeyX = New-Object byte[] 32
  $innerKeyX = New-Object byte[] 32
  [Array]::Copy($kOuter1, 0, $outerKeyX, 0, 8)
  [Array]::Copy($kOuter2, 0, $outerKeyX, 8, 8)
  [Array]::Copy($kOuter3, 0, $outerKeyX, 16, 8)
  [Array]::Copy($kOuter4, 0, $outerKeyX, 24, 8)

  [Array]::Copy($kInner1, 0, $innerKeyX, 0, 8)
  [Array]::Copy($kInner2, 0, $innerKeyX, 8, 8)
  [Array]::Copy($kInner3, 0, $innerKeyX, 16, 8)
  [Array]::Copy($kInner4, 0, $innerKeyX, 24, 8)

  # De-obfuscate
  for ($i=0; $i -lt 32; $i++) {
    $outerKeyX[$i] = [byte]($outerKeyX[$i] -bxor $xor)
    $innerKeyX[$i] = [byte]($innerKeyX[$i] -bxor $xor)
  }

  $outerCipher = [Convert]::FromBase64String($encB64)
  $outerIv     = [Convert]::FromBase64String($ivB64)

  $outerPlain = $null
  $token = $null

  $aesOuter = $null
  $aesInner = $null

  try {
    # OUTER DECRYPT -> yields: [innerIV (16 bytes)] + [innerCiphertext]
    $aesOuter = New-AesManaged -Key $outerKeyX -IV $outerIv
    $decOuter = $aesOuter.CreateDecryptor()
    $outerPlain = $decOuter.TransformFinalBlock($outerCipher, 0, $outerCipher.Length)

    if ($outerPlain.Length -lt 17) { throw "Outer payload too short." }

    $innerIv = New-Object byte[] 16
    [Array]::Copy($outerPlain, 0, $innerIv, 0, 16)

    $innerCipherLen = $outerPlain.Length - 16
    $innerCipher = New-Object byte[] $innerCipherLen
    [Array]::Copy($outerPlain, 16, $innerCipher, 0, $innerCipherLen)

    # INNER DECRYPT -> yields SAS token string
    $aesInner = New-AesManaged -Key $innerKeyX -IV $innerIv
    $decInner = $aesInner.CreateDecryptor()
    $plainBytes = $decInner.TransformFinalBlock($innerCipher, 0, $innerCipher.Length)
    $token = [Text.Encoding]::UTF8.GetString($plainBytes)

    $token = $token.Trim()
    if ($token.StartsWith('?')) { $token = $token.TrimStart('?') }
    return $token
  }
  finally {
    # Best-effort memory cleanup
    if ($outerPlain) { [Array]::Clear($outerPlain, 0, $outerPlain.Length) }
    if ($outerCipher) { [Array]::Clear($outerCipher, 0, $outerCipher.Length) }
    if ($outerIv) { [Array]::Clear($outerIv, 0, $outerIv.Length) }
    if ($outerKeyX) { [Array]::Clear($outerKeyX, 0, $outerKeyX.Length) }
    if ($innerKeyX) { [Array]::Clear($innerKeyX, 0, $innerKeyX.Length) }

    if ($aesOuter) { $aesOuter.Dispose() }
    if ($aesInner) { $aesInner.Dispose() }

    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
  }
}

# ---------------------------
# Azure upload (Put Blob) with MD5 integrity header
# ---------------------------
function Upload-FileAzureBlobSasPut {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][string]$ContainerBaseUrl,  # https://.../<container>
    [Parameter(Mandatory)][string]$ObjectKey,         # company/ticket/file.csb
    [Parameter(Mandatory)][string]$SasToken,          # sp=cw&...&sig=...
    [hashtable]$ExtraHeaders,
    [Parameter(Mandatory)][string]$ContentMd5Base64
  )

  $base = $ContainerBaseUrl.TrimEnd('/')
  $key  = $ObjectKey.TrimStart('/')

  $sas = $SasToken.Trim()
  if ($sas.StartsWith('?')) { $sas = $sas.TrimStart('?') }
  if ([string]::IsNullOrWhiteSpace($sas)) { throw "Azure SAS token missing." }

  $url = "$base/$key`?$sas"

  $headers = @{}
  $headers['x-ms-blob-type'] = 'BlockBlob'
  $headers['Content-MD5']    = $ContentMd5Base64

  if ($ExtraHeaders) {
    foreach ($k in $ExtraHeaders.Keys) { $headers[$k] = $ExtraHeaders[$k] }
  }

  $resp = Invoke-WebRequest -Uri $url -Method Put -Headers $headers -InFile $FilePath -TimeoutSec 120 -UseBasicParsing
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Azure PUT failed HTTP $($resp.StatusCode) $($resp.StatusDescription)"
  }
}

# ---------------------------
# MAIN
# ---------------------------
try {
  # Env overrides (base URL / headers)
  if (-not [string]::IsNullOrWhiteSpace($env:CS_AZURE_PUT_BASEURL)) { $CsAzurePutBaseUrl = $env:CS_AZURE_PUT_BASEURL }
  if ([string]::IsNullOrWhiteSpace($CsAzurePutHeaders))            { $CsAzurePutHeaders = $env:CS_AZURE_PUT_HEADERS }

  # Optional env handoff (company/ticket)
  if ([string]::IsNullOrWhiteSpace($Company)) { $Company = $env:CS_SECURE_UPLOAD_COMPANY }
  if ([string]::IsNullOrWhiteSpace($Ticket))  { $Ticket  = $env:CS_SECURE_UPLOAD_TICKET }

  if ([string]::IsNullOrWhiteSpace($CsAzurePutBaseUrl)) { Fail "CsAzurePutBaseUrl is empty." }

  # Discover upload files
  $files = @()
  $singleBundle = $env:CS_SECURE_UPLOAD_BUNDLE

  if (-not [string]::IsNullOrWhiteSpace($singleBundle)) {
    if (-not (Test-Path -LiteralPath $singleBundle)) { Fail "CS_SECURE_UPLOAD_BUNDLE was set but file not found: $singleBundle" }
    $ext = [System.IO.Path]::GetExtension($singleBundle).ToLowerInvariant()
    if ($ext -ne '.csb' -and -not ($Zip -and $ext -eq '.zip')) {
      Fail "CS_SECURE_UPLOAD_BUNDLE must point to a .csb file (or .zip when -Zip is used). Got: $singleBundle"
    }
    $files = @((Get-Item -LiteralPath $singleBundle -ErrorAction Stop))
  } else {
    if (-not (Test-Path -LiteralPath $ScanPath)) { Fail "Scan path not found: $ScanPath" }
    $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.csb' -ErrorAction Stop))
    if ($Zip) { $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.zip' -ErrorAction SilentlyContinue)) }
    $files = @($files | Sort-Object FullName -Unique)
  }

  if (@($files).Count -eq 0) { Write-LogLine 'ERROR' "No uploadable files found (.csb + optional .zip)."; exit 1 }

  # Per-file ticket map
  $det = @(
    foreach ($f in @($files)) {
      [pscustomobject]@{
        Name   = $f.Name
        Full   = $f.FullName
        Bytes  = $f.Length
        Ticket = (Get-TicketFromFileName -Name $f.Name)
      }
    }
  )

  # Fill missing tickets
  $missing = @($det | Where-Object { [string]::IsNullOrWhiteSpace($_.Ticket) })
  if ($missing.Count -gt 0) {
    if ([string]::IsNullOrWhiteSpace($Ticket) -and $Silent) {
      $Ticket = '99999'
      Write-LogLine 'WARN' "Ticket missing for one or more files; -Silent used with no -Ticket. Defaulting missing tickets to 99999."
    }
    if (-not [string]::IsNullOrWhiteSpace($Ticket)) {
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    } else {
      if ($ExportOnly) { Fail "Ticket missing for one or more files and no -Ticket provided." }
      do { $Ticket = (Read-Host "Enter ticket number for missing file(s)").Trim() } while ([string]::IsNullOrWhiteSpace($Ticket))
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied entered ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    }
  }

  # Finalize log filename
  $companyTag = if ([string]::IsNullOrWhiteSpace($Company)) { 'UnknownCompany' } else { $Company }
  $uniqTickets = @($det | Select-Object -ExpandProperty Ticket -ErrorAction SilentlyContinue | Where-Object { $_ } | Sort-Object -Unique)
  $ticketTag   = if ($uniqTickets.Count -eq 1) { [string]$uniqTickets[0] } else { 'Mixed' }

  Finalize-LogPath -DestinationTag 'Azure' -CompanyTag $companyTag -TicketTag $ticketTag
  Write-LogLine 'INFO' ("Log file: {0}" -f $script:LogPath)

  # Confirm upload (interactive only)
  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "Detected upload files:" -ForegroundColor Yellow
    foreach ($r in $det) { Write-Host ("  - {0}  (ticket: {1})" -f $r.Name, $r.Ticket) }
    Write-Host ""
    $totalBytes = ($det | Measure-Object -Property Bytes -Sum).Sum
    if ($null -eq $totalBytes) { $totalBytes = 0 }
    Write-Host ("Total files: {0}" -f $det.Count)
    Write-Host ("Total size : {0}" -f (Get-SizeHuman ([long]$totalBytes)))
    Write-Host ""
    $confirm = (Read-Host "Upload ALL listed files now? (Y/N)").Trim().ToUpperInvariant()
    if ($confirm -ne 'Y') { Write-LogLine 'WARN' "User cancelled upload."; exit 0 }
  }

  $extraHeaders = Parse-HeaderStringToHashtable $CsAzurePutHeaders
  $companyKey = Sanitize-ForKey $Company

  $failed = 0
  $uploaded = @()

  foreach ($r in @($det)) {
    $safeName = Sanitize-FileForKey $r.Name
    $prefix = if ($companyKey) { "$companyKey/$($r.Ticket)" } else { "$($r.Ticket)" }
    $objKey = "$prefix/$safeName"

    # Behavioral hardening: decrypt SAS per-file (short-lived), then wipe
    $sasToken = $null

    try {
      $sasToken = Get-EmbeddedAzureSasToken
      if ([string]::IsNullOrWhiteSpace($sasToken)) { throw "Embedded Azure SAS token decrypt failed." }

      $md5 = Get-FileMD5 -Path $r.Full

      Write-LogLine 'INFO' ("Uploading (Azure): {0} -> {1}/{2}" -f $r.Name, $CsAzurePutBaseUrl.TrimEnd('/'), $objKey)
      Write-LogLine 'INFO' ("MD5 (local, hex)  : {0}" -f $md5.Hex)
      Write-LogLine 'INFO' ("MD5 (header, b64) : {0}" -f $md5.Base64)

      Invoke-RetrySilent -Attempts 3 -PauseSeconds 1 -Action {
        Upload-FileAzureBlobSasPut -FilePath $r.Full -ContainerBaseUrl $CsAzurePutBaseUrl -ObjectKey $objKey -SasToken $sasToken -ExtraHeaders $extraHeaders -ContentMd5Base64 $md5.Base64
      } | Out-Null

      Write-LogLine 'OK'  "Upload completed (HTTP 2xx)"
      Write-LogLine 'OK'  "Integrity verified: Content-MD5 validated by server during PUT"
      Write-LogLine 'OK'  ("Uploaded OK (Azure): {0}" -f $r.Name)

      $uploaded += [pscustomobject]@{
        name=$r.Name; ticket=$r.Ticket; objectKey=$objKey; bytes=$r.Bytes;
        destination="cs-azure-blob"; md5_hex=$md5.Hex; md5_b64=$md5.Base64
      }
    }
    catch {
      $failed++
      $msg = Sanitize-ErrorMessage $_.Exception.Message
      Write-LogLine 'ERROR' ("Upload FAILED (Azure): {0} :: {1}" -f $r.Name, $msg)
      Write-LogLine 'ERROR' "Integrity verification failed or upload rejected. (If Content-MD5 mismatched, server will reject the PUT.)"
    }
    finally {
      if ($sasToken) {
        # Best-effort wipe the token variable
        $sasToken = $null
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
      }
    }
  }

  # ExportOnly summary
  if ($ExportOnly) {
    $totalBytes = ($det | Measure-Object -Property Bytes -Sum).Sum
    if ($null -eq $totalBytes) { $totalBytes = 0 }

    $summary = [pscustomobject]@{
      csAzurePutBaseUrl = $CsAzurePutBaseUrl
      scanPath          = $ScanPath
      company           = $Company
      includeZip        = [bool]$Zip
      totalFiles        = $det.Count
      totalBytes        = [long]$totalBytes
      failed            = $failed
      destinationUsed   = "CS Azure Blob (primary-vault)"
      uploaded          = $uploaded
      logPath           = $script:LogPath
      timestamp         = (Get-Date).ToString('s')
    }
    $jsonPath = Join-Path $script:LogRoot ("secure-upload-export_{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    ($summary | ConvertTo-Json -Depth 7) | Out-File -LiteralPath $jsonPath -Encoding UTF8
  }

  if ($failed -gt 0) { exit 1 }

  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD SUCCESS. All files uploaded." -ForegroundColor Green
    Write-Host ""
    Write-Host ("Destination used: CS Azure Blob (primary-vault)") -ForegroundColor Cyan
    Write-Host ""
    Write-Host ("Log file: {0}" -f $script:LogPath) -ForegroundColor Yellow
    Write-Host ""
  }

  exit 0
}
catch {
  $msg = Sanitize-ErrorMessage $_.Exception.Message
  Write-LogLine 'ERROR' $msg
  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD FAILED. See log:" -ForegroundColor Red
    Write-Host ("  {0}" -f $script:LogPath) -ForegroundColor Yellow
    Write-Host ""
  }
  exit 1
}