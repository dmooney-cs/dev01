#requires -version 5.1
[CmdletBinding()]
param(
  # ---------------------------
  # Primary: Lab destination (S3/MinIO)
  # ---------------------------
  [string]$LabEndpoint = 'http://10.0.0.238:9000',
  [string]$LabBucket   = 'cs-test-bucket',
  [string]$LabRegion   = 'us-east-1',

  # ---------------------------
  # Secondary: Azure Blob (container URL) + SAS token
  # Default is your container. Replace the SAS token value below.
  # ---------------------------
  [string]$CsAzurePutBaseUrl = 'https://csvault01.blob.core.windows.net/primary-vault',

  # SAS token ONLY (no leading '?')
  # Paste your token here:
  [string]$CsAzureSasToken = 'sp=cw&st=2026-02-22T21:58:18Z&se=2026-12-31T06:13:18Z&spr=https&sv=2024-11-04&sr=c&sig=KKL7R5cp8HOPh6Zy5NspVtxS5x1AZOBa4QgQYorQFkQ%3D',

  # Optional extra headers: "Header1=Value1;Header2=Value2"
  [string]$CsAzurePutHeaders,

  # ---------------------------
  # Inputs
  # ---------------------------
  [string]$ScanPath = 'C:\CS-Toolbox-TEMP\ZIP',

  [Alias('t')]
  [string]$Ticket,     # used ONLY to fill missing tickets

  [string]$Company,

  # ---------------------------
  # Controls
  # ---------------------------
  [switch]$Zip,        # also include .zip files in upload set (in addition to .csb)
  [switch]$Silent,     # no prompts; minimal/no console output (still logs)
  [switch]$ExportOnly,

  # ---------------------------
  # Destination control (NEW)
  # ---------------------------
  [switch]$ForceLab,   # if set, use Lab ONLY
  [switch]$ForceAzure  # if set, use Azure ONLY
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Silent -or $ExportOnly) {
  $global:ProgressPreference    = 'SilentlyContinue'
  $global:VerbosePreference     = 'SilentlyContinue'
  $global:InformationPreference = 'SilentlyContinue'
  $global:WarningPreference     = 'SilentlyContinue'
  $global:DebugPreference       = 'SilentlyContinue'
  $global:ConfirmPreference     = 'None'
}

# ---------------------------
# Logging (file always)
# ---------------------------
$LogRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$LogPath = Join-Path $LogRoot 'secure-upload.log'
New-Item -ItemType Directory -Path $LogRoot -Force | Out-Null

function Write-LogLine {
  param([string]$Level,[string]$Message)
  $line = "[{0}] {1} {2}" -f $Level, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
  Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8

  if (-not ($Silent -or $ExportOnly)) {
    switch ($Level) {
      'ERROR' { Write-Host $line -ForegroundColor Red }
      'WARN'  { Write-Host $line -ForegroundColor Yellow }
      'OK'    { Write-Host $line -ForegroundColor Green }
      default { Write-Host $line -ForegroundColor Gray }
    }
  }
}
function Fail([string]$Message) { Write-LogLine 'ERROR' $Message; throw $Message }

# ---------------------------
# Helpers
# ---------------------------
function Test-EndpointReachableOnce([string]$Url) {
  try { $u = [Uri]$Url } catch { return $false }
  $hostName = $u.Host
  $port = if ($u.IsDefaultPort) { if ($u.Scheme -eq 'https') { 443 } else { 80 } } else { $u.Port }

  try {
    $client = New-Object System.Net.Sockets.TcpClient
    $iar = $client.BeginConnect($hostName, $port, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds(2))
    if ($ok -and $client.Connected) { $client.EndConnect($iar) | Out-Null; $client.Close(); return $true }
    $client.Close()
    return $false
  } catch { return $false }
}
function Test-ReachableWithRetrySilent {
  param([Parameter(Mandatory)][string]$Url,[int]$Attempts=3,[int]$PauseSeconds=1)
  for ($i=1; $i -le $Attempts; $i++) {
    if (Test-EndpointReachableOnce -Url $Url) { return $true }
    if ($i -lt $Attempts) { Start-Sleep -Seconds $PauseSeconds }
  }
  return $false
}
function Invoke-RetrySilent {
  param([Parameter(Mandatory)][scriptblock]$Action,[int]$Attempts=3,[int]$PauseSeconds=1)
  $last = $null
  for ($i=1; $i -le $Attempts; $i++) {
    try { & $Action; return $true } catch { $last = $_; if ($i -lt $Attempts) { Start-Sleep -Seconds $PauseSeconds } }
  }
  if ($last) { throw $last.Exception }
  return $false
}
function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N2} {1}" -f $size, $u) }
  }
  return ("{0:N2} PB" -f ($bytes / [math]::Pow(2,50)))
}
function Get-TicketFromFileName([string]$Name) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)
  $m = [regex]::Match($base, '_\d{8}_\d{6}_[^0-9]*?(\d+)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}
function Resolve-Creds {
  $ak = $env:AWS_ACCESS_KEY_ID
  $sk = $env:AWS_SECRET_ACCESS_KEY
  if ([string]::IsNullOrWhiteSpace($ak) -or [string]::IsNullOrWhiteSpace($sk)) {
    Fail "Missing required environment variables AWS_ACCESS_KEY_ID and/or AWS_SECRET_ACCESS_KEY. Lab destination upload cannot continue."
  }
  return @{ AccessKey=$ak; SecretKey=$sk }
}

function HmacSHA256([byte[]]$key,[byte[]]$data){
  $h = New-Object System.Security.Cryptography.HMACSHA256(,$key)
  try { return $h.ComputeHash($data) } finally { $h.Dispose() }
}
function SHA256Hex([byte[]]$data){
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try { return (([BitConverter]::ToString($sha.ComputeHash($data))) -replace '-','').ToLowerInvariant() }
  finally { $sha.Dispose() }
}
function ToHexLower([byte[]]$b){ return ([BitConverter]::ToString($b) -replace '-','').ToLowerInvariant() }

function Get-AwsV4Signature {
  param(
    [Parameter(Mandatory)][string]$Method,
    [Parameter(Mandatory)][Uri]$EndpointUri,
    [Parameter(Mandatory)][string]$Bucket,
    [Parameter(Mandatory)][string]$ObjectKey,
    [Parameter(Mandatory)][string]$Region,
    [Parameter(Mandatory)][string]$AccessKey,
    [Parameter(Mandatory)][string]$SecretKey,
    [Parameter(Mandatory)][string]$PayloadHashHex,
    [Parameter(Mandatory)][string]$AmzDate,
    [Parameter(Mandatory)][string]$DateStamp
  )

  $canonicalUri = "/$Bucket/$ObjectKey"
  $hostHeader = if ($EndpointUri.IsDefaultPort) { $EndpointUri.Host } else { "{0}:{1}" -f $EndpointUri.Host, $EndpointUri.Port }

  $canonicalHeaders = "host:$hostHeader`n" +
                      "x-amz-content-sha256:$PayloadHashHex`n" +
                      "x-amz-date:$AmzDate`n"
  $signedHeaders = "host;x-amz-content-sha256;x-amz-date"

  $canonicalRequest = ($Method.ToUpper(), $canonicalUri, "", $canonicalHeaders, $signedHeaders, $PayloadHashHex) -join "`n"
  $canonicalRequestHash = SHA256Hex([Text.Encoding]::UTF8.GetBytes($canonicalRequest))

  $service = "s3"
  $credentialScope = "$DateStamp/$Region/$service/aws4_request"
  $stringToSign = ("AWS4-HMAC-SHA256", $AmzDate, $credentialScope, $canonicalRequestHash) -join "`n"

  $kSecret  = [Text.Encoding]::UTF8.GetBytes("AWS4$SecretKey")
  $kDate    = HmacSHA256 $kSecret  ([Text.Encoding]::UTF8.GetBytes($DateStamp))
  $kRegion  = HmacSHA256 $kDate    ([Text.Encoding]::UTF8.GetBytes($Region))
  $kService = HmacSHA256 $kRegion  ([Text.Encoding]::UTF8.GetBytes($service))
  $kSign    = HmacSHA256 $kService ([Text.Encoding]::UTF8.GetBytes("aws4_request"))

  $sigBytes = HmacSHA256 $kSign ([Text.Encoding]::UTF8.GetBytes($stringToSign))
  $signature = ToHexLower $sigBytes

  $authHeader = "AWS4-HMAC-SHA256 Credential=$AccessKey/$credentialScope, SignedHeaders=$signedHeaders, Signature=$signature"

  return @{ Host = $hostHeader; Authorization = $authHeader }
}

function Upload-FileLab {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][Uri]$EndpointUri,
    [Parameter(Mandatory)][string]$Bucket,
    [Parameter(Mandatory)][string]$Region,
    [Parameter(Mandatory)][string]$AccessKey,
    [Parameter(Mandatory)][string]$SecretKey,
    [Parameter(Mandatory)][string]$ObjectKey
  )

  $bytes = [System.IO.File]::ReadAllBytes($FilePath)
  $payloadHash = SHA256Hex($bytes)

  $now = [DateTime]::UtcNow
  $amzDate   = $now.ToString("yyyyMMddTHHmmssZ")
  $dateStamp = $now.ToString("yyyyMMdd")

  $sig = Get-AwsV4Signature -Method "PUT" -EndpointUri $EndpointUri -Bucket $Bucket -ObjectKey $ObjectKey `
                            -Region $Region -AccessKey $AccessKey -SecretKey $SecretKey `
                            -PayloadHashHex $payloadHash -AmzDate $amzDate -DateStamp $dateStamp

  $hostPart = if ($EndpointUri.IsDefaultPort) { $EndpointUri.Host } else { "{0}:{1}" -f $EndpointUri.Host, $EndpointUri.Port }
  $url = "{0}://{1}/{2}/{3}" -f $EndpointUri.Scheme, $hostPart, $Bucket, $ObjectKey

  $headers = @{
    "Host" = $sig.Host
    "x-amz-date" = $amzDate
    "x-amz-content-sha256" = $payloadHash
    "Authorization" = $sig.Authorization
  }

  $resp = Invoke-WebRequest -Uri $url -Method Put -Headers $headers -Body $bytes -TimeoutSec 120 -UseBasicParsing
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Lab upload failed HTTP $($resp.StatusCode) $($resp.StatusDescription)"
  }
}

function Parse-HeaderStringToHashtable([string]$s) {
  $h = @{}
  if ([string]::IsNullOrWhiteSpace($s)) { return $h }
  $pairs = $s.Split(';') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
  foreach ($p in $pairs) {
    $idx = $p.IndexOf('=')
    if ($idx -gt 0) {
      $k = $p.Substring(0,$idx).Trim()
      $v = $p.Substring($idx+1).Trim()
      if ($k) { $h[$k] = $v }
    }
  }
  return $h
}

function Upload-FileAzureBlobSasPut {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][string]$ContainerBaseUrl,  # https://.../<container>
    [Parameter(Mandatory)][string]$ObjectKey,         # company/ticket/file.csb
    [Parameter(Mandatory)][string]$SasToken,          # sp=cw&...&sig=...
    [hashtable]$ExtraHeaders
  )

  $base = $ContainerBaseUrl.TrimEnd('/')
  $key  = $ObjectKey.TrimStart('/')

  $sas = $SasToken
  if ($null -eq $sas) { $sas = '' }
  $sas = $sas.Trim()
  if ($sas.StartsWith('?')) { $sas = $sas.TrimStart('?') }

  if ([string]::IsNullOrWhiteSpace($sas)) { throw "Azure SAS token missing." }

  $url = "$base/$key`?$sas"

  $headers = @{}
  # REQUIRED for Put Blob (block blob)
  $headers['x-ms-blob-type'] = 'BlockBlob'

  if ($ExtraHeaders) {
    foreach ($k in $ExtraHeaders.Keys) { $headers[$k] = $ExtraHeaders[$k] }
  }

  $resp = Invoke-WebRequest -Uri $url -Method Put -Headers $headers -InFile $FilePath -TimeoutSec 120 -UseBasicParsing
  if ($resp.StatusCode -lt 200 -or $resp.StatusCode -ge 300) {
    throw "Azure PUT failed HTTP $($resp.StatusCode) $($resp.StatusDescription)"
  }
}

function Sanitize-ForKey([string]$s){
  if ([string]::IsNullOrWhiteSpace($s)) { return $null }
  $t = $s.Trim() -replace '[^\w\-\.]','-'
  $t = $t -replace '-{2,}','-'
  return $t.Trim('-')
}
function Sanitize-FileForKey([string]$name) {
  $safeName = ($name -replace '[^\w\-\.\(\)\s]','_')
  $safeName = ($safeName -replace '\s+','_')
  return $safeName
}

# ---------------------------
# MAIN
# ---------------------------
try {
  # Optional env handoff
  $singleBundle = $env:CS_SECURE_UPLOAD_BUNDLE
  if ([string]::IsNullOrWhiteSpace($Company)) { $Company = $env:CS_SECURE_UPLOAD_COMPANY }
  if ([string]::IsNullOrWhiteSpace($Ticket))  { $Ticket  = $env:CS_SECURE_UPLOAD_TICKET }

  # Allow env override, but defaults will still work
  if (-not [string]::IsNullOrWhiteSpace($env:CS_AZURE_PUT_BASEURL)) { $CsAzurePutBaseUrl = $env:CS_AZURE_PUT_BASEURL }
  if (-not [string]::IsNullOrWhiteSpace($env:CS_AZURE_SAS_TOKEN))  { $CsAzureSasToken   = $env:CS_AZURE_SAS_TOKEN }
  if ([string]::IsNullOrWhiteSpace($CsAzurePutHeaders))            { $CsAzurePutHeaders = $env:CS_AZURE_PUT_HEADERS }

  # Discover upload files
  $files = @()
  if (-not [string]::IsNullOrWhiteSpace($singleBundle)) {
    if (-not (Test-Path -LiteralPath $singleBundle)) { Fail "CS_SECURE_UPLOAD_BUNDLE was set but file not found: $singleBundle" }
    $ext = [System.IO.Path]::GetExtension($singleBundle).ToLowerInvariant()
    if ($ext -ne '.csb' -and -not ($Zip -and $ext -eq '.zip')) {
      Fail "CS_SECURE_UPLOAD_BUNDLE must point to a .csb file (or .zip when -Zip is used). Got: $singleBundle"
    }
    $files = @((Get-Item -LiteralPath $singleBundle -ErrorAction Stop))
  } else {
    if (-not (Test-Path -LiteralPath $ScanPath)) { Fail "Scan path not found: $ScanPath" }
    $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.csb' -ErrorAction Stop))
    if ($Zip) { $files += @((Get-ChildItem -LiteralPath $ScanPath -File -Filter '*.zip' -ErrorAction SilentlyContinue)) }
    $files = @($files | Sort-Object FullName -Unique)
  }

  if (@($files).Count -eq 0) { Write-LogLine 'ERROR' "No uploadable files found (.csb + optional .zip)."; exit 1 }

  # Per-file ticket map (FORCE ARRAY)
  $det = @(
    foreach ($f in @($files)) {
      [pscustomobject]@{
        Name   = $f.Name
        Full   = $f.FullName
        Bytes  = $f.Length
        Ticket = (Get-TicketFromFileName -Name $f.Name)
      }
    }
  )

  # Fill missing tickets
  $missing = @($det | Where-Object { [string]::IsNullOrWhiteSpace($_.Ticket) })
  if ($missing.Count -gt 0) {
    if ([string]::IsNullOrWhiteSpace($Ticket) -and $Silent) {
      $Ticket = '99999'
      Write-LogLine 'WARN' "Ticket missing for one or more files; -Silent used with no -Ticket. Defaulting missing tickets to 99999."
    }
    if (-not [string]::IsNullOrWhiteSpace($Ticket)) {
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    } else {
      if ($ExportOnly) { Fail "Ticket missing for one or more files and no -Ticket provided." }
      do { $Ticket = (Read-Host "Enter ticket number for missing file(s)").Trim() } while ([string]::IsNullOrWhiteSpace($Ticket))
      foreach ($m in $missing) { $m.Ticket = $Ticket }
      Write-LogLine 'INFO' ("Applied entered ticket '{0}' to {1} missing file(s)." -f $Ticket, $missing.Count)
    }
  }

  # Confirm upload (interactive only)
  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "Detected upload files:" -ForegroundColor Yellow
    foreach ($r in $det) {
      $t = if ($r.Ticket) { $r.Ticket } else { '(none)' }
      Write-Host ("  - {0}  (ticket: {1})" -f $r.Name, $t)
    }
    Write-Host ""
    $totalBytes = ($det | Measure-Object -Property Bytes -Sum).Sum
    if ($null -eq $totalBytes) { $totalBytes = 0 }
    Write-Host ("Total files: {0}" -f $det.Count)
    Write-Host ("Total size : {0}" -f (Get-SizeHuman ([long]$totalBytes)))
    Write-Host ""
    $confirm = (Read-Host "Upload ALL listed files now? (Y/N)").Trim().ToUpperInvariant()
    if ($confirm -ne 'Y') { Write-LogLine 'WARN' "User cancelled upload."; exit 0 }
  }

  $companyKey = Sanitize-ForKey $Company
  $failed = 0
  $uploaded = @()
  $destinationUsed = $null

  # ---------------------------
  # FIX: Destination selection
  # Default behavior is now:
  #   - If Azure is configured -> use Azure
  #   - Else -> try Lab
  # Also supports -ForceAzure / -ForceLab
  # ---------------------------
  $azureConfigured = (-not [string]::IsNullOrWhiteSpace($CsAzurePutBaseUrl)) -and (-not [string]::IsNullOrWhiteSpace($CsAzureSasToken)) -and ($CsAzureSasToken -ne 'PASTE_SAS_TOKEN_HERE')

  if ($ForceLab -and $ForceAzure) { Fail "Cannot use -ForceLab and -ForceAzure together." }

  $useAzure = $false
  $useLab   = $false

  if ($ForceAzure) {
    $useAzure = $true
  } elseif ($ForceLab) {
    $useLab = $true
  } else {
    # NEW DEFAULT: Azure first if configured
    if ($azureConfigured) { $useAzure = $true } else { $useLab = $true }
  }

  if ($useAzure) {
    if (-not $azureConfigured) {
      Fail "Azure upload selected but CsAzurePutBaseUrl/CsAzureSasToken not configured. Paste the SAS token into the script or set env vars CS_AZURE_PUT_BASEURL and CS_AZURE_SAS_TOKEN."
    }

    $destinationUsed = "CS Azure Blob (primary-vault)"
    $extraHeaders = Parse-HeaderStringToHashtable $CsAzurePutHeaders

    foreach ($r in @($det)) {
      $safeName = Sanitize-FileForKey $r.Name
      $prefix = if ($companyKey) { "$companyKey/$($r.Ticket)" } else { "$($r.Ticket)" }
      $objKey = "$prefix/$safeName"

      try {
        Write-LogLine 'INFO' ("Uploading (Azure): {0} -> {1}/{2}" -f $r.Name, $CsAzurePutBaseUrl.TrimEnd('/'), $objKey)
        Invoke-RetrySilent -Attempts 3 -PauseSeconds 1 -Action {
          Upload-FileAzureBlobSasPut -FilePath $r.Full -ContainerBaseUrl $CsAzurePutBaseUrl -ObjectKey $objKey -SasToken $CsAzureSasToken -ExtraHeaders $extraHeaders
        } | Out-Null
        Write-LogLine 'OK' ("Uploaded OK (Azure): {0}" -f $r.Name)
        $uploaded += [pscustomobject]@{ name=$r.Name; ticket=$r.Ticket; objectKey=$objKey; bytes=$r.Bytes; destination="cs-azure-blob" }
      } catch {
        $failed++
        Write-LogLine 'ERROR' ("Upload FAILED (Azure): {0} :: {1}" -f $r.Name, $_.Exception.Message)
      }
    }
  }

  if ($useLab) {
    $destinationUsed = "Lab destination"

    $labReachable = Test-ReachableWithRetrySilent -Url $LabEndpoint -Attempts 3 -PauseSeconds 1
    if (-not $labReachable) {
      Fail "Lab destination selected but endpoint not reachable: $LabEndpoint"
    }

    $creds = Resolve-Creds
    $ak = $creds.AccessKey
    $sk = $creds.SecretKey
    $labUri = [Uri]$LabEndpoint

    foreach ($r in @($det)) {
      $safeName = Sanitize-FileForKey $r.Name
      $prefix = if ($companyKey) { "$companyKey/$($r.Ticket)" } else { "$($r.Ticket)" }
      $objKey = "$prefix/$safeName"

      try {
        Write-LogLine 'INFO' ("Uploading (Lab): {0} -> s3://{1}/{2}" -f $r.Name, $LabBucket, $objKey)
        Invoke-RetrySilent -Attempts 3 -PauseSeconds 1 -Action {
          Upload-FileLab -FilePath $r.Full -EndpointUri $labUri -Bucket $LabBucket -Region $LabRegion -AccessKey $ak -SecretKey $sk -ObjectKey $objKey
        } | Out-Null
        Write-LogLine 'OK' ("Uploaded OK (Lab): {0}" -f $r.Name)
        $uploaded += [pscustomobject]@{ name=$r.Name; ticket=$r.Ticket; objectKey=$objKey; bytes=$r.Bytes; destination="lab" }
      } catch {
        $failed++
        Write-LogLine 'ERROR' ("Upload FAILED (Lab): {0} :: {1}" -f $r.Name, $_.Exception.Message)
      }
    }
  }

  # ExportOnly summary
  if ($ExportOnly) {
    $totalBytes = ($det | Measure-Object -Property Bytes -Sum).Sum
    if ($null -eq $totalBytes) { $totalBytes = 0 }

    $summary = [pscustomobject]@{
      labEndpoint       = $LabEndpoint
      labBucket         = $LabBucket
      labRegion         = $LabRegion
      csAzurePutBaseUrl = $CsAzurePutBaseUrl
      scanPath          = $ScanPath
      company           = $Company
      includeZip        = [bool]$Zip
      totalFiles        = $det.Count
      totalBytes        = [long]$totalBytes
      failed            = $failed
      destinationUsed   = $destinationUsed
      uploaded          = $uploaded
      logPath           = $LogPath
      timestamp         = (Get-Date).ToString('s')
    }
    $jsonPath = Join-Path $LogRoot ("secure-upload-export_{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    ($summary | ConvertTo-Json -Depth 7) | Out-File -LiteralPath $jsonPath -Encoding UTF8
  }

  if ($failed -gt 0) { exit 1 }

  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD SUCCESS. All files uploaded." -ForegroundColor Green
    Write-Host ""
    if ($destinationUsed) {
      Write-Host ("Destination used: {0}" -f $destinationUsed) -ForegroundColor Cyan
      Write-Host ""
    }
  }

  exit 0
}
catch {
  Write-LogLine 'ERROR' $_.Exception.Message
  if (-not ($Silent -or $ExportOnly)) {
    Write-Host ""
    Write-Host "UPLOAD FAILED. See log:" -ForegroundColor Red
    Write-Host ("  {0}" -f $LogPath) -ForegroundColor Yellow
    Write-Host ""
  }
  exit 1
}