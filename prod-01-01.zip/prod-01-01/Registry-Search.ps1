<# =================================================================================================
  Registry-Search.ps1  (v1.5.3)
  - Menu: [1] Search Uninstall Registry Hives, [Q] Quit (returns to Secondary-Validation-Tools)
  - After you enter the search text, it runs immediately with defaults:
      • Match mode: Wildcard (plain text auto-wrapped as *text*)
      • Scope: HKLM + HKCU (x64/x86 via reg.exe)
      • Export: CSV + Sidecar JSON (Excel-friendly)
  - After search completes, pressing ENTER returns to the menu (no exit)
================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
    [string]$Pattern,
    [switch]$Regex,
    [switch]$AllUsers,
    [ValidateSet('Inline','Sidecar','None')]
    [string]$JsonDetail = 'Sidecar',
    [int]$MaxInlineChars = 300,
    [string]$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Registry',
    [switch]$NoMenu
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-Info ($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Write-Ok   ($m){ Write-Host "[OK]  $m" -ForegroundColor Green }
function Write-Warn ($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }
function Write-Err  ($m){ Write-Host "[ERR] $m" -ForegroundColor Red }
function Pause-IfInteractive { try { if ($Host.Name -notlike '*ServerRemoteHost*') { Write-Host ""; $null = Read-Host "Press ENTER to return to menu" } } catch {} }
function Ensure-Directory   { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null } }

function Show-Header {
    Clear-Host
    Write-Host " ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host "==================================" -ForegroundColor Cyan
    Write-Host " Registry Search Utility" -ForegroundColor Gray
    Write-Host ""
}

# ---------- Core (reg.exe dual-view) ----------
$uninstRel = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
$roots = @(
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='64' },
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='32' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='64' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='32' }
)

$script:compiledRegex = $null
$script:Pattern = $null

function Build-Matchers {
    param([string]$Pattern, [switch]$Regex)
    $script:Pattern = $Pattern
    if (-not $Regex) { if (-not ($script:Pattern -match '[\*\?\[\]]')) { $script:Pattern = "*$script:Pattern*" } }
    if ($Regex) {
        try { $script:compiledRegex = [regex]::new($Pattern,'IgnoreCase') } catch { Write-Err "Invalid regex: $($_.Exception.Message)"; throw }
    } else { $script:compiledRegex = $null }
}

function Test-TextMatch {
    param([string]$Text)
    if ($null -eq $Text) { return $false }
    if ($script:compiledRegex) { return $script:compiledRegex.IsMatch([string]$Text) }
    else                      { return ([string]$Text -like $script:Pattern) }
}

function Invoke-RegQuery {
    param([string]$RootKey, [ValidateSet('64','32')][string]$View)
    $viewSwitch = if ($View -eq '64') { '/reg:64' } else { '/reg:32' }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:WINDIR\System32\reg.exe"
    $psi.Arguments = "query `"$RootKey`" /s $viewSwitch"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEnd()
    $err = $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    if ($p.ExitCode -ne 0 -and $err) { Write-Err $err.Trim() }
    return $out
}

function Parse-RegOutput {
    param([string]$Text, [string]$Hive, [string]$View)
    $rows = New-Object System.Collections.Generic.List[object]
    $currentKey = $null
    $currentVals = @()

    foreach ($line in ($Text -split "`r?`n")) {
        $trim = $line.TrimEnd()
        if ([string]::IsNullOrWhiteSpace($trim)) {
            if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }); $currentKey = $null; $currentVals = @() }
            continue
        }
        if ($trim -match '^(HKEY_[A-Z_\\0-9]+\\.+)$') {
            if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }); $currentVals = @() }
            $currentKey = $trim
            continue
        }
        if ($currentKey -and $trim -match '^\s{2,}(.+?)\s{2,}(REG_\w+)\s{2,}(.*)$') {
            $name = $matches[1].Trim()
            $type = $matches[2].Trim()
            $data = $matches[3]
            $currentVals += ,@{ Name=$name; Type=$type; Data=$data }
        }
    }
    if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }) }

    $out = New-Object System.Collections.Generic.List[object]
    foreach ($r in $rows) {
        $bag = @{}
        foreach ($v in $r.Values) { $bag[$v.Name] = $v.Data }
        $dispName = $bag['DisplayName']
        $dispVer  = $bag['DisplayVersion']
        $pub      = $bag['Publisher']
        $uninst   = $bag['UninstallString']
        $quninst  = $bag['QuietUninstallString']
        $keyName  = ($r.Key -replace '^HKEY_[^\\]+\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\','')
        $viewStr  = if ($View -eq '64') { 'x64' } else { 'x86' }
        $out.Add([pscustomobject]@{
            Hive                 = $Hive
            View                 = $viewStr
            KeyPath              = $r.Key
            KeyName              = $keyName
            DisplayName          = $dispName
            DisplayVersion       = $dispVer
            Publisher            = $pub
            UninstallString      = $uninst
            QuietUninstallString = $quninst
            _AllValues           = $bag
        })
    }
    return $out
}

function Get-ByView {
    param([string]$Hive, [string]$Root, [ValidateSet('64','32')][string]$View)
    $text = Invoke-RegQuery -RootKey $Root -View $View
    if ([string]::IsNullOrWhiteSpace($text)) { return @() }
    return Parse-RegOutput -Text $text -Hive $Hive -View $View
}

function Search-Uninstall {
    param([string]$Pattern, [switch]$Regex, [switch]$AllUsers, [string]$JsonDetail, [int]$MaxInlineChars, [string]$ExportRoot)

    Show-Header
    Write-Info "Searching uninstall entries via reg.exe (dual view) ..."
    if ($Regex) { Write-Info "Mode: Regex" } else { Write-Info "Mode: Wildcard -like" }
    Write-Info ("Pattern: {0}" -f $Pattern)
    Write-Info "Scope: Full key path + value names + value data"

    Build-Matchers -Pattern $Pattern -Regex:$Regex

    $all = New-Object System.Collections.Generic.List[object]
    foreach ($r in $roots) {
        $rows = Get-ByView -Hive $r.Hive -Root $r.Root -View $r.View
        foreach ($row in $rows) { $all.Add($row) }
    }

    # Match
    $hits = New-Object System.Collections.Generic.List[object]
    foreach ($row in $all) {
        $matched = $false
        if (Test-TextMatch -Text $row.KeyPath) { $matched = $true }
        elseif (Test-TextMatch -Text $row.KeyName) { $matched = $true }
        else {
            foreach ($k in $row._AllValues.Keys) {
                if (Test-TextMatch -Text $k) { $matched = $true; break }
                if (Test-TextMatch -Text $row._AllValues[$k]) { $matched = $true; break }
            }
        }
        if ($matched) { $hits.Add($row) }
    }

    $sorted = $hits | Sort-Object Hive, View, KeyName

    if (@($sorted).Count -eq 0) {
        Write-Warn "No matches found."
        Pause-IfInteractive
        return
    }

    @($sorted) | Select-Object Hive, View, KeyName, DisplayName, DisplayVersion, Publisher, UninstallString | Format-Table -AutoSize

    # Export
    Ensure-Directory -Path $ExportRoot
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $safe  = ($Pattern -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_'); if ([string]::IsNullOrWhiteSpace($safe)) { $safe = 'query' }
    $csv   = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, $safe)
    $detailsDir = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_details" -f $stamp)
    Ensure-Directory -Path $detailsDir

    @($sorted) | ForEach-Object {
        $o = $_ | Select-Object Hive, View, KeyName, KeyPath, DisplayName, DisplayVersion, Publisher, UninstallString, QuietUninstallString
        $namePart = ($_.KeyName -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_'); if ([string]::IsNullOrWhiteSpace($namePart)) { $namePart = 'unnamed' }
        $file = Join-Path $detailsDir ("{0}_{1}_{2}.json" -f $_.Hive, $_.View, $namePart)
        ($_._AllValues | ConvertTo-Json -Depth 4) | Set-Content -Path $file -Encoding UTF8
        Add-Member -InputObject $o -NotePropertyName AllValuesPath -NotePropertyValue $file -Force
        $o
    } | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Ok ("Found {0} matches. CSV saved to: {1}" -f (@($sorted).Count), $csv)
    Write-Ok ("Full value JSON saved under: {0}" -f $detailsDir)
    Pause-IfInteractive
}

# ---------- Menu ----------
function Run-Menu {
    while ($true) {
        Show-Header
        Write-Host "  [1] Search Uninstall Registry Hives" -ForegroundColor White
        Write-Host "  [Q] Quit (return to Secondary-Validation-Tools)" -ForegroundColor Yellow
        Write-Host ""
        $choice = Read-Host "Enter your choice"
        switch -Regex ($choice) {
            '^(1)$' {
                $pat = Read-Host "Enter search text (wildcards OK; plain text becomes *text*)"
                if ([string]::IsNullOrWhiteSpace($pat)) { Write-Warn "No input provided."; Pause-IfInteractive; continue }
                Search-Uninstall -Pattern $pat -Regex:$false -AllUsers:$false -JsonDetail $JsonDetail -MaxInlineChars $MaxInlineChars -ExportRoot $ExportRoot
                continue  # loops back to menu
            }
            '^(q|Q)$' {
                Show-Header
                Write-Info "Returning to Secondary-Validation-Tools..."
                $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\Secondary-Validation-Tools.ps1'
                if (Test-Path -LiteralPath $launcher) { & $launcher } else { Write-Warn "Launcher not found at $launcher" }
                break
            }
            default { Write-Warn "Invalid selection. Choose 1 or Q."; Pause-IfInteractive }
        }
    }
}

# ---------- Entrypoint ----------
if ($NoMenu) {
    if ([string]::IsNullOrWhiteSpace($Pattern)) { throw "When -NoMenu is used, -Pattern is required." }
    Search-Uninstall -Pattern $Pattern -Regex:$Regex -AllUsers:$AllUsers -JsonDetail $JsonDetail -MaxInlineChars $MaxInlineChars -ExportRoot $ExportRoot
} else {
    Run-Menu
}
