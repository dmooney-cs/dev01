<# =================================================================================================
  Registry-Search.ps1  (v1.7.3a - fixed parser issues, single-copy, "press Enter after selection")

  Menu:
    [1] Search Uninstall Registry Hives
    [Q] Quit (returns to CS-Toolbox-Launcher.ps1)

  Defaults:
    • Match mode: Wildcard (plain text auto-wrapped as *text*)
    • Scope: HKLM + HKCU (x64/x86 via reg.exe)
    • Export: CSV + per-result JSON sidecars (Excel-friendly)

  Non-interactive:
    -App "name"   -> direct search, no menu, NO pause. (Exports only; no blocks)
    -NoMenu       -> direct search with -Pattern, COMPLETELY SILENT (exports only)

================================================================================================= #>

#requires -version 5.1

param(
    [string]$Pattern,
    [string]$App,                        # Direct app search without menu
    [switch]$Regex,
    [switch]$AllUsers,                   # reserved / compat
    [ValidateSet('Inline','Sidecar','None')]
    [string]$JsonDetail = 'Sidecar',
    [int]$MaxInlineChars = 300,
    [string]$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Registry',
    [switch]$NoMenu
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Non-interactive flag:
#   -App: non-interactive, exports only, no blocks, no pause
#   -NoMenu: non-interactive AND completely silent (no screen output)
$script:IsNonInteractive = $false
$script:IsSilentNoMenu   = $false

# ---------- UI helpers ----------
function Write-Info ($m){ if (-not $script:IsNonInteractive) { Write-Host "[INFO] $m" -ForegroundColor Cyan } }
function Write-Ok   ($m){ if (-not $script:IsNonInteractive) { Write-Host "[OK]  $m" -ForegroundColor Green } }
function Write-Warn ($m){ if (-not $script:IsNonInteractive) { Write-Host "[WARN] $m" -ForegroundColor Yellow } }
function Write-Err  ($m){ if (-not $script:IsNonInteractive) { Write-Host "[ERR] $m" -ForegroundColor Red } }

function Prompt-Selection {
    param(
        [Parameter(Mandatory)][string]$PromptLabel,
        [string]$DefaultValue = $null
    )
    if ($script:IsNonInteractive) { return $null }

    $p = if ($DefaultValue) {
        "{0} (default {1}; press Enter after selection)" -f $PromptLabel, $DefaultValue
    } else {
        "{0} (press Enter after selection)" -f $PromptLabel
    }

    $val = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($val) -and $DefaultValue) { $val = $DefaultValue }
    return $val
}

function Pause-IfInteractive {
    if ($script:IsNonInteractive) { return }
    try {
        Write-Host ""
        $null = Read-Host "Press ENTER to return to menu (press Enter after selection)"
    } catch {}
}

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Show-Header {
    if ($script:IsNonInteractive) { return }
    Clear-Host
    Write-Host " ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host "==================================" -ForegroundColor Cyan
    Write-Host " Registry Search Utility" -ForegroundColor Gray
    Write-Host ""
}

function Get-ConsoleWidth {
    try {
        $w = $Host.UI.RawUI.WindowSize.Width
        if ($w -lt 40) { return 120 } else { return [math]::Min($w, 220) }
    } catch { return 120 }
}

function Wrap-Text {
    param(
        [Parameter(Mandatory)][string]$Text,
        [int]$Width = 120,
        [int]$IndentSpaces = 2
    )
    if (-not $Text) { return "" }
    $indent = ' ' * $IndentSpaces
    $soft = ($Text -replace "(.{1,$Width})(\s+|$)",'$1`n').TrimEnd("`n")
    $lines = $soft -split "`n"
    if ($lines.Count -le 1) { return $soft }
    $out = New-Object System.Collections.Generic.List[string]
    for ($i=0; $i -lt $lines.Count; $i++) {
        if ($i -eq 0) { $out.Add($lines[$i]) } else { $out.Add($indent + $lines[$i]) }
    }
    return ($out -join "`n")
}

function Line {
    param([int]$Width)
    $w = if ($Width) { $Width } else { Get-ConsoleWidth }
    return ('-' * [math]::Max(40, [math]::Min($w, 220)))
}

function Show-Block {
    param(
        [int]$Index,
        [int]$Total,
        [pscustomobject]$Item,
        [hashtable]$AllValues,
        [int]$Width,
        [string]$JsonPath
    )

    # Non-interactive modes: no block printing
    if ($script:IsNonInteractive) { return }

    $w = if ($Width) { $Width } else { Get-ConsoleWidth }
    $sep = Line -Width $w

    $title = $Item.DisplayName
    if ([string]::IsNullOrWhiteSpace($title)) { $title = "(no DisplayName)" }
    $ver = if ($Item.DisplayVersion) { "  v$($Item.DisplayVersion)" } else { "" }
    $pub = if ($Item.Publisher) { " - $($Item.Publisher)" } else { "" }

    $hdr = "[{0}/{1}] {2}{3}{4}" -f $Index, $Total, $title, $ver, $pub

    Write-Host $sep -ForegroundColor DarkGray
    Write-Host $hdr -ForegroundColor White
    Write-Host ("Hive/View:  {0}/{1}" -f $Item.Hive, $Item.View) -ForegroundColor Gray
    Write-Host ("Key Name:   {0}" -f $Item.KeyName) -ForegroundColor Gray
    Write-Host ("Key Path:   {0}" -f $Item.KeyPath) -ForegroundColor Gray

    if ($Item.UninstallString) {
        $u = Wrap-Text -Text $Item.UninstallString -Width ($w-14) -IndentSpaces 12
        Write-Host ("Uninstall:  {0}" -f $u) -ForegroundColor Gray
    }
    if ($Item.QuietUninstallString) {
        $q = Wrap-Text -Text $Item.QuietUninstallString -Width ($w-14) -IndentSpaces 12
        Write-Host ("Quiet Un:   {0}" -f $q) -ForegroundColor Gray
    }

    Write-Host ""
    Write-Host "Values:" -ForegroundColor DarkCyan

    $preferred = @(
        'DisplayName','DisplayVersion','Publisher','InstallLocation','InstallDate',
        'URLInfoAbout','URLUpdateInfo','HelpLink','ModifyPath','InstallSource',
        'EstimatedSize','Language','ProductName'
    )

    $keys = [System.Collections.Generic.List[string]]::new()
    foreach ($k in $preferred) { if ($AllValues.ContainsKey($k)) { $keys.Add($k) } }
    foreach ($k in ($AllValues.Keys | Sort-Object)) { if (-not $keys.Contains($k)) { $keys.Add($k) } }

    foreach ($k in $keys) {
        $val = [string]$AllValues[$k]
        if ($null -eq $val) { $val = "" }
        if ($MaxInlineChars -gt 0 -and $val.Length -gt $MaxInlineChars) {
            $val = ($val -replace "(.{1,$MaxInlineChars})(?=\S)",'$1 ')
        }
        $wrapped = Wrap-Text -Text $val -Width ($w-16) -IndentSpaces 14
        Write-Host ("  {0,-12}: {1}" -f $k, $wrapped)
    }

    if ($JsonPath) {
        Write-Host ""
        Write-Host ("[details] Full value JSON: {0}" -f $JsonPath) -ForegroundColor DarkGray
    }
}

# ---------- Core (reg.exe dual-view) ----------
$uninstRel = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
$roots = @(
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='64' },
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='32' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='64' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='32' }
)

$script:compiledRegex = $null
$script:PatternLike   = $null

function Build-Matchers {
    param([string]$Pattern, [switch]$Regex)

    if ($Regex) {
        try { $script:compiledRegex = [regex]::new($Pattern,'IgnoreCase') }
        catch {
            if (-not $script:IsSilentNoMenu) { Write-Err "Invalid regex: $($_.Exception.Message)" }
            throw
        }
        $script:PatternLike = $null
        return
    }

    $script:compiledRegex = $null
    $p = $Pattern
    if (-not ($p -match '[\*\?\[\]]')) { $p = "*$p*" }
    $script:PatternLike = $p
}

function Test-TextMatch {
    param([string]$Text)
    if ($null -eq $Text) { return $false }
    if ($script:compiledRegex) { return $script:compiledRegex.IsMatch([string]$Text) }
    return ([string]$Text -like $script:PatternLike)
}

function Invoke-RegQuery {
    param([string]$RootKey, [ValidateSet('64','32')][string]$View)

    $viewSwitch = if ($View -eq '64') { '/reg:64' } else { '/reg:32' }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:WINDIR\System32\reg.exe"
    $psi.Arguments = "query `"$RootKey`" /s $viewSwitch"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true

    $p = [System.Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEnd()
    $err = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if (-not $script:IsSilentNoMenu) {
        if ($p.ExitCode -ne 0 -and $err) { Write-Err $err.Trim() }
    }
    return $out
}

function Parse-RegOutput {
    param([string]$Text, [string]$Hive, [string]$View)

    $rows = New-Object System.Collections.Generic.List[object]
    $currentKey  = $null
    $currentVals = @()

    foreach ($line in ($Text -split "`r?`n")) {
        $trim = $line.TrimEnd()

        if ([string]::IsNullOrWhiteSpace($trim)) {
            if ($currentKey) {
                $rows.Add(@{ Key=$currentKey; Values=$currentVals })
                $currentKey  = $null
                $currentVals = @()
            }
            continue
        }

        if ($trim -match '^(HKEY_[A-Z_\\0-9]+\\.+)$') {
            if ($currentKey) {
                $rows.Add(@{ Key=$currentKey; Values=$currentVals })
                $currentVals = @()
            }
            $currentKey = $trim
            continue
        }

        if ($currentKey -and $trim -match '^\s{2,}(.+?)\s{2,}(REG_\w+)\s{2,}(.*)$') {
            $name = $matches[1].Trim()
            $data = $matches[3]
            $currentVals += ,@{ Name=$name; Data=$data }
        }
    }

    if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }) }

    $out = New-Object System.Collections.Generic.List[object]
    foreach ($r in $rows) {
        $bag = @{}
        foreach ($v in $r.Values) { $bag[$v.Name] = $v.Data }

        $keyName = ($r.Key -replace '^HKEY_[^\\]+\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\','')
        $viewStr = if ($View -eq '64') { 'x64' } else { 'x86' }

        $out.Add([pscustomobject]@{
            Hive                 = $Hive
            View                 = $viewStr
            KeyPath              = $r.Key
            KeyName              = $keyName
            DisplayName          = $bag['DisplayName']
            DisplayVersion       = $bag['DisplayVersion']
            Publisher            = $bag['Publisher']
            UninstallString      = $bag['UninstallString']
            QuietUninstallString = $bag['QuietUninstallString']
            _AllValues           = $bag
        })
    }

    return $out
}

function Get-ByView {
    param([string]$Hive, [string]$Root, [ValidateSet('64','32')][string]$View)

    $text = Invoke-RegQuery -RootKey $Root -View $View
    if ([string]::IsNullOrWhiteSpace($text)) { return @() }
    return Parse-RegOutput -Text $text -Hive $Hive -View $View
}

function Search-Uninstall {
    param(
        [Parameter(Mandatory)][string]$Pattern,
        [switch]$Regex,
        [string]$ExportRoot
    )

    if (-not $script:IsNonInteractive) {
        Show-Header
        Write-Info "Searching uninstall entries via reg.exe (dual view) ..."
        Write-Info ("Mode: {0}" -f ($(if ($Regex) { 'Regex' } else { 'Wildcard -like' })))
        Write-Info ("Pattern: {0}" -f $Pattern)
        Write-Info "Scope: Full key path + value names + value data"
    }

    Build-Matchers -Pattern $Pattern -Regex:$Regex

    $all = New-Object System.Collections.Generic.List[object]
    foreach ($r in $roots) {
        $rows = Get-ByView -Hive $r.Hive -Root $r.Root -View $r.View
        foreach ($row in $rows) { $all.Add($row) }
    }

    $hits = New-Object System.Collections.Generic.List[object]
    foreach ($row in $all) {
        $matched = $false

        if (Test-TextMatch -Text $row.KeyPath) { $matched = $true }
        elseif (Test-TextMatch -Text $row.KeyName) { $matched = $true }
        else {
            foreach ($k in $row._AllValues.Keys) {
                if (Test-TextMatch -Text $k) { $matched = $true; break }
                if (Test-TextMatch -Text $row._AllValues[$k]) { $matched = $true; break }
            }
        }

        if ($matched) { $hits.Add($row) }
    }

    $sorted = $hits | Sort-Object Hive, View, KeyName
    $total  = @($sorted).Count

    if ($total -eq 0) {
        if (-not $script:IsNonInteractive) {
            Write-Warn "No matches found."
            Pause-IfInteractive
        }
        return
    }

    Ensure-Directory -Path $ExportRoot
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $safe  = ($Pattern -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_')
    if ([string]::IsNullOrWhiteSpace($safe)) { $safe = 'query' }

    $csv        = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, $safe)
    $detailsDir = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_details" -f $stamp)
    Ensure-Directory -Path $detailsDir

    $exportRows = @()
    $idx = 0
    $w = if ($script:IsNonInteractive) { 120 } else { Get-ConsoleWidth }

    if (-not $script:IsNonInteractive) {
        Write-Host ""
        Write-Host ("Summary: Found {0} matching uninstall entries." -f $total) -ForegroundColor Green
        Write-Host ""
    }

    foreach ($item in $sorted) {
        $idx++

        $namePart = ($item.KeyName -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_')
        if ([string]::IsNullOrWhiteSpace($namePart)) { $namePart = 'unnamed' }

        $file = Join-Path $detailsDir ("{0}_{1}_{2}.json" -f $item.Hive, $item.View, $namePart)
        ($item._AllValues | ConvertTo-Json -Depth 6) | Set-Content -Path $file -Encoding UTF8

        Show-Block -Index $idx -Total $total -Item $item -AllValues $item._AllValues -Width $w -JsonPath $file

        $exportRows += [pscustomobject]@{
            Hive                 = $item.Hive
            View                 = $item.View
            KeyName              = $item.KeyName
            KeyPath              = $item.KeyPath
            DisplayName          = $item.DisplayName
            DisplayVersion       = $item.DisplayVersion
            Publisher            = $item.Publisher
            UninstallString      = $item.UninstallString
            QuietUninstallString = $item.QuietUninstallString
            AllValuesPath        = $file
        }
    }

    $exportRows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    if (-not $script:IsNonInteractive) {
        Write-Host (Line -Width $w) -ForegroundColor DarkGray
        Write-Ok ("CSV saved to: {0}" -f $csv)
        Write-Ok ("Full value JSON saved under: {0}" -f $detailsDir)
        Write-Host ""
        Pause-IfInteractive
    }
}

function Run-Menu {
    while ($true) {
        Show-Header
        Write-Host "  [1] Search Uninstall Registry Hives" -ForegroundColor White
        Write-Host "  [Q] Quit (return to CS-Toolbox-Launcher)" -ForegroundColor Yellow
        Write-Host ""

        $choice = Prompt-Selection "Enter your choice"
        switch -Regex ($choice) {
            '^(1)$' {
                $pat = Prompt-Selection "Enter search text (wildcards OK; plain text becomes *text*)"
                if ([string]::IsNullOrWhiteSpace($pat)) {
                    Write-Warn "No input provided."
                    Pause-IfInteractive
                    continue
                }
                Search-Uninstall -Pattern $pat -Regex:$false -ExportRoot $ExportRoot
                continue
            }
            '^(q|Q)$' {
                Show-Header
                Write-Info "Returning to CS-Toolbox-Launcher..."
                $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
                if (Test-Path -LiteralPath $launcher) {
                    & $launcher
                } else {
                    Write-Warn "Launcher not found at $launcher"
                    Pause-IfInteractive
                }
                break
            }
            default {
                Write-Warn "Invalid selection. Choose 1 or Q."
                Pause-IfInteractive
            }
        }
    }
}

# ---------- Entrypoint ----------
if (-not [string]::IsNullOrWhiteSpace($App)) {
    $script:IsNonInteractive = $true
    $script:IsSilentNoMenu   = $false
    Search-Uninstall -Pattern $App -Regex:$Regex -ExportRoot $ExportRoot
    return
}

if ($NoMenu) {
    $script:IsNonInteractive = $true
    $script:IsSilentNoMenu   = $true
    if ([string]::IsNullOrWhiteSpace($Pattern)) { return }
    Search-Uninstall -Pattern $Pattern -Regex:$Regex -ExportRoot $ExportRoot
    return
}

$script:IsNonInteractive = $false
$script:IsSilentNoMenu   = $false
Run-Menu