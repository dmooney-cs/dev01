<# =================================================================================================
  Registry-Search.ps1  (v1.6.1 - OSQuery-style readable blocks, ASCII-safe)
  - Menu: [1] Search Uninstall Registry Hives, [Q] Quit (returns to Secondary-Validation-Tools)
  - After you enter the search text, it runs immediately with defaults:
      • Match mode: Wildcard (plain text auto-wrapped as *text*)
      • Scope: HKLM + HKCU (x64/x86 via reg.exe)
      • Export: CSV + per-result JSON (Excel-friendly)
  - Screen output mirrors the OSQuery "Application Results" style:
      • Summary header
      • One visually separated block per match
      • Full values shown with wrapped lines for readability
================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
    [string]$Pattern,
    [switch]$Regex,
    [switch]$AllUsers,
    [ValidateSet('Inline','Sidecar','None')]
    [string]$JsonDetail = 'Sidecar',
    [int]$MaxInlineChars = 300,
    [string]$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Registry',
    [switch]$NoMenu
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---------- UI helpers ----------
function Write-Info ($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Write-Ok   ($m){ Write-Host "[OK]  $m" -ForegroundColor Green }
function Write-Warn ($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }
function Write-Err  ($m){ Write-Host "[ERR] $m" -ForegroundColor Red }
function Pause-IfInteractive { try { if ($Host.Name -notlike '*ServerRemoteHost*') { Write-Host ""; $null = Read-Host "Press ENTER to return to menu" } } catch {} }
function Ensure-Directory { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null } }

function Show-Header {
    Clear-Host
    Write-Host " ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host "==================================" -ForegroundColor Cyan
    Write-Host " Registry Search Utility" -ForegroundColor Gray
    Write-Host ""
}

function Get-ConsoleWidth {
    try {
        $w = $Host.UI.RawUI.WindowSize.Width
        if ($w -lt 40) { return 120 } else { return [math]::Min($w, 220) }
    } catch { return 120 }
}

function Wrap-Text {
    param(
        [Parameter(Mandatory)][string]$Text,
        [int]$Width = 120,
        [int]$IndentSpaces = 2
    )
    if (-not $Text) { return "" }
    $indent = ' ' * $IndentSpaces
    $soft = ($Text -replace "(.{1,$Width})(\s+|$)",'$1`n').TrimEnd("`n")
    $lines = $soft -split "`n"
    if ($lines.Count -le 1) { return $soft }
    $out = New-Object System.Collections.Generic.List[string]
    for ($i=0; $i -lt $lines.Count; $i++) {
        if ($i -eq 0) { $out.Add($lines[$i]) } else { $out.Add($indent + $lines[$i]) }
    }
    return ($out -join "`n")
}

function Line {
    param([int]$Width)
    $w = if ($Width) { $Width } else { Get-ConsoleWidth }
    return ('-' * [math]::Max(40, [math]::Min($w, 220)))
}

function Show-Block {
    param(
        [int]$Index,
        [int]$Total,
        [pscustomobject]$Item,     # row with mapped fields
        [hashtable]$AllValues,     # full value bag
        [int]$Width,
        [string]$JsonPath          # where the sidecar full JSON is saved
    )

    $w = if ($Width) { $Width } else { Get-ConsoleWidth }
    $sep = Line -Width $w
    $title = $Item.DisplayName
    if ([string]::IsNullOrWhiteSpace($title)) { $title = "(no DisplayName)" }
    $ver = ""
    if ($Item.DisplayVersion) { $ver = "  v$($Item.DisplayVersion)" }
    $pub = ""
    if ($Item.Publisher) { $pub = " - $($Item.Publisher)" }  # ASCII-only dash

    $hdr = "[{0}/{1}] {2}{3}{4}" -f $Index, $Total, $title, $ver, $pub

    Write-Host $sep -ForegroundColor DarkGray
    Write-Host $hdr -ForegroundColor White
    Write-Host ("Hive/View:  {0}/{1}" -f $Item.Hive, $Item.View) -ForegroundColor Gray
    Write-Host ("Key Name:   {0}" -f $Item.KeyName) -ForegroundColor Gray
    Write-Host ("Key Path:   {0}" -f $Item.KeyPath) -ForegroundColor Gray

    if ($Item.UninstallString) {
        $u = Wrap-Text -Text $Item.UninstallString -Width ($w-14) -IndentSpaces 12
        Write-Host ("Uninstall:  {0}" -f $u) -ForegroundColor Gray
    }
    if ($Item.QuietUninstallString) {
        $q = Wrap-Text -Text $Item.QuietUninstallString -Width ($w-14) -IndentSpaces 12
        Write-Host ("Quiet Un:   {0}" -f $q) -ForegroundColor Gray
    }

    Write-Host ""
    Write-Host "Values:" -ForegroundColor DarkCyan

    # Preferred order first, then the rest in alpha
    $preferred = @(
        'DisplayName','DisplayVersion','Publisher','InstallLocation','InstallDate',
        'URLInfoAbout','URLUpdateInfo','HelpLink','ModifyPath','InstallSource',
        'EstimatedSize','Language','ProductName'
    )

    $keys = [System.Collections.Generic.List[string]]::new()
    foreach ($k in $preferred) { if ($AllValues.ContainsKey($k)) { $keys.Add($k) } }
    foreach ($k in ($AllValues.Keys | Sort-Object)) { if (-not $keys.Contains($k)) { $keys.Add($k) } }

    foreach ($k in $keys) {
        $val = [string]$AllValues[$k]
        if ($null -eq $val) { $val = "" }
        if ($MaxInlineChars -gt 0 -and $val.Length -gt $MaxInlineChars) {
            $val = ($val -replace "(.{1,$MaxInlineChars})(?=\S)",'$1 ')
        }
        $wrapped = Wrap-Text -Text $val -Width ($w-16) -IndentSpaces 14
        Write-Host ("  {0,-12}: {1}" -f $k, $wrapped)
    }

    if ($JsonPath) {
        Write-Host ""
        Write-Host ("[details] Full value JSON: {0}" -f $JsonPath) -ForegroundColor DarkGray
    }
}

# ---------- Core (reg.exe dual-view) ----------
$uninstRel = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
$roots = @(
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='64' },
    @{ Hive='HKLM'; Root="HKLM\$uninstRel"; View='32' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='64' },
    @{ Hive='HKCU'; Root="HKCU\$uninstRel"; View='32' }
)

$script:compiledRegex = $null
$script:Pattern = $null

function Build-Matchers {
    param([string]$Pattern, [switch]$Regex)
    $script:Pattern = $Pattern
    if (-not $Regex) { if (-not ($script:Pattern -match '[\*\?\[\]]')) { $script:Pattern = "*$script:Pattern*" } }
    if ($Regex) {
        try { $script:compiledRegex = [regex]::new($Pattern,'IgnoreCase') } catch { Write-Err "Invalid regex: $($_.Exception.Message)"; throw }
    } else { $script:compiledRegex = $null }
}

function Test-TextMatch {
    param([string]$Text)
    if ($null -eq $Text) { return $false }
    if ($script:compiledRegex) { return $script:compiledRegex.IsMatch([string]$Text) }
    else { return ([string]$Text -like $script:Pattern) }
}

function Invoke-RegQuery {
    param([string]$RootKey, [ValidateSet('64','32')][string]$View)
    $viewSwitch = if ($View -eq '64') { '/reg:64' } else { '/reg:32' }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:WINDIR\System32\reg.exe"
    $psi.Arguments = "query `"$RootKey`" /s $viewSwitch"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEnd()
    $err = $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    if ($p.ExitCode -ne 0 -and $err) { Write-Err $err.Trim() }
    return $out
}

function Parse-RegOutput {
    param([string]$Text, [string]$Hive, [string]$View)
    $rows = New-Object System.Collections.Generic.List[object]
    $currentKey = $null
    $currentVals = @()

    foreach ($line in ($Text -split "`r?`n")) {
        $trim = $line.TrimEnd()
        if ([string]::IsNullOrWhiteSpace($trim)) {
            if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }); $currentKey = $null; $currentVals = @() }
            continue
        }
        if ($trim -match '^(HKEY_[A-Z_\\0-9]+\\.+)$') {
            if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }); $currentVals = @() }
            $currentKey = $trim
            continue
        }
        if ($currentKey -and $trim -match '^\s{2,}(.+?)\s{2,}(REG_\w+)\s{2,}(.*)$') {
            $name = $matches[1].Trim()
            $type = $matches[2].Trim()
            $data = $matches[3]
            $currentVals += ,@{ Name=$name; Type=$type; Data=$data }
        }
    }
    if ($currentKey) { $rows.Add(@{ Key=$currentKey; Values=$currentVals }) }

    $out = New-Object System.Collections.Generic.List[object]
    foreach ($r in $rows) {
        $bag = @{}
        foreach ($v in $r.Values) { $bag[$v.Name] = $v.Data }
        $dispName = $bag['DisplayName']
        $dispVer  = $bag['DisplayVersion']
        $pub      = $bag['Publisher']
        $uninst   = $bag['UninstallString']
        $quninst  = $bag['QuietUninstallString']
        $keyName  = ($r.Key -replace '^HKEY_[^\\]+\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\','')
        $viewStr  = if ($View -eq '64') { 'x64' } else { 'x86' }
        $out.Add([pscustomobject]@{
            Hive                 = $Hive
            View                 = $viewStr
            KeyPath              = $r.Key
            KeyName              = $keyName
            DisplayName          = $dispName
            DisplayVersion       = $dispVer
            Publisher            = $pub
            UninstallString      = $uninst
            QuietUninstallString = $quninst
            _AllValues           = $bag
        })
    }
    return $out
}

function Get-ByView {
    param([string]$Hive, [string]$Root, [ValidateSet('64','32')][string]$View)
    $text = Invoke-RegQuery -RootKey $Root -View $View
    if ([string]::IsNullOrWhiteSpace($text)) { return @() }
    return Parse-RegOutput -Text $text -Hive $Hive -View $View
}

function Search-Uninstall {
    param([string]$Pattern, [switch]$Regex, [switch]$AllUsers, [string]$JsonDetail, [int]$MaxInlineChars, [string]$ExportRoot)

    Show-Header
    Write-Info "Searching uninstall entries via reg.exe (dual view) ..."
    if ($Regex) { Write-Info "Mode: Regex" } else { Write-Info "Mode: Wildcard -like" }
    Write-Info ("Pattern: {0}" -f $Pattern)
    Write-Info "Scope: Full key path + value names + value data"

    Build-Matchers -Pattern $Pattern -Regex:$Regex

    $all = New-Object System.Collections.Generic.List[object]
    foreach ($r in $roots) {
        $rows = Get-ByView -Hive $r.Hive -Root $r.Root -View $r.View
        foreach ($row in $rows) { $all.Add($row) }
    }

    # Match
    $hits = New-Object System.Collections.Generic.List[object]
    foreach ($row in $all) {
        $matched = $false
        if (Test-TextMatch -Text $row.KeyPath) { $matched = $true }
        elseif (Test-TextMatch -Text $row.KeyName) { $matched = $true }
        else {
            foreach ($k in $row._AllValues.Keys) {
                if (Test-TextMatch -Text $k) { $matched = $true; break }
                if (Test-TextMatch -Text $row._AllValues[$k]) { $matched = $true; break }
            }
        }
        if ($matched) { $hits.Add($row) }
    }

    $sorted = $hits | Sort-Object Hive, View, KeyName
    $total = @($sorted).Count
    if ($total -eq 0) {
        Write-Warn "No matches found."
        Pause-IfInteractive
        return
    }

    # ---------- Export ----------
    Ensure-Directory -Path $ExportRoot
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $safe  = ($Pattern -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_'); if ([string]::IsNullOrWhiteSpace($safe)) { $safe = 'query' }
    $csv   = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, $safe)
    $detailsDir = Join-Path $ExportRoot ("Registry-UninstallSearch_{0}_details" -f $stamp)
    Ensure-Directory -Path $detailsDir

    $exportRows = @()

    $idx = 0
    $w = Get-ConsoleWidth
    Write-Host ""
    Write-Host ("Summary: Found {0} matching uninstall entries." -f $total) -ForegroundColor Green
    Write-Host ""

    foreach ($item in $sorted) {
        $idx++
        # Save full values sidecar JSON (and include path for display)
        $namePart = ($item.KeyName -replace '[^\p{L}\p{Nd}\-_.]+','_').Trim('_')
        if ([string]::IsNullOrWhiteSpace($namePart)) { $namePart = 'unnamed' }
        $file = Join-Path $detailsDir ("{0}_{1}_{2}.json" -f $item.Hive, $item.View, $namePart)
        ($item._AllValues | ConvertTo-Json -Depth 4) | Set-Content -Path $file -Encoding UTF8

        # Screen block (OSQuery-style)
        Show-Block -Index $idx -Total $total -Item $item -AllValues $item._AllValues -Width $w -JsonPath $file

        # CSV export row
        $exportRows += [pscustomobject]@{
            Hive                 = $item.Hive
            View                 = $item.View
            KeyName              = $item.KeyName
            KeyPath              = $item.KeyPath
            DisplayName          = $item.DisplayName
            DisplayVersion       = $item.DisplayVersion
            Publisher            = $item.Publisher
            UninstallString      = $item.UninstallString
            QuietUninstallString = $item.QuietUninstallString
            AllValuesPath        = $file
        }
    }

    $exportRows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Host (Line -Width $w) -ForegroundColor DarkGray
    Write-Ok ("CSV saved to: {0}" -f $csv)
    Write-Ok ("Full value JSON saved under: {0}" -f $detailsDir)
    Write-Host ""
    Pause-IfInteractive
}

# ---------- Menu ----------
function Run-Menu {
    while ($true) {
        Show-Header
        Write-Host "  [1] Search Uninstall Registry Hives" -ForegroundColor White
        Write-Host "  [Q] Quit (return to Secondary-Validation-Tools)" -ForegroundColor Yellow
        Write-Host ""
        $choice = Read-Host "Enter your choice"
        switch -Regex ($choice) {
            '^(1)$' {
                $pat = Read-Host "Enter search text (wildcards OK; plain text becomes *text*)"
                if ([string]::IsNullOrWhiteSpace($pat)) { Write-Warn "No input provided."; Pause-IfInteractive; continue }
                Search-Uninstall -Pattern $pat -Regex:$false -AllUsers:$false -JsonDetail $JsonDetail -MaxInlineChars $MaxInlineChars -ExportRoot $ExportRoot
                continue
            }
            '^(q|Q)$' {
                Show-Header
                Write-Info "Returning to Secondary-Validation-Tools..."
                $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
                if (Test-Path -LiteralPath $launcher) { & $launcher } else { Write-Warn "Launcher not found at $launcher" }
                break
            }
            default { Write-Warn "Invalid selection. Choose 1 or Q."; Pause-IfInteractive }
        }
    }
}

# ---------- Entrypoint ----------
if ($NoMenu) {
    if ([string]::IsNullOrWhiteSpace($Pattern)) { throw "When -NoMenu is used, -Pattern is required." }
    Search-Uninstall -Pattern $Pattern -Regex:$Regex -AllUsers:$AllUsers -JsonDetail $JsonDetail -MaxInlineChars $MaxInlineChars -ExportRoot $ExportRoot
} else {
    Run-Menu
}
