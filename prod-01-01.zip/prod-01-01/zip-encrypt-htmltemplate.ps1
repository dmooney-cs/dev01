<# =================================================================================================
 zip-encrypt-htmltemplate.ps1  (v1.18 - Secure HTML fallback fixed)
 Behavior (now):
  - Unsecure:
      * Creates ZIP
      * Opens Compose Helper HTML unless -NoHtml
  - Secure:
      * Creates ZIP in C:\CS-Toolbox-TEMP\ZIP
      * Encrypts ZIP -> .csb using embedded RSA public key (PS5.1-compatible OAEP handling)
      * ALWAYS deletes the ZIP (only .csb remains)
      * Calls: C:\CS-Toolbox-TEMP\prod-01-01\CS-secure-file-upload.ps1
        - Opens Compose Helper HTML ONLY if upload fails (unless -NoHtml)
        - Does NOT open HTML on success unless explicitly forced with -Html
      * "Press any key..." then returns to Toolbox Launcher (CS-Toolbox-Launcher.ps1)

 Notes:
  - NO PowerShell 7 syntax. (No ?:, no ??)
  - No reliance on $LASTEXITCODE existing (safe reads only)
  - -ExportOnly supported (exports bundle info to Collected-Info and exits)
================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
  # MODE SELECTION
  [Alias('s')]
  [switch]$Secure,

  [Alias('u')]
  [switch]$Unsecure,

  # OPTIONAL METADATA (can be passed via CLI)
  [Alias('c')]
  [string]$Company,

  [Alias('t')]
  [string]$Ticket,

  [string]$Signature,
  [string]$Cc,
  [string]$To,

  # OUTPUT CONTROLS
  [switch]$Html,        # Force: generate + auto-open helper (Secure: ONLY if explicitly provided)
  [switch]$NoHtml,      # Force: never generate/open helper
  [switch]$SkipZip,     # kept for compatibility; Secure will still delete ZIP regardless

  # COOKBOOK CONTROL
  [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --------------------------
# Mode / Silence rules
# --------------------------
$NonInteractive = ($Secure -or $Unsecure -or $ExportOnly)
$Silent         = ($Secure -or $Unsecure -or $ExportOnly)

if ($Secure) { $SkipZip = $true }  # compatibility switch; we still build zip then delete

# NOTE: Removed the old rule that forced -NoHtml for non-interactive runs.
# Old behavior (removed):
#   if ($NonInteractive -and -not $PSBoundParameters.ContainsKey('Html')) { $NoHtml = $true }
# New behavior:
#   - HTML fallback works in Secure mode on upload failure unless user explicitly sets -NoHtml.

# Explicit -NoHtml always wins
if ($NoHtml) { $Html = $false }

if ($Silent) {
  $global:ProgressPreference    = 'SilentlyContinue'
  $global:VerbosePreference     = 'SilentlyContinue'
  $global:InformationPreference = 'SilentlyContinue'
  $global:WarningPreference     = 'SilentlyContinue'
  $global:DebugPreference       = 'SilentlyContinue'
  $global:ConfirmPreference     = 'None'
}

# =================== Config ===================
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$OutDir     = if ($ExportOnly) { Join-Path $ExportRoot 'ZIP' } else { 'C:\CS-Toolbox-TEMP\ZIP' }

$DefaultSources = @(
  'C:\Program Files (x86)\CyberCNSAgent\logs',
  'C:\Program Files (x86)\CyberCNSAgent\results_data',
  'C:\CS-Toolbox-TEMP\Collected-Info'
)

$LogoUrl   = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$DefaultTo = 'support@connectsecure.com'

# Upload script (Secure mode)
$SecureUploadScript = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-secure-file-upload.ps1'
$LauncherScript     = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# ---- Embedded RSA Public Key (SubjectPublicKeyInfo PEM) ----
$RsaPublicPem = @'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxGmwf7MuyKnVeL3jT8K8
nwU9Tq3qfjum06H3Tt/vR2PEJLWBa0cqm2fxPIHccvWYRe++Ta3YyFtBwnPxq6qE
k+yR88eX8lxhD3Kbgxlw1ITuUuo1dH9fJ3Nu+Hp+Mr53Jj4UmsoEvSEK1/66cwNN
FeP8Ezwtcv4OpPp04ZmXFjCfYmvxP65NvmPmd9qNuwA6nJYo37TKjKk3tJ/OkJHE
6DdiD7Cmn68I0+EJUt/FqtGT427YAON6NCvT6UKjAgmYtlKOQsQBSm+mLoGbeQsn
OjowqAaf0+7/Xw5C45S4psq5UbcRmCd+HZ+N5cjfQFNQYh/57+RD9Jxhf6SW6Ytk
GQIDAQAB
-----END PUBLIC KEY-----
'@

# =================== Logging Helpers ===================
if ($Silent) {
  function Write-Info { param($m) }
  function Write-Ok   { param($m) }
  function Write-Warn { param($m) }
  function Write-Err  { param($m) }
} else {
  function Write-Info ($m){ Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Cyan }
  function Write-Ok   ($m){ Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Green }
  function Write-Warn ($m){ Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Yellow }
  function Write-Err  ($m){ Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Red }
}

function Ensure-Folder {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function HtmlEncode {
  param([string]$s)
  if ($null -eq $s) { return '' }
  $s = $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;'
  $s = $s -replace '"','&quot;' -replace "'","&#39;"
  return $s
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) {
    $size = $size / 1KB
    if ($size -lt 1024) { return ("{0:N1} {1}" -f $size, $u) }
  }
  return ("{0:N1} PB" -f ($bytes / [math]::Pow(2,50)))
}

function Read-KeyPause([string]$Msg) {
  if ($Silent) { return }
  Write-Host ""
  Write-Host $Msg -ForegroundColor Yellow
  try {
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
  } catch {
    Read-Host "Press Enter to continue" | Out-Null
  }
}

function Get-SafeLastExitCode {
  try {
    if (Test-Path variable:global:LASTEXITCODE) { return $global:LASTEXITCODE }
    if (Test-Path variable:LASTEXITCODE) { return $LASTEXITCODE }
  } catch { }
  return $null
}

# ---- NEW: metadata filename tag (Company-Ticket-Signature) appended at END ----
function Sanitize-ForFileName {
  param([string]$Text,[int]$MaxLen = 40)
  if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
  $t = $Text.Trim()
  $t = $t -replace '[\\\/:\*\?"<>\|]','-'
  $t = $t -replace '\s+','-'
  $t = $t -replace '-{2,}','-'
  $t = $t.Trim('-','.')
  if ($t.Length -gt $MaxLen) { $t = $t.Substring(0,$MaxLen).Trim('-','.') }
  if ([string]::IsNullOrWhiteSpace($t)) { return $null }
  return $t
}
function Get-MetaSuffix {
  param([string]$Company,[string]$Ticket,[string]$Signature)

  $cTag = Sanitize-ForFileName $Company 40
  $tTag = Sanitize-ForFileName $Ticket  30
  $sTag = Sanitize-ForFileName $Signature 30

  $parts = @()
  if ($cTag) { $parts += $cTag }
  if ($tTag) { $parts += $tTag }
  if ($sTag) { $parts += $sTag }

  if ($parts.Count -eq 0) { return '' }

  $suffix = ($parts -join '-')
  if ($suffix.Length -gt 90) { $suffix = $suffix.Substring(0,90).Trim('-','.') }
  return "_$suffix"
}

# =================== ZIP Helpers ===================
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+ or ensure System.IO.Compression assemblies are present." }
  }
}

function Get-FilesFromSources {
  param([Parameter(Mandatory)][string[]]$Sources)
  $results = New-Object System.Collections.Generic.List[object]
  $i = 1
  foreach ($src in $Sources) {
    if (-not (Test-Path -LiteralPath $src)) { Write-Warn "Missing source: $src"; $i++; continue }
    $root = (Resolve-Path -LiteralPath $src).Path
    if (-not $root.EndsWith('\')) { $root += '\' }
    $labelBase = Split-Path -Leaf ($root.TrimEnd('\'))
    $label = "{0}_{1}" -f $i, $labelBase

    Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $rel = $_.FullName.Substring($root.Length).TrimStart('\','/')
      $results.Add([pscustomobject]@{
        SourceRoot=$root; Label=$label; FullName=$_.FullName; RelPath=($rel -replace '\\','/'); Length=$_.Length
      })
    }
    $i++
  }
  return $results
}

function New-ZipFromItems {
  param([Parameter(Mandatory)][pscustomobject[]]$Items,[Parameter(Mandatory)][string]$ZipPath)
  Ensure-ZipAssemblies
  if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }

  $fs = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::Create,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
  $zip = $null
  try {
    $zip = New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Create,$true)
    $skipped = New-Object System.Collections.Generic.List[string]

    foreach ($it in $Items) {
      if (-not (Test-Path -LiteralPath $it.FullName)) { continue }
      $entryRel  = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
      $entryName = "$($it.Label)/$entryRel"
      try {
        $entry   = $zip.CreateEntry($entryName,[System.IO.Compression.CompressionLevel]::Optimal)
        $ostream = $entry.Open()
        try {
          $istream = New-Object System.IO.FileStream($it.FullName,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
          try { $istream.CopyTo($ostream) } finally { $istream.Dispose() }
        } finally { $ostream.Dispose() }
      } catch { $skipped.Add($it.FullName) | Out-Null }
    }

    if ($skipped.Count -gt 0) {
      $note = "The following files were locked or otherwise unreadable at capture time:`r`n`r`n" + ($skipped -join "`r`n") + "`r`n"
      $noteEntry  = $zip.CreateEntry("0_SKIPPED_locked_files.txt",[System.IO.Compression.CompressionLevel]::Optimal)
      $noteStream = $noteEntry.Open()
      try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        $bytes = $enc.GetBytes($note)
        $noteStream.Write($bytes,0,$bytes.Length)
      } finally { $noteStream.Dispose() }
    }
  } finally {
    if ($zip) { $zip.Dispose() }
    $fs.Dispose()
  }
}

# =================== ASN.1 + RSA Loader (PS 5.1-safe) ===================
function PR-AssertTag { param([byte[]]$Buf,[int]$Idx,[byte]$Tag)
  if ($Buf[$Idx] -ne $Tag) { throw ("ASN.1 tag mismatch. Expected 0x{0:X2}, got 0x{1:X2}" -f $Tag, $Buf[$Idx]) }
  return ($Idx + 1)
}
function PR-ReadLen { param([byte[]]$Buf,[int]$Idx)
  $lenByte = [int]$Buf[$Idx]; $Idx++
  if ($lenByte -lt 0x80) { return @{ Len=$lenByte; Idx=$Idx } }
  $num = $lenByte - 0x80
  if ($num -lt 1 -or $num -gt 4) { throw "Unsupported length octets ($num)" }
  $val = 0
  for ($k=0; $k -lt $num; $k++){ $val = (($val -shl 8) -bor [int]$Buf[$Idx]); $Idx++ }
  return @{ Len=$val; Idx=$Idx }
}
function PR-ReadInteger { param([byte[]]$Buf,[int]$Idx)
  $Idx = PR-AssertTag -Buf $Buf -Idx $Idx -Tag 0x02
  $lr = PR-ReadLen -Buf $Buf -Idx $Idx
  $len = $lr.Len; $Idx = $lr.Idx
  $start=$Idx
  $bytes = New-Object byte[] $len
  [System.Buffer]::BlockCopy($Buf, $start, $bytes, 0, $len)
  $Idx += $len
  if ($bytes.Length -gt 1 -and $bytes[0] -eq 0x00) {
    $trim = New-Object byte[] ($bytes.Length - 1)
    [System.Array]::Copy($bytes, 1, $trim, 0, $trim.Length)
    $bytes = $trim
  }
  return @{ Val = $bytes; Idx = $Idx }
}
function PR-ParseSpki { param([byte[]]$Buf)
  $i = 0
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $spkiEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $algEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x06; $lr = PR-ReadLen -Buf $Buf -Idx $i; $i = $lr.Idx + $lr.Len
  if ($i -lt $algEnd -and $Buf[$i] -eq 0x05) { $i++; $lr = PR-ReadLen -Buf $Buf -Idx $i; if ($lr.Len -ne 0) { throw "AlgorithmIdentifier NULL has non-zero length." } ; $i = $lr.Idx }
  if ($i -ne $algEnd) { $i = $algEnd }
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x03; $lr = PR-ReadLen -Buf $Buf -Idx $i; $bitEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $unused = $Buf[$i]; if ($unused -ne 0) { throw "Unsupported BIT STRING (unused bits = $unused)" } ; $i++
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $rsaEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $mod = $r.Val; $i = $r.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $exp = $r.Val; $i = $r.Idx
  if ($i -ne $rsaEnd) { $i = $rsaEnd }
  if ($i -ne $bitEnd) { $i = $bitEnd }
  if ($i -ne $spkiEnd){ $i = $spkiEnd }
  return @{ Modulus=$mod; Exponent=$exp }
}
Remove-Item function:\Get-RsaFromPem -ErrorAction SilentlyContinue
function Get-RsaFromPem {
  param([Parameter(Mandatory)][string]$Pem)
  $clean = $Pem -replace '-----BEGIN PUBLIC KEY-----','' -replace '-----END PUBLIC KEY-----',''
  $clean = $clean -replace '\s+',''
  try { $spki = [Convert]::FromBase64String($clean) } catch { throw "Invalid PEM public key (Base64 parse failed)." }
  $parsed = PR-ParseSpki -Buf $spki
  $rsaParams = New-Object System.Security.Cryptography.RSAParameters
  $rsaParams.Modulus  = [byte[]]$parsed.Modulus
  $rsaParams.Exponent = [byte[]]$parsed.Exponent
  $rsa = [System.Security.Cryptography.RSA]::Create()
  $rsa.ImportParameters($rsaParams)
  return $rsa
}

# =================== Crypto Helpers ===================
function New-RandomBytes([int]$len){
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  $buf = New-Object byte[] $len
  $rng.GetBytes($buf)
  $rng.Dispose()
  return $buf
}
function New-BE16([int]$n){
  $t = New-Object byte[] 2
  $t[0] = (($n -shr 8) -band 0xFF)
  $t[1] = ($n -band 0xFF)
  return $t
}
function Bytes-Cat {
  param([Parameter(ValueFromRemainingArguments=$true)][object[]]$Chunks)
  $total = 0
  foreach($c in $Chunks){ $total += ([byte[]]$c).Length }
  $buf = New-Object byte[] $total
  $off = 0
  foreach($c in $Chunks){
    $arr = [byte[]]$c
    [System.Array]::Copy($arr,0,$buf,$off,$arr.Length)
    $off += $arr.Length
  }
  return $buf
}

function Protect-Zip-ToCSB {
  param(
    [Parameter(Mandatory)][string]$ZipPath,
    [Parameter(Mandatory)][string]$OutCsbPath,
    [Parameter(Mandatory)][string]$PemPublicKey
  )

  $secret = New-RandomBytes 80
  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0, $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret,32, $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret,64, $iv,     0, 16)

  $plain = [System.IO.File]::ReadAllBytes($ZipPath)

  $aes   = [System.Security.Cryptography.Aes]::Create()
  $aes.KeySize = 256
  $aes.Mode = 'CBC'
  $aes.Padding = 'PKCS7'
  $aes.Key = $aesKey
  $aes.IV  = $iv

  $ms = New-Object System.IO.MemoryStream
  $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateEncryptor(), 'Write')
  $cs.Write($plain,0,$plain.Length)
  $cs.FlushFinalBlock()
  $cs.Dispose()
  $cipher = $ms.ToArray()
  $ms.Dispose()
  $aes.Dispose()

  # RSA wrap secret (PS5.1 safe)
  $rsa = Get-RsaFromPem -Pem $PemPublicKey
  $wrapped = $null
  $flags = 0x01

  try {
    if ($rsa -is [System.Security.Cryptography.RSACng] -or $rsa.GetType().FullName -match 'Cng|OpenSsl') {
      try {
        $wrapped = $rsa.Encrypt($secret, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        $flags = $flags -bor 0x02
      } catch {
        $wrapped = $rsa.Encrypt($secret, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
        $flags = $flags -bor 0x04
      }
    } else {
      $wrapped = $rsa.Encrypt($secret, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
      $flags = $flags -bor 0x04
    }
  } catch {
    $csp = $null
    try {
      $pub = $rsa.ExportParameters($false)
      $keySizeBits = $pub.Modulus.Length * 8
      $cspParams = New-Object System.Security.Cryptography.CspParameters
      $cspParams.ProviderType = 24
      $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
      $csp.PersistKeyInCsp = $false
      $csp.ImportParameters($pub)

      $wrapped = $csp.Encrypt($secret, $true) # OAEP-SHA1
      $flags = $flags -bor 0x08
    } finally {
      if ($csp) { try { $csp.Clear() } catch {}; try { $csp.Dispose() } catch {} }
    }
  }

  $wrapped = [byte[]]$wrapped
  if ($null -eq $wrapped -or $wrapped.Length -le 0) { throw "RSA encryption produced no data (wrappedLen=0)." }
  if ($wrapped.Length -gt 65535) { throw "Wrapped key blob too large for CSB header." }

  $magic   = [byte[]]([Text.Encoding]::ASCII.GetBytes('CSB1'))
  $verB    = [byte[]]@([byte]1)
  $flagsB  = [byte[]]@([byte]$flags)
  $wlenBE  = New-BE16 $wrapped.Length

  $headerNoTag = Bytes-Cat $magic $verB $flagsB $wlenBE $wrapped

  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  $msComb = New-Object System.IO.MemoryStream
  $msComb.Write($headerNoTag,0,$headerNoTag.Length)
  $msComb.Write($cipher,0,$cipher.Length)
  $tag = $hmac.ComputeHash($msComb.ToArray())
  $msComb.Dispose()
  $hmac.Dispose()

  $finalLen = $headerNoTag.Length + $cipher.Length + $tag.Length
  $bundle = New-Object byte[] $finalLen
  [Array]::Copy($headerNoTag,0,$bundle,0,$headerNoTag.Length)
  [Array]::Copy($cipher,0,$bundle,$headerNoTag.Length,$cipher.Length)
  [Array]::Copy($tag,0,$bundle,$headerNoTag.Length+$cipher.Length,$tag.Length)
  [System.IO.File]::WriteAllBytes($OutCsbPath,$bundle)
}

# =================== Compose Helper (HTML) ===================
function Build-ComposeHelper {
  param(
    [Parameter(Mandatory)][pscustomobject[]]$Attachments,
    [Parameter(Mandatory)][string]$Stamp,
    [Parameter(Mandatory)][string]$LogoUrl,
    [Parameter(Mandatory)][string]$OutDir,
    [Parameter(Mandatory)][string]$ModeTag,
    [Parameter(Mandatory)][string]$ManifestPath,
    [Parameter(Mandatory)][string]$Company,
    [string]$Ticket,
    [string]$SignatureText,
    [string]$ToParam,
    [string]$CcParam,
    [switch]$AutoOpen
  )

  $ToFinal = $DefaultTo
  if (-not [string]::IsNullOrWhiteSpace($ToParam)) { $ToFinal = $ToParam }

  $sig = $SignatureText
  if ([string]::IsNullOrWhiteSpace($sig)) { $sig = 'ConnectSecure Technician' }

  $attachLis = if ($Attachments -and $Attachments.Count -gt 0) {
    ($Attachments | ForEach-Object {
      '<li><code>'+(HtmlEncode $_.Name)+'</code> <span class="size">('+(HtmlEncode $_.SizeHuman)+')</span></li>'
    }) -join "`n        "
  } else {
    '<li><code>(No files detected in output folder at generation time)</code></li>'
  }

  $manifestEncoded = '(Manifest not available)'
  try {
    if (Test-Path -LiteralPath $ManifestPath) {
      $lines = Get-Content -LiteralPath $ManifestPath -ErrorAction Stop
      $max = 800
      $take = [Math]::Min($lines.Count,$max)
      $manifestText = [string]::Join("`n",$lines[0..($take-1)])
      if ($lines.Count -gt $max) { $manifestText += "`n... (truncated; total lines: $($lines.Count))" }
      $manifestEncoded = HtmlEncode $manifestText
    } else {
      $manifestEncoded = HtmlEncode "(Manifest file not found at $ManifestPath)"
    }
  } catch {
    $manifestEncoded = HtmlEncode "(Manifest read error: $($_.Exception.Message))"
  }

  $HtmlTemplate = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ConnectSecure - Compose Helper</title>
<style>
  :root{--bg:#0f172a;--panel:#111827;--text:#e5e7eb;--muted:#9ca3af;--accent:#22c55e;--link:#60a5fa;--border:rgba(255,255,255,.12);--mono:Consolas,ui-monospace,Menlo,monospace}
  html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
  *,*::before,*::after{box-sizing:border-box}
  .wrap{max-width:1100px;margin:0 auto;padding:28px 22px 40px}
  header{display:flex;flex-direction:column;align-items:center;gap:10px;margin:6px 0 18px}
  .brand{font-weight:700;letter-spacing:.3px;font-size:1.05rem;color:var(--muted)}
  h1{margin:4px 0 6px;font-size:1.6rem;line-height:1.2;text-align:center}
  .subtitle{color:var(--muted);text-align:center;margin-top:2px;max-width:850px}
  .panel{background:linear-gradient(180deg,rgba(255,255,255,.02),rgba(255,255,255,0));border:1px solid var(--border);border-radius:14px;padding:16px;margin:16px 0}
  .label-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}
  .label{font-weight:700}.subcopy{color:var(--muted);font-size:.92rem;margin-top:2px}
  a{color:var(--link);text-decoration:none}a:hover{text-decoration:underline}
  .btn{display:inline-flex;align-items:center;gap:8px;background:var(--panel);border:1px solid var(--border);color:var(--text);padding:9px 12px;border-radius:10px;cursor:pointer;text-decoration:none;font-weight:700;user-select:none}
  .btn:hover{border-color:rgba(255,255,255,.25)}
  .hint{color:var(--muted);font-size:.95rem;margin-top:6px}
  .footer{margin-top:24px;color:var(--muted);font-size:.9rem;text-align:center}
  .pill{display:inline-block;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);color:#86efac;border-radius:6px;padding:2px 8px;font-size:.8rem;margin:6px 0}
  .copyfield{background:#0b1020;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:13px}
  .copyfield.singleline{white-space:nowrap;overflow:auto}.copyfield.multiline{white-space:pre-wrap;word-break:break-word;overflow:auto;line-height:1.5}
  .file-list{margin:0;padding-left:24px;list-style:disc}.file-list li{margin:.15rem 0}.file-list code{font-family:var(--mono);font-size:13px;word-break:break-all}
  .manifest{max-height:280px;overflow:auto;border:1px solid rgba(255,255,255,.1);background:#0b1020;border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:12px;line-height:1.45}
  .flash{outline:2px solid var(--accent);outline-offset:1px;transition:outline-color .2s ease}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <div style="margin-bottom:12px;text-align:center"><img src="__LOGOURL__" alt="ConnectSecure Logo" style="max-width:180px;height:auto"/></div>
      <div class="brand">ConnectSecure</div>
      <h1>Compose Email Helper <span class="pill">__STAMP__</span></h1>
      <div class="subtitle">Attach the file(s) below, then copy To/Subject/Body into your email client.</div>
    </header>

    <section class="panel">
      <div class="label-row">
        <div><div class="label">Attach these file(s) before sending</div><div class="subcopy">Open the output folder and attach the files listed below.</div></div>
        <a class="btn" href="file:///__OUTDIR__" target="_blank" rel="noopener">Open folder</a>
      </div>
      <ul class="file-list" id="attachments">__ATTACHMENTS__</ul>
      <div class="hint">If your browser blocks file links, open File Explorer and browse to: <code>__OUTDIR_RAW__</code></div>
    </section>

    <section class="panel"><div class="label-row"><div><div class="label">To</div><div class="subcopy">Copies the recipient list to your clipboard.</div></div><button class="btn" data-copy="#toField">Copy To</button></div><div class="copyfield singleline" id="toField">__TO__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Cc</div><div class="subcopy">Optional - copies Cc to your clipboard.</div></div><button class="btn" data-copy="#ccField">Copy Cc</button></div><div class="copyfield singleline" id="ccField">__CC__</div></section>

    <section class="panel"><div class="label-row"><div><div class="label">Subject</div><div class="subcopy">Copies the subject line exactly as shown.</div></div><button class="btn" data-copy="#subjectField">Copy Subject</button></div><div class="copyfield singleline" id="subjectField">ConnectSecure Support Bundle | __MODE__ | __COMPANY__ | __TICKET__</div></section>

    <section class="panel">
      <div class="label-row"><div><div class="label">Body (HTML)</div><div class="subcopy">Copies rich HTML for clients that support it.</div></div><button class="btn" data-copy-html="#bodyHtmlField">Copy HTML Body</button></div>
      <div class="copyfield multiline" id="bodyHtmlField">
<p>Hello ConnectSecure Support,</p>
<p>Please find the attached <b>__MODE__</b> support bundle for:</p>
<ul><li>Company: <b>__COMPANY__</b></li><li>Ticket: <b>__TICKET__</b></li></ul>
<p><b>Included Manifest (snapshot)</b></p>
<details open><summary>Bundle Manifest</summary><pre class="manifest">__MANIFEST__</pre></details>
<p>Thanks,<br/>__SIGNATURE__</p>
      </div>

      <div style="height:10px"></div>
      <div class="label-row"><div><div class="label">Body (Plain Text)</div><div class="subcopy">Copies a plain text version for all clients.</div></div><button class="btn" data-copy="#bodyTextField">Copy Text Body</button></div>
      <div class="copyfield multiline" id="bodyTextField">Hello ConnectSecure Support,

Please find the attached __MODE__ support bundle for:
- Company: __COMPANY__
- Ticket: __TICKET__

Thanks,
__SIGNATURE__</div>
    </section>

    <div class="footer">&copy; <span id="year"></span> ConnectSecure. All rights reserved.</div>
  </div>

<script>
(function(){
  document.getElementById('year').textContent = new Date().getFullYear();
  const flash = (el)=>{ el.classList.add('flash'); setTimeout(()=>el.classList.remove('flash'), 650); };
  async function copyText(text, el){
    try{ if(navigator.clipboard && navigator.clipboard.writeText){ await navigator.clipboard.writeText(text); flash(el); return; } }catch(_){}
    const ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(ta); flash(el);
  }
  async function copyHtml(html, el){
    if(navigator.clipboard && navigator.clipboard.write){
      try{ const blob=new Blob([html],{type:"text/html"}); const item=new ClipboardItem({"text/html":blob}); await navigator.clipboard.write([item]); flash(el); return; }catch(_){}
    }
    const box=document.createElement('div'); box.contentEditable='true'; box.style.position='fixed'; box.style.left='-9999px'; document.body.appendChild(box);
    box.innerHTML=html; const range=document.createRange(); range.selectNodeContents(box);
    const sel=window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(box); flash(el);
  }
  document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',()=>{
    const t=document.querySelector(btn.getAttribute('data-copy'));
    copyText((t.innerText||t.textContent), t);
  }));
  document.querySelectorAll('[data-copy-html]').forEach(btn=>btn.addEventListener('click',()=>{
    const t=document.querySelector(btn.getAttribute('data-copy-html'));
    copyHtml(t.innerHTML, t);
  }));
})();
</script>
</body>
</html>
'@

  $outForHref = ($OutDir -replace '\\','/')
  $HtmlOut = $HtmlTemplate.
    Replace('__STAMP__',       (HtmlEncode $Stamp)).
    Replace('__ATTACHMENTS__', $attachLis).
    Replace('__TO__',          (HtmlEncode $ToFinal)).
    Replace('__CC__',          (HtmlEncode $CcParam)).
    Replace('__COMPANY__',     (HtmlEncode $Company)).
    Replace('__TICKET__',      (HtmlEncode $Ticket)).
    Replace('__SIGNATURE__',   (HtmlEncode $sig)).
    Replace('__LOGOURL__',     (HtmlEncode $LogoUrl)).
    Replace('__MODE__',        (HtmlEncode $ModeTag)).
    Replace('__OUTDIR__',      (HtmlEncode $outForHref)).
    Replace('__OUTDIR_RAW__',  (HtmlEncode $OutDir)).
    Replace('__MANIFEST__',    $manifestEncoded)

  $helperPath = Join-Path $OutDir ("Compose_Helper_{0}.html" -f $Stamp)
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($helperPath, $HtmlOut, $Utf8NoBom)

  if ($AutoOpen) { try { Start-Process $helperPath | Out-Null } catch {} }
  return $helperPath
}

# =================== MAIN ===================
try {
  Ensure-Folder -Path $OutDir
  if ($ExportOnly) { Ensure-Folder -Path $ExportRoot }

  if ($Secure -and $Unsecure) { if (-not $Silent) { Write-Err "Cannot use -Secure and -Unsecure together." } ; exit 1 }

  # Interactive mode selection FIRST
  if (-not $NonInteractive) {
    Write-Host ""
    Write-Host "ConnectSecure Support Bundle Generator" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Secure (Recommended):" -ForegroundColor White
    Write-Host "  - Encrypts bundle (.csb) and attempts secure cloud upload to CS Support only." -ForegroundColor DarkGray
    Write-Host "  - If upload fails, the email Compose Helper HTML opens as fallback." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "Unsecure:" -ForegroundColor White
    Write-Host "  - Creates a normal ZIP bundle (.zip)." -ForegroundColor DarkGray
    Write-Host "  - Always opens the email Compose Helper HTML (no upload attempt)." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "Choose bundle type:" -ForegroundColor Yellow
    Write-Host "  [S] Secure" -ForegroundColor Yellow
    Write-Host "  [U] Unsecure" -ForegroundColor Yellow
    Write-Host "  [Q] Quit" -ForegroundColor Yellow

    $choice = (Read-Host "Choose mode (S/U/Q)").Trim().ToUpper()
    switch ($choice) {
      'S' { $Secure = $true }
      'U' { $Unsecure = $true }
      'Q' { exit 0 }
      default { Write-Err "Invalid selection."; exit 1 }
    }
  }

  $modeTag  = if ($Secure) { 'Secure' } else { 'Unsecure' }
  $srcPaths = $DefaultSources

  # Prompts for metadata (Company required)
  if (-not $Silent) {
    Write-Host ""
    Write-Host "Capture source roots (defaults):" -ForegroundColor Yellow
    $DefaultSources | ForEach-Object -Begin { $idx=1 } -Process { Write-Host ("  {0}) {1}" -f $idx, $_); $idx++ }

    if ([string]::IsNullOrWhiteSpace($Company))   { $Company   = (Read-Host "Enter Company").Trim() }
    if ([string]::IsNullOrWhiteSpace($Ticket))    { $Ticket    = (Read-Host "Enter Support Ticket (optional)").Trim() }
    if ([string]::IsNullOrWhiteSpace($Signature)) { $Signature = (Read-Host "Enter Signature (optional)").Trim() }

    if ([string]::IsNullOrWhiteSpace($Company)) { Write-Err "Company is required."; exit 1 }
  } else {
    if ([string]::IsNullOrWhiteSpace($Company)) { throw "Company is required when running non-interactive (-Secure/-Unsecure/-ExportOnly)." }
  }

  # Collect files
  $items = Get-FilesFromSources -Sources $srcPaths
  $items = $items | Where-Object { $_.FullName -notlike "$OutDir*" }
  if (-not $items) { $items = @() }

  # Manifest
  $Stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
  $manifestPath = Join-Path $OutDir ("BundleManifest_{0}.txt" -f $Stamp)

  $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
  if ($null -eq $totalBytes) { $totalBytes = 0 }
  ("{0} files, total {1}" -f $items.Count,(Get-SizeHuman ([long]$totalBytes))) | Out-File -FilePath $manifestPath -Encoding UTF8

  foreach ($it in $items) {
    $sz = Get-SizeHuman $it.Length
    $dispPath = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
    ("{0}`t{1}\{2}`t{3}" -f $sz,$it.Label,$dispPath,$it.FullName) | Out-File -FilePath $manifestPath -Append -Encoding UTF8
  }

  # Names
  $metaSuffix = Get-MetaSuffix -Company $Company -Ticket $Ticket -Signature $Signature
  $baseName   = "CS-SupportBundle_{0}{1}" -f $Stamp, $metaSuffix

  # Build ZIP
  $zipPath = Join-Path $OutDir ("{0}.zip" -f $baseName)

  $zipItems = @([pscustomobject]@{
    Label   = '0_MANIFEST'
    RelPath = (Split-Path -Leaf $manifestPath)
    FullName= $manifestPath
    Length  = (Get-Item $manifestPath).Length
  }) + $items

  Write-Info ("Creating ZIP: {0}" -f (Split-Path -Leaf $zipPath))
  New-ZipFromItems -Items $zipItems -ZipPath $zipPath

  # Secure -> CSB (and ALWAYS delete ZIP afterwards)
  $csbPath = $null
  if ($Secure) {
    $csbPath = Join-Path $OutDir ("{0}.csb" -f $baseName)
    Write-Info ("Encrypting to CSB: {0}" -f (Split-Path -Leaf $csbPath))
    Protect-Zip-ToCSB -ZipPath $zipPath -OutCsbPath $csbPath -PemPublicKey $RsaPublicPem

    if (Test-Path -LiteralPath $zipPath) {
      Remove-Item -LiteralPath $zipPath -Force
      $zipPath = $null
    }
  }

  # ExportOnly JSON (cookbook)
  if ($ExportOnly) {
    $outObj = [pscustomobject]@{
      stamp      = $Stamp
      mode       = $modeTag
      outDir     = $OutDir
      manifest   = $manifestPath
      zip        = $zipPath
      csb        = $csbPath
      company    = $Company
      ticket     = $Ticket
      signature  = $Signature
      sources    = $srcPaths
    }
    $jsonPath = Join-Path $ExportRoot ("bundle_export_{0}.json" -f $Stamp)
    $outObj | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $jsonPath -Encoding UTF8 -Force
    exit 0
  }

  # Decide HTML behavior (final):
  #  - Unsecure: ALWAYS open HTML unless -NoHtml
  #  - Secure:   open HTML ONLY if upload fails (unless explicitly forced -Html)
  $openHtml = $false
  if ($Unsecure -and -not $NoHtml) { $openHtml = $true }

  # Secure upload call (determines fallback HTML)
  $uploadOk = $true
  if ($Secure) {
    $uploadOk = $false

    if (-not (Test-Path -LiteralPath $SecureUploadScript)) {
      Write-Warn "Secure upload script not found: $SecureUploadScript"
      $uploadOk = $false
    } else {
      try {
        Write-Info "Calling secure upload script..."
        try { if (Test-Path variable:global:LASTEXITCODE) { Remove-Variable -Name LASTEXITCODE -Scope Global -ErrorAction SilentlyContinue } } catch { }

        & $SecureUploadScript

        $exitCode = Get-SafeLastExitCode
        if ($null -eq $exitCode) { $exitCode = 0 }  # if script doesn't set it, treat as success if no exception
        if ([int]$exitCode -eq 0) {
          $uploadOk = $true
          Write-Ok "Secure upload completed."
        } else {
          $uploadOk = $false
          Write-Warn ("Secure upload returned exit code {0}." -f $exitCode)
        }
      } catch {
        $uploadOk = $false
        Write-Warn ("Secure upload exception: {0}" -f $_.Exception.Message)
      }
    }

    if (-not $uploadOk) {
      # Fallback: open HTML helper ONLY on failure (unless suppressed)
      if (-not $NoHtml) { $openHtml = $true }
    } else {
      # Success: do NOT open HTML unless explicitly forced with -Html
      if ($PSBoundParameters.ContainsKey('Html') -and $Html -and -not $NoHtml) {
        $openHtml = $true
      } else {
        $openHtml = $false
      }
    }
  }

  # Compose Helper generation
  if ($openHtml) {
    $attachments = @()
    if ($Secure -and $csbPath -and (Test-Path -LiteralPath $csbPath)) {
      $fi = Get-Item -LiteralPath $csbPath
      $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) }
    } elseif ($zipPath -and (Test-Path -LiteralPath $zipPath)) {
      $fi = Get-Item -LiteralPath $zipPath
      $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) }
    }

    $finalTo = $DefaultTo
    if (-not [string]::IsNullOrWhiteSpace($To)) { $finalTo = $To }

    $null = Build-ComposeHelper `
      -Attachments $attachments `
      -Stamp $Stamp `
      -LogoUrl $LogoUrl `
      -OutDir $OutDir `
      -ModeTag $modeTag `
      -ManifestPath $manifestPath `
      -Company $Company `
      -Ticket $Ticket `
      -SignatureText $Signature `
      -ToParam $finalTo `
      -CcParam $Cc `
      -AutoOpen:$true
  }

  # End pause + return to launcher
  if (-not $Silent) { Read-KeyPause "Press any key to return to the Toolbox menu..." }
  if (Test-Path -LiteralPath $LauncherScript) { try { & $LauncherScript } catch {} }

  exit 0
}
catch {
  if (-not $Silent) { Write-Err $_.Exception.Message }
  if (-not $Silent) { Read-KeyPause "Press any key to return to the Toolbox menu..." }
  if (Test-Path -LiteralPath $LauncherScript) { try { & $LauncherScript } catch {} }
  exit 1
}
