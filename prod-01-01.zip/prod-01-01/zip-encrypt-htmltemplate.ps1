# === Ensure .NET Zip assemblies are available (PS 5.1-safe) ===
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+ or ensure System.IO.Compression assemblies are present." }
  }
}

<# ======================================================
  ConnectSecure - Menu: Secure / Unsecure / Inspect
  S: List -> ZIP (multi-root preserved) -> Encrypt (AES + RSA wrap) -> Helper
  U: List -> ZIP (multi-root preserved) -> Helper
  L: Learn -> Opens info HTML then returns
  Outputs: C:\CS-Toolbox-TEMP\ZIP
  Notes:
    - Public key is embedded (no download)
    - Manual SPKI (BEGIN PUBLIC KEY) parser with NO [ref] params (PS 5.1-safe)
    - Avoids object[] vs byte[] issues when building RSAParameters
    - RSA encrypt has fallbacks for older .NET
====================================================== #>

# ------------------- Settings -------------------
$OutDir         = 'C:\CS-Toolbox-TEMP\ZIP'
$DefaultSources = @(
  'C:\Program Files (x86)\CyberCNSAgent\logs',
  'C:\Program Files (x86)\CyberCNSAgent\results_data',
  'C:\CS-Toolbox-TEMP\Collected-Info'
)
$LogoUrl        = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$DefaultTo      = 'support@connectsecure.com'
$DefaultCc      = ''
$DefaultBcc     = ''

# ---- Embedded RSA Public Key (SubjectPublicKeyInfo PEM) ----
$RsaPublicPem = @'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxGmwf7MuyKnVeL3jT8K8
nwU9Tq3qfjum06H3Tt/vR2PEJLWBa0cqm2fxPIHccvWYRe++Ta3YyFtBwnPxq6qE
k+yR88eX8lxhD3Kbgxlw1ITuUuo1dH9fJ3Nu+Hp+Mr53Jj4UmsoEvSEK1/66cwNN
FeP8Ezwtcv4OpPp04ZmXFjCfYmvxP65NvmPmd9qNuwA6nJYo37TKjKk3tJ/OkJHE
6DdiD7Cmn68I0+EJUt/FqtGT427YAON6NCvT6UKjAgmYtlKOQsQBSm+mLoGbeQsn
OjowqAaf0+7/Xw5C45S4psq5UbcRmCd+HZ+N5cjfQFNQYh/57+RD9Jxhf6SW6Ytk
GQIDAQAB
-----END PUBLIC KEY-----
'@

# ------------------- Helpers -------------------
function Write-Info ($msg) { Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Cyan }
function Write-Ok   ($msg) { Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Green }
function Write-Warn ($msg) { Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Yellow }
function Write-Err  ($msg) { Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $msg" -ForegroundColor Red }

function Ensure-Folder {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function HtmlEncode {
  param([string]$s)
  if ($null -eq $s) { return '' }
  $s = $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;'
  $s = $s -replace '"','&quot;' -replace "'","&#39;"
  return $s
}

function Get-SizeHuman([long]$bytes) {
  if ($bytes -lt 1KB) { return "$bytes B" }
  $units = "KB","MB","GB","TB"
  $size = [double]$bytes
  foreach ($u in $units) { $size = $size / 1KB; if ($size -lt 1024) { return ("{0:N1} {1}" -f $size, $u) } }
  return ("{0:N1} PB" -f ($bytes / [math]::Pow(2,50)))
}

function Normalize-SourceInput([string]$srcIn){
  if ([string]::IsNullOrWhiteSpace($srcIn)) { return $null }
  $s = $srcIn -replace '["“”]', '' -replace '(\r?\n)+',';' -replace '\s+and\s+', ';' -replace '\s*,\s*', ';'
  return ($s -split '\s*;\s*' | Where-Object { $_ -and $_.Trim().Length -gt 0 })
}

function Get-FilesFromSources {
  param([Parameter(Mandatory)][string[]]$Sources)
  $results = New-Object System.Collections.Generic.List[object]; $i = 1
  foreach ($src in $Sources) {
    if (-not (Test-Path -LiteralPath $src)) { Write-Warn "Missing source: $src"; $i++; continue }
    $root = (Resolve-Path -LiteralPath $src).Path; if (-not $root.EndsWith('\')) { $root += '\' }
    $labelBase = Split-Path -Leaf ($root.TrimEnd('\')); $label = "{0}_{1}" -f $i, $labelBase
    Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $rel = $_.FullName.Substring($root.Length).TrimStart('\','/')
      $results.Add([pscustomobject]@{
        SourceRoot=$root; Label=$label; FullName=$_.FullName; RelPath=($rel -replace '\\','/'); Length=$_.Length
      })
    }; $i++
  }
  return $results
}

function New-ZipFromItems {
  param([Parameter(Mandatory)][pscustomobject[]]$Items,[Parameter(Mandatory)][string]$ZipPath)
  Ensure-ZipAssemblies
  if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
  $fs = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::Create,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
  try {
    $zip = New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Create,$true)
    $skipped = New-Object System.Collections.Generic.List[string]
    foreach ($it in $Items) {
      if (-not (Test-Path -LiteralPath $it.FullName)) { continue }
      $entryRel = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
      $entryName = "$($it.Label)/$entryRel"
      try {
        $entry=$zip.CreateEntry($entryName,[System.IO.Compression.CompressionLevel]::Optimal)
        $ostream=$entry.Open()
        try {
          $istream=New-Object System.IO.FileStream($it.FullName,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
          try { $istream.CopyTo($ostream) } finally { $istream.Dispose() }
        } finally { $ostream.Dispose() }
      } catch { $skipped.Add($it.FullName) }
    }
    if ($skipped.Count -gt 0) {
      $note = "The following files were locked or otherwise unreadable at capture time:`r`n`r`n" + ($skipped -join "`r`n") + "`r`n"
      $noteEntry  = $zip.CreateEntry("0_SKIPPED_locked_files.txt",[System.IO.Compression.CompressionLevel]::Optimal)
      $noteStream = $noteEntry.Open()
      try { $enc = New-Object System.Text.UTF8Encoding($false); $bytes = $enc.GetBytes($note); $noteStream.Write($bytes,0,$bytes.Length) } finally { $noteStream.Dispose() }
    }
  } finally { if ($zip){$zip.Dispose()} ; $fs.Dispose() }
}

# ---------- ASN.1 helpers WITHOUT [ref] and returning true byte[] ----------
function PR-AssertTag {
  param([byte[]]$Buf,[int]$Idx,[byte]$Tag)
  if ($Buf[$Idx] -ne $Tag) { throw ("ASN.1 tag mismatch. Expected 0x{0:X2}, got 0x{1:X2}" -f $Tag, $Buf[$Idx]) }
  return ($Idx + 1)
}
function PR-ReadLen {
  param([byte[]]$Buf,[int]$Idx)
  $lenByte = [int]$Buf[$Idx]; $Idx++
  if ($lenByte -lt 0x80) { return @{ Len=$lenByte; Idx=$Idx } }
  $num = $lenByte - 0x80
  if ($num -lt 1 -or $num -gt 4) { throw "Unsupported length octets ($num)" }
  $val = 0
  for ($k=0; $k -lt $num; $k++){ $val = (($val -shl 8) -bor [int]$Buf[$Idx]); $Idx++ }
  return @{ Len=$val; Idx=$Idx }
}
function PR-ReadInteger {
  param([byte[]]$Buf,[int]$Idx)
  $Idx = PR-AssertTag -Buf $Buf -Idx $Idx -Tag 0x02
  $lr = PR-ReadLen -Buf $Buf -Idx $Idx
  $len = $lr.Len; $Idx = $lr.Idx
  $start=$Idx

  # Copy exact segment as byte[] (avoid object[] slicing)
  $bytes = New-Object byte[] $len
  [System.Buffer]::BlockCopy($Buf, $start, $bytes, 0, $len)
  $Idx += $len

  # Strip leading 0x00 if present
  if ($bytes.Length -gt 1 -and $bytes[0] -eq 0x00) {
    $trim = New-Object byte[] ($bytes.Length - 1)
    [System.Array]::Copy($bytes, 1, $trim, 0, $trim.Length)
    $bytes = $trim
  }
  return @{ Val = $bytes; Idx = $Idx }   # <— TRUE byte[] here
}
function PR-ParseSpki {
  param([byte[]]$Buf)
  $i = 0
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $spkiEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $algEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x06; $lr = PR-ReadLen -Buf $Buf -Idx $i; $i = $lr.Idx + $lr.Len
  if ($i -lt $algEnd -and $Buf[$i] -eq 0x05) { $i++; $lr = PR-ReadLen -Buf $Buf -Idx $i; if ($lr.Len -ne 0) { throw "AlgorithmIdentifier NULL has non-zero length." } ; $i = $lr.Idx }
  if ($i -ne $algEnd) { $i = $algEnd }
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x03; $lr = PR-ReadLen -Buf $Buf -Idx $i; $bitEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $unused = $Buf[$i]; if ($unused -ne 0) { throw "Unsupported BIT STRING (unused bits = $unused)" } ; $i++
  $i = PR-AssertTag -Buf $Buf -Idx $i -Tag 0x30; $lr = PR-ReadLen -Buf $Buf -Idx $i; $rsaEnd = $lr.Idx + $lr.Len; $i = $lr.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $mod = $r.Val; $i = $r.Idx
  $r = PR-ReadInteger -Buf $Buf -Idx $i; $exp = $r.Val; $i = $r.Idx
  if ($i -ne $rsaEnd) { $i = $rsaEnd }
  if ($i -ne $bitEnd) { $i = $bitEnd }
  if ($i -ne $spkiEnd){ $i = $spkiEnd }
  return @{ Modulus=$mod; Exponent=$exp }
}

# ---------- RSA loader (manual SPKI) ----------
Remove-Item function:\Get-RsaFromPem -ErrorAction SilentlyContinue
function Get-RsaFromPem {
  param([Parameter(Mandatory)][string]$Pem)
  $clean = $Pem -replace '-----BEGIN PUBLIC KEY-----','' -replace '-----END PUBLIC KEY-----',''
  $clean = $clean -replace '\s+',''
  try { $spki = [Convert]::FromBase64String($clean) } catch { throw "Invalid PEM public key (Base64 parse failed)." }
  $parsed = PR-ParseSpki -Buf $spki

  $rsaParams = New-Object System.Security.Cryptography.RSAParameters
  $rsaParams.Modulus  = [byte[]]$parsed.Modulus
  $rsaParams.Exponent = [byte[]]$parsed.Exponent

  $rsa = [System.Security.Cryptography.RSA]::Create()
  $rsa.ImportParameters($rsaParams)

  Write-Info ("RSA import path: manual SPKI parser (mod={0} bytes, exp={1} bytes)" -f $rsaParams.Modulus.Length, $rsaParams.Exponent.Length)
  return $rsa
}

function New-RandomBytes([int]$len){
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  $buf = New-Object byte[] $len
  $rng.GetBytes($buf)
  return $buf
}

function Protect-Zip-With-RSA {
  param(
    [Parameter(Mandatory)][string]$ZipPath,
    [Parameter(Mandatory)][string]$OutEncPath,   # .zip.aes
    [Parameter(Mandatory)][string]$OutKeyPath,   # .zip.aes.key (Base64 of RSA(AES||IV))
    [Parameter(Mandatory)][string]$PemPublicKey
  )

  # Generate AES-256 key + IV
  $aesKey = New-RandomBytes 32
  $aesIV  = New-RandomBytes 16

  # AES-CBC + PKCS7
  $aes = [System.Security.Cryptography.Aes]::Create()
  $aes.KeySize = 256
  $aes.Mode    = [System.Security.Cryptography.CipherMode]::CBC
  $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
  $aes.Key     = $aesKey
  $aes.IV      = $aesIV

  $plain = [System.IO.File]::ReadAllBytes($ZipPath)
  $encTransform = $aes.CreateEncryptor()
  $ms = New-Object System.IO.MemoryStream
  $cs = New-Object System.Security.Cryptography.CryptoStream($ms,$encTransform,[System.Security.Cryptography.CryptoStreamMode]::Write)
  $cs.Write($plain,0,$plain.Length); $cs.FlushFinalBlock(); $cs.Close()
  $cipher = $ms.ToArray(); $ms.Close()
  [System.IO.File]::WriteAllBytes($OutEncPath,$cipher)
  Write-Ok "Encrypted ZIP -> $OutEncPath"

  # RSA-wrap AES||IV
  $blob = New-Object byte[] ($aesKey.Length + $aesIV.Length)
  [Array]::Copy($aesKey,0,$blob,0,$aesKey.Length)
  [Array]::Copy($aesIV,0,$blob,$aesKey.Length,$aesIV.Length)

  $rsa = Get-RsaFromPem -Pem $PemPublicKey

  # Prefer modern padding API; fall back to RSACryptoServiceProvider(Encrypt(byte[], bool))
  $wrapped = $null
  try {
    $wrapped = $rsa.Encrypt($blob,[System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
  } catch {
    try {
      Write-Warn "OAEP-SHA256 not available; trying OAEP(SHA1)."
      $wrapped = $rsa.Encrypt($blob,[System.Security.Cryptography.RSAEncryptionPadding]::Oaep)
    } catch {
      # Legacy fallback
      $csp = $rsa -as [System.Security.Cryptography.RSACryptoServiceProvider]
      if ($csp -ne $null) {
        try {
          Write-Warn "Falling back to RSACryptoServiceProvider OAEP(true)."
          $wrapped = $csp.Encrypt($blob, $true)  # OAEP-SHA1
        } catch {
          Write-Warn "Falling back to RSACryptoServiceProvider PKCS#1 v1.5."
          $wrapped = $csp.Encrypt($blob, $false)
        }
      } else {
        Write-Warn "OAEP not available; using PKCS#1 v1.5 padding as final fallback."
        $wrapped = $rsa.Encrypt($blob,[System.Security.Cryptography.RSAEncryptionPadding]::Pkcs1)
      }
    }
  }

  [System.IO.File]::WriteAllText($OutKeyPath,[Convert]::ToBase64String($wrapped))
  Write-Ok "Wrote RSA-wrapped AES key: $OutKeyPath"
}

# ---------- Compose Helper (UI; lists .zip/.zip.aes/.key) ----------
function Build-ComposeHelper {
  param(
    [Parameter(Mandatory)][pscustomobject[]]$Attachments,
    [Parameter(Mandatory)][string]$Stamp,
    [Parameter(Mandatory)][string]$LogoUrl,
    [Parameter(Mandatory)][string]$OutDir,
    [Parameter(Mandatory)][string]$ModeTag,
    [Parameter(Mandatory)][string]$ManifestPath
  )

  $Company = Read-Host "Enter Company"
  $Tenant  = Read-Host "Enter Tenant"
  $Ticket  = Read-Host "Enter Ticket (optional, press Enter to skip)"
  $To      = Read-Host "Enter To (press Enter for default: $DefaultTo)"; if ([string]::IsNullOrWhiteSpace($To)) { $To = $DefaultTo }
  $Cc      = Read-Host "Enter Cc (optional)"
  $Bcc     = Read-Host "Enter Bcc (optional)"
  $Sender  = Read-Host "Enter your name or signature (optional)"; if ([string]::IsNullOrWhiteSpace($Sender)) { $Sender = 'dmoon' }

  $companyEsc = HtmlEncode $Company; $tenantEsc = HtmlEncode $Tenant; $ticketEsc = HtmlEncode $Ticket
  $toEsc = HtmlEncode $To; $ccEsc = HtmlEncode $Cc; $bccEsc = HtmlEncode $Bcc
  $senderEsc = HtmlEncode $Sender; $logoEsc = HtmlEncode $LogoUrl; $modeEsc = HtmlEncode $ModeTag; $outEsc = HtmlEncode $OutDir

  if ($Attachments.Count -gt 0) {
    $attachLis = ($Attachments | ForEach-Object {
      '<li><code>'+(HtmlEncode $_.Name)+'</code> <span class="size">('+$_.SizeHuman+')</span></li>'
    }) -join "`n        "
  } else {
    $attachLis = '<li><code>(No files detected in C:\CS-Toolbox-TEMP\ZIP at generation time)</code></li>'
  }

  $manifestEncoded = '(Manifest not available)'
  try {
    if (Test-Path -LiteralPath $ManifestPath) {
      $lines = Get-Content -LiteralPath $ManifestPath -ErrorAction Stop
      $max = 800; $take = [Math]::Min($lines.Count,$max)
      $manifestText = [string]::Join("`n",$lines[0..($take-1)])
      if ($lines.Count -gt $max) { $manifestText += "`n... (truncated; total lines: $($lines.Count))" }
      $manifestEncoded = HtmlEncode $manifestText
    } else { $manifestEncoded = HtmlEncode "(Manifest file not found at $ManifestPath)" }
  } catch { $manifestEncoded = HtmlEncode "(Manifest read error: $($_.Exception.Message))" }

  $HtmlTemplate = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ConnectSecure - Compose Helper</title>
<style>
  :root{--bg:#0f172a;--panel:#111827;--text:#e5e7eb;--muted:#9ca3af;--accent:#22c55e;--link:#60a5fa;--border:rgba(255,255,255,.12);--mono:Consolas,ui-monospace,Menlo,monospace}
  html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
  *,*::before,*::after{box-sizing:border-box}
  .wrap{max-width:1100px;margin:0 auto;padding:28px 22px 40px}
  header{display:flex;flex-direction:column;align-items:center;gap:10px;margin:6px 0 18px}
  .brand{font-weight:700;letter-spacing:.3px;font-size:1.05rem;color:var(--muted)}
  h1{margin:4px 0 6px;font-size:1.6rem;line-height:1.2;text-align:center}
  .subtitle{color:var(--muted);text-align:center;margin-top:2px;max-width:850px}
  .panel{background:linear-gradient(180deg,rgba(255,255,255,.02),rgba(255,255,255,0));border:1px solid var(--border);border-radius:14px;padding:16px;margin:16px 0}
  .label-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}
  .label{font-weight:700}.subcopy{color:var(--muted);font-size:.92rem;margin-top:2px}
  a{color:var(--link);text-decoration:none}a:hover{text-decoration:underline}
  .btn{display:inline-flex;align-items:center;gap:8px;background:var(--panel);border:1px solid var(--border);color:var(--text);padding:9px 12px;border-radius:10px;cursor:pointer;text-decoration:none;font-weight:700;user-select:none}
  .btn:hover{border-color:rgba(255,255,255,.25)}
  .hint{color:var(--muted);font-size:.95rem;margin-top:6px}
  .footer{margin-top:24px;color:var(--muted);font-size:.9rem;text-align:center}
  .pill{display:inline-block;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);color:#86efac;border-radius:6px;padding:2px 8px;font-size:.8rem;margin:6px 0}
  .copyfield{background:#0b1020;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:13px}
  .copyfield.singleline{white-space:nowrap;overflow:auto}.copyfield.multiline{white-space:pre-wrap;word-break:break-word;overflow:auto;line-height:1.5}
  .file-list{margin:0;padding-left:24px;list-style:disc}.file-list li{margin:.15rem 0}.file-list code{font-family:var(--mono);font-size:13px;word-break:break-all}
  .manifest{max-height:280px;overflow:auto;border:1px solid rgba(255,255,255,.1);background:#0b1020;border-radius:10px;padding:10px 12px;font-family:var(--mono);font-size:12px;line-height:1.45}
  .flash{outline:2px solid var(--accent);outline-offset:1px;transition:outline-color .2s ease}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <div style="margin-bottom:12px;text-align:center"><img src="__LOGOURL__" alt="ConnectSecure Logo" style="max-width:180px;height:auto"/></div>
      <div class="brand">ConnectSecure</div>
      <h1>Compose Email Helper <span class="pill">__STAMP__</span></h1>
      <div class="subtitle">Attach the files below, then copy To/Subject/Body into your email client.</div>
    </header>

    <section class="panel">
      <div class="label-row">
        <div><div class="label">Attach these file(s) before sending</div><div class="subcopy">Open the output folder and attach the files listed below.</div></div>
        <a class="btn" href="file:///__OUTDIR__" target="_blank" rel="noopener">Open folder</a>
      </div>
      <ul class="file-list" id="attachments">__ATTACHMENTS__</ul>
      <div class="hint">If your browser blocks file links, open File Explorer and browse to: <code>__OUTDIR__</code></div>
    </section>

    <section class="panel"><div class="label-row"><div><div class="label">To</div><div class="subcopy">Copies the recipient list to your clipboard.</div></div><button class="btn" data-copy="#toField">Copy To</button></div><div class="copyfield singleline" id="toField">__TO__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Cc</div><div class="subcopy">Optional - copies Cc to your clipboard.</div></div><button class="btn" data-copy="#ccField">Copy Cc</button></div><div class="copyfield singleline" id="ccField">__CC__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Bcc</div><div class="subcopy">Optional - copies Bcc to your clipboard.</div></div><button class="btn" data-copy="#bccField">Copy Bcc</button></div><div class="copyfield singleline" id="bccField">__BCC__</div></section>
    <section class="panel"><div class="label-row"><div><div class="label">Subject</div><div class="subcopy">Copies the subject line exactly as shown.</div></div><button class="btn" data-copy="#subjectField">Copy Subject</button></div><div class="copyfield singleline" id="subjectField">ConnectSecure Support Bundle | __MODE__ | __COMPANY__ | __TENANT__ | __TICKET__</div></section>

    <section class="panel">
      <div class="label-row"><div><div class="label">Body (HTML)</div><div class="subcopy">Copies rich HTML for clients that support it.</div></div><button class="btn" data-copy-html="#bodyHtmlField">Copy HTML Body</button></div>
      <div class="copyfield multiline" id="bodyHtmlField">
<p>Hello ConnectSecure Support,</p>
<p>Please find the attached <b>__MODE__</b> support bundle for:</p>
<ul><li>Company: <b>__COMPANY__</b></li><li>Tenant: <b>__TENANT__</b></li><li>Ticket: <b>__TICKET__</b></li></ul>
<p><b>Included Manifest (snapshot)</b></p>
<details open><summary>Bundle Manifest</summary><pre class="manifest">__MANIFEST__</pre></details>
<p>Thanks,<br/>__SENDER__</p>
      </div>
      <div class="hint">Use this if your mail client supports HTML composition.</div>

      <div style="height:10px"></div>
      <div class="label-row"><div><div class="label">Body (Plain Text)</div><div class="subcopy">Copies a plain text version for all clients.</div></div><button class="btn" data-copy="#bodyTextField">Copy Text Body</button></div>
      <div class="copyfield multiline" id="bodyTextField">Hello ConnectSecure Support,

Please find the attached __MODE__ support bundle for:
- Company: __COMPANY__
- Tenant: __TENANT__
- Ticket: __TICKET__

(See HTML body for embedded manifest snapshot.)

Thanks,
__SENDER__</div>
      <div class="hint">Tip: Paste with Ctrl+V (Windows) or Cmd+V (macOS).</div>
    </section>

    <div class="footer">&copy; <span id="year"></span> ConnectSecure. All rights reserved.</div>
  </div>

<script>
(function(){
  document.getElementById('year').textContent = new Date().getFullYear();
  const flash = (el)=>{ el.classList.add('flash'); setTimeout(()=>el.classList.remove('flash'), 650); };
  async function copyText(text, el){
    try{ if(navigator.clipboard && navigator.clipboard.writeText){ await navigator.clipboard.writeText(text); flash(el); return; } }catch(_){}
    const ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(ta); flash(el);
  }
  async function copyHtml(html, el){
    if(navigator.clipboard && navigator.clipboard.write){
      try{ const blob=new Blob([html],{type:"text/html"}); const item=new ClipboardItem({"text/html":blob}); await navigator.clipboard.write([item]); flash(el); return; }catch(_){}
    }
    const box=document.createElement('div'); box.contentEditable='true'; box.style.position='fixed'; box.style.left='-9999px'; document.body.appendChild(box);
    box.innerHTML=html; const range=document.createRange(); range.selectNodeContents(box);
    const sel=window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
    try{ document.execCommand('copy'); }catch(_){}
    document.body.removeChild(box); flash(el);
  }
  document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',()=>{ const t=document.querySelector(btn.getAttribute('data-copy')); copyText((t.innerText||t.textContent),t); }));
  document.querySelectorAll('[data-copy-html]').forEach(btn=>btn.addEventListener('click',()=>{ const t=document.querySelector(btn.getAttribute('data-copy-html')); copyHtml(t.innerHTML,t); }));
  const ul=document.getElementById('attachments'); if(ul && !ul.getAttribute('type')) ul.setAttribute('type','disc');
})();
</script>
</body>
</html>
'@

  $Html = $HtmlTemplate.
    Replace('__STAMP__',      $Stamp).
    Replace('__ATTACHMENTS__',$attachLis).
    Replace('__TO__',         $toEsc).
    Replace('__CC__',         $ccEsc).
    Replace('__BCC__',        $bccEsc).
    Replace('__COMPANY__',    $companyEsc).
    Replace('__TENANT__',     $tenantEsc).
    Replace('__TICKET__',     $ticketEsc).
    Replace('__SENDER__',     $senderEsc).
    Replace('__LOGOURL__',    $logoEsc).
    Replace('__MODE__',       $modeEsc).
    Replace('__OUTDIR__',     ($outEsc -replace '\\','/')).
    Replace('__MANIFEST__',   $manifestEncoded)

  $helperPath = Join-Path $OutDir ("Compose_Helper_{0}.html" -f $Stamp)
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($helperPath, $Html, $Utf8NoBom)
  Write-Ok "Wrote Compose Helper HTML: $helperPath"
  Start-Process $helperPath | Out-Null
}

# ------------------- Menu -------------------
$ErrorActionPreference = 'Stop'
Ensure-Folder -Path $OutDir

Write-Host ""
Write-Host "ConnectSecure Menu:" -ForegroundColor Cyan
Write-Host "  [S] Secure    - List -> Zip -> Encrypt (RSA) -> Helper"
Write-Host "  [U] Unsecure  - List -> Zip -> Helper"
Write-Host "  [L] Learn     - Information on Encryption"
Write-Host "  [Q] Back to CS Toolbox Main Menu"
Write-Host ""
$mode = (Read-Host "Choose mode (S/U/L/Q)").ToUpper().Trim()
if ($mode -notin @('S','U','L','Q')) { Write-Err "Invalid choice. Use S, U, L, or Q."; exit 1 }

if ($mode -eq 'L') {
  try {
    Write-Host "[INFO] Opening encryption info page (L)..." -ForegroundColor Cyan
    $htmlPath = 'C:\CS-TOOLBOX-TEMP\prod-01-01\DOC\connectsecure_encryption_info_final.html'
    if (Test-Path $htmlPath) { Start-Process $htmlPath } else { Write-Warning "HTML not found at $htmlPath" }
  } catch { Write-Warning ("Failed to open HTML: {0}" -f $_.Exception.Message) }
  Read-Host "Press Enter to return to the menu" | Out-Null
  & 'C:\CS-TOOLBOX-TEMP\prod-01-01\zip-encrypt-htmltemplate.ps1'
  exit
}
$modeTag = if ($mode -eq 'S') { 'Secure' } elseif ($mode -eq 'U') { 'Unsecure' } else { 'Back' }

Write-Host ""
Write-Host "Enter source roots. Press Enter to use defaults:" -ForegroundColor Yellow
$DefaultSources | ForEach-Object -Begin { $idx=1 } -Process { Write-Host ("  {0}) {1}" -f $idx, $_); $idx++ }
Write-Host "You can also paste a semicolon-, comma-, or 'and'-separated list."
$srcIn = Read-Host "Source paths"
[string[]]$srcPaths = Normalize-SourceInput $srcIn
if (-not $srcPaths) { $srcPaths = $DefaultSources }

# Collect files
$items = Get-FilesFromSources -Sources $srcPaths
$items = $items | Where-Object { $_.FullName -notlike "$OutDir*" }
if ($items.Count -eq 0) { Write-Warn "No files found under the provided sources." }

# Manifest
$Stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
$manifestPath = Join-Path $OutDir ("BundleManifest_{0}.txt" -f $Stamp)
$totalBytes = ($items | Measure-Object -Property Length -Sum).Sum; if ($null -eq $totalBytes) { $totalBytes = 0 }
$header = ("{0} files, total {1}" -f $items.Count,(Get-SizeHuman ([long]$totalBytes))); $header | Out-File -FilePath $manifestPath -Encoding UTF8
foreach ($it in $items) {
  $sz = Get-SizeHuman $it.Length
  $dispPath = if ([string]::IsNullOrWhiteSpace($it.RelPath)) { (Split-Path -Leaf $it.FullName) } else { $it.RelPath }
  ("{0}`t{1}\{2}`t{3}" -f $sz,$it.Label,$dispPath,$it.FullName) | Out-File -FilePath $manifestPath -Append -Encoding UTF8
}
Write-Ok "Manifest: $manifestPath"

# Paths
$zipPath = $null; $encPath = $null; $keyPath = $null

switch ($mode) {
  'Q' {
    Write-Host "Returning to CS Toolbox Main Menu..."
    if (Test-Path 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1') { & 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1' }
    else { Write-Host "Launcher not found at: C:\CS-ToolBOX-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1" -ForegroundColor Red }
  }
  'U' {
    if ($items.Count -eq 0) { Write-Warn "Nothing to zip." }
    else {
      $zipPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip" -f $Stamp)
      Write-Info "Building zip (unsecure): $zipPath"
      $zipItems = @([pscustomobject]@{ Label='0_MANIFEST'; RelPath=(Split-Path -Leaf $manifestPath); FullName=$manifestPath; Length=(Get-Item $manifestPath).Length }) + $items
      New-ZipFromItems -Items $zipItems -ZipPath $zipPath
      Write-Ok "ZIP created"
    }
  }
  'S' {
    if ($items.Count -eq 0) { Write-Warn "Nothing to zip/encrypt." }
    else {
      $zipPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip" -f $Stamp)
      Write-Info "Building zip (secure path): $zipPath"
      $zipItems = @([pscustomobject]@{ Label='0_MANIFEST'; RelPath=(Split-Path -Leaf $manifestPath); FullName=$manifestPath; Length=(Get-Item $manifestPath).Length }) + $items
      New-ZipFromItems -Items $zipItems -ZipPath $zipPath
      Write-Ok "ZIP created"

      # Encrypt + wrap
      $encPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip.aes" -f $Stamp)
      $keyPath = Join-Path $OutDir ("CS-SupportBundle_{0}.zip.aes.key" -f $Stamp)
      Write-Info "Encrypting ZIP with AES-256 and wrapping key with RSA..."
      Protect-Zip-With-RSA -ZipPath $zipPath -OutEncPath $encPath -OutKeyPath $keyPath -PemPublicKey $RsaPublicPem
      Write-Ok "Encrypted bundle written."
    }
  }
}

# Compose helper
$attachments = @()
$attachments += [pscustomobject]@{ Name=(Split-Path -Leaf $manifestPath); SizeHuman=(Get-SizeHuman (Get-Item $manifestPath).Length) }
if ($zipPath) { $fi=Get-Item -LiteralPath $zipPath; $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) } }
if ($encPath){ $fi=Get-Item -LiteralPath $encPath; $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) } }
if ($keyPath){ $fi=Get-Item -LiteralPath $keyPath; $attachments += [pscustomobject]@{ Name=$fi.Name; SizeHuman=(Get-SizeHuman $fi.Length) } }

Build-ComposeHelper -Attachments $attachments -Stamp $Stamp -LogoUrl $LogoUrl -OutDir $OutDir -ModeTag $modeTag -ManifestPath $manifestPath

Write-Ok "Done."
if ($zipPath) { Write-Info "ZIP: $zipPath" }
if ($encPath) { Write-Info "Encrypted: $encPath" }
if ($keyPath) { Write-Info "Keyfile : $keyPath" }
