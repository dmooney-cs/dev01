<# =================================================================================================
 CS-Toolbox-ShortcutInstall.ps1  (v2.1)

 Source (NEW):
   C:\CS-Toolbox-TEMP\prod-01-01\DOCS\Launchers

 Landing rules (REQUIRED):
   - ALL .ps1 and ALL .ico  -> C:\CS-Toolbox-TEMP\Launchers   (create if missing, overwrite)
   - ALL .lnk               -> ACTIVE (interactive) user's Desktop (create if missing, overwrite)

 Optional:
   -Taskbar  : Pins "ConnectSecure Toolbox Launcher.lnk" from Desktop to Taskbar (best-effort)
   -Desktop  : Forces Desktop copy behavior (still copies .lnk; default is "only if -Desktop or -Taskbar")

 ExportOnly:
   -ExportOnly exports JSON to: C:\CS-Toolbox-TEMP\Collected-Info\shortcut-install.json
   (No prompts; suitable for cookbook collection)

 Notes:
   - Taskbar pinning uses Shell verb matching 'Taskbar' and may fail silently on some builds/locales.
================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Desktop,
    [switch]$Taskbar,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# -----------------------------
# Config
# -----------------------------
$LauncherSourceDir = 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\Launchers'

# New rule destinations
$LaunchersDir     = 'C:\CS-Toolbox-TEMP\Launchers'     # .ps1 + .ico land here

# Export / audit output
$CollectedInfo    = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPath       = Join-Path $CollectedInfo 'shortcut-install.json'

# If pinning, we will prefer this specific shortcut name on Desktop
$PrimaryLnkName   = 'ConnectSecure Toolbox Launcher.lnk'

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Dir {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

function Get-InteractiveUser {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        if ($cs.UserName) { return $cs.UserName }
    } catch { }

    try {
        $exp = Get-Process explorer -ErrorAction Stop | Select-Object -First 1
        $o = $exp.GetOwner()
        if ($o.User) {
            if ($o.Domain) { return "$($o.Domain)\$($o.User)" }
            return $o.User
        }
    } catch { }

    return $null
}

function Get-SidFromAccount {
    param([Parameter(Mandatory=$true)][string]$Account)
    try {
        $nt = New-Object System.Security.Principal.NTAccount($Account)
        return ($nt.Translate([System.Security.Principal.SecurityIdentifier])).Value
    } catch { return $null }
}

function Get-DesktopPathForSid {
    param([Parameter(Mandatory=$true)][string]$Sid)

    $reg1 = "Registry::HKEY_USERS\$Sid\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    try {
        $p = (Get-ItemProperty -LiteralPath $reg1 -ErrorAction Stop).Desktop
        if ($p) { return [Environment]::ExpandEnvironmentVariables($p) }
    } catch { }

    $reg2 = "Registry::HKEY_USERS\$Sid\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
    try {
        $p2 = (Get-ItemProperty -LiteralPath $reg2).Desktop
        if ($p2) { return $p2 }
    } catch { }

    return $null
}

function Resolve-InteractiveDesktopPath {
    $user = Get-InteractiveUser
    if (-not $user) { return @{ ok=$false; user=$null; sid=$null; desktop=$null; reason='No interactive user detected' } }

    $sid = Get-SidFromAccount $user
    if (-not $sid) { return @{ ok=$false; user=$user; sid=$null; desktop=$null; reason="Unable to resolve SID for $user" } }

    $desktop = Get-DesktopPathForSid $sid
    if (-not $desktop) {
        $userOnly = ($user -split '\\')[-1]
        $desktop = "C:\Users\$userOnly\Desktop"
    }

    return @{ ok=$true; user=$user; sid=$sid; desktop=$desktop; reason=$null }
}

function Pin-ShortcutToTaskbar {
    param([Parameter(Mandatory=$true)][string]$ShortcutPath)

    if (-not (Test-Path -LiteralPath $ShortcutPath)) { return $false }

    try {
        $shell  = New-Object -ComObject Shell.Application
        $folder = $shell.Namespace((Split-Path $ShortcutPath -Parent))
        $item   = $folder.ParseName((Split-Path $ShortcutPath -Leaf))

        foreach ($verb in $item.Verbs()) {
            if ($verb.Name -match 'Taskbar') {
                $verb.DoIt()
                return $true
            }
        }
    } catch { }

    return $false
}

function Copy-FilesByExtension {
    param(
        [Parameter(Mandatory=$true)][string]$SourceDir,
        [Parameter(Mandatory=$true)][string]$DestDir,
        [Parameter(Mandatory=$true)][string[]]$Extensions  # e.g. @('*.ps1','*.ico')
    )

    Ensure-Dir $DestDir

    $copied = @()
    foreach ($ext in $Extensions) {
        $files = @(Get-ChildItem -LiteralPath $SourceDir -File -Filter $ext -ErrorAction SilentlyContinue)
        foreach ($f in $files) {
            $dest = Join-Path $DestDir $f.Name
            Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
            $copied += $dest
        }
    }

    return $copied
}

# -----------------------------
# Main
# -----------------------------
$result = [ordered]@{
    ok                    = $false
    requestedDesktop      = [bool]$Desktop
    requestedTaskbar      = [bool]$Taskbar
    sourceDir             = $LauncherSourceDir
    launchersDir          = $LaunchersDir
    collectedInfoDir      = $CollectedInfo

    ps1CopiedCount        = 0
    icoCopiedCount        = 0
    lnkCopiedCount        = 0

    ps1Copied             = @()
    icoCopied             = @()
    lnkCopied             = @()

    interactiveUser       = $null
    interactiveSid        = $null
    desktopPath           = $null

    desktopInstalled      = $false
    taskbarInstalled      = $false

    error                 = $null
}

try {
    if (-not (Test-Path -LiteralPath $LauncherSourceDir)) {
        throw "Launcher source folder missing: $LauncherSourceDir"
    }

    # 1) Copy ALL .ps1 and .ico to C:\CS-Toolbox-TEMP\Launchers
    $ps1Copied = Copy-FilesByExtension -SourceDir $LauncherSourceDir -DestDir $LaunchersDir -Extensions @('*.ps1')
    $icoCopied = Copy-FilesByExtension -SourceDir $LauncherSourceDir -DestDir $LaunchersDir -Extensions @('*.ico')

    $result.ps1Copied      = @($ps1Copied)
    $result.icoCopied      = @($icoCopied)
    $result.ps1CopiedCount = $result.ps1Copied.Count
    $result.icoCopiedCount = $result.icoCopied.Count

    # 2) Desktop / Taskbar requested? If yes, copy ALL .lnk to Desktop
    if ($Desktop -or $Taskbar) {
        $d = Resolve-InteractiveDesktopPath
        if (-not $d.ok) { throw $d.reason }

        $result.interactiveUser = $d.user
        $result.interactiveSid  = $d.sid
        $result.desktopPath     = $d.desktop

        Ensure-Dir $d.desktop

        $lnkFiles = @(Get-ChildItem -LiteralPath $LauncherSourceDir -File -Filter '*.lnk' -ErrorAction SilentlyContinue)
        foreach ($f in $lnkFiles) {
            $dest = Join-Path $d.desktop $f.Name
            Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
            $result.lnkCopied += $dest
        }
        $result.lnkCopiedCount = $result.lnkCopied.Count
        $result.desktopInstalled = $true

        # 3) Optional pin
        if ($Taskbar) {
            $primaryOnDesktop = Join-Path $d.desktop $PrimaryLnkName
            if (-not (Test-Path -LiteralPath $primaryOnDesktop)) {
                # If the "primary" lnk isn't found, attempt to pin the first lnk we copied
                $primaryOnDesktop = if ($result.lnkCopiedCount -ge 1) { $result.lnkCopied[0] } else { $null }
            }

            if ($primaryOnDesktop -and (Test-Path -LiteralPath $primaryOnDesktop)) {
                if (Pin-ShortcutToTaskbar -ShortcutPath $primaryOnDesktop) {
                    $result.taskbarInstalled = $true
                }
            }
        }
    }

    $result.ok = $true
} catch {
    $result.error = $_.Exception.Message
}

# -----------------------------
# ExportOnly
# -----------------------------
if ($ExportOnly) {
    try {
        Ensure-Dir $CollectedInfo
        ($result | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $ExportPath -Encoding UTF8
    } catch { }
}

return
