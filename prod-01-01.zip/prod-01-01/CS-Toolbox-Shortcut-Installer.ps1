param(
    [switch]$Desktop,
    [switch]$Taskbar,
    [switch]$ExportOnly
)

#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -----------------------------
# Config
# -----------------------------
$ShortcutSource = 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\ETC\ConnectSecure Toolbox Launcher.lnk'
$DevToolsSource = 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\ETC\CS-Toolbox-Launcher-DevTools-ZeroTouch.ps1'

$TempDir      = 'C:\Temp'
$DevToolsDest = Join-Path $TempDir 'CS-Toolbox-Launcher-DevTools-ZeroTouch.ps1'

# -----------------------------
# Helpers
# -----------------------------
function Get-InteractiveUser {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        if ($cs.UserName) { return $cs.UserName }
    } catch { }

    try {
        $exp = Get-Process explorer -ErrorAction Stop | Select-Object -First 1
        $o = $exp.GetOwner()
        if ($o.User) {
            if ($o.Domain) { return "$($o.Domain)\$($o.User)" }
            return $o.User
        }
    } catch { }

    return $null
}

function Get-SidFromAccount([string]$Account) {
    try {
        $nt = New-Object System.Security.Principal.NTAccount($Account)
        return ($nt.Translate([System.Security.Principal.SecurityIdentifier])).Value
    } catch { return $null }
}

function Get-DesktopPathForSid([string]$Sid) {
    $reg1 = "Registry::HKEY_USERS\$Sid\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    try {
        $p = (Get-ItemProperty -LiteralPath $reg1 -ErrorAction Stop).Desktop
        if ($p) { return [Environment]::ExpandEnvironmentVariables($p) }
    } catch { }

    $reg2 = "Registry::HKEY_USERS\$Sid\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
    try {
        $p2 = (Get-ItemProperty -LiteralPath $reg2).Desktop
        if ($p2) { return $p2 }
    } catch { }

    return $null
}

function Ensure-Dir([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

function Copy-ShortcutToDesktop {
    param([string]$SourceLnk)

    $user = Get-InteractiveUser
    if (-not $user) { return $false }

    $sid = Get-SidFromAccount $user
    if (-not $sid) { return $false }

    $desktop = Get-DesktopPathForSid $sid
    if (-not $desktop) {
        $userOnly = ($user -split '\\')[-1]
        $desktop = "C:\Users\$userOnly\Desktop"
    }

    Ensure-Dir $desktop
    Copy-Item -LiteralPath $SourceLnk -Destination (Join-Path $desktop (Split-Path $SourceLnk -Leaf)) -Force
    return $true
}

function Pin-ShortcutToTaskbar {
    param([string]$ShortcutPath)

    if (-not (Test-Path -LiteralPath $ShortcutPath)) { return $false }

    try {
        $shell = New-Object -ComObject Shell.Application
        $folder = $shell.Namespace((Split-Path $ShortcutPath -Parent))
        $item   = $folder.ParseName((Split-Path $ShortcutPath -Leaf))

        foreach ($verb in $item.Verbs()) {
            # Works across Win10/Win11 language packs
            if ($verb.Name -match 'Taskbar') {
                $verb.DoIt()
                return $true
            }
        }
    } catch { }

    return $false
}

# -----------------------------
# Main
# -----------------------------
$result = [ordered]@{
    ok                  = $false
    desktop             = $Desktop
    taskbar             = $Taskbar
    desktopInstalled    = $false
    taskbarInstalled    = $false
    devToolsCopied      = $false
    error               = $null
}

try {
    if (-not (Test-Path -LiteralPath $ShortcutSource)) {
        throw "Shortcut source missing"
    }

    if (-not (Test-Path -LiteralPath $DevToolsSource)) {
        throw "DevTools launcher source missing"
    }

    # Ensure DevTools in C:\Temp
    Ensure-Dir $TempDir
    Copy-Item -LiteralPath $DevToolsSource -Destination $DevToolsDest -Force
    $result.devToolsCopied = $true

    # Desktop shortcut
    if ($Desktop) {
        if (Copy-ShortcutToDesktop -SourceLnk $ShortcutSource) {
            $result.desktopInstalled = $true
        }
    }

    # Taskbar pin (must use a real file path)
    if ($Taskbar) {
        # Taskbar pin must reference a shortcut on disk (Desktop is safest)
        $user = Get-InteractiveUser
        if ($user) {
            $sid = Get-SidFromAccount $user
            $desktop = Get-DesktopPathForSid $sid
            if (-not $desktop) {
                $desktop = "C:\Users\$(($user -split '\\')[-1])\Desktop"
            }

            $lnkPath = Join-Path $desktop (Split-Path $ShortcutSource -Leaf)

            # Ensure shortcut exists before pinning
            Copy-Item -LiteralPath $ShortcutSource -Destination $lnkPath -Force
            if (Pin-ShortcutToTaskbar -ShortcutPath $lnkPath) {
                $result.taskbarInstalled = $true
            }
        }
    }

    $result.ok = $true
} catch {
    $result.error = $_.Exception.Message
}

# -----------------------------
# ExportOnly
# -----------------------------
if ($ExportOnly) {
    try {
        $outDir = 'C:\CS-Toolbox-TEMP\collected-info'
        Ensure-Dir $outDir
        ($result | ConvertTo-Json -Depth 6) |
            Set-Content (Join-Path $outDir 'shortcut-install.json') -Encoding UTF8
    } catch { }
}

return
