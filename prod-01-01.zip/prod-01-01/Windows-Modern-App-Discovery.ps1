<#
=====================================================================================
  Windows-Appx-Discovery.ps1
  ConnectSecure Technicians Toolbox

  Windows Application Discovery (Appx/UWP)
  Exports: C:\CS-Toolbox-TEMP\Collected-Info\WindowsApps

  CLI SWITCHES:

    -ListAll
        Runs the "List All Apps" action immediately.
        Shows standard output, then exits (no menu).

    -App "pattern"
        Direct search mode (no menu, no prompts, no pauses).
        Uses wildcard matching (wildcards OK). If no wildcard is present, pattern is wrapped as *pattern*.
        Exports CSV/JSON normally. All GUI/output messages are suppressed.
        If pattern is empty/whitespace, exits cleanly (no error, no output).

    -ExportOnly
        Silent mode.
        Collects all Appx packages, exports CSV/JSON, no prompts, no menu, no pauses.
=====================================================================================
#>

[CmdletBinding()]
param(
    [switch]$ListAll,

    # NOTE: allow empty string; we handle it explicitly for clean exit
    [AllowEmptyString()]
    [string]$App,

    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host $Message
    }
}

function Show-Header {
    param([string]$Title = "Windows Application Discovery")
    Clear-Host
    $isAdmin   = Get-IsAdmin
    $hostName  = $env:COMPUTERNAME
    $userName  = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("==========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# Load shared functions (Functions-Common.ps1) if present
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    return
}
try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    return
}

Ensure-ExportFolder

# WindowsApps-specific export root
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\WindowsApps'
Ensure-Directory -Path $ExportRoot

$ErrorLogPath = Join-Path $ExportRoot 'WindowsApps-Discovery-Errors.log'
function Write-ErrorLog {
    param([Parameter(Mandatory)][string]$Message)
    try {
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        ("[{0}] {1}" -f $ts, $Message) | Out-File -FilePath $ErrorLogPath -Encoding UTF8 -Append
    } catch { }
}

function Sanitize-ForFileName {
    param([Parameter(Mandatory)][string]$Text)
    return ($Text -replace '[\\/:*?"<>|]+','_')
}

function Export-AppxData {
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Data,
        [Parameter(Mandatory)][string]$BaseName
    )

    $items = @()
    try { $items = @($Data) } catch { $items = @() }
    if ($null -eq $items) { $items = @() }

    $timestamp    = Get-Date -Format 'yyyyMMdd_HHmmss'
    $ComputerName = $env:COMPUTERNAME
    $base         = Sanitize-ForFileName -Text $BaseName

    $csvPath  = Join-Path $ExportRoot "$($base)_$($ComputerName)_$($timestamp).csv"
    $jsonPath = Join-Path $ExportRoot "$($base)_$($ComputerName)_$($timestamp).json"

    $items | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath
    $items | ConvertTo-Json -Depth 5 | Out-File -FilePath $jsonPath -Encoding UTF8

    return [PsCustomObject]@{
        Csv   = $csvPath
        Json  = $jsonPath
        Count = ($items.Count)
    }
}

function Format-AppxProjection {
    param([Parameter(Mandatory)][System.Collections.IEnumerable]$Data)

    $items = @()
    try { $items = @($Data) } catch { $items = @() }
    if ($null -eq $items) { $items = @() }

    $items | Select-Object `
        Name,
        PackageFullName,
        Version,
        Architecture,
        Publisher,
        NonRemovable,
        IsFramework,
        IsResourcePackage,
        InstallLocation
}

function Get-AllAppx { @(Get-AppxPackage -AllUsers) }

function Search-AppxByName {
    param([Parameter(Mandatory)][string]$Pattern)
    $like = if ($Pattern -match '\*|\?') { $Pattern } else { "*$Pattern*" }
    @(
        Get-AppxPackage -AllUsers |
            Where-Object { $_.Name -like $like }
    )
}

function Show-Menu {
    Clear-Host
    Show-Header "Windows Application Discovery"
    Write-Host ""
    Write-Host " [1] List All Apps              - Appx/UWP inventory (All Users)" -ForegroundColor White
    Write-Host " [2] Search for Specific App    - Name filter (wildcards OK)" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

function Do-ListAll {
    Show-Header "Windows Application Discovery - List All"
    try {
        Write-Host "[INFO] Collecting Appx packages for all users..." -ForegroundColor Cyan

        $raw    = Get-AllAppx
        $data   = Format-AppxProjection -Data $raw
        $export = Export-AppxData -Data $data -BaseName 'WindowsApps-AllUsers'

        $count = $export.Count
        Write-Host ""
        Write-Host ("Found {0} Appx packages." -f $count) -ForegroundColor Green
        if ($count -gt 0) {
            $preview = $data |
                Sort-Object Name |
                Select-Object Name, Version, Architecture, Publisher, InstallLocation -First 20

            $preview | Format-Table -AutoSize
            if ($count -gt 20) {
                Write-Host ("...and {0} more not shown." -f ($count - 20)) -ForegroundColor DarkGray
            }
        }

        Write-Host ""
        Write-Host "Exports saved to:" -ForegroundColor Yellow
        Write-Host " CSV : $($export.Csv)" -ForegroundColor Gray
        Write-Host " JSON: $($export.Json)" -ForegroundColor Gray

    } catch {
        Write-Host "❌ ERROR listing apps: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script "Press any key to return to the menu..."
}

function Do-Search {
    Show-Header "Windows Application Discovery - Search"
    try {
        $pattern = Read-Host "Enter full or partial app name (wildcards OK, e.g., *Viewer*)"
        if ([string]::IsNullOrWhiteSpace($pattern)) {
            Write-Host "No pattern entered. Returning to menu..." -ForegroundColor DarkYellow
            Pause-Script
            return
        }

        Write-Host ("[INFO] Searching for Appx with Name like: {0}" -f $pattern) -ForegroundColor Cyan
        $raw    = Search-AppxByName -Pattern $pattern
        $data   = Format-AppxProjection -Data $raw
        $base   = "WindowsApps-Search-$((Sanitize-ForFileName $pattern))"
        $export = Export-AppxData -Data $data -BaseName $base

        $count = $export.Count
        Write-Host ""
        Write-Host ("Matches found: {0}" -f $count) -ForegroundColor Green
        if ($count -gt 0) {
            $data |
                Sort-Object Name |
                Select-Object Name, Version, Architecture, Publisher, InstallLocation |
                Format-Table -AutoSize
        } else {
            Write-Host "No Appx packages matched your search." -ForegroundColor DarkYellow
        }

        Write-Host ""
        Write-Host "Exports saved to:" -ForegroundColor Yellow
        Write-Host " CSV : $($export.Csv)" -ForegroundColor Gray
        Write-Host " JSON: $($export.Json)" -ForegroundColor Gray

    } catch {
        Write-Host "❌ ERROR searching apps: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script "Press any key to return to the menu..."
}

function Invoke-AppSearchSilent {
    param([AllowEmptyString()][string]$Pattern)

    # If caller passes empty/whitespace, exit cleanly with no output, no error
    if ([string]::IsNullOrWhiteSpace($Pattern)) { return }

    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        $raw  = Search-AppxByName -Pattern $Pattern
        $data = Format-AppxProjection -Data $raw
        $base = "WindowsApps-Search-$((Sanitize-ForFileName $Pattern))"
        [void](Export-AppxData -Data $data -BaseName $base)
    } catch {
        Write-ErrorLog ("-App failed (Pattern='{0}'): {1}" -f $Pattern, $_.Exception.Message)
    } finally {
        $ProgressPreference = $oldProgress
    }
}

# ----- CLI switch handling -----
if ($ExportOnly) {
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        $raw  = Get-AllAppx
        $data = Format-AppxProjection -Data $raw
        [void](Export-AppxData -Data $data -BaseName 'WindowsApps-AllUsers')
    } catch {
        Write-ErrorLog ("-ExportOnly failed: {0}" -f $_.Exception.Message)
    } finally {
        $ProgressPreference = $oldProgress
    }
    return
}

if ($PSBoundParameters.ContainsKey('App')) {
    Invoke-AppSearchSilent -Pattern $App
    return
}

if ($ListAll) {
    Do-ListAll
    return
}

while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Do-ListAll }
        '2' { Do-Search }
        'Q' {
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) { & $launcher }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
