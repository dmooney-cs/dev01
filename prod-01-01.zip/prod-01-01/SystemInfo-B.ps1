<#
    SystemInfo-B.ps1
    Standalone module: no external function imports required.

    Outputs live under:
        C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo

    Menu:
      [1] Pending Reboot Status      - Registry checks and summary
      [2] Application & System Logs  - Last 7 days, CSV + EVTX
      [3] Startup Audit              - Startup folders and Run keys
      [Q] Quit

    NEW:
      -Silent     : Runs ALL 3 options, exports only, no menu, no pauses, minimal/no console output.
      -ExportOnly : Cookbook mode (no pauses/menu). If -Mode not set, runs All.
      -Mode       : 1,2,3,All (optional for non-interactive selection)
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$ExportOnly,
    [ValidateSet('1','2','3','All')]
    [string]$Mode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region ---------- Config / Globals ----------
$script:ProductName     = 'ConnectSecure Technicians Toolbox'
$script:ModuleName      = 'System Info B'
$script:DefaultRoot     = 'C:\CS-Toolbox-TEMP'
$script:ExportRoot      = Join-Path $script:DefaultRoot 'Collected-Info\SystemInfo'
$script:HostStamp       = "$($env:COMPUTERNAME)  User: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

# If Silent, keep console noise minimal (still allow warnings/errors if needed)
$script:IsSilent = $false
#endregion

#region ---------- Console UX ----------
function Show-Header {
    param([Parameter(Mandatory)][string]$Title)
    if ($script:IsSilent) { return }
    Clear-Host
    $bar = ('=' * 70)
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host $bar -ForegroundColor DarkGray
}

function Pause-Script {
    if ($script:IsSilent -or $ExportOnly.IsPresent) { return }
    Write-Host ""
    $null = Read-Host "Press Enter to return to the menu (press enter after selection)"
}

function Read-Choice {
    param([Parameter(Mandatory)][string]$Prompt)
    return (Read-Host ("{0} (press enter after selection)" -f $Prompt))
}

function Write-Info {
    param([string]$Message)
    if ($script:IsSilent) { return }
    Write-Host $Message
}
function Write-Ok {
    param([string]$Message)
    if ($script:IsSilent) { return }
    Write-Host $Message -ForegroundColor DarkGray
}
function Write-Warn {
    param([string]$Message)
    if ($script:IsSilent) { return }
    Write-Host $Message -ForegroundColor Yellow
}
function Write-Err {
    param([string]$Message)
    # In silent mode, still show errors (rare) to help techs if something breaks.
    Write-Host $Message -ForegroundColor Red
}
#endregion

#region ---------- IO Helpers ----------
function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    return (Resolve-Path -LiteralPath $Path).Path
}
function Get-Timestamp { (Get-Date).ToString('yyyyMMdd_HHmmss') }

function Ensure-ExportFolder {
    # Ensures base \Collected-Info\SystemInfo and returns it
    Ensure-Folder -Path $script:ExportRoot
}

function Write-SafeCsv {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$InputObject,
        [Parameter(Mandatory)][string]$Path,
        [switch]$NoTypeInformation
    )
    try {
        $dir = Split-Path -Parent $Path
        Ensure-Folder $dir | Out-Null
        $InputObject | Export-Csv -Path $Path -Force -NoTypeInformation:$NoTypeInformation.IsPresent -Encoding UTF8
        return $true
    } catch {
        Write-Err "ERROR writing CSV: $($_.Exception.Message)"
        return $false
    }
}
#endregion

#region ---------- Registry Helpers ----------
function Test-RegKeyExists {
    param([Parameter(Mandatory)][string]$KeyPath)
    try {
        $null = Get-Item -LiteralPath $KeyPath -ErrorAction Stop
        return $true
    } catch { return $false }
}
function Test-RegValueExists {
    param(
        [Parameter(Mandatory)][string]$KeyPath,
        [Parameter(Mandatory)][string]$ValueName
    )
    try {
        $itm = Get-ItemProperty -LiteralPath $KeyPath -ErrorAction Stop
        return ($null -ne ($itm.PSObject.Properties[$ValueName].Value))
    } catch { return $false }
}
function Get-RegValue {
    param(
        [Parameter(Mandatory)][string]$KeyPath,
        [Parameter(Mandatory)][string]$ValueName
    )
    try {
        $itm = Get-ItemProperty -LiteralPath $KeyPath -ErrorAction Stop
        return $itm.$ValueName
    } catch { return $null }
}
#endregion

#region ---------- Option 1: Pending Reboot Status ----------
function Collect-PendingRebootStatus {
    Show-Header "$script:ModuleName - Pending Reboot Status"

    $rows = New-Object System.Collections.Generic.List[object]

    # CBS: RebootPending
    $rows.Add([PSCustomObject]@{
        Check  = 'CBS RebootPending (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        Detail = ''
    })

    # CBS: PackagesPending
    $rows.Add([PSCustomObject]@{
        Check  = 'CBS PackagesPending (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
        Detail = ''
    })

    # Windows Update: RebootRequired
    $rows.Add([PSCustomObject]@{
        Check  = 'WindowsUpdate RebootRequired (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        Detail = ''
    })

    # PendingFileRenameOperations
    $pfroPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
    $pfroName = 'PendingFileRenameOperations'
    $pfroVal  = Get-RegValue $pfroPath $pfroName
    $rows.Add([PSCustomObject]@{
        Check  = 'PendingFileRenameOperations (value)'
        Path   = $pfroPath
        Exists = Test-RegValueExists $pfroPath $pfroName
        Detail = if ($pfroVal) { @($pfroVal) -join '; ' } else { '' }
    })

    # Active vs Pending ComputerName mismatch (indicator)
    $activeKey  = 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName'
    $pendingKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName'
    $active  = $null
    $pending = $null
    try { $active  = (Get-ItemProperty -LiteralPath $activeKey  -ErrorAction Stop).ComputerName } catch {}
    try { $pending = (Get-ItemProperty -LiteralPath $pendingKey -ErrorAction Stop).ComputerName } catch {}

    $nameDetail = if ($active -and $pending -and $active -ne $pending) { "Active=$active; Pending=$pending" } else { "" }
    $rows.Add([PSCustomObject]@{
        Check  = 'Active ComputerName differs from ComputerName'
        Path   = 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName'
        Exists = $true
        Detail = $nameDetail
    })

    # Write CSV
    $ts     = Get-Timestamp
    $outDir = Ensure-ExportFolder
    $csv    = Join-Path $outDir ("PendingReboot_{0}.csv" -f $ts)
    $ok     = Write-SafeCsv -InputObject $rows -Path $csv -NoTypeInformation

    if (-not $script:IsSilent) {
        $needsReboot = @($rows | Where-Object { $_.Check -ne 'Active ComputerName differs from ComputerName' -and $_.Exists })
        $hasNameMismatch = -not [string]::IsNullOrWhiteSpace(
            ($rows | Where-Object { $_.Check -eq 'Active ComputerName differs from ComputerName' } | Select-Object -First 1 | Select-Object -ExpandProperty Detail -ErrorAction SilentlyContinue)
        )

        Write-Host ""
        if ($needsReboot.Count -gt 0 -or $hasNameMismatch) {
            Write-Host "PENDING REBOOT INDICATORS FOUND." -ForegroundColor Yellow
        } else {
            Write-Host "No reboot indicators detected." -ForegroundColor Green
        }

        if ($ok) { Write-Ok "[OK] Wrote CSV: $csv" }
    }

    Pause-Script
}
#endregion

#region ---------- Option 2: Event Logs (last 7 days) ----------
function Collect-EventLogsLast7Days {
    Show-Header "$script:ModuleName - Application & System Logs (7 days)"

    $outDir   = Ensure-ExportFolder
    $stamp    = Get-Timestamp
    $sevenAgo = (Get-Date).AddDays(-7)

    # EVTX full exports (point-in-time snapshot)
    $evtxDir = Ensure-Folder (Join-Path $outDir "EVTX")
    $appEvtx = Join-Path $evtxDir ("Application_{0}.evtx" -f $stamp)
    $sysEvtx = Join-Path $evtxDir ("System_{0}.evtx" -f $stamp)

    try {
        wevtutil.exe epl Application $appEvtx /ow:true | Out-Null
        wevtutil.exe epl System      $sysEvtx /ow:true | Out-Null
        Write-Ok "[OK] Exported EVTX: $appEvtx"
        Write-Ok "[OK] Exported EVTX: $sysEvtx"
    } catch {
        Write-Warn "[WARN] EVTX export failed: $($_.Exception.Message)"
    }

    # CSV summaries (last 7 days)
    $csvDir  = Ensure-Folder (Join-Path $outDir "CSV")
    $appCsv  = Join-Path $csvDir ("AppLog_7days_{0}.csv" -f $stamp)
    $sysCsv  = Join-Path $csvDir ("SysLog_7days_{0}.csv" -f $stamp)

    $commonSelect = @('TimeCreated','Id','LevelDisplayName','ProviderName','MachineName','LogName','Message')

    try {
        $app = Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$sevenAgo } -ErrorAction Stop |
               Select-Object $commonSelect
        Write-SafeCsv -InputObject $app -Path $appCsv -NoTypeInformation | Out-Null
        Write-Ok "[OK] Wrote CSV: $appCsv"
    } catch {
        Write-Warn "[WARN] Application log summary failed: $($_.Exception.Message)"
    }

    try {
        $sys = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$sevenAgo } -ErrorAction Stop |
               Select-Object $commonSelect
        Write-SafeCsv -InputObject $sys -Path $sysCsv -NoTypeInformation | Out-Null
        Write-Ok "[OK] Wrote CSV: $sysCsv"
    } catch {
        Write-Warn "[WARN] System log summary failed: $($_.Exception.Message)"
    }

    Pause-Script
}
#endregion

#region ---------- Option 3: Startup Audit ----------
function Get-StartupFolderItems {
    param([string]$FolderPath, [string]$Scope)

    $items = @()
    if (-not [string]::IsNullOrWhiteSpace($FolderPath) -and (Test-Path -LiteralPath $FolderPath)) {

        Get-ChildItem -LiteralPath $FolderPath -File -ErrorAction SilentlyContinue | ForEach-Object {
            $items += [PSCustomObject]@{
                Location    = 'Folder'
                Scope       = $Scope
                Wow6432     = $false
                Name        = $_.Name
                Command     = $_.FullName
                SourcePath  = $FolderPath
            }
        }

        # .lnk target resolution (best-effort)
        Get-ChildItem -LiteralPath $FolderPath -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $wsh = New-Object -ComObject WScript.Shell
                $lnk = $wsh.CreateShortcut($_.FullName)
                $items += [PSCustomObject]@{
                    Location    = 'Folder(.lnk)'
                    Scope       = $Scope
                    Wow6432     = $false
                    Name        = $_.Name
                    Command     = $lnk.TargetPath
                    SourcePath  = $_.FullName
                }
            } catch {}
        }
    }
    return $items
}

function Get-RunKeyItems {
    param(
        [Parameter(Mandatory)][ValidateSet('HKLM','HKCU')]$Hive,
        [switch]$IncludeWow6432
    )

    $result = @()

    $baseKeys = @(
        "$Hive`:\Software\Microsoft\Windows\CurrentVersion\Run",
        "$Hive`:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
    )
    $wowKeys = @(
        "$Hive`:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
        "$Hive`:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce"
    )

    foreach ($k in $baseKeys) {
        if (Test-RegKeyExists $k) {
            try {
                $props = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).PSObject.Properties |
                    Where-Object { $_.Name -notin @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') }

                foreach ($p in $props) {
                    $result += [PSCustomObject]@{
                        Location    = 'Registry'
                        Scope       = $Hive
                        Wow6432     = $false
                        Name        = $p.Name
                        Command     = [string]$p.Value
                        SourcePath  = $k
                    }
                }
            } catch {}
        }
    }

    if ($IncludeWow6432) {
        foreach ($k in $wowKeys) {
            if (Test-RegKeyExists $k) {
                try {
                    $props = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).PSObject.Properties |
                        Where-Object { $_.Name -notin @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') }

                    foreach ($p in $props) {
                        $result += [PSCustomObject]@{
                            Location    = 'Registry'
                            Scope       = $Hive
                            Wow6432     = $true
                            Name        = $p.Name
                            Command     = [string]$p.Value
                            SourcePath  = $k
                        }
                    }
                } catch {}
            }
        }
    }

    return $result
}

function Collect-StartupAudit {
    Show-Header "$script:ModuleName - Startup Audit"

    $outDir = Ensure-ExportFolder
    $stamp  = Get-Timestamp
    $csv    = Join-Path $outDir ("StartupAudit_{0}.csv" -f $stamp)

    $items = @()

    # Startup folders
    $userStartup    = [Environment]::GetFolderPath('Startup')
    $commonStartup  = [Environment]::GetFolderPath('CommonStartup')

    $items += (Get-StartupFolderItems -FolderPath $userStartup   -Scope 'HKCU (Startup Folder)')
    $items += (Get-StartupFolderItems -FolderPath $commonStartup -Scope 'HKLM (Startup Folder)')

    # Run / RunOnce keys (HKLM/HKCU, 32+64 views)
    $items += (Get-RunKeyItems -Hive HKLM -IncludeWow6432)
    $items += (Get-RunKeyItems -Hive HKCU -IncludeWow6432)

    # Dedup by (Scope, Name, Command)
    $deduped = $items | Sort-Object Scope, Name, Command -Unique

    if (Write-SafeCsv -InputObject $deduped -Path $csv -NoTypeInformation) {
        Write-Ok "[OK] Wrote CSV: $csv"
    }

    if (-not $script:IsSilent) {
        $top = $deduped | Select-Object -First 15
        if ($top) {
            Write-Host ""
            Write-Host "Preview (first 15 rows):" -ForegroundColor Cyan
            $top | Format-Table -AutoSize | Out-String | Write-Host
        }
    }

    Pause-Script
}
#endregion

#region ---------- Run Helpers ----------
function Invoke-Mode {
    param([ValidateSet('1','2','3','All')][string]$RunMode)

    switch ($RunMode) {
        '1' { Collect-PendingRebootStatus }
        '2' { Collect-EventLogsLast7Days }
        '3' { Collect-StartupAudit }
        'All' {
            Collect-PendingRebootStatus
            Collect-EventLogsLast7Days
            Collect-StartupAudit
        }
    }
}
#endregion

#region ---------- Menu ----------
function Show-Menu {
    Show-Header "$script:ModuleName"
    Write-Host ""
    Write-Host " [1] Pending Reboot Status      - Registry checks and summary"
    Write-Host " [2] Application & System Logs  - Last 7 days, CSV + EVTX"
    Write-Host " [3] Startup Audit              - Startup folders and Run keys"
    Write-Host ""
    Write-Host " [Q] Quit"
    Write-Host ""
}

function Menu-Loop {
    while ($true) {
        Show-Menu
        $choice = Read-Choice "Enter your choice"
        switch ($choice.ToUpperInvariant()) {
            '1' { Collect-PendingRebootStatus }
            '2' { Collect-EventLogsLast7Days }
            '3' { Collect-StartupAudit }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Choose 1, 2, 3, or Q." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 900
            }
        }
    }
}
#endregion

#region ---------- Entry ----------
try {
    Ensure-ExportFolder | Out-Null

    # Determine behavior:
    # -Silent => always All, non-interactive
    # -ExportOnly => non-interactive (Mode or All)
    # Mode by itself => non-interactive run
    # otherwise => menu
    if ($Silent.IsPresent) {
        $script:IsSilent = $true
        Invoke-Mode -RunMode 'All'
        exit 0
    }

    if ($ExportOnly.IsPresent) {
        $run = if ([string]::IsNullOrWhiteSpace($Mode)) { 'All' } else { $Mode }
        Invoke-Mode -RunMode $run
        exit 0
    }

    if (-not [string]::IsNullOrWhiteSpace($Mode)) {
        Invoke-Mode -RunMode $Mode
        exit 0
    }

    # Default interactive
    Menu-Loop
} catch {
    Write-Err "Unhandled error: $($_.Exception.Message)"
    if (-not $script:IsSilent -and -not $ExportOnly.IsPresent) {
        Write-Host $_.Exception.StackTrace -ForegroundColor DarkGray
        Pause-Script
    }
    exit 1
}
#endregion