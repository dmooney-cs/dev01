# === CS Toolbox pre-init (StrictMode-safe) ===
$ErrorActionPreference = 'Stop'

# Ensure an export root exists before any common functions run
if (-not (Get-Variable -Name 'OutRoot' -Scope Script -ErrorAction SilentlyContinue)) {
  $script:OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo'
}

# Fallback Show-Header if commons aren't loaded
if (-not (Get-Command -Name Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header {
    param([string]$Title = 'System Info B')
    try { Clear-Host } catch {}
    Write-Host ''
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host ('='*70)
  }
}

# Fallback Ensure-ExportFolder if commons aren't loaded
if (-not (Get-Command -Name Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
  function Ensure-ExportFolder {
    param([string]$Path)
    if (-not $PSBoundParameters.ContainsKey('Path') -or [string]::IsNullOrWhiteSpace($Path)) {
      if (Get-Variable -Name 'OutRoot' -Scope Script -ErrorAction SilentlyContinue) {
        $Path = $script:OutRoot
      } else {
        $Path = 'C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo'
      }
    }
    if (-not (Test-Path -LiteralPath $Path)) {
      New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    return $Path
  }
}

# Make sure folder exists now
$null = Ensure-ExportFolder -Path $script:OutRoot
# === end pre-init ===


#requires -version 5.1
<#
    SystemInfo-B_STANDALONE.ps1
    Purpose: Run without external function libraries. Provides menu with:
      [1] Pending Reboot Status
      [2] Application & System Logs (last 7 days) -> CSV + EVTX
      [3] Startup Audit (Startup folders + Run keys) -> CSV
      [Q] Quit
#>

# ---------------------------
# Minimal local "commons"
# ---------------------------

function Get-Timestamp {
    (Get-Date).ToString('yyyyMMdd_HHmmss')
}

function Ensure-ExportFolder {
    param(
        [string]$Path = $null
    )
    if (-not $script:OutRoot) {
        $script:OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo'
    }
    $target = if ($Path) { $Path } else { $script:OutRoot }
    if (-not (Test-Path -LiteralPath $target)) {
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    return (Resolve-Path -LiteralPath $target).Path
}

function Show-Header {
    param([string]$Title = 'System Info B')
    $line = ('=' * 70)
    Write-Host ""
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host $line -ForegroundColor DarkCyan
}

function Pause-Script {
    param([string]$Message = "Press any key to return to the menu...")
    Write-Host ""
    Write-Host $Message -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Write-SafeCsv {
    param(
        [Parameter(Mandatory)] $InputObject,
        [Parameter(Mandatory)][string] $Path
    )
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        # Use -Force to overwrite if exists, stable UTF8
        $InputObject | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force
        Write-Host "[OK] Wrote CSV: $Path" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "ERROR writing CSV: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Registry helpers
function Test-RegKeyExists {
    param([Parameter(Mandatory)][string]$Path)
    try { Test-Path -LiteralPath $Path } catch { $false }
}
function Test-RegValueExists {
    param([Parameter(Mandatory)][string]$Path,
          [Parameter(Mandatory)][string]$Name)
    try {
        $null = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop
        $true
    } catch { $false }
}
function Get-RegValue {
    param([Parameter(Mandatory)][string]$Path,
          [Parameter(Mandatory)][string]$Name)
    try {
        (Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop).$Name
    } catch { $null }
}

# ---------------------------
#  [1] Pending Reboot Status
# ---------------------------
function Collect-PendingRebootStatus {
    Show-Header "System Info B - Pending Reboot Status"

    $rows = New-Object System.Collections.Generic.List[object]

    # Canonical reboot indicators
    $rows.Add([PSCustomObject]@{
        Check  = 'CBS RebootPending (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        Detail = ''
    })
    $rows.Add([PSCustomObject]@{
        Check  = 'CBS PackagesPending (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
        Detail = ''
    })
    $rows.Add([PSCustomObject]@{
        Check  = 'WindowsUpdate RebootRequired (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        Detail = ''
    })
    $rows.Add([PSCustomObject]@{
        Check  = 'PendingFileRenameOperations (value)'
        Path   = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
        Exists = Test-RegValueExists 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations'
        Detail = (Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations') -join '; '
    })
    $rows.Add([PSCustomObject]@{
        Check  = 'Active ComputerName differs from ComputerName'
        Path   = 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName'
        Exists = $true
        Detail = try {
            $active  = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -ErrorAction Stop).ComputerName
            $pending = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -ErrorAction Stop).ComputerName
            if ($active -ne $pending) { "Active=$active; Pending=$pending" } else { "" }
        } catch { "" }
    })
    # SCCM/CCM
    $rows.Add([PSCustomObject]@{
        Check  = 'SCCM/CCM PendingReboot (key)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\CCM\PendingReboot'
        Exists = Test-RegKeyExists 'HKLM:\SOFTWARE\Microsoft\CCM\PendingReboot'
        Detail = ''
    })
    $rows.Add([PSCustomObject]@{
        Check  = 'SCCM/CCM RebootNeeded (value)'
        Path   = 'HKLM:\SOFTWARE\Microsoft\CCM\StateSystem'
        Exists = Test-RegValueExists 'HKLM:\SOFTWARE\Microsoft\CCM\StateSystem' 'RebootRequired'
        Detail = (Get-RegValue 'HKLM:\SOFTWARE\Microsoft\CCM\StateSystem' 'RebootRequired')
    })

    $ts = Get-Timestamp
    $outDir = Ensure-ExportFolder
    $csv = Join-Path $outDir ("PendingReboot_{0}.csv" -f $ts)

    $ok = Write-SafeCsv -InputObject $rows -Path $csv

    # Simple on-screen summary
    $needsReboot = $rows | Where-Object {
        $_.Check -ne 'Active ComputerName differs from ComputerName' -and $_.Exists
    }
    $nameMismatch = ($rows | Where-Object { $_.Check -eq 'Active ComputerName differs from ComputerName' -and $_.Detail }) -ne $null

    Write-Host ""
    if ($needsReboot.Count -gt 0 -or $nameMismatch) {
        Write-Host "PENDING REBOOT INDICATORS FOUND." -ForegroundColor Yellow
    } else {
        Write-Host "No reboot indicators detected." -ForegroundColor Green
    }
    if ($ok) { Write-Host "CSV saved to: $csv" -ForegroundColor DarkGray }

    Pause-Script
}

# ---------------------------------------------
#  [2] Application & System Logs (last 7 days)
# ---------------------------------------------
function Collect-Last7Days-Logs {
    Show-Header "System Info B - Application & System Logs (7 days)"
    $outDir = Ensure-ExportFolder

    $start = (Get-Date).AddDays(-7)
    Write-Host ("Collecting events since {0}" -f $start) -ForegroundColor DarkGray

    # CSV (filtered, compact selection)
    $appCsv = Join-Path $outDir ("Application_Last7d_{0}.csv" -f (Get-Timestamp))
    $sysCsv = Join-Path $outDir ("System_Last7d_{0}.csv" -f (Get-Timestamp))

    try {
        Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$start } |
            Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, MachineName, Message |
            Export-Csv -Path $appCsv -NoTypeInformation -Encoding UTF8 -Force
        Write-Host "[OK] Wrote CSV: $appCsv" -ForegroundColor Green
    } catch {
        Write-Host "ERROR exporting Application CSV: $($_.Exception.Message)" -ForegroundColor Red
    }

    try {
        Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$start } |
            Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, MachineName, Message |
            Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8 -Force
        Write-Host "[OK] Wrote CSV: $sysCsv" -ForegroundColor Green
    } catch {
        Write-Host "ERROR exporting System CSV: $($_.Exception.Message)" -ForegroundColor Red
    }

    # EVTX (wevtutil export entire logs; most compatible approach)
    $appEvtx = Join-Path $outDir ("Application_{0}.evtx" -f (Get-Timestamp))
    $sysEvtx = Join-Path $outDir ("System_{0}.evtx" -f (Get-Timestamp))

    try {
        & wevtutil epl Application $appEvtx
        Write-Host "[OK] Exported EVTX: $appEvtx" -ForegroundColor Green
    } catch {
        Write-Host "ERROR exporting Application EVTX: $($_.Exception.Message)" -ForegroundColor Red
    }
    try {
        & wevtutil epl System $sysEvtx
        Write-Host "[OK] Exported EVTX: $sysEvtx" -ForegroundColor Green
    } catch {
        Write-Host "ERROR exporting System EVTX: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script
}

# ---------------------------
#  [3] Startup Audit
# ---------------------------
function Collect-StartupAudit {
    Show-Header "System Info B - Startup Audit"

    $rows = New-Object System.Collections.Generic.List[object]

    # Startup folders
    $commonStartup = "$Env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"
    $userStartup   = "$Env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"

    foreach ($path in @($commonStartup, $userStartup)) {
        if (Test-Path -LiteralPath $path) {
            Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | ForEach-Object {
                $rows.Add([PSCustomObject]@{
                    Source = "StartupFolder"
                    Path   = $_.FullName
                    Name   = $_.Name
                    Type   = $_.Extension
                    Owner  = (try { (Get-Acl -LiteralPath $_.FullName).Owner } catch { "" })
                })
            }
        } else {
            $rows.Add([PSCustomObject]@{
                Source = "StartupFolder"
                Path   = $path
                Name   = ""
                Type   = ""
                Owner  = ""
            })
        }
    }

    # Run and RunOnce keys (HKLM/HKCU)
    $runPaths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    )
    foreach ($rk in $runPaths) {
        if (Test-RegKeyExists $rk) {
            try {
                $props = Get-ItemProperty -LiteralPath $rk -ErrorAction Stop | Select-Object -Property * -ExcludeProperty PS*, Microsoft*
                $props.PSObject.Properties | Where-Object { $_.MemberType -eq 'NoteProperty' } | ForEach-Object {
                    $rows.Add([PSCustomObject]@{
                        Source = $rk
                        Path   = $rk
                        Name   = $_.Name
                        Type   = "RegistryValue"
                        Owner  = ""
                        Value  = $_.Value
                    })
                }
            } catch {
                $rows.Add([PSCustomObject]@{
                    Source = $rk
                    Path   = $rk
                    Name   = ""
                    Type   = "RegistryValue"
                    Owner  = ""
                    Value  = "ERROR: $($_.Exception.Message)"
                })
            }
        } else {
            $rows.Add([PSCustomObject]@{
                Source = $rk
                Path   = $rk
                Name   = ""
                Type   = "RegistryValue"
                Owner  = ""
                Value  = "<key not found>"
            })
        }
    }

    $outDir = Ensure-ExportFolder
    $csv = Join-Path $outDir ("StartupAudit_{0}.csv" -f (Get-Timestamp))
    $null = Write-SafeCsv -InputObject $rows -Path $csv

    Pause-Script
}

# ---------------------------
#           MENU
# ---------------------------
function Show-Menu {
    Show-Header "System Info B"
    Write-Host ""
    Write-Host " [1] Pending Reboot Status      - Registry checks and summary"
    Write-Host " [2] Application & System Logs  - Last 7 days, CSV + EVTX"
    Write-Host " [3] Startup Audit              - Startup folders and Run keys"
    Write-Host ""
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main loop
$script:OutRoot = Ensure-ExportFolder  # ensure ready
while ($true) {
    Clear-Host
    Show-Menu
    $choice = Read-Host "Enter your choice"
    switch ($choice.ToUpperInvariant()) {
        '1' { Collect-PendingRebootStatus }
        '2' { Collect-Last7Days-Logs }
        '3' { Collect-StartupAudit }
        'Q' { break }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Seconds 1.2
        }
    }
}
