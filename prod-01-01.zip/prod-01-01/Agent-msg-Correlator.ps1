param(
    [Alias('DefaultLogs')]
    [switch]$DefaultLog,
    [switch]$Html,
    [switch]$ExportOnly,
    [string]$LogPath,
    [switch]$CheckCalc,
    [string]$CheckCalcLogPath,
    [string]$CheckCalcJsonLogPath,
    [int]$CheckCalcMaxAttempts = 10,
    [switch]$MLC
)

# =====================================================================
# agent-msg-correlator.ps1  (PS 5.1 compatible)
# ---------------------------------------------------------------------
# SWITCHES:
#   -DefaultLog / -DefaultLogs
#       * Uses default agent log path automatically:
#           C:\Program Files (x86)\CyberCNSAgent\logs
#       * Quiet mode (suppresses info chatter; errors always shown)
#       * Skips interactive main menu entirely
#       * Skips HTML prompt; only console summary + details
#
#   -Html
#       * Auto-creates HTML report (no "Y/N" prompt)
#       * Does NOT open the HTML file (no Start-Process)
#       * Works with or without -DefaultLog
#
#   -ExportOnly   (required for cookbook commands)
#       * Uses default agent log path automatically
#       * Quiet mode
#       * Forces HTML export (no prompt), does NOT open
#       * Exits after export (no menu/launcher hand-off)
#
#   -CheckCalc
#       * Uses default agent log path automatically when -LogPath is not provided
#       * Runs all calculations but skips HTML generation
#       * Prints structured pass/fail checks for Cursor-friendly debugging
#       * Exits with code 0 on pass, 1 on failure
#       * Escalates after repeated failures on the same check (default 10 attempts)
#       * Optional: -CheckCalcLogPath writes readable progress log
#       * Optional: -CheckCalcJsonLogPath writes JSONL machine log
#       * Optional: -CheckCalcMaxAttempts sets escalation threshold
#
#   -MLC
#       * Mass Log Correlator mode
#       * Requires -LogPath "root folder"
#       * Recursively finds only cybercns.log files under the supplied path
#       * Lists file paths and sizes, shows total count, then prompts to continue
#       * Generates HTML one-by-one for each discovered cybercns.log with a progress bar
#
# Occurrence snapshots:
#   * Shows ONLY ONE occurrence per match (MOST RECENT)
#   * Includes the exact matching line + 5 lines before/after
#   * Shown in console and included in HTML export
# =====================================================================

# -----------------------------
# Configurable Paths & URLs
# -----------------------------
$Global:MsgIndexPrimaryUrl       = 'https://raw.githubusercontent.com/dmooney-cs/prod/main/cs-message-index.csv'
$Global:MsgIndexSecondaryUrl     = ''

# Optional hash URLs (plain text SHA256). Leave $null if not used.
$Global:MsgIndexPrimaryHashUrl   = $null
$Global:MsgIndexSecondaryHashUrl = $null

# Local storage root for the message index
$Global:MsgIndexLocalRoot        = 'C:\CS-Toolbox-TEMP\prod-01-01\KnownIssues'
$Global:MsgIndexLocalFileName    = 'cs-message-index.csv'

# Default agent log root path
$Global:DefaultAgentLogRoot      = 'C:\Program Files (x86)\CyberCNSAgent\logs'

# Path to CS Toolbox Launcher (for Q in menu)
$Global:LauncherPath             = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# Quiet mode for -DefaultLog / -ExportOnly
$Global:MsgCorrelatorQuiet       = $false
if ($DefaultLog -or $ExportOnly -or ($LogPath -and $LogPath.Trim().Length -gt 0)) { $Global:MsgCorrelatorQuiet = $true }

# HTML behavior flags for -Html / -ExportOnly
$Global:MsgCorrelatorAutoHtml    = $false
$Global:MsgCorrelatorOpenHtml    = $true

if ($Html -or $ExportOnly) {
    $Global:MsgCorrelatorAutoHtml = $true
    $Global:MsgCorrelatorOpenHtml = $false
}

# If -LogPath is provided, force silent HTML generation (no prompt, no auto-open)
if ($LogPath -and $LogPath.Trim().Length -gt 0) {
    $Global:MsgCorrelatorAutoHtml = $true
    $Global:MsgCorrelatorOpenHtml = $false
}

# Silent mode when -LogPath is provided:
# - No console output (no headers, no tables, no match blocks)
# - Still generates HTML
$Global:MsgCorrelatorSilent = $false
$Global:MsgCorrelatorOrigProgressPreference = $ProgressPreference
if (($LogPath -and $LogPath.Trim().Length -gt 0) -or $ExportOnly -or $DefaultLog) {
    $Global:MsgCorrelatorSilent = $true
    # Reduce any incidental progress output
    $ProgressPreference = 'SilentlyContinue'
}
# Script-scope storage for CSV column names
$script:MsgIndexColumns          = @()

# -----------------------------
# Script Settings
# -----------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Deterministic process exit code for automation
$Global:CSExitCode = 0

# -----------------------------
# Helper: Logging (quiet-aware)
# -----------------------------
$script:AgentSummaryFromLogs = $null

function Write-LogInfo {
    param([string]$Message)
    if ($Global:MsgCorrelatorQuiet) { return }
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[INFO]  $ts  $Message"
}
function Write-LogWarn {
    param([string]$Message)
    if ($Global:MsgCorrelatorQuiet) { return }
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[WARN]  $ts  $Message" -ForegroundColor Yellow
}
function Write-LogErrorLine {
    param([string]$Message)
    if ($Global:MsgCorrelatorSilent) { return }
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[ERROR] $ts  $Message" -ForegroundColor Red
}

# -----------------------------
# Helper: Ensure directory
# -----------------------------
function Ensure-Directory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-LogInfo "Creating directory: $Path"
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

# -----------------------------
# Helper: HTML escaping
# -----------------------------
function HtmlEscape {
    param([string]$s)
    if ($null -eq $s) { return '' }
    $s = $s -replace '&','&amp;'
    $s = $s -replace '<','&lt;'
    $s = $s -replace '>','&gt;'
    return $s
}


function Get-SafeIntSum {
    param(
        [object[]]$Items = @(),
        [string]$PropertyName = ''
    )

    $total = 0
    foreach ($item in @($Items)) {
        if ($null -eq $item) { continue }

        $value = $null
        if ([string]::IsNullOrWhiteSpace($PropertyName)) {
            $value = $item
        }
        elseif ($item.PSObject.Properties.Name -contains $PropertyName) {
            $value = $item.$PropertyName
        }
        else {
            continue
        }

        if ($null -eq $value) { continue }
        $intValue = 0
        if ([int]::TryParse(([string]$value), [ref]$intValue)) {
            $total += $intValue
        }
    }

    return [int]$total
}

function Get-AgentSummaryFromLogs {
    param([Parameter(Mandatory = $true)][string]$CollectDir)

    $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.Extension -in @('.log','.txt') } |
                 Sort-Object FullName | Where-Object { $_.Name -match 'cybercns' } | Select-Object -First 1
    if (-not $candidate) {
        $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
                     Where-Object { $_.Extension -in @('.log','.txt') } |
                     Where-Object { Select-String -Path $_.FullName -Pattern 'AGENT INFO' -SimpleMatch -ErrorAction SilentlyContinue } |
                     Select-Object -First 1
    }
    if (-not $candidate) { return $null }

    $meta = [ordered]@{
        Hostname     = $null
        IP           = $null
        MAC          = $null
        AgentVersion = $null
        AgentID      = $null
        TenantID     = $null
        CompanyID    = $null
        AgentType    = $null
        PODID        = $null
        SourceFile   = $candidate.FullName
    }

    $lines = @()
    try { $lines = @(Get-Content -LiteralPath $candidate.FullName -ErrorAction Stop) } catch { $lines = @() }

    foreach ($ln in $lines) {
        $line = [string]$ln
        if (-not $meta.IP -and $line -match 'IP ADDRESS') {
            $ipm  = [regex]::Match($line,'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)')
            if ($ipm.Success) { $meta.IP = $ipm.Groups[1].Value }
            $macm = [regex]::Match($line,'\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b')
            if ($macm.Success) { $meta.MAC = $macm.Groups[1].Value.ToLower() }
            $hostm = [regex]::Match($line,'HostName.?s\s*\[([^\]]+)\]')
            if ($hostm.Success) { $meta.Hostname = $hostm.Groups[1].Value }
            if (-not $meta.Hostname) {
                $uidm = [regex]::Match($line,"UniqueId.?s\s*\[([^\]]+)\]")
                if ($uidm.Success) {
                    $maybe = ($uidm.Groups[1].Value -split '[\s,]') | Where-Object { $_ -and ($_ -notmatch ':') } | Select-Object -First 1
                    if ($maybe) { $meta.Hostname = $maybe }
                }
            }
        }
        if ($line -match '\[Agent Version\s*:-\s*([^\]]+)\]') { $meta.AgentVersion = $Matches[1].Trim() }
        if ($line -match '\[Agent ID\s*:-\s*([^\]]+)\]')      { $meta.AgentID      = $Matches[1].Trim() }
        if ($line -match '\[Tenant ID\s*:-\s*([^\]]+)\]')     { $meta.TenantID     = $Matches[1].Trim() }
        if ($line -match '\[Company ID\s*:-\s*([^\]]+)\]')    { $meta.CompanyID    = $Matches[1].Trim() }
        if ($line -match '\[Agent Type\s*:-\s*([^\]]+)\]')    { $meta.AgentType    = $Matches[1].Trim() }
        if ($line -match '\[PODID\s*:-\s*([^\]]+)\]')         { $meta.PODID        = $Matches[1].Trim() }
    }

    return [pscustomobject]$meta
}

# -----------------------------
# Helper: Detect HTML masquerading as CSV
# -----------------------------
function Test-FileLooksLikeHtml {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try {
        $lines  = Get-Content -LiteralPath $Path -TotalCount 5 -ErrorAction Stop
        $joined = ($lines -join "`n").TrimStart()
        if ($joined.StartsWith("<!DOCTYPE html", [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
        if ($joined.StartsWith("<html", [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
        return $false
    }
    catch { return $false }
}

# -----------------------------
# Helper: Read file lines with caching (for context blocks)
# -----------------------------
function Get-CachedFileLines {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Cache,
        [Parameter(Mandatory = $true)][string]$Path
    )
    if ($Cache.ContainsKey($Path)) { return $Cache[$Path] }
    try { $lines = @(Get-Content -LiteralPath $Path -ErrorAction Stop) } catch { $lines = @() }
    $Cache[$Path] = $lines
    return $lines
}

# -----------------------------
# Helper: Build a context snippet (N lines before/after) for a match
# -----------------------------
function Get-LogContextSnippet {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Cache,
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][int]$LineNumber,
        [int]$Before = 5,
        [int]$After  = 5
    )

    $lines = Get-CachedFileLines -Cache $Cache -Path $Path
    if (-not $lines -or $lines.Count -eq 0) {
        return [pscustomobject]@{
            Path          = $Path
            MatchLine     = $LineNumber
            StartLine     = $LineNumber
            EndLine       = $LineNumber
            Lines         = @()
            MatchLineText = ''
        }
    }

    $total = $lines.Count
    if ($LineNumber -lt 1) { $LineNumber = 1 }
    if ($LineNumber -gt $total) { $LineNumber = $total }

    $start = $LineNumber - $Before
    if ($start -lt 1) { $start = 1 }
    $end = $LineNumber + $After
    if ($end -gt $total) { $end = $total }

    $slice = @()
    for ($i = $start; $i -le $end; $i++) {
        $slice += [pscustomobject]@{
            LineNumber = $i
            Text       = [string]$lines[$i-1]
            IsMatch    = ($i -eq $LineNumber)
        }
    }

    $matchText = [string]$lines[$LineNumber-1]

    return [pscustomobject]@{
        Path          = $Path
        MatchLine     = $LineNumber
        StartLine     = $start
        EndLine       = $end
        Lines         = $slice
        MatchLineText = $matchText
    }
}

# -----------------------------
# Helper: Download index
# -----------------------------
function Download-IndexFromSource {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$CsvUrl,
        [string]$HashUrl,
        [Parameter(Mandatory = $true)][string]$TargetPath
    )

    $attemptMax = 3
    $success    = $false

    Ensure-Directory -Path (Split-Path -Parent $TargetPath)

    for ($i = 1; $i -le $attemptMax -and -not $success; $i++) {
        Write-LogInfo "Attempt $i of $attemptMax to download index from $Label..."

        $tmpPath = "$TargetPath.download"
        if (Test-Path -LiteralPath $tmpPath) {
            Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
        }

        try {
            Invoke-WebRequest -Uri $CsvUrl -OutFile $tmpPath -UseBasicParsing -ErrorAction Stop

            if (Test-FileLooksLikeHtml -Path $tmpPath) {
                Write-LogWarn "Downloaded content from $Label appears to be HTML (not CSV). Discarding."
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                continue
            }

            $hashValue = $null
            try {
                $hashObj   = Get-FileHash -Path $tmpPath -Algorithm SHA256
                $hashValue = $hashObj.Hash
                Write-LogInfo "Downloaded index from $Label. SHA256: $hashValue"
            } catch {
                Write-LogWarn ("Failed to compute hash for download from {0}: {1}" -f $Label, $_.Exception.Message)
            }

            if ($HashUrl -and $HashUrl.Trim().Length -gt 0 -and $hashValue) {
                Write-LogInfo "Retrieving expected hash from: $HashUrl"
                try {
                    $expected = (Invoke-WebRequest -Uri $HashUrl -UseBasicParsing -ErrorAction Stop).Content.Trim()
                    Write-LogInfo "Expected SHA256: $expected"
                    if ($expected -and $expected -ne $hashValue) {
                        Write-LogWarn "Hash mismatch from $Label. Discarding downloaded file."
                        Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                        continue
                    }
                } catch {
                    Write-LogWarn "Failed to retrieve/read hash from $HashUrl : $($_.Exception.Message)"
                }
            } else {
                Write-LogInfo "No remote hash URL configured for $Label; local SHA256 shown for reference only."
            }

            if (Test-Path -LiteralPath $TargetPath) {
                Remove-Item -LiteralPath $TargetPath -Force -ErrorAction SilentlyContinue
            }
            Move-Item -Path $tmpPath -Destination $TargetPath -Force
            Write-LogInfo "Index downloaded and saved to: $TargetPath"
            $success = $true
        }
        catch {
            Write-LogWarn "Download attempt $i from $Label failed: $($_.Exception.Message)"
            if (Test-Path -LiteralPath $tmpPath) {
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
            }
        }
    }

    if (-not $success) { Write-LogWarn "All attempts to download from $Label failed." }
    return $success
}

# -----------------------------
# Helper: Index metadata
# -----------------------------
function Get-IndexMetadata {
    param([string]$LocalRoot,[string]$LocalFileName)

    Ensure-Directory -Path $LocalRoot
    $localPath = Join-Path $LocalRoot $LocalFileName

    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        if (Test-FileLooksLikeHtml -Path $localPath) {
            Write-LogWarn "Existing local index appears to be HTML (corrupted). Deleting."
            Remove-Item -LiteralPath $localPath -Force -ErrorAction SilentlyContinue
            return [pscustomobject]@{ Path=$localPath; Exists=$false; LastWriteTime=$null; AgeDays=$null }
        }

        $info   = Get-Item -LiteralPath $localPath
        $age    = (New-TimeSpan -Start $info.LastWriteTime -End (Get-Date)).TotalDays
        $ageR   = [Math]::Round([double]$age, 2)

        return [pscustomobject]@{
            Path          = $localPath
            Exists        = $true
            LastWriteTime = $info.LastWriteTime
            AgeDays       = $ageR
        }
    }

    return [pscustomobject]@{ Path=$localPath; Exists=$false; LastWriteTime=$null; AgeDays=$null }
}

# -----------------------------
# Helper: Ensure index fresh (7-day rule)
# -----------------------------
function Ensure-IndexFreshForCorrelation {
    param(
        [string]$PrimaryUrl,
        [string]$SecondaryUrl,
        [string]$PrimaryHashUrl,
        [string]$SecondaryHashUrl,
        [string]$LocalRoot,
        [string]$LocalFileName,
        [switch]$ForceRefresh
    )

    $meta = Get-IndexMetadata -LocalRoot $LocalRoot -LocalFileName $LocalFileName

    $needsDownload = $ForceRefresh.IsPresent -or (-not $meta.Exists) -or (
        $meta.AgeDays -ne $null -and $meta.AgeDays -gt 7.0
    )

    if ($meta.Exists -and -not $ForceRefresh.IsPresent -and $meta.AgeDays -ne $null -and $meta.AgeDays -le 7.0) {
        Write-LogInfo "Local index updated within last 7 days; no automatic refresh needed."
    }

    if ($needsDownload) {
        if (-not $ForceRefresh.IsPresent -and $meta.Exists) {
            Write-LogInfo ("Local index is older than 7 days (Age: {0} day(s)); refreshing from server." -f $meta.AgeDays)
        } elseif (-not $meta.Exists) {
            Write-LogInfo "No local index present; fetching from server."
        } else {
            Write-LogInfo "Force update of index requested."
        }

        $ok = $false
        if ($PrimaryUrl -and $PrimaryUrl.Trim().Length -gt 0) {
            $ok = Download-IndexFromSource -Label 'DL1' -CsvUrl $PrimaryUrl -HashUrl $PrimaryHashUrl -TargetPath (Join-Path $LocalRoot $LocalFileName)
        }
        if (-not $ok -and $SecondaryUrl -and $SecondaryUrl.Trim().Length -gt 0) {
            $ok = Download-IndexFromSource -Label 'DL2' -CsvUrl $SecondaryUrl -HashUrl $SecondaryHashUrl -TargetPath (Join-Path $LocalRoot $LocalFileName)
        }

        $meta = Get-IndexMetadata -LocalRoot $LocalRoot -LocalFileName $LocalFileName
        if (-not $meta.Exists) { throw "Unable to obtain index file from DL1 or DL2." }
    }

    return [pscustomobject]@{ Path=$meta.Path; Metadata=$meta }
}

# -----------------------------
# Helper: Extract CSV (if ZIP)
# -----------------------------
function Get-IndexCsvPath {
    param([Parameter(Mandatory = $true)][string]$IndexFilePath)

    $ext = [System.IO.Path]::GetExtension($IndexFilePath)
    if ($ext -ieq '.zip') {
        $tempDir = Join-Path ([System.IO.Path]::GetDirectoryName($IndexFilePath)) 'agent-msg-index-unzipped'
        Ensure-Directory -Path $tempDir
        Write-LogInfo "Index appears to be a ZIP. Extracting to: $tempDir"
        Get-ChildItem -LiteralPath $tempDir -File -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Expand-Archive -LiteralPath $IndexFilePath -DestinationPath $tempDir -Force

        $csv = Get-ChildItem -Path $tempDir -Filter *.csv -File -Recurse | Select-Object -First 1
        if (-not $csv) { throw "No CSV file found inside index archive: $IndexFilePath" }
        Write-LogInfo "Using CSV from archive: $($csv.FullName)"
        return $csv.FullName
    }

    Write-LogInfo "Index treated as CSV: $IndexFilePath"
    return $IndexFilePath
}

# -----------------------------
# Severity detection
# -----------------------------
$Global:LevelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'

function Get-SeverityFromLine {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return 'Unknown' }
    if ($Line -match $Global:LevelRegex) {
        $upper = $Matches[1].ToUpperInvariant()
        switch -Regex ($upper) {
            '^FAIL(ED)?$' { return 'FAIL' }
            default       { return $upper }
        }
    }
    return 'Unknown'
}
function Get-SeverityColor {
    param([string]$Severity)
    switch ($Severity) {
        'FATAL'          { return 'Red' }
        'ERROR'          { return 'Red' }
        'EXCEPTION'      { return 'Red' }
        'FAIL'           { return 'Magenta' }
        'TIMEOUT'        { return 'Magenta' }
        'UNAUTHORIZED'   { return 'DarkYellow' }
        'ACCESS DENIED'  { return 'DarkYellow' }
        'WARN'           { return 'Yellow' }
        'WARNING'        { return 'Yellow' }
        default          { return 'Cyan' }
    }
}

# -----------------------------
# Helper: Find CSV column by candidate names
# -----------------------------
function Find-CsvColName {
    param([string[]]$Props,[string[]]$Candidates)
    foreach ($cand in $Candidates) {
        $candNorm = ($cand -replace "^\uFEFF","").Trim().ToLowerInvariant()
        foreach ($p in $Props) {
            if (-not $p) { continue }
            $pNorm = ($p -replace "^\uFEFF","").Trim().ToLowerInvariant()
            if ($pNorm -eq $candNorm) { return $p }
        }
    }
    return $null
}

# -----------------------------
# Helper: normalize CSV values (BOM/quotes)
# -----------------------------
function Normalize-CsvValue {
    param([object]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace "^\uFEFF",""
    $s = $s.Trim()
    if ($s.Length -ge 2 -and $s.StartsWith('"') -and $s.EndsWith('"')) {
        $s = $s.Substring(1, $s.Length - 2)
    } else {
        if ($s.EndsWith('"')) { $s = $s.Substring(0, $s.Length - 1) }
        if ($s.StartsWith('"')) { $s = $s.Substring(1) }
    }
    return $s
}

# -----------------------------
# Multiline-safe CSV reader (PS 5.1)
# -----------------------------
function Read-CsvMultilineSafe {
    param([Parameter(Mandatory = $true)][string]$Path,[string]$Delimiter = ',')

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "CSV not found: $Path" }

    Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction Stop

    $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($Path)
    try {
        $parser.TextFieldType = 'Delimited'
        $parser.SetDelimiters($Delimiter)
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $false

        $headers = $parser.ReadFields()
        if (-not $headers -or $headers.Count -eq 0) {
            throw "CSV has no header row: $Path"
        }

        $headers[0] = $headers[0] -replace "^\uFEFF",""
        $out = New-Object System.Collections.Generic.List[object]

        while (-not $parser.EndOfData) {
            $fields = $parser.ReadFields()
            if ($null -eq $fields) { continue }

            if ($fields.Count -lt $headers.Count) {
                $fields = $fields + (@('') * ($headers.Count - $fields.Count))
            } elseif ($fields.Count -gt $headers.Count) {
                $fields = $fields[0..($headers.Count - 1)]
            }

            $obj = [ordered]@{}
            for ($i = 0; $i -lt $headers.Count; $i++) {
                $obj[$headers[$i]] = Normalize-CsvValue -Value $fields[$i]
            }
            [void]$out.Add([pscustomobject]$obj)
        }

        return $out.ToArray()
    }
    finally {
        if ($parser) { $parser.Close() }
    }
}

# -----------------------------
# Import Known Issues from CSV (patterns)
# -----------------------------
function Import-KnownIssuePatterns {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Index CSV not found at: $Path" }

    Write-LogInfo "Importing Known Issues from CSV: $Path"

    try { $rows = Read-CsvMultilineSafe -Path $Path -Delimiter ',' }
    catch { throw "Failed to read index CSV: $($_.Exception.Message)" }

    if (-not $rows -or @($rows).Count -eq 0) { throw "Index CSV is empty: $Path" }

    $first     = $rows[0]
    $propNames = @($first.PSObject.Properties.Name)
    $script:MsgIndexColumns = $propNames
    Write-LogInfo ("Index CSV columns: " + ($propNames -join ', '))

    $colError = Find-CsvColName -Props $propNames -Candidates @('ERROR','Error','MESSAGE','Message','Log Message','LogMessage')
    if (-not $colError) {
        Write-LogWarn "Index CSV does not have a recognizable ERROR/Message column; falling back to first non-empty property per row."
    } else {
        Write-LogInfo "Using column '$colError' as Error/Message source."
    }

    $patterns = @()
    foreach ($row in $rows) {
        $errorText = $null
        if ($colError) { $errorText = [string]$row.$colError }

        if ([string]::IsNullOrWhiteSpace($errorText)) {
            foreach ($p in $row.PSObject.Properties) {
                $s = [string]$p.Value
                if (-not [string]::IsNullOrWhiteSpace($s)) { $errorText = $s; break }
            }
        }

        if ([string]::IsNullOrWhiteSpace($errorText)) { continue }
        $errorText = $errorText.Trim()
        if ($errorText.Length -lt 5) { continue }

        $patterns += [pscustomobject]@{ CsvRow=$row; ErrorText=$errorText }
    }

    if (@($patterns).Count -eq 0) { throw "No usable error patterns could be derived from the index CSV." }

    Write-LogInfo "Prepared $(@($patterns).Count) error pattern(s) from index."
    return $patterns
}

# -----------------------------
# Parse timestamp from a log line
# -----------------------------
function Get-LogLineTimestamp {
    param([Parameter(Mandatory = $true)][string]$Line)

    $regex1 = '(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2})'
    $m1 = [regex]::Match($Line, $regex1)
    if ($m1.Success) {
        try { return [datetime]$m1.Groups[1].Value } catch { }
    }

    $regex2 = '(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*(AM|PM)?)'
    $m2 = [regex]::Match($Line, $regex2)
    if ($m2.Success) {
        try { return [datetime]$m2.Groups[1].Value } catch { }
    }

    if ($Line.Length -ge 19) {
        try { return [datetime]$Line.Substring(0, 19) } catch { }
    }

    return $null
}

# -----------------------------
# Format "X minutes/hours ago"
# -----------------------------
function Format-TimeAgo {
    param([Parameter(Mandatory = $true)][DateTime]$LastTime,[Parameter(Mandatory = $true)][DateTime]$Now)

    $span = $Now - $LastTime
    if ($span.TotalMinutes -lt 120) {
        $mins = [int][Math]::Round($span.TotalMinutes)
        if ($mins -le 1) { return "1 minute ago" }
        return "$mins minutes ago"
    }

    $hours = [int][Math]::Round($span.TotalHours)
    if ($hours -le 1) { return "1 hour ago" }
    return "$hours hours ago"
}

# -----------------------------
# Normalize eligible error/failure log lines for grouping
#   - strips leading timestamps so repeated messages group together
#   - normalizes bracket spacing and repeated whitespace
# -----------------------------
function Normalize-EligibleLogLine {
    param([string]$Line)

    if ([string]::IsNullOrWhiteSpace($Line)) { return '' }

    $s = [string]$Line

    # Remove common leading timestamp formats used in agent logs
    $s = [regex]::Replace($s, '^\s*\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}\s*', '')
    $s = [regex]::Replace($s, '^\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\s*', '')
    $s = [regex]::Replace($s, '^\s*\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}(?:\s*(?:AM|PM))?\s*', '', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)

    # Normalize extra spacing but preserve the actual message content
    $s = $s.Trim()
    $s = $s -replace '\s+\[', ' ['
    $s = $s -replace '\]\s+', '] '
    $s = $s -replace '\s{2,}', ' '

    return $s.Trim()
}

function Get-UnmatchedGroupName {
    param([string]$NormalizedLine)

    $lower = $NormalizedLine.ToLowerInvariant()

    # CUSTOM NON-MATCH GROUP RULES - EDIT HERE
    # Order matters. First match wins.
    $GroupPatterns = @(

    # --- EXISTING RULES ---
    [pscustomobject]@{ Text = 'exit status 1'; Label = 'Contains: exit status 1' },
    [pscustomobject]@{ Text = 'exit code: 1602'; Label = 'Contains: exit code: 1602' },
    [pscustomobject]@{ Text = "invalid character 'f' looking"; Label = "Contains: invalid character 'F' looking" },
    [pscustomobject]@{ Text = 'i/o timeout'; Label = 'Contains: i/o timeout' },
    [pscustomobject]@{ Text = 'mqtt: connection'; Label = 'Contains: MQTT: Connection' },
    [pscustomobject]@{ Text = 'access is denied.'; Label = 'Contains: Access is denied.' },
    [pscustomobject]@{ Text = 'an existing connection was forcibly closed by the remote host.'; Label = 'Contains: An existing connection was forcibly closed by the remote host.' },
    [pscustomobject]@{ Text = '"status":"failed","status_msg":"upgrade failed'; Label = 'Contains: "status":"Failed","status_msg":"Upgrade Failed"' },

    # --- NEW HIGH-VALUE RULES ---
    [pscustomobject]@{ Text = "error decoding response body: invalid character 'e' looking"; Label = "Contains: invalid character 'e' looking" },
    [pscustomobject]@{ Text = 'error in getting agent scheduler, failed with status code'; Label = 'Contains: agent scheduler failed with status code' },
    [pscustomobject]@{ Text = "restart-service : service 'cybercnsagent (cybercnsagent)' cannot be stopped"; Label = "Contains: Restart-Service cannot stop CyberCNSAgent" },
    [pscustomobject]@{ Text = 'error publishing message via api, falling back to mqtt'; Label = 'Contains: API publish failed, falling back to MQTT' },
    [pscustomobject]@{ Text = 'error making request for asset last scan time, checking with fall back url'; Label = 'Contains: asset last scan time fallback request error' },

    # --- SECOND-TIER ADDITIONS ---
    [pscustomobject]@{ Text = 'winget upgrade process failed'; Label = 'Contains: Winget upgrade process failed' },
    [pscustomobject]@{ Text = 'local repo download failed, falling back to original url'; Label = 'Contains: local repo download failed, fallback used' },
    [pscustomobject]@{ Text = 'restarting the service due to a query timeout'; Label = 'Contains: restarting service due to query timeout' }

    )

    $lower = $NormalizedLine.ToLowerInvariant(
    )

    foreach ($rule in $GroupPatterns) {
        if ($lower.Contains($rule.Text)) {
            return $rule.Label
        }
    }

    return $NormalizedLine
}

# -----------------------------
# Folder selection (menu option 2)
# -----------------------------
function Select-FolderPath {
    param([string]$InitialPath)
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select folder containing agent logs'
        if ($InitialPath -and (Test-Path -LiteralPath $InitialPath -PathType Container)) { $dialog.SelectedPath = $InitialPath }
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $dialog.SelectedPath) { return $dialog.SelectedPath }
    }
    catch {
        Write-LogWarn "Folder selection dialog unavailable; falling back to manual path entry. $($_.Exception.Message)"
    }
    return (Read-Host "Enter folder path to scan for agent logs (press Enter after making selection)")
}

# -----------------------------
# Show full CSV row (console)
# -----------------------------
function Show-CsvRowDetails {
    param([Parameter(Mandatory = $true)][psobject]$Row)
    foreach ($prop in $Row.PSObject.Properties) {
        $name  = $prop.Name
        $value = $(if ($null -eq $prop.Value) { '' } else { $prop.Value })
        Write-Host ("  {0}: {1}" -f $name, $value)
    }
}

# -----------------------------
# Startup Snapshot (colored)
# -----------------------------
function Show-StartupSnapshot {
    param(
        [string]$LogRoot,
        [int]$LogFileCount,
        [psobject]$IndexMeta,
        [string[]]$CsvColumns,
        [int]$PatternCount
    )

    if ($Global:MsgCorrelatorQuiet) { return }

    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host '  Agent Message Correlator - Startup Snapshot' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''

    Write-Host '[LOG SCAN]' -ForegroundColor Yellow
    Write-Host ("  Root       : {0}" -f $LogRoot) -ForegroundColor Gray
    Write-Host ("  Log Files  : {0}" -f $LogFileCount) -ForegroundColor Gray
    Write-Host ''

    Write-Host '[INDEX]' -ForegroundColor Yellow
    if ($IndexMeta -and $IndexMeta.Exists) {
        $ageTxt = $(if ($IndexMeta.AgeDays -ne $null) { ("{0:N2} day(s)" -f $IndexMeta.AgeDays) } else { 'n/a' })
        Write-Host ("  File       : {0}" -f $IndexMeta.Path) -ForegroundColor Gray
        Write-Host ("  Status     : Present") -ForegroundColor Green
        Write-Host ("  Last Write : {0}" -f $IndexMeta.LastWriteTime) -ForegroundColor Gray
        Write-Host ("  Age        : {0}" -f $ageTxt) -ForegroundColor Gray
    } else {
        $pathTxt = $(if ($IndexMeta) { $IndexMeta.Path } else { '(not set)' })
        Write-Host ("  File       : {0}" -f $pathTxt) -ForegroundColor Gray
        Write-Host ("  Status     : MISSING") -ForegroundColor Red
    }
    Write-Host ''

    Write-Host '[INDEX CONTENT]' -ForegroundColor Yellow
    $colsDisp = $(if ($CsvColumns -and $CsvColumns.Count -gt 0) { ($CsvColumns -join ', ') } else { '(unknown)' })
    Write-Host ("  Columns    : {0}" -f $colsDisp) -ForegroundColor Gray
    Write-Host ("  Patterns   : {0} error pattern(s) prepared" -f $PatternCount) -ForegroundColor Gray
    Write-Host ''
}

# -----------------------------
# Coverage stats for indexed vs unindexed error/failure log lines
# -----------------------------
function Get-IndexedCoverageStats {
    param(
        [Parameter(Mandatory = $true)][System.IO.FileInfo[]]$LogFiles,
        [Parameter(Mandatory = $true)][hashtable]$MatchedKeys,
        [datetime]$WindowStart,
        [datetime]$WindowEnd,
        [switch]$IncludeOlderThanWindowStart
    )

    # $totalEligible is computed later as ($matchedEligible + $unmatchedEligible); no need to initialize here.
    $matchedEligible = 0
    $unmatchedGroups = @{}
    $latestTimestamp = $null

    foreach ($logFile in @($LogFiles)) {
        $lineNumber = 0
        try {
            Get-Content -LiteralPath $logFile.FullName -ErrorAction Stop | ForEach-Object {
                $lineNumber++
                $line = [string]$_
                if ([string]::IsNullOrWhiteSpace($line)) { return }
                if ($line -notmatch $Global:LevelRegex) { return }

                $lineTs = Get-LogLineTimestamp -Line $line

                $includeLine = $true
                if ($WindowStart) {
                    if ($IncludeOlderThanWindowStart) {
                        if (-not $lineTs -or $lineTs -ge $WindowStart) { $includeLine = $false }
                    }
                    else {
                        if (-not $lineTs -or $lineTs -lt $WindowStart) { $includeLine = $false }
                    }
                }
                if ($includeLine -and $WindowEnd) {
                    if (-not $lineTs -or $lineTs -gt $WindowEnd) { $includeLine = $false }
                }
                if (-not $includeLine) { return }

                # Only update latest-timestamp tracker with lines that passed the window filter
                if ($lineTs -and ((-not $latestTimestamp) -or ($lineTs -gt $latestTimestamp))) {
                    $latestTimestamp = $lineTs
                }

                $key = ('{0}|{1}|{2}' -f $logFile.FullName, $lineNumber, $line)
                if ($MatchedKeys.ContainsKey($key)) {
                    $matchedEligible++
                }
                else {
                    $normalizedLine = Normalize-EligibleLogLine -Line $line
                    if ($normalizedLine.Length -gt 0) {
                        $groupName = Get-UnmatchedGroupName -NormalizedLine $normalizedLine
                        if (-not $unmatchedGroups.ContainsKey($groupName)) {
                            $unmatchedGroups[$groupName] = [ordered]@{
                                Count   = 0
                                Details = @{}
                            }
                        }

                        $group = $unmatchedGroups[$groupName]
                        $group.Count = [int]$group.Count + 1

                        if ($group.Details.ContainsKey($normalizedLine)) {
                            $detailEntry = $group.Details[$normalizedLine]
                            $detailEntry.Count = [int]$detailEntry.Count + 1
                            $detailEntry.LastPath = $logFile.FullName
                            $detailEntry.LastLine = $lineNumber
                            if ($lineTs) { $detailEntry.LastTimestamp = $lineTs }
                            $group.Details[$normalizedLine] = $detailEntry
                        }
                        else {
                            $group.Details[$normalizedLine] = [pscustomobject]@{
                                Count         = 1
                                LastPath      = $logFile.FullName
                                LastLine      = $lineNumber
                                LastTimestamp = $lineTs
                            }
                        }
                    }
                }
            }
        }
        catch {
            Write-LogWarn ("Failed to analyze eligible error/failure lines in {0}: {1}" -f $logFile.FullName, $_.Exception.Message)
        }
    }

    $matchedGroupCount = 0
    try {
        $matchedPieMessages = @{}
        foreach ($matchedKey in @($MatchedKeys.Keys)) {
            if (-not $MatchedKeys[$matchedKey]) { continue }
            $matchedEntry = $MatchedKeys[$matchedKey]
            if ($matchedEntry -and $matchedEntry.PSObject.Properties.Name -contains 'CsvRow' -and $matchedEntry.CsvRow) {
                $msgVal = ''
                if ($matchedEntry.CsvRow.PSObject.Properties.Name -contains 'MESSAGE') {
                    $msgVal = [string]$matchedEntry.CsvRow.MESSAGE
                }
                elseif ($matchedEntry.CsvRow.PSObject.Properties.Name -contains 'Message') {
                    $msgVal = [string]$matchedEntry.CsvRow.Message
                }
                if (-not [string]::IsNullOrWhiteSpace($msgVal)) {
                    $matchedPieMessages[$msgVal] = $true
                }
            }
        }
        $matchedGroupCount = [int]$matchedPieMessages.Count
    } catch {
        $matchedGroupCount = 0
    }

    $unmatchedGroupCount = @($unmatchedGroups.Keys).Count
    $rawUnmatchedTotal = (Get-SafeIntSum -Items @($unmatchedGroups.Keys | ForEach-Object { [int]$unmatchedGroups[$_].Count }))
    $unmatchedEligible = $rawUnmatchedTotal
    $totalEligible = $matchedEligible + $unmatchedEligible

    $matchedPercent = 0.0
    $unmatchedPercent = 0.0
    if ($totalEligible -gt 0) {
        $matchedPercent = [Math]::Round((100.0 * $matchedEligible / $totalEligible), 2)
        $unmatchedPercent = [Math]::Round((100.0 * $unmatchedEligible / $totalEligible), 2)
    }

    $matchedGroupPercent = 0.0
    $unmatchedGroupPercent = 0.0
    $groupTotalEligible = $matchedGroupCount + $unmatchedGroupCount
    if ($groupTotalEligible -gt 0) {
        $matchedGroupPercent = [Math]::Round((100.0 * $matchedGroupCount / $groupTotalEligible), 2)
        $unmatchedGroupPercent = [Math]::Round((100.0 * $unmatchedGroupCount / $groupTotalEligible), 2)
    }

    $unmatchedGroupedRows = @(
        foreach ($groupKey in ($unmatchedGroups.Keys | Sort-Object @{ Expression = { [int]$unmatchedGroups[$_].Count } ; Descending = $true }, @{ Expression = { [string]$_ } ; Descending = $false })) {
            $group = $unmatchedGroups[$groupKey]
            $count = [int]$group.Count
            $percentOfTotal = 0.0
            if ($rawUnmatchedTotal -gt 0) {
                $percentOfTotal = [Math]::Round((100.0 * $count / $rawUnmatchedTotal), 2)
            }

            $detailRows = @(
                foreach ($detailKey in ($group.Details.Keys | Sort-Object @{ Expression = { [int]$group.Details[$_].Count } ; Descending = $true }, @{ Expression = { [string]$_ } ; Descending = $false })) {
                    $detailEntry = $group.Details[$detailKey]
                    [pscustomobject]@{
                        Message       = [string]$detailKey
                        Count         = [int]$detailEntry.Count
                        LastPath      = [string]$detailEntry.LastPath
                        LastLine      = [int]$detailEntry.LastLine
                        LastTimestamp = $detailEntry.LastTimestamp
                    }
                }
            )

            $groupLastSeen = $null
try {
    $dated = @($detailRows | Where-Object { $_.LastTimestamp })
    if ($dated.Count -gt 0) {
        $groupLastSeen = @($dated | Sort-Object LastTimestamp)[-1].LastTimestamp
    }
} catch {}
[pscustomobject]@{
    Message        = [string]$groupKey
    Count          = $count
    PercentOfTotal = $percentOfTotal
    Details        = @($detailRows)
    LastSeen       = $groupLastSeen
}
        }
    )

    return [pscustomobject]@{
        TotalEligible         = $totalEligible
        MatchedEligible       = $matchedEligible
        MatchedGroupCount     = $matchedGroupCount
        UnmatchedEligible     = $unmatchedEligible
        UnmatchedGroupCount   = $unmatchedGroupCount
        MatchedPercent        = $matchedPercent
        UnmatchedPercent      = $unmatchedPercent
        MatchedGroupPercent   = $matchedGroupPercent
        UnmatchedGroupPercent = $unmatchedGroupPercent
        UnmatchedGroupedLines = @($unmatchedGroupedRows)
        LatestTimestamp       = $latestTimestamp
    }
}

function Get-AnchorTimestampFromCoverageStats {
    param([psobject[]]$CoverageStatsList)

    $latest = $null
    foreach ($stats in @($CoverageStatsList)) {
        if ($stats -and $stats.LatestTimestamp) {
            if ((-not $latest) -or ($stats.LatestTimestamp -gt $latest)) {
                $latest = $stats.LatestTimestamp
            }
        }
    }
    return $latest
}

function Render-CoveragePanelHtml {
    param(
        [Parameter(Mandatory = $true)][System.Text.StringBuilder]$Builder,
        [Parameter(Mandatory = $true)][string]$Title,
        [Parameter(Mandatory = $true)][psobject]$CoverageStats,
        [string]$Subtitle,
        [psobject]$MatchBreakdown,
        [string]$SectionId
    )

    $matchedGroupsCount = 0
    if ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'MatchedCount') {
        $matchedGroupsCount = [int]$CoverageStats.MatchedCount
    }
    elseif ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'Matches') {
        $matchedGroupsCount = @($CoverageStats.Matches).Count
    }

    $unmatchedGroupsCount = 0
    if ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'UnmatchedCount') {
        $unmatchedGroupsCount = [int]$CoverageStats.UnmatchedCount
    }
    elseif ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'UnmatchedGroupedLines') {
        $unmatchedGroupsCount = @($CoverageStats.UnmatchedGroupedLines).Count
    }

    $matchedOccurrencesCount = 0
    if ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'MatchedEligible') {
        $matchedOccurrencesCount = [int]$CoverageStats.MatchedEligible
    }
    elseif ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'Matches') {
        $matchedOccurrencesCount = (Get-SafeIntSum -Items @($CoverageStats.Matches) -PropertyName 'PieFrequency')
        if ($matchedOccurrencesCount -lt 0) { $matchedOccurrencesCount = 0 }
    }

    $unmatchedOccurrencesCount = 0
    if ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'UnmatchedEligible') {
        $unmatchedOccurrencesCount = [int]$CoverageStats.UnmatchedEligible
    }
    elseif ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'UnmatchedGroupedLines') {
        $unmatchedOccurrencesCount = (Get-SafeIntSum -Items @($CoverageStats.UnmatchedGroupedLines) -PropertyName 'Count')
        if ($unmatchedOccurrencesCount -lt 0) { $unmatchedOccurrencesCount = 0 }
    }

    $recomputedGroupTotal = $matchedGroupsCount + $unmatchedGroupsCount
    $recomputedOccurrenceTotal = $matchedOccurrencesCount + $unmatchedOccurrencesCount


    if (-not $CoverageStats) {
        $CoverageStats = [pscustomobject]@{
            TotalEligible         = 0
            MatchedEligible       = 0
            MatchedGroupCount     = 0
            UnmatchedEligible     = 0
            UnmatchedGroupCount   = 0
            MatchedPercent        = 0
            UnmatchedPercent      = 0
            MatchedGroupPercent   = 0
            UnmatchedGroupPercent = 0
            UnmatchedGroupedLines = @()
        }
    }
    if (-not $MatchBreakdown) {
        $MatchBreakdown = [pscustomobject]@{
            EligibleMatchedInChart = [int]$CoverageStats.MatchedEligible
            MatchedGroupsInChart = 0
            InformationalOrOtherMatched = 0
            OtherRowsShownInTables = 0
            OverlappingOrDuplicateMatched = 0
            NonPieInsideCountedOrMixedRows = 0
            TotalMatchedShownInTables = [int]$CoverageStats.MatchedEligible
        }
    }

    $groupMatchedCount = 0
    if ($MatchBreakdown -and $MatchBreakdown.PSObject.Properties.Name -contains 'MatchedGroupsInChart') {
        $groupMatchedCount = [int]$MatchBreakdown.MatchedGroupsInChart
    }
    elseif ($CoverageStats.PSObject.Properties.Name -contains 'MatchedGroupCount') {
        $groupMatchedCount = [int]$CoverageStats.MatchedGroupCount
    }
    else {
        $groupMatchedCount = [int]$CoverageStats.MatchedEligible
    }

    $groupUnmatchedCount = 0
    if ($CoverageStats -and $CoverageStats.PSObject.Properties.Name -contains 'UnmatchedGroupCount') {
        $groupUnmatchedCount = [int]$CoverageStats.UnmatchedGroupCount
    }
    $groupTotalCount = $groupMatchedCount + $groupUnmatchedCount
    $groupMatchedPctValue = 0.0
    $groupUnmatchedPctValue = 0.0
    if ($groupTotalCount -gt 0) {
        $groupMatchedPctValue = [Math]::Round((100.0 * $groupMatchedCount / $groupTotalCount), 2)
        $groupUnmatchedPctValue = [Math]::Round((100.0 * $groupUnmatchedCount / $groupTotalCount), 2)
    }

    $groupMatchedPctText = ('{0:N2}' -f ([double]$groupMatchedPctValue))
    $groupUnmatchedPctText = ('{0:N2}' -f ([double]$groupUnmatchedPctValue))
    $groupMatchedDeg = [Math]::Round((360.0 * [double]$groupMatchedPctValue / 100.0), 2)
    $groupStyle = ('background:conic-gradient(#2e7d32 0deg, #2e7d32 {0}deg, #d32f2f {0}deg, #d32f2f 360deg);' -f $groupMatchedDeg)

    $occMatchedCount = [int]$CoverageStats.MatchedEligible
    if ($MatchBreakdown -and $MatchBreakdown.PSObject.Properties.Name -contains 'EligibleMatchedInChart') {
        $occMatchedCount = [int]$MatchBreakdown.EligibleMatchedInChart
    }
    $occUnmatchedCount = [int]$CoverageStats.UnmatchedEligible
    $occTotalCount = $occMatchedCount + $occUnmatchedCount
    $occMatchedPctValue = 0.0
    $occUnmatchedPctValue = 0.0
    if ($occTotalCount -gt 0) {
        $occMatchedPctValue = [Math]::Round((100.0 * $occMatchedCount / $occTotalCount), 2)
        $occUnmatchedPctValue = [Math]::Round((100.0 * $occUnmatchedCount / $occTotalCount), 2)
    }

    $occMatchedPctText = ('{0:N2}' -f ([double]$occMatchedPctValue))
    $occUnmatchedPctText = ('{0:N2}' -f ([double]$occUnmatchedPctValue))
    $occMatchedDeg = [Math]::Round((360.0 * [double]$occMatchedPctValue / 100.0), 2)
    $occStyle = ('background:conic-gradient(#2e7d32 0deg, #2e7d32 {0}deg, #d32f2f {0}deg, #d32f2f 360deg);' -f $occMatchedDeg)

    $idAttr = ''
    if (-not [string]::IsNullOrWhiteSpace($SectionId)) { $idAttr = ' id="' + (HtmlEscape $SectionId) + '"' }

    $matchAnchor = ''
    $unmatchedAnchor = ''
    $topUnknownAnchor = ''
    if ($SectionId -eq 'summary-72h') {
        $matchAnchor = '#recent-matches'
        $unmatchedAnchor = '#recent-unmatched'
        $topUnknownAnchor = '#top-errors'
    }
    elseif ($SectionId -eq 'summary-older') {
        $matchAnchor = '#older-matches'
        $unmatchedAnchor = '#older-unmatched'
        $topUnknownAnchor = '#older-top-errors'
    }

    [void]$Builder.AppendLine('<div class="section"' + $idAttr + '>')
    [void]$Builder.AppendLine('<h2>' + (HtmlEscape $Title) + '</h2>')
    if (-not [string]::IsNullOrWhiteSpace($Subtitle)) {
        [void]$Builder.AppendLine('<div class="small">' + (HtmlEscape $Subtitle) + '</div>')
    }
    [void]$Builder.AppendLine('<div class="small" style="margin-top:8px;">What these numbers mean:</div>')
    [void]$Builder.AppendLine('<ul class="note-list">')
    [void]$Builder.AppendLine('<li><b>Group view</b> compares indexed matched groups against the number of unmatched groups.</li>')
    [void]$Builder.AppendLine('<li><b>Occurrence view</b> compares indexed matched lines against the total count of unmatched messages.</li>')
    [void]$Builder.AppendLine('<li><b>Other matched lines shown below</b> = matched lines that appear in the match tables but are not counted in either pie.</li>')
    [void]$Builder.AppendLine('</ul>')

    [void]$Builder.AppendLine('<div class="coverage-wrap" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(320px,100%),1fr));gap:18px;align-items:start;width:100%;max-width:100%;box-sizing:border-box;">')

    # Group-based pie
    [void]$Builder.AppendLine('<div class="section" style="margin:0;">')
    [void]$Builder.AppendLine('<h3 style="margin-top:0;">Group View</h3>')
    [void]$Builder.AppendLine('<div class="small">Matched groups vs unmatched groups.</div>')
    [void]$Builder.AppendLine('<div class="pie-wrap">')
    [void]$Builder.AppendLine('<div class="pie-chart" style="' + $groupStyle + '"><div class="pie-hole">' + (HtmlEscape $groupMatchedPctText) + '%<br><span style="font-size:11px;font-weight:600;color:#666;">Indexed</span></div></div>')
    [void]$Builder.AppendLine('<div class="legend">')
    [void]$Builder.AppendLine('<div class="legend-item"><span class="legend-swatch swatch-matched"></span><span>Indexed / matched groups (' + (HtmlEscape ([string]$groupMatchedCount)) + ')</span></div>')
    [void]$Builder.AppendLine('<div class="legend-item"><span class="legend-swatch swatch-unmatched"></span><span>Not indexed / unmatched groups (' + (HtmlEscape ([string]$groupUnmatchedCount)) + ')</span></div>')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('<div class="coverage-stats">')
    [void]$Builder.AppendLine('' + $(if ($matchAnchor) { '<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="' + $matchAnchor + '">' } else { '<div class="stat-card">' }) + '<div class="stat-label">Indexed / matched groups</div><div class="stat-value">' + (HtmlEscape ([string]$groupMatchedCount)) + '</div>' + $(if ($matchAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('' + $(if ($topUnknownAnchor) { '<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="' + $topUnknownAnchor + '">' } else { '<div class="stat-card">' }) + '<div class="stat-label">Not indexed / unmatched groups</div><div class="stat-value">' + (HtmlEscape ([string]$groupUnmatchedCount)) + '</div>' + $(if ($topUnknownAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="#recent-matches" data-target-id="recent-matches"><div class="stat-label">Matched percent (group view)</div><div class="stat-value">' + (HtmlEscape $groupMatchedPctText) + '%</div></a>')
    [void]$Builder.AppendLine('<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="#recent-unmatched" data-target-id="recent-unmatched"><div class="stat-label">Unmatched percent (group view)</div><div class="stat-value">' + (HtmlEscape $groupUnmatchedPctText) + '%</div></a>')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('</div>')

    # Occurrence-based pie
    [void]$Builder.AppendLine('<div class="section" style="margin:0;">')
    [void]$Builder.AppendLine('<h3 style="margin-top:0;">Occurrence View</h3>')
    [void]$Builder.AppendLine('<div class="small">Matched occurrences vs total unmatched messages.</div>')
    [void]$Builder.AppendLine('<div class="pie-wrap">')
    [void]$Builder.AppendLine('<div class="pie-chart" style="' + $occStyle + '"><div class="pie-hole">' + (HtmlEscape $occMatchedPctText) + '%<br><span style="font-size:11px;font-weight:600;color:#666;">Indexed</span></div></div>')
    [void]$Builder.AppendLine('<div class="legend">')
    [void]$Builder.AppendLine('<div class="legend-item"><span class="legend-swatch swatch-matched"></span><span>Indexed / matched occurrences (' + (HtmlEscape ([string]$occMatchedCount)) + ')</span></div>')
    [void]$Builder.AppendLine('<div class="legend-item"><span class="legend-swatch swatch-unmatched"></span><span>Total unmatched messages (' + (HtmlEscape ([string]$CoverageStats.UnmatchedEligible)) + ')</span></div>')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('<div class="coverage-stats">')
    [void]$Builder.AppendLine('' + $(if ($matchAnchor) { '<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="' + $matchAnchor + '">' } else { '<div class="stat-card">' }) + '<div class="stat-label">Indexed / matched occurrences</div><div class="stat-value">' + (HtmlEscape ([string]$occMatchedCount)) + '</div>' + $(if ($matchAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('' + $(if ($unmatchedAnchor) { '<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="' + $unmatchedAnchor + '">' } else { '<div class="stat-card">' }) + '<div class="stat-label">Total unmatched messages</div><div class="stat-value">' + (HtmlEscape ([string]$occUnmatchedCount)) + '</div>' + $(if ($unmatchedAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="#recent-matches" data-target-id="recent-matches"><div class="stat-label">Matched percent (occurrence view)</div><div class="stat-value">' + (HtmlEscape $occMatchedPctText) + '%</div></a>')
    [void]$Builder.AppendLine('<a class="stat-card clickable-tile js-tile-hover" data-hint="Click for details" href="#recent-unmatched" data-target-id="recent-unmatched"><div class="stat-label">Unmatched percent (occurrence view)</div><div class="stat-value">' + (HtmlEscape $occUnmatchedPctText) + '%</div></a>')
    [void]$Builder.AppendLine('' + $(if ($matchAnchor) { '<a class="stat-card stat-card-sm clickable-tile js-tile-hover" href="' + $matchAnchor + '" data-hint="Click for details">' } else { '<div class="stat-card stat-card-sm">' }) + '<div class="stat-label">Other matched informational lines</div><div class="stat-value">' + (HtmlEscape ([string]$MatchBreakdown.InformationalOrOtherMatched)) + '</div>' + $(if ($matchAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('' + $(if ($matchAnchor) { '<a class="stat-card stat-card-sm clickable-tile js-tile-hover" href="' + $matchAnchor + '" data-hint="Click for details">' } else { '<div class="stat-card stat-card-sm">' }) + '<div class="stat-label">Total matched lines in tables</div><div class="stat-value">' + (HtmlEscape ([string]$MatchBreakdown.TotalMatchedShownInTables)) + '</div>' + $(if ($matchAnchor) { '</a>' } else { '</div>' }) + '')
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('</div>')

    [void]$Builder.AppendLine('</div>')
}

function Render-TopFrequentErrorsHtml {
    param(
        [Parameter(Mandatory = $true)][System.Text.StringBuilder]$Builder,
        [object[]]$GroupedLines = @(),
        [string]$Title = 'Top 3 Unknown',
        [string]$SectionId = 'top-errors',
        [string]$Subtitle,
        [int]$TotalMessagesDenominator = 0
    )

    $topRows = @($GroupedLines | Select-Object -First 3)

    $idAttr = ''
    if (-not [string]::IsNullOrWhiteSpace($SectionId)) { $idAttr = ' id="' + (HtmlEscape $SectionId) + '"' }

    [void]$Builder.AppendLine('<div class="section"' + $idAttr + '>')
    [void]$Builder.AppendLine('<h2>' + (HtmlEscape $Title) + '</h2>')
    if (-not [string]::IsNullOrWhiteSpace($Subtitle)) {
        [void]$Builder.AppendLine('<div class="small">' + (HtmlEscape $Subtitle) + '</div>')
    }

    if ($topRows.Count -eq 0) {
        [void]$Builder.AppendLine('<p>No unknown groups available to highlight.</p>')
        [void]$Builder.AppendLine('</div>')
        return
    }

    [void]$Builder.AppendLine('<div class="top-errors-grid">')
    $rank = 0
    $rawUnmatchedTotal = (Get-SafeIntSum -Items @($GroupedLines) -PropertyName 'Count')
    if ($rawUnmatchedTotal -lt 0) { $rawUnmatchedTotal = 0 }

    $topLastSeenTicks = @()
    foreach ($topRow in @($topRows)) {
        $tmpLastSeen = $null
        if ($topRow.LastSeen) { $tmpLastSeen = $topRow.LastSeen }
        elseif ($topRow.Details) {
            try {
                $dated = @(@($topRow.Details) | Where-Object { $_ -and $_.PSObject.Properties.Name -contains 'LastTimestamp' -and $_.LastTimestamp })
                if ($dated.Count -gt 0) { $tmpLastSeen = @($dated | Sort-Object LastTimestamp)[-1].LastTimestamp }
            } catch {}
        }
        if ($tmpLastSeen -and $tmpLastSeen -is [datetime]) {
            $topLastSeenTicks += [int64]$tmpLastSeen.Ticks
        }
    }
    $topMinTicks = $null
    $topMaxTicks = $null
    if ($topLastSeenTicks.Count -gt 0) {
        $topMinTicks = ($topLastSeenTicks | Measure-Object -Minimum).Minimum
        $topMaxTicks = ($topLastSeenTicks | Measure-Object -Maximum).Maximum
    }

    $totalMessages = [int]$TotalMessagesDenominator
    if ($totalMessages -le 0) { $totalMessages = $rawUnmatchedTotal }
    if ($totalMessages -lt 0) { $totalMessages = 0 }

    foreach ($row in $topRows) {
        $rank++
        $lastSeenText = 'N/A'
$topLastSeen = $null
if ($row.LastSeen) { $topLastSeen = $row.LastSeen }
elseif ($row.Details) {
    $dated = @($row.Details | Where-Object { $_.LastTimestamp })
    if ($dated.Count -gt 0) {
        $topLastSeen = @($dated | Sort-Object LastTimestamp)[-1].LastTimestamp
    }
}
if ($topLastSeen) {
    $lastSeenText = $topLastSeen.ToString('yyyy-MM-dd HH:mm:ss')
}
        if ($row.PSObject.Properties.Name -contains 'LastSeen' -and $row.LastSeen) {
            try {
                if ($row.LastSeen -is [datetime]) {
                    $lastSeenText = $row.LastSeen.ToString('yyyy-MM-dd HH:mm:ss')
                }
                else {
                    $lastSeenText = [string]$row.LastSeen
                }
            }
            catch {
                $lastSeenText = [string]$row.LastSeen
            }
        }

        $percentOfUnmatchedText = (HtmlEscape ('{0:N2}' -f ([double]$row.PercentOfTotal))) + '%'
        $percentOfTotalMessages = 0.0
        if ($totalMessages -gt 0) {
            $percentOfTotalMessages = ([double]$row.Count / [double]$totalMessages) * 100.0
        }
        $percentOfTotalText = (HtmlEscape ('{0:N2}' -f $percentOfTotalMessages)) + '%'

        $topTargetId = ''
        if (-not [string]::IsNullOrWhiteSpace($SectionId)) {
            $detailSectionTarget = ''
            if ($SectionId -eq 'top-errors') { $detailSectionTarget = 'recent-unmatched-detail-' + ([Math]::Abs(([string]$row.Message).GetHashCode())) }
            elseif ($SectionId -eq 'older-top-errors') { $detailSectionTarget = 'older-unmatched-detail-' + ([Math]::Abs(([string]$row.Message).GetHashCode())) }
            else { $detailSectionTarget = $SectionId + '-detail-' + ([Math]::Abs(([string]$row.Message).GetHashCode())) }
            $topTargetId = $detailSectionTarget
        }
        [void]$Builder.AppendLine('<a class="top-error-card clickable-tile js-tile-hover rank-' + $rank + '" href="#' + (HtmlEscape $topTargetId) + '" data-target-id="' + (HtmlEscape $topTargetId) + '" data-hint="Click for details">')
        [void]$Builder.AppendLine('<div class="top-error-rank">Top ' + $rank + '</div>')
        [void]$Builder.AppendLine('<div class="top-error-msg">' + (HtmlEscape ([string]$row.Message)) + '</div>')
        $topLastSeenClass = ''
        if ($topLastSeen -and $topLastSeen -is [datetime]) {
            $topLastSeenClass = Get-DateAgeClass -Dt $topLastSeen -MinTicks $topMinTicks -MaxTicks $topMaxTicks
        }
        [void]$Builder.AppendLine('<div class="top-error-metrics"><span><b>Count:</b> ' + (HtmlEscape ([string]$row.Count)) + '</span><span><b>% of unmatched occurrences:</b> ' + $percentOfUnmatchedText + '</span><span><b>% of total messages:</b> ' + $percentOfTotalText + '</span><span class="top-lastseen ' + (HtmlEscape $topLastSeenClass) + '"><b>Last Seen:</b> ' + (HtmlEscape $lastSeenText) + '</span></div>')
        [void]$Builder.AppendLine('</a>')
    }
    [void]$Builder.AppendLine('</div>')
    [void]$Builder.AppendLine('</div>')
}


function ConvertTo-MailtoEncoded {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    try { return [uri]::EscapeDataString([string]$Text) } catch { return [string]$Text }
}

function Render-UnmatchedGroupsHtml {
    param(
        [Parameter(Mandatory = $true)][System.Text.StringBuilder]$Builder,
        [object[]]$GroupedLines = @(),
        [Parameter(Mandatory = $true)][string]$Title,
        [string]$SectionId,
        [int]$TotalMessagesDenominator = 0,
        [hashtable]$ComparisonLookup = @{},
        [int]$ComparisonDenominator = 0,
        [int]$ComparisonTotal = 0,
        [string]$ComparisonLabel = '% of All Time Coverage',
        [int]$OccurrenceDenominator = 0
    )

    $AgentSummaryFromLogsLocal = $null
    try { $AgentSummaryFromLogsLocal = $script:AgentSummaryFromLogs } catch { $AgentSummaryFromLogsLocal = $null }

    
    $minLastSeenTicks = $null
    $maxLastSeenTicks = $null

    $resolvedLastSeenTicks = @()
    foreach ($gl in @($GroupedLines)) {
        $resolvedLastSeen = $null
        if ($gl -and $gl.PSObject.Properties.Name -contains 'LastSeen' -and $gl.LastSeen) {
            $resolvedLastSeen = $gl.LastSeen
        }
        elseif ($gl -and $gl.PSObject.Properties.Name -contains 'Details') {
            try {
                $datedDetails = @(@($gl.Details) | Where-Object { $_ -and $_.PSObject.Properties.Name -contains 'LastTimestamp' -and $_.LastTimestamp })
                if ($datedDetails.Count -gt 0) {
                    $resolvedLastSeen = @($datedDetails | Sort-Object LastTimestamp)[-1].LastTimestamp
                }
            } catch {}
        }
        if ($resolvedLastSeen -and $resolvedLastSeen -is [datetime]) {
            $resolvedLastSeenTicks += [int64]$resolvedLastSeen.Ticks
        }
    }
    if ($resolvedLastSeenTicks.Count -gt 0) {
        $minLastSeenTicks = ($resolvedLastSeenTicks | Measure-Object -Minimum).Minimum
        $maxLastSeenTicks = ($resolvedLastSeenTicks | Measure-Object -Maximum).Maximum
    }

$sectionOpen = $(if ($SectionId -and $SectionId -like 'older-*') { $false } else { $true })
    if ($SectionId -and $SectionId -like 'older-*') {
        [void]$Builder.AppendLine('<details class="section section-collapsible" id="' + (HtmlEscape $SectionId) + '">')
    [void]$Builder.AppendLine('<summary><h2>' + (HtmlEscape $Title) + '</h2><span class="collapse-hint">Click to expand/collapse</span></summary>')
    }
    else {
        $idAttr = ''
        if (-not [string]::IsNullOrWhiteSpace($SectionId)) { $idAttr = ' id="' + (HtmlEscape $SectionId) + '"' }
        [void]$Builder.AppendLine('<div class="section"' + $idAttr + '>')
    [void]$Builder.AppendLine('<h2>' + (HtmlEscape $Title) + '</h2>')
        [void]$Builder.AppendLine('<div class="small" style="margin:6px 0 10px;">To submit a new unknown error, use the Email Support link beside the unknown name. It opens Outlook or your default mail app to send details to support@connectsecure.com.</div>')
        if ($Title -eq 'Last 72 Hours - Matches') {
            [void]$Builder.AppendLine('<div class="small" style="margin:6px 0 8px;">Other (Info) reason tags are based on actual matched line classification:</div>')
    [void]$Builder.AppendLine('<ul class="note-list">')
    [void]$Builder.AppendLine('<li>Status / heartbeat messages</li>')
    [void]$Builder.AppendLine('<li>Successful operations</li>')
    [void]$Builder.AppendLine('<li>Expected transient retries / checks</li>')
    [void]$Builder.AppendLine('<li>Debug / verbose logging</li>')
    [void]$Builder.AppendLine('<li>Operational / informational lines</li>')
    [void]$Builder.AppendLine('</ul>')
        }
    }
    if (@($GroupedLines).Count -gt 0) {
                $rawUnmatchedTotal = (Get-SafeIntSum -Items @($GroupedLines) -PropertyName 'Count')
        $totalMessagesDenominatorLocal = [int]$TotalMessagesDenominator
    if ($totalMessagesDenominatorLocal -le 0) { $totalMessagesDenominatorLocal = $rawUnmatchedTotal }
    if ($totalMessagesDenominatorLocal -lt 0) { $totalMessagesDenominatorLocal = 0 }

    $unmatchedPrimaryLabel = '% of Unmatched Occurrences'
    if ($Title -like 'Anything Older / 72hr+*') {
        $unmatchedPrimaryLabel = '% of 72hr+ Coverage'
    }
    [void]$Builder.AppendLine('<table><thead><tr><th>Unmatched Message</th><th>Count</th><th>' + (HtmlEscape $unmatchedPrimaryLabel) + '</th><th>' + (HtmlEscape $ComparisonLabel) + '</th><th>Last Seen</th></tr></thead><tbody>')
        foreach ($groupRow in @($GroupedLines)) {
            $messageCell = HtmlEscape ([string]$groupRow.Message)
            $detailsRows = @($groupRow.Details)
            if ($detailsRows.Count -gt 0) {
                $detailBlockId = ''
                if (-not [string]::IsNullOrWhiteSpace($SectionId)) {
                    $detailBlockId = $SectionId + '-detail-' + ([Math]::Abs(([string]$groupRow.Message).GetHashCode()))
                }
                $detailSb = New-Object System.Text.StringBuilder
                [void]$detailSb.Append('<details class="unmatched-details"' + $(if ($detailBlockId) { ' id="' + (HtmlEscape $detailBlockId) + '"' } else { '' }) + '><summary>View grouped lines (' + (HtmlEscape ([string]$detailsRows.Count)) + ')</summary><ul class="unmatched-sublist">')
                foreach ($detailRow in $detailsRows) {
                    $detailMessage = HtmlEscape ([string]$detailRow.Message)
                    $detailCount = HtmlEscape ([string]$detailRow.Count)
                    [void]$detailSb.Append('<li><span>' + $detailMessage + '</span> <span class="small">(' + $detailCount + ')</span>')

                    if (-not [string]::IsNullOrWhiteSpace([string]$detailRow.LastPath) -and ([int]$detailRow.LastLine -gt 0)) {
                        $snippet = Get-LogContextSnippet -Cache $script:HtmlContextCache -Path ([string]$detailRow.LastPath) -LineNumber ([int]$detailRow.LastLine) -Before 5 -After 5
                        $exampleSb = New-Object System.Text.StringBuilder
                        [void]$exampleSb.Append('<details class="unmatched-example"><summary>Last example with 5 lines above and 5 below</summary>')
                        [void]$exampleSb.Append('<div class="unmatched-example-title">')
                        [void]$exampleSb.Append((HtmlEscape ([string]$snippet.Path)))
                        [void]$exampleSb.Append(' &mdash; line ' + (HtmlEscape ([string]$snippet.MatchLine)))
                        if ($detailRow.LastTimestamp) {
                            [void]$exampleSb.Append(' &mdash; ' + (HtmlEscape ($detailRow.LastTimestamp.ToString('yyyy-MM-dd HH:mm:ss'))))
                        }
                        [void]$exampleSb.Append('</div>')
                        [void]$exampleSb.Append('<pre class="unmatched-context">')
                        foreach ($ctxLine in @($snippet.Lines)) {
                            $prefix = ('{0,6}: ' -f ([int]$ctxLine.LineNumber))
                            $ctxText = HtmlEscape ($prefix + [string]$ctxLine.Text)
                            if ($ctxLine.IsMatch) {
                                [void]$exampleSb.Append('<span class="hit">' + $ctxText + '</span>')
                            }
                            else {
                                [void]$exampleSb.Append('<span class="ctx">' + $ctxText + '</span>')
                            }
                        }
                        [void]$exampleSb.Append('</pre></details>')
                        [void]$detailSb.Append($exampleSb.ToString())
                    }

                    [void]$detailSb.Append('</li>')
                }
                [void]$detailSb.Append('</ul></details>')
                $messageCell = $messageCell + $detailSb.ToString()
            }

            $hoverPreviewSb = New-Object System.Text.StringBuilder
            [void]$hoverPreviewSb.Append('<div class="hover-details-title">Grouped Details</div>')
            [void]$hoverPreviewSb.Append('<div style="font-weight:600;margin-bottom:8px;">' + (HtmlEscape ([string]$groupRow.Message)) + '</div>')
            if (@($detailsRows).Count -gt 0) {
                [void]$hoverPreviewSb.Append('<ul class="unmatched-sublist">')
                $hoverDetailCount = 0
                foreach ($detailRow in @($detailsRows)) {
                    $hoverDetailCount++
                    if ($hoverDetailCount -gt 6) { break }
                    [void]$hoverPreviewSb.Append('<li><span>' + (HtmlEscape ([string]$detailRow.Message)) + '</span> <span class="small">(' + (HtmlEscape ([string]$detailRow.Count)) + ')</span></li>')
                }
                [void]$hoverPreviewSb.Append('</ul>')
            }
            else {
                [void]$hoverPreviewSb.Append('<div class="small">No grouped details available for this row.</div>')
            }
            $hoverPreviewHtml = $hoverPreviewSb.ToString()

            $rowClass = ''
            $resolvedGroupLastSeen = $null
            if ($groupRow.PSObject.Properties.Name -contains 'LastSeen' -and $groupRow.LastSeen) {
                $resolvedGroupLastSeen = $groupRow.LastSeen
            }
            elseif ($groupRow.PSObject.Properties.Name -contains 'Details') {
                try {
                    $datedDetails = @(@($groupRow.Details) | Where-Object { $_ -and $_.PSObject.Properties.Name -contains 'LastTimestamp' -and $_.LastTimestamp })
                    if ($datedDetails.Count -gt 0) {
                        $resolvedGroupLastSeen = @($datedDetails | Sort-Object LastTimestamp)[-1].LastTimestamp
                    }
                } catch {}
            }
            $lastSeenText = $(if ($resolvedGroupLastSeen) { $resolvedGroupLastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { '' })
            $lastSeenClass = $(if ($resolvedGroupLastSeen) { Get-DateAgeClass -Dt $resolvedGroupLastSeen -MinTicks $minLastSeenTicks -MaxTicks $maxLastSeenTicks } else { '' })
            if ($script:HtmlTopGroupRanks -and $script:HtmlTopGroupRanks.ContainsKey([string]$groupRow.Message)) {
                $rowClass = ' class="top-rank-' + [string]$script:HtmlTopGroupRanks[[string]$groupRow.Message] + '"'
            }
            $sectionPct = 0.0
            if ($rawUnmatchedTotal -gt 0) {
                $sectionPct = [Math]::Round((100.0 * [double]$groupRow.Count / [double]$rawUnmatchedTotal), 2)
            }
            $totalPct = $null
            if ($ComparisonDenominator -gt 0 -and $ComparisonLookup -and $ComparisonLookup.ContainsKey([string]$groupRow.Message)) {
                $comparisonRow = $ComparisonLookup[[string]$groupRow.Message]
                if ($comparisonRow -and $comparisonRow.PSObject.Properties.Name -contains 'Count' -and [int]$comparisonRow.Count -gt 0) {
                    $totalPct = [Math]::Round((100.0 * [double]$comparisonRow.Count / [double]$ComparisonDenominator), 2)
                }
            }
            elseif ($totalMessagesDenominatorLocal -gt 0) {
                $totalPct = [Math]::Round((100.0 * [double]$groupRow.Count / [double]$totalMessagesDenominatorLocal), 2)
            }

            $totalPctText = ''
            if ($totalPct -ne $null) {
                $totalPctText = ('{0:N2}' -f $totalPct)
            }

            $bodyLines = @()
            $bodyLines += 'Support,

A new unknown message has been submitted to be documented. Symptoms, message, info, reference ticket, and URL should be supplied and updated in the message correlator when this information can be collected and published. '
            $bodyLines += ''

            if ($AgentSummaryFromLogs) {
                $bodyLines += 'Agent Info'
                $bodyLines += ('Hostname: ' + [string]$AgentSummaryFromLogs.Hostname)
                $bodyLines += ('IP: ' + [string]$AgentSummaryFromLogs.IP)
                $bodyLines += ('MAC: ' + [string]$AgentSummaryFromLogs.MAC)
                $bodyLines += ('Agent Version: ' + [string]$AgentSummaryFromLogs.AgentVersion)
                $bodyLines += ('Agent ID: ' + [string]$AgentSummaryFromLogs.AgentID)
                $bodyLines += ('Tenant ID: ' + [string]$AgentSummaryFromLogs.TenantID)
                $bodyLines += ('Company ID: ' + [string]$AgentSummaryFromLogs.CompanyID)
                $bodyLines += ('Agent Type: ' + [string]$AgentSummaryFromLogs.AgentType)
                $bodyLines += ('PODID: ' + [string]$AgentSummaryFromLogs.PODID)
                if ($AgentSummaryFromLogs.SourceFile) {
                    $bodyLines += ('Source File: ' + [string]$AgentSummaryFromLogsLocal.SourceFile)
                }
                $bodyLines += ''
            }

            $timeBucketLabel = 'Unknown time bucket'
            if ($SectionId -eq 'recent-unmatched' -or $Title -like 'Last 72 Hours*') {
                $timeBucketLabel = 'Last 72 Hours'
            }
            elseif ($SectionId -eq 'older-unmatched' -or $Title -like 'Anything Older*' -or $Title -like '*72hr+*') {
                $timeBucketLabel = '72hr+'
            }

            $bodyLines += ('Time Bucket: ' + $timeBucketLabel)
            $bodyLines += ('Error Name: ' + [string]$groupRow.Message)
            $bodyLines += ('Count: ' + [string]$groupRow.Count)
            $bodyLines += ('% of Unmatched Occurrences: ' + ('{0:N2}%%' -f $sectionPct))
            $bodyLines += (([string]$ComparisonLabel).Trim() + ': ' + $(if ($totalPctText) { $totalPctText + '%%' } else { '' }))
            if (-not [string]::IsNullOrWhiteSpace($lastSeenText)) {
                $bodyLines += ('Last Seen: ' + $lastSeenText)
            }
            if ($detailsRows.Count -gt 0) {
                $latestDetail = @($detailsRows | Select-Object -Last 1)[0]
                if ($latestDetail) {
                    if ($latestDetail.LastPath) { $bodyLines += ('File: ' + [string]$latestDetail.LastPath) }
                    if ($latestDetail.LastLine) { $bodyLines += ('Line Number: ' + [string]$latestDetail.LastLine) }
                    if ($latestDetail.LastTimestamp) { $bodyLines += ('Example Timestamp: ' + $latestDetail.LastTimestamp.ToString('yyyy-MM-dd HH:mm:ss')) }
                    if ($latestDetail.Message) {
                        $bodyLines += ''
                        $bodyLines += 'Detail:'
                        $bodyLines += ([string]$latestDetail.Message)
                    }

                    if (-not [string]::IsNullOrWhiteSpace([string]$latestDetail.LastPath) -and ([int]$latestDetail.LastLine -gt 0)) {
                        $emailSnippet = Get-LogContextSnippet -Cache $script:HtmlContextCache -Path ([string]$latestDetail.LastPath) -LineNumber ([int]$latestDetail.LastLine) -Before 10 -After 10
                        if ($emailSnippet -and @($emailSnippet.Lines).Count -gt 0) {
                            $bodyLines += ''
                            $bodyLines += '10 lines above / 10 lines below snippet:'
                            foreach ($snippetLine in @($emailSnippet.Lines)) {
                                $snippetPrefix = ('{0,6}: ' -f ([int]$snippetLine.LineNumber))
                                $snippetText = [string]$snippetLine.Text
                                if ($snippetLine.IsMatch) {
                                    $bodyLines += ($snippetPrefix + '>> ' + $snippetText)
                                }
                                else {
                                    $bodyLines += ($snippetPrefix + '   ' + $snippetText)
                                }
                            }
                        }
                    }
                }
            }
            $mailtoSubject = ConvertTo-MailtoEncoded ('Error Submission - ' + [string]$groupRow.Message)
            $mailtoBody = ConvertTo-MailtoEncoded (($bodyLines -join [Environment]::NewLine))
            $emailLink = '<a href="mailto:support@connectsecure.com?subject=' + $mailtoSubject + '&body=' + $mailtoBody + '">Email Support</a>'

            $rowTargetAttr = ''
            if (-not [string]::IsNullOrWhiteSpace($SectionId)) {
                $rowTargetAttr = ' data-target-id="' + (HtmlEscape ($SectionId + '-detail-' + ([Math]::Abs(([string]$groupRow.Message).GetHashCode())))) + '"'
            }
            [void]$Builder.AppendLine('<tr class="hover-preview-row' + $(if ($rowClass) { ' ' + (($rowClass -replace '^ class="','') -replace '"$','') } else { '' }) + '"' + $rowTargetAttr + '><td>' + $messageCell + '<div class="small" style="margin-top:4px;">' + $emailLink + '</div><div class="hover-preview-source">' + $hoverPreviewHtml + '</div></td><td>' + (HtmlEscape ([string]$groupRow.Count)) + '</td><td>' + (HtmlEscape ('{0:N2}' -f $sectionPct)) + '%</td><td>' + (HtmlEscape $totalPctText) + $(if ($totalPctText) { '%' } else { '' }) + '</td><td class="' + $lastSeenClass + '">' + (HtmlEscape $lastSeenText) + '</td></tr>')
        }
        $footerSectionPctText = $(if ($rawUnmatchedTotal -gt 0) { '100.00%' } else { '0.00%' })
        if ($OccurrenceDenominator -gt 0) {
            $footerSectionPctText = ('{0:N2}%' -f (([double]$rawUnmatchedTotal / [double]$OccurrenceDenominator) * 100.0))
        }

        $totalMessagesPctText = '0.00%'
        if ($ComparisonDenominator -gt 0 -and $ComparisonTotal -ge 0) {
            $totalMessagesPctText = ('{0:N2}%' -f (([double]$ComparisonTotal / [double]$ComparisonDenominator) * 100.0))
        }
        elseif ($totalMessagesDenominatorLocal -gt 0) {
            $totalMessagesPctText = ('{0:N2}%' -f (([double]$rawUnmatchedTotal / [double]$totalMessagesDenominatorLocal) * 100.0))
        }
        [void]$Builder.AppendLine('</tbody><tfoot><tr><th>Total</th><th>' + (HtmlEscape ([string]$rawUnmatchedTotal)) + '</th><th>' + (HtmlEscape $footerSectionPctText) + '</th><th>' + (HtmlEscape $totalMessagesPctText) + '</th><th></th></tr></tfoot></table>')
    }
    else {
        [void]$Builder.AppendLine('<p>No unmatched eligible error/failure lines in this section.</p>')
    }

    if ($SectionId -and $SectionId -like 'older-*') {
        [void]$Builder.AppendLine('</details>')
    }
    else {
        [void]$Builder.AppendLine('</div>')
    }
}


function Get-DateAgeClass {
    param(
        [datetime]$Dt,
        [nullable[long]]$MinTicks,
        [nullable[long]]$MaxTicks
    )

    if (-not $Dt) { return '' }
    if (-not $MinTicks -or -not $MaxTicks) { return '' }

    $minVal = [long]$MinTicks
    $maxVal = [long]$MaxTicks
    $dtVal  = [long]$Dt.Ticks

    if ($maxVal -le $minVal) { return 'date-age-1' }

    $ratio = ([double]($dtVal - $minVal)) / ([double]($maxVal - $minVal))

    if ($ratio -ge 0.80) { return 'date-age-5' }
    elseif ($ratio -ge 0.60) { return 'date-age-4' }
    elseif ($ratio -ge 0.40) { return 'date-age-3' }
    elseif ($ratio -ge 0.20) { return 'date-age-2' }
    else { return 'date-age-1' }
}


function Render-MatchedSectionsHtml {
    param(
        [Parameter(Mandatory = $true)][System.Text.StringBuilder]$Builder,
        [object[]]$Matches = @(),
        [Parameter(Mandatory = $true)][string]$Title,
        [string]$SectionId,
        [int]$PercentDenominator = 0,
        [int]$SummaryPercentNumerator = 0,
        [hashtable]$ComparisonLookup = @{},
        [int]$ComparisonDenominator = 0,
        [int]$ComparisonPieTotal = 0,
        [string]$ComparisonLabel = '% of All Time Coverage'
    )

    $matchesArray = @($Matches)
    $totalMessagesDenominator = [int]$PercentDenominator
    if ($SectionId -and $SectionId -like 'older-*') {
        [void]$Builder.AppendLine('<details class="section section-collapsible" id="' + (HtmlEscape $SectionId) + '">')
    [void]$Builder.AppendLine('<summary><h2>' + (HtmlEscape $Title) + '</h2><span class="collapse-hint">Click to expand/collapse</span></summary>')
    }
    else {
        $idAttr = ''
        if (-not [string]::IsNullOrWhiteSpace($SectionId)) { $idAttr = ' id="' + (HtmlEscape $SectionId) + '"' }
        [void]$Builder.AppendLine('<div class="section"' + $idAttr + '>')
    [void]$Builder.AppendLine('<h2>' + (HtmlEscape $Title) + '</h2>')
        if ($Title -eq 'Last 72 Hours - Matches') {
            [void]$Builder.AppendLine('<div class="small" style="margin:6px 0 8px;">Other (Info) reason tags are based on actual matched line classification:</div>')
    [void]$Builder.AppendLine('<ul class="note-list">')
    [void]$Builder.AppendLine('<li>Status / heartbeat messages</li>')
    [void]$Builder.AppendLine('<li>Successful operations</li>')
    [void]$Builder.AppendLine('<li>Expected transient retries / checks</li>')
    [void]$Builder.AppendLine('<li>Debug / verbose logging</li>')
    [void]$Builder.AppendLine('<li>Operational / informational lines</li>')
    [void]$Builder.AppendLine('</ul>')
        }
    }

    if ($matchesArray.Count -eq 0) {
        [void]$Builder.AppendLine('<p>No matched messages in this section.</p>')
        if ($SectionId -and $SectionId -like 'older-*') {
            [void]$Builder.AppendLine('</details>')
        }
        else {
            [void]$Builder.AppendLine('</div>')
        }
        return
    }

    $datedMatches = @($matchesArray | Where-Object { $_.PSObject.Properties.Name -contains 'LastSeen' -and $_.LastSeen })
    $minLastSeenTicks = $null
    $maxLastSeenTicks = $null
    if ($datedMatches.Count -gt 0) {
        $sortedMatchDates = @($datedMatches | Sort-Object LastSeen)
        $minLastSeenTicks = $sortedMatchDates[0].LastSeen.Ticks
        $maxLastSeenTicks = $sortedMatchDates[-1].LastSeen.Ticks
    }

    function Get-DateAgeClass {
        param(
            [object]$Dt,
            [object]$MinTicks,
            [object]$MaxTicks
        )
        if (-not $Dt) { return '' }
        if ($MinTicks -eq $null -or $MaxTicks -eq $null) { return 'date-age-3' }
        if ([int64]$MaxTicks -le [int64]$MinTicks) { return 'date-age-5' }
        $ratio = (([double]$Dt.Ticks) - [double]$MinTicks) / (([double]$MaxTicks) - [double]$MinTicks)
        if ($ratio -lt 0.2) { return 'date-age-1' }
        elseif ($ratio -lt 0.4) { return 'date-age-2' }
        elseif ($ratio -lt 0.6) { return 'date-age-3' }
        elseif ($ratio -lt 0.8) { return 'date-age-4' }
        else { return 'date-age-5' }
    }

        $sectionMatchTotal = (Get-SafeIntSum -Items @($matchesArray) -PropertyName 'Frequency')
    $pieTotalForPercent = (Get-SafeIntSum -Items @($matchesArray) -PropertyName 'PieFrequency')
    if ($pieTotalForPercent -lt 0) { $pieTotalForPercent = 0 }

    $matchedPercentDenominator = 0
    if ($pieTotalForPercent -gt 0 -and $SummaryPercentNumerator -gt 0) {
        $matchedPercentDenominator = [int]($pieTotalForPercent + $SummaryPercentNumerator)
    }
    elseif ($pieTotalForPercent -gt 0 -and $PercentDenominator -gt 0) {
        $matchedPercentDenominator = [int]($pieTotalForPercent + $PercentDenominator)
    }
    elseif ($PercentDenominator -gt 0) {
        $matchedPercentDenominator = [int]$PercentDenominator
    }
    elseif ($pieTotalForPercent -gt 0) {
        $matchedPercentDenominator = [int]$pieTotalForPercent
    }
    elseif ($sectionMatchTotal -gt 0) {
        $matchedPercentDenominator = [int]$sectionMatchTotal
    }

    $showPercentColumn = $matchesArray.Count -gt 0 -and (($Title -eq 'Last 72 Hours - Matches') -or ($Title -eq 'Anything Older / 72hr+ - Matches'))

    $tableHeader = '<table><thead><tr>' +
                   '<th>Severity</th><th>Frequency</th>'
    if ($showPercentColumn) {
        $primaryCoverageLabel = '% of 72h Coverage'
        if ($Title -like 'Anything Older / 72hr+*') {
            $primaryCoverageLabel = '% of 72hr+ Coverage'
        }
        $tableHeader += '<th>' + (HtmlEscape $primaryCoverageLabel) + '</th><th>' + (HtmlEscape $ComparisonLabel) + '</th><th>Category</th><th>Reason Tag</th><th>Pie Count</th><th>Other Count</th>'
    }
    $tableHeader += '<th>Last Seen</th><th>Last Seen (ago)</th>' +
                    '<th>Predicted Next</th><th>Avg Minutes Between</th>' +
                    '<th>Message</th></tr></thead><tbody>'
    [void]$Builder.AppendLine($tableHeader)

    $rowIdx = 0
    foreach ($m in $matchesArray) {
        $rowIdx++
        $sev    = [string]$m.Severity
        $sevEsc = HtmlEscape $sev
        $sevClass = 'sev-' + ($sev -replace '\s','')
        $freq  = [string]$m.Frequency
        $last  = $(if ($m.PSObject.Properties.Name -contains 'LastSeen' -and $m.LastSeen) { HtmlEscape ($m.LastSeen.ToString('yyyy-MM-dd HH:mm:ss')) } else { '' })
        $lastSeenClass = $(if ($m.PSObject.Properties.Name -contains 'LastSeen' -and $m.LastSeen) { Get-DateAgeClass -Dt $m.LastSeen -MinTicks $minLastSeenTicks -MaxTicks $maxLastSeenTicks } else { '' })
        $ago   = $(if ($m.LastSeenAgo)    { HtmlEscape ([string]$m.LastSeenAgo) } else { '' })
        $pred  = $(if ($m.PredictedNext)  { HtmlEscape ($m.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss')) } else { '' })

        $avg   = ''
        if ($m.AverageMinutesBetween -ne $null -and $m.AverageMinutesBetween -gt 0) {
            $avg = [Math]::Round([double]$m.AverageMinutesBetween,2).ToString()
        }

        $msgEsc = HtmlEscape ([string]$m.Message)

        $hoverPreviewSb = New-Object System.Text.StringBuilder
        if ($m.CsvRow) {
            [void]$hoverPreviewSb.Append('<div class="hover-details-title">Matching Details</div><table>')
            foreach ($hoverProp in $m.CsvRow.PSObject.Properties) {
                $hoverName = HtmlEscape ([string]$hoverProp.Name)
                $hoverVal = ''
                if ($null -ne $hoverProp.Value) { $hoverVal = [string]$hoverProp.Value }
                $hoverValHtml = HtmlEscape $hoverVal
                if ($hoverVal -match '^https?://') {
                    $hoverValHtml = '<a href="' + (HtmlEscape $hoverVal) + '" target="_blank">' + (HtmlEscape $hoverVal) + '</a>'
                }
                [void]$hoverPreviewSb.Append('<tr><td class="keycell key">' + $hoverName + '</td><td>' + $hoverValHtml + '</td></tr>')
            }
            [void]$hoverPreviewSb.Append('</table>')
        }
        else {
            [void]$hoverPreviewSb.Append('<div class="hover-details-title">Matching Details</div><div class="small">No matching details available for this row.</div>')
        }
        $hoverPreviewHtml = $hoverPreviewSb.ToString()

        $pctCell = ''
        if ($showPercentColumn) {
            $pctValue = $null
            if ([int]$m.PieFrequency -gt 0 -and $matchedPercentDenominator -gt 0) {
                $pctValue = ([double]$m.PieFrequency / [double]$matchedPercentDenominator) * 100.0
            }

            $comparisonPctValue = $null
            if ($ComparisonDenominator -gt 0 -and $ComparisonLookup -and $ComparisonLookup.ContainsKey([string]$m.Message)) {
                $comparisonRow = $ComparisonLookup[[string]$m.Message]
                if ($comparisonRow -and $comparisonRow.PSObject.Properties.Name -contains 'PieFrequency' -and [int]$comparisonRow.PieFrequency -gt 0) {
                    $comparisonPctValue = ([double]$comparisonRow.PieFrequency / [double]$ComparisonDenominator) * 100.0
                }
            }
            elseif ($totalMessagesDenominator -gt 0) {
                $comparisonPctValue = ([double]$m.Frequency / [double]$totalMessagesDenominator) * 100.0
            }

            $pctCellText = ''
            if ($pctValue -ne $null) {
                $pctCellText = ('{0:N2}%' -f $pctValue)
            }

            $comparisonPctText = ''
            if ($comparisonPctValue -ne $null) {
                $comparisonPctText = ('{0:N2}%' -f $comparisonPctValue)
            }

            $pctCell = '<td>' + (HtmlEscape $pctCellText) + '</td>'
            $pctCell += '<td>' + (HtmlEscape $comparisonPctText) + '</td>'
            $pctCell += '<td>' + (HtmlEscape ([string]$m.Category)) + '</td>'
            $pctCell += '<td>' + (HtmlEscape ([string]$m.ReasonTag)) + '</td>'
            $pctCell += '<td>' + (HtmlEscape ([string]$m.PieFrequency)) + '</td>'
            $pctCell += '<td>' + (HtmlEscape ([string]$m.OtherFrequency)) + '</td>'
        }

        $rowTargetAttr = ''
        if (-not [string]::IsNullOrWhiteSpace($SectionId)) {
            $rowTargetAttr = ' data-target-id="' + (HtmlEscape ($SectionId + '-detail-' + $rowIdx)) + '"'
        }
        [void]$Builder.AppendLine('<tr class="hover-preview-row"' + $rowTargetAttr + '>' +
            '<td class="' + $sevClass + '">' + $sevEsc + '</td>' +
            '<td>' + $freq + '</td>' +
            $pctCell +
            '<td class="' + $lastSeenClass + '">' + $last + '</td>' +
            '<td>' + $ago + '</td>' +
            '<td>' + $pred + '</td>' +
            '<td>' + (HtmlEscape $avg) + '</td>' +
            '<td>' + $msgEsc + '<div class="hover-preview-source">' + $hoverPreviewHtml + '</div></td>' +
            '</tr>')
    }

    $matchTotalPctText = ''
    if ($showPercentColumn) {
        if ($matchedPercentDenominator -gt 0) {
            $pieOnlyTotal = (Get-SafeIntSum -Items @($matchesArray) -PropertyName 'PieFrequency')
            if ($pieOnlyTotal -lt 0) { $pieOnlyTotal = 0 }
            $matchTotalPctText = ('{0:N2}%' -f (([double]$pieOnlyTotal / [double]$matchedPercentDenominator) * 100.0))
        }
        else {
            $matchTotalPctText = '0.00%'
        }
    }

    $comparisonTotalPctText = '100.00%'
    if ($showPercentColumn) {
        if ($ComparisonDenominator -gt 0 -and $ComparisonPieTotal -ge 0) {
            $comparisonTotalPctText = ('{0:N2}%' -f (([double]$ComparisonPieTotal / [double]$ComparisonDenominator) * 100.0))
        }
        elseif ($totalMessagesDenominator -gt 0) {
            $comparisonTotalPctText = ('{0:N2}%' -f (([double]$sectionMatchTotal / [double]$totalMessagesDenominator) * 100.0))
        }
        else {
            $comparisonTotalPctText = '0.00%'
        }
    }
    $tfoot = '<tfoot><tr><th>Total</th><th>' + (HtmlEscape ([string]$sectionMatchTotal)) + '</th>'
    if ($showPercentColumn) {
        $pieTotal = (Get-SafeIntSum -Items @($matchesArray) -PropertyName 'PieFrequency')
        if ($pieTotal -lt 0) { $pieTotal = 0 }
        $otherTotal = (Get-SafeIntSum -Items @($matchesArray) -PropertyName 'OtherFrequency')
        if ($otherTotal -lt 0) { $otherTotal = 0 }
        $tfoot += '<th>' + (HtmlEscape $matchTotalPctText) + '</th><th>' + (HtmlEscape $comparisonTotalPctText) + '</th><th colspan="2"></th><th>' + (HtmlEscape ([string]$pieTotal)) + '</th><th>' + (HtmlEscape ([string]$otherTotal)) + '</th>'
        $tfoot += '<th colspan="5"></th></tr>'
        $overlapTotal = $sectionMatchTotal - $pieTotal - $otherTotal
        if ($overlapTotal -lt 0) { $overlapTotal = 0 }
        $tfoot += '<tr><th colspan="4" style="text-align:right;">Counted (Pie)</th><th colspan="2">' + (HtmlEscape ([string]$pieTotal)) + '</th><th colspan="5">Unique matched error/failure-type lines counted in the chart</th></tr>'
        $tfoot += '<tr><th colspan="4" style="text-align:right;">Other (Info)</th><th colspan="2">' + (HtmlEscape ([string]$otherTotal)) + '</th><th colspan="5">Other matched lines shown below but not counted in the pie</th></tr>'
        if ($overlapTotal -gt 0) {
            $tfoot += '<tr><th colspan="4" style="text-align:right;">Overlap / duplicate table entries (already included in Other matched lines shown below)</th><th colspan="2">' + (HtmlEscape ([string]$overlapTotal)) + '</th><th colspan="5">Extra table entries created when a single log line matched more than one CSV pattern</th></tr>'
        }
    }
    else {
        $tfoot += '<th colspan="5"></th></tr>'
    }
    $tfoot += '</tfoot>'
    [void]$Builder.AppendLine('</tbody>' + $tfoot + '</table>')

    $idx = 0
    foreach ($m in $matchesArray) {
        $idx++
        $sev    = [string]$m.Severity
        $sevEsc = HtmlEscape $sev
        $sevClass = 'sev-' + ($sev -replace '\s','')
        $freq   = [string]$m.Frequency
        $last   = $(if ($m.PSObject.Properties.Name -contains 'LastSeen' -and $m.LastSeen) { $m.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' })
        $lastSeenClass = $(if ($m.PSObject.Properties.Name -contains 'LastSeen' -and $m.LastSeen) { Get-DateAgeClass -Dt $m.LastSeen -MinTicks $minLastSeenTicks -MaxTicks $maxLastSeenTicks } else { '' })
        $ago    = [string]$m.LastSeenAgo
        $pred   = $(if ($m.PredictedNext) { $m.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' })
        $avg    = 'N/A'
        if ($m.AverageMinutesBetween -ne $null -and $m.AverageMinutesBetween -gt 0) {
            $avg = [Math]::Round([double]$m.AverageMinutesBetween,2).ToString()
        }
        $msgTxt = [string]$m.Message

        $detailBlockId = ''
        if (-not [string]::IsNullOrWhiteSpace($SectionId)) {
            $detailBlockId = $SectionId + '-detail-' + $idx
        }
        [void]$Builder.AppendLine('<details class="match-block"' + $(if ($detailBlockId) { ' id="' + (HtmlEscape $detailBlockId) + '"' } else { '' }) + '>')
        [void]$Builder.AppendLine('<summary class="match-header">Match #' + $idx + ' <span class="badge ' + $sevClass + '">' + $sevEsc + '</span></summary>')
        $freqDetail = (HtmlEscape $freq)
        if ($showPercentColumn) {
            if ([int]$m.PieFrequency -gt 0 -and $matchedPercentDenominator -gt 0) {
                $detailPctValue = ([double]$m.PieFrequency / [double]$matchedPercentDenominator) * 100.0
                $freqDetail += ' (' + (HtmlEscape ('{0:N2}% of 72h coverage' -f $detailPctValue)) + ')'
            }
        }

        [void]$Builder.AppendLine('<table>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Frequency</td><td>' + $freqDetail + '</td></tr>')
        if ($showPercentColumn) {
            $detailComparisonPctValue = $null
            if ($ComparisonDenominator -gt 0 -and $ComparisonLookup -and $ComparisonLookup.ContainsKey([string]$m.Message)) {
                $detailComparisonRow = $ComparisonLookup[[string]$m.Message]
                if ($detailComparisonRow -and $detailComparisonRow.PSObject.Properties.Name -contains 'PieFrequency' -and [int]$detailComparisonRow.PieFrequency -gt 0) {
                    $detailComparisonPctValue = ([double]$detailComparisonRow.PieFrequency / [double]$ComparisonDenominator) * 100.0
                }
            }
            elseif ($totalMessagesDenominator -gt 0) {
                $detailComparisonPctValue = ([double]$m.Frequency / [double]$totalMessagesDenominator) * 100.0
            }

            $detailComparisonText = ''
            if ($detailComparisonPctValue -ne $null) {
                $detailComparisonText = ('{0:N2}%' -f $detailComparisonPctValue)
            }

            [void]$Builder.AppendLine('<tr><td class="keycell key">' + (HtmlEscape $ComparisonLabel) + '</td><td>' + (HtmlEscape $detailComparisonText) + '</td></tr>')
            [void]$Builder.AppendLine('<tr><td class="keycell key">Category</td><td>' + (HtmlEscape ([string]$m.Category)) + '</td></tr>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Reason Tag</td><td>' + (HtmlEscape ([string]$m.ReasonTag)) + '</td></tr>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Pie Count / Other Count</td><td>' + (HtmlEscape ([string]$m.PieFrequency)) + ' / ' + (HtmlEscape ([string]$m.OtherFrequency)) + '</td></tr>')
        }
        [void]$Builder.AppendLine('<tr><td class="keycell key">Last Seen</td><td class="' + $lastSeenClass + '">' + (HtmlEscape $last) + ' (' + (HtmlEscape $ago) + ')</td></tr>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Average Gap</td><td>' + (HtmlEscape $avg) + ' minute(s)</td></tr>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Predicted Reoccurrence</td><td>' + (HtmlEscape $pred) + '</td></tr>')
    [void]$Builder.AppendLine('<tr><td class="keycell key">Match</td><td>' + (HtmlEscape $msgTxt) + '</td></tr>')
    [void]$Builder.AppendLine('</table>')

        $row = $m.CsvRow
        if ($row) {
            [void]$Builder.AppendLine('<div class="small" style="margin-top:4px;margin-bottom:2px;">Matching Details:</div>')
    [void]$Builder.AppendLine('<table>')
            foreach ($prop in $row.PSObject.Properties) {
                $name  = HtmlEscape $prop.Name
                $val   = $(if ($null -ne $prop.Value) { [string]$prop.Value } else { '' })
                $valHtml = HtmlEscape $val
                if ($val -match '^https?://') {
                    $valHtml = '<a href="' + (HtmlEscape $val) + '" target="_blank">' + (HtmlEscape $val) + '</a>'
                }
                [void]$Builder.AppendLine('<tr><td class="keycell key">' + $name + '</td><td>' + $valHtml + '</td></tr>')
            }
            [void]$Builder.AppendLine('</table>')
        }

        $c = $m.LatestContext
        if ($c) {
            [void]$Builder.AppendLine('<div class="small" style="margin-top:8px;margin-bottom:2px;">Most Recent Occurrence (match line with 5 lines before/after):</div>')
    [void]$Builder.AppendLine('<div style="margin:6px 0 10px;">')
    [void]$Builder.AppendLine('<div class="small"><b>Occurrence</b> &mdash; ' + (HtmlEscape ([string]$c.Path)) + ' (Line ' + (HtmlEscape ([string]$c.MatchLine)) + ')</div>')
    [void]$Builder.AppendLine('<pre style="background:#0b0b0b;color:#e6e6e6;padding:8px;border-radius:10px;overflow:auto;max-width:100%;box-sizing:border-box;font-size:12px;line-height:1.35;">')
            foreach ($l in @($c.Lines)) {
                $num = ('{0,6}' -f [int]$l.LineNumber)
                $text = [string]$l.Text
                if ($l.IsMatch) {
                    [void]$Builder.AppendLine((HtmlEscape ($num + ': >> ' + $text)))
                } else {
                    [void]$Builder.AppendLine((HtmlEscape ($num + ':    ' + $text)))
                }
            }
            [void]$Builder.AppendLine('</pre>')
    [void]$Builder.AppendLine('</div>')
        }

        [void]$Builder.AppendLine('</details>')
    }

    if ($SectionId -and $SectionId -like 'older-*') {
        [void]$Builder.AppendLine('</details>')
    }
    else {
        [void]$Builder.AppendLine('</div>')
    }
}

# -----------------------------
# HTML report generation
# -----------------------------

function Get-OtherMatchReasonTag {
    param(
        [string]$Line,
        [string]$Message
    )

    $text = (([string]$Line) + ' ' + ([string]$Message)).ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($text)) { return 'Operational / informational' }

    if ($text -match 'heartbeat|agent status|status update|last scan time|last_scanned_time|checked for pending jobs|pending jobs|heartbeat received') {
        return 'Status / heartbeat'
    }
    if ($text -match 'success|successfully|completed|processed|saved successfully|updated successfully|posted through api 200|agent status updated successfully') {
        return 'Successful operation'
    }
    if ($text -match 'retry|attempt\s+\d+|checking for self-scan|threshold duration|scheduled scan|connection attempt|trying again|restarting') {
        return 'Expected transient retry / check'
    }
    if ($text -match 'debug|verbose|responsebody|payload|processing|filtered hostnames|asset before updating|asset after updating|publishing self asset scan data|processing mac address') {
        return 'Debug / verbose'
    }
    if ($text -match 'running kill command|taskkill|monitoring agent service is running|entered to publish asset info|mqtt: not able to publish after retries') {
        return 'Operational / informational'
    }
    return 'Operational / informational'
}

function Get-MatchSummaryForWindow {
    param(
        [Parameter(Mandatory=$true)][object[]]$Matches,
        [datetime]$WindowStart,
        [datetime]$WindowEnd,
        [switch]$IncludeOlderThanWindowStart,
        [hashtable]$EligibleMatchedKeys,
        [switch]$DoNotFilterToEligible
    )

    $result = @()
    foreach ($m in @($Matches)) {
        $sourceOccurrences = @()
        if ($m.PSObject.Properties.Name -contains 'Occurrences') {
            $sourceOccurrences = @($m.Occurrences)
        }

        $filteredOccurrences = @()
        foreach ($occ in $sourceOccurrences) {
            $occTs = $null
            if ($occ -and ($occ.PSObject.Properties.Name -contains 'Timestamp')) { $occTs = $occ.Timestamp }

            $occLineText = [string]$occ.Line
            $isEligibleOccurrence = ($occLineText -match $Global:LevelRegex)
            if ($EligibleMatchedKeys) {
                $occKey = ('{0}|{1}|{2}' -f [string]$occ.Path, [int]$occ.LineNumber, $occLineText)
                $isEligibleOccurrence = ($EligibleMatchedKeys.ContainsKey($occKey) -and ($occLineText -match $Global:LevelRegex))
                if ((-not $DoNotFilterToEligible) -and (-not $isEligibleOccurrence)) { continue }
            }
            if ($occ) {
                try { Add-Member -InputObject $occ -NotePropertyName IsEligibleForPie -NotePropertyValue ([bool]$isEligibleOccurrence) -Force } catch {}
            }

            if ($IncludeOlderThanWindowStart) {
                if ($WindowStart) {
                    if ($occTs -and $occTs -lt $WindowStart) { $filteredOccurrences += $occ }
                    elseif (-not $occTs -and $m.LastSeen -and $m.LastSeen -lt $WindowStart) { $filteredOccurrences += $occ }
                } else {
                    $filteredOccurrences += $occ
                }
            }
            elseif ($WindowStart -or $WindowEnd) {
                $inWindow = $true
                if ($WindowStart -and ((-not $occTs) -or ($occTs -lt $WindowStart))) { $inWindow = $false }
                if ($WindowEnd -and ((-not $occTs) -or ($occTs -gt $WindowEnd))) { $inWindow = $false }
                if ($inWindow) { $filteredOccurrences += $occ }
            }
            else {
                $filteredOccurrences += $occ
            }
        }

        if (@($filteredOccurrences).Count -eq 0) { continue }

        $timestamps = New-Object System.Collections.Generic.List[datetime]
        $severityCounts = @{}
        $lastSeen = $null
        $latestKey = $null
        $latestCtx = $null
        $pieCount = 0
        $otherCount = 0
        $otherReasonCounts = @{}
        $representativeOtherLine = $null

        foreach ($occ in $filteredOccurrences) {
            $line = [string]$occ.Line
            $sev = Get-SeverityFromLine -Line $line
            $isEligibleOccurrence = $true
            if ($occ.PSObject.Properties.Name -contains 'IsEligibleForPie') { $isEligibleOccurrence = [bool]$occ.IsEligibleForPie }
            if ($isEligibleOccurrence) { $pieCount++ } else {
                $otherCount++
                if (-not $representativeOtherLine) { $representativeOtherLine = $line }
                $reasonTag = Get-OtherMatchReasonTag -Line $line -Message ([string]$m.Message)
                if (-not $otherReasonCounts.ContainsKey($reasonTag)) { $otherReasonCounts[$reasonTag] = 0 }
                $otherReasonCounts[$reasonTag]++
            }
            if (-not $severityCounts.ContainsKey($sev)) { $severityCounts[$sev] = 0 }
            $severityCounts[$sev]++

            $ts = $null
            if ($occ.PSObject.Properties.Name -contains 'Timestamp') { $ts = $occ.Timestamp }
            if ($ts) {
                if (-not $lastSeen -or $ts -gt $lastSeen) { $lastSeen = $ts }
                [void]$timestamps.Add($ts)
            }

            $ctxKey = $null
            if ($ts) {
                $ctxKey = $ts
            } else {
                $fileTime = $null
                try { $fileTime = (Get-Item -LiteralPath $occ.Path -ErrorAction Stop).LastWriteTime } catch { $fileTime = $null }
                if ($fileTime) {
                    $ctxKey = $fileTime.AddMilliseconds([Math]::Min(999, [int]($occ.LineNumber % 1000)))
                } else {
                    $ctxKey = [datetime]::MinValue
                }
            }

            if (-not $latestKey -or $ctxKey -gt $latestKey) {
                $latestKey = $ctxKey
                try { $latestCtx = Get-LogContextSnippet -Cache $script:fileLineCache -Path $occ.Path -LineNumber $occ.LineNumber -Before 5 -After 5 }
                catch { $latestCtx = $null }
            }
        }

        $avgMinutes = $null
        $predicted  = $null
        if ($timestamps.Count -ge 2) {
            $orderedTimes = $timestamps.ToArray() | Sort-Object
            $totalDelta = 0.0
            for ($i = 1; $i -lt $orderedTimes.Length; $i++) {
                $totalDelta += ($orderedTimes[$i] - $orderedTimes[$i-1]).TotalMinutes
            }
            $avgMinutes = $totalDelta / [double]($orderedTimes.Length - 1)
            if ($lastSeen -and $avgMinutes -gt 0) { $predicted = $lastSeen.AddMinutes($avgMinutes) }
        }

        $timeAgo = $(if ($lastSeen) { Format-TimeAgo -LastTime $lastSeen -Now $script:HtmlNow } else { 'N/A' })
        $sevOrder = @('FATAL','ERROR','EXCEPTION','FAIL','TIMEOUT','UNAUTHORIZED','ACCESS DENIED','WARN','WARNING','Unknown')
        $primarySeverity = 'Unknown'
        foreach ($s in $sevOrder) {
            if ($severityCounts.ContainsKey($s) -and $severityCounts[$s] -gt 0) { $primarySeverity = $s; break }
        }

        $primaryReasonTag = ''
        if ($otherReasonCounts.Count -gt 0) {
            $primaryReasonTag = [string](($otherReasonCounts.GetEnumerator() | Sort-Object -Property Value -Descending | Select-Object -First 1).Key)
        }
        $categoryLabel = 'Counted (Pie)'
        if ($pieCount -gt 0 -and $otherCount -gt 0) { $categoryLabel = 'Mixed' }
        elseif ($pieCount -eq 0 -and $otherCount -gt 0) { $categoryLabel = 'Other (Info)' }

        $result += [pscustomobject]@{
            Severity              = $primarySeverity
            SeverityBreakdown     = $severityCounts
            Message               = $m.Message
            CsvRow                = $m.CsvRow
            Frequency             = @($filteredOccurrences).Count
            PieFrequency          = [int]$pieCount
            OtherFrequency        = [int]$otherCount
            Category              = $categoryLabel
            ReasonTag             = $primaryReasonTag
            RepresentativeOtherLine = $representativeOtherLine
            LastSeen              = $lastSeen
            LastSeenAgo           = $timeAgo
            AverageMinutesBetween = $avgMinutes
            PredictedNext         = $predicted
            LatestContext         = $latestCtx
            Occurrences           = @($filteredOccurrences)
        }
    }

    return @($result)
}

function Get-MatchBreakdownStats {
    param(
        [object[]]$MatchSummaries = @(),
        [int]$EligibleMatchedCount = 0
    )

    $tableMatchedTotal = (Get-SafeIntSum -Items @($MatchSummaries) -PropertyName 'Frequency')
    $uniquePieKeys = @{}
    $uniqueOtherKeys = @{}
    $matchedGroupsInChart = 0
    $summedPieFrequency = 0
    $summedOtherFrequency = 0

    foreach ($matchRow in @($MatchSummaries)) {
        $rowUniquePieKeys = @{}

        $rowPieFrequency = 0
        $rowOtherFrequency = 0
        if ($matchRow -and $matchRow.PSObject.Properties.Name -contains 'PieFrequency') {
            $rowPieFrequency = [int]$matchRow.PieFrequency
        }
        if ($matchRow -and $matchRow.PSObject.Properties.Name -contains 'OtherFrequency') {
            $rowOtherFrequency = [int]$matchRow.OtherFrequency
        }

        $summedPieFrequency += $rowPieFrequency
        $summedOtherFrequency += $rowOtherFrequency

        foreach ($occ in @($matchRow.Occurrences)) {
            if (-not $occ) { continue }

            $occPath = ''
            $occLineNo = ''
            $occLine = ''
            $occEligible = $true

            if ($occ.PSObject.Properties.Name -contains 'Path') { $occPath = [string]$occ.Path }
            if ($occ.PSObject.Properties.Name -contains 'LineNumber') { $occLineNo = [string]$occ.LineNumber }
            if ($occ.PSObject.Properties.Name -contains 'Line') { $occLine = [string]$occ.Line }
            if ($occ.PSObject.Properties.Name -contains 'IsEligibleForPie') { $occEligible = [bool]$occ.IsEligibleForPie }

            $occKey = ('{0}|{1}|{2}' -f $occPath, $occLineNo, $occLine)
            if ($occEligible) {
                if (-not $uniquePieKeys.ContainsKey($occKey)) { $uniquePieKeys[$occKey] = $true }
                if (-not $rowUniquePieKeys.ContainsKey($occKey)) { $rowUniquePieKeys[$occKey] = $true }
            }
            else {
                if (-not $uniqueOtherKeys.ContainsKey($occKey)) { $uniqueOtherKeys[$occKey] = $true }
            }
        }

        if ($rowPieFrequency -gt 0) {
            $matchedGroupsInChart++
        }
        elseif ($rowUniquePieKeys.Count -gt 0) {
            $matchedGroupsInChart++
        }
    }

    $eligibleMatched = [Math]::Max(0, [int]$summedPieFrequency)
    if ($eligibleMatched -eq 0) {
        $eligibleMatched = [Math]::Max(0, [int]$uniquePieKeys.Count)
    }
    if ($eligibleMatched -eq 0 -and $EligibleMatchedCount -gt 0) {
        $eligibleMatched = [Math]::Max(0, [int]$EligibleMatchedCount)
    }

    $informationalMatched = [Math]::Max(0, [int]$summedOtherFrequency)
    if ($informationalMatched -eq 0) {
        $informationalMatched = [Math]::Max(0, [int]$uniqueOtherKeys.Count)
    }

    $otherRowsShownInTables = [Math]::Max(0, [int]$summedOtherFrequency)

    $overlappingOrDuplicateMatched = $tableMatchedTotal - $eligibleMatched - $informationalMatched
    if ($overlappingOrDuplicateMatched -lt 0) { $overlappingOrDuplicateMatched = 0 }

    $nonPieInsideCountedOrMixedRows = $informationalMatched - $otherRowsShownInTables
    if ($nonPieInsideCountedOrMixedRows -lt 0) { $nonPieInsideCountedOrMixedRows = 0 }

    return [pscustomobject]@{
        EligibleMatchedInChart = [int]$eligibleMatched
        MatchedGroupsInChart = [int]$matchedGroupsInChart
        InformationalOrOtherMatched = [int]$informationalMatched
        OtherRowsShownInTables = [int]$otherRowsShownInTables
        OverlappingOrDuplicateMatched = [int]$overlappingOrDuplicateMatched
        NonPieInsideCountedOrMixedRows = [int]$nonPieInsideCountedOrMixedRows
        TotalMatchedShownInTables = [int]$tableMatchedTotal
    }
}

function Get-StrictLeadingLogTimestamp {
    param([Parameter(Mandatory = $true)][string]$Line)

    if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

    $m1 = [regex]::Match($Line, '^\s*(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})')
    if ($m1.Success) {
        try { return [datetime]::ParseExact($m1.Groups[1].Value, 'yyyy/MM/dd HH:mm:ss', $null) } catch {}
    }

    $m2 = [regex]::Match($Line, '^\s*(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})')
    if ($m2.Success) {
        try { return [datetime]$m2.Groups[1].Value } catch {}
    }

    $m3 = [regex]::Match($Line, '^\s*(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*(AM|PM)?)')
    if ($m3.Success) {
        try { return [datetime]$m3.Groups[1].Value } catch {}
    }

    return $null
}

function Get-EarliestTimestampFromLogFiles {
    param(
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [datetime]$WindowStart,
        [switch]$IncludeOlderThanWindowStart
    )

    $earliest = $null
    if ([string]::IsNullOrWhiteSpace($LogRoot) -or -not (Test-Path -LiteralPath $LogRoot)) {
        return $null
    }

    try {
        $logFiles = @(Get-ChildItem -LiteralPath $LogRoot -File -Filter '*.log' -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName)
        foreach ($logFile in @($logFiles)) {
            try {
                Get-Content -LiteralPath $logFile.FullName -ErrorAction Stop | ForEach-Object {
                    $line = [string]$_
                    if ([string]::IsNullOrWhiteSpace($line)) { return }

                    $lineTs = Get-StrictLeadingLogTimestamp -Line $line
                    if (-not $lineTs) { return }

                    $includeLine = $true
                    if ($WindowStart) {
                        if ($IncludeOlderThanWindowStart) {
                            if ($lineTs -ge $WindowStart) { $includeLine = $false }
                        }
                        else {
                            if ($lineTs -lt $WindowStart) { $includeLine = $false }
                        }
                    }
                    if (-not $includeLine) { return }

                    if ((-not $earliest) -or ($lineTs -lt $earliest)) {
                        $earliest = $lineTs
                    }
                }
            } catch {}
        }
    } catch {}

    return $earliest
}

function Get-LatestTimestampFromLogFiles {
    param(
        [Parameter(Mandatory = $true)][string]$LogRoot
    )

    $latest = $null
    if ([string]::IsNullOrWhiteSpace($LogRoot) -or -not (Test-Path -LiteralPath $LogRoot)) {
        return $null
    }

    try {
        $logFiles = @(Get-ChildItem -LiteralPath $LogRoot -File -Filter '*.log' -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName)
        foreach ($logFile in @($logFiles)) {
            try {
                Get-Content -LiteralPath $logFile.FullName -ErrorAction Stop | ForEach-Object {
                    $line = [string]$_
                    if ([string]::IsNullOrWhiteSpace($line)) { return }

                    $lineTs = Get-StrictLeadingLogTimestamp -Line $line
                    if (-not $lineTs) { return }

                    if ((-not $latest) -or ($lineTs -gt $latest)) {
                        $latest = $lineTs
                    }
                }
            } catch {}
        }
    } catch {}

    return $latest
}

function New-AgentMsgHtmlReport {
    param(
        [object[]]$Matches = @(),
        [Parameter(Mandatory = $true)][string]$IndexPath,
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [Parameter(Mandatory = $true)][datetime]$GeneratedAt,
        [psobject]$CoverageStats,
        [psobject]$CoverageStats72Hours,
        [psobject]$CoverageStatsOlder,
        [datetime]$AnchorTimestamp,
        [datetime]$WindowStart72Hours,
        [hashtable]$EligibleMatchedKeys,
        [switch]$CheckCalc,
        [string]$CheckCalcLogPath,
        [string]$CheckCalcJsonLogPath,
        [int]$CheckCalcMaxAttempts = 10,
        [System.IO.FileInfo[]]$LogFilesAnalyzed = @()
    )

    $outRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'
    Ensure-Directory -Path $outRoot
    $contextCache = @{}
    $script:HtmlContextCache = $contextCache

    $ts       = $GeneratedAt.ToString('yyyyMMdd_HHmmss_fff')
    $fileName = "CS-AgentMsgCorrelator-$ts.html"
    $htmlPath = Join-Path $outRoot $fileName

    $logoUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
    $sb = New-Object System.Text.StringBuilder

    [void]$sb.AppendLine('<!doctype html>')
    [void]$sb.AppendLine('<html><head><meta charset="utf-8">')
    [void]$sb.AppendLine('<title>Agent Message Correlator</title>')
    [void]$sb.AppendLine('<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:20px;padding-top:70px;overflow-x:hidden;}
h1{text-align:center;margin:4px 0 6px;scroll-margin-top:90px;}
.logo-wrap{text-align:center;margin-bottom:6px;}
.logo{max-height:60px;display:inline-block;}
.small{color:#777;font-size:12px;}

.sticky-nav{position:fixed;top:0;left:0;right:0;z-index:1000;background:#ffffff;border-bottom:1px solid #dcdcdc;box-shadow:0 2px 8px rgba(0,0,0,0.08);padding:10px 14px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;}
.sticky-nav a{text-decoration:none;color:#0b57d0;background:#f5f8ff;border:1px solid #d9e5ff;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:600;}
.sticky-nav a:hover{background:#eaf1ff;}
.section[id]{scroll-margin-top:95px;}
.top-errors-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;}
.top-error-card{border:1px solid #e0e0e0;background:#fff;border-radius:12px;padding:12px;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.top-error-card.rank-1{border-color:#d4af37;background:#fffaf0;}
.top-error-card.rank-2{border-color:#b0bec5;background:#fafcfd;}
.top-error-card.rank-3{border-color:#cd7f32;background:#fff8f3;}
.top-error-rank{font-size:12px;font-weight:700;color:#555;margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em;}
.top-error-msg{font-size:14px;font-weight:600;line-height:1.35;margin-bottom:8px;word-break:break-word;}
.top-error-metrics{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:#555;}
.top-lastseen.date-age-1,.top-lastseen.date-age-2,.top-lastseen.date-age-3,.top-lastseen.date-age-4,.top-lastseen.date-age-5{padding:2px 6px;border-radius:8px;display:inline-block;}
.section-collapsible summary{cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px;list-style:none;}
.section-collapsible summary::-webkit-details-marker{display:none;}
.section-collapsible summary h2{margin:0;display:inline;}
.collapse-hint{font-size:12px;color:#666;font-weight:600;}
tr.top-rank-1 td:first-child{border-left:5px solid #d4af37;background:#fffaf0;}
tr.top-rank-2 td:first-child{border-left:5px solid #b0bec5;background:#fafcfd;}
tr.top-rank-3 td:first-child{border-left:5px solid #cd7f32;background:#fff8f3;}
table{border-collapse:collapse;width:100%;margin:8px 0 16px;table-layout:fixed;}
th,td{border:1px solid #e0e0e0;padding:6px 8px;text-align:left;vertical-align:top;font-size:13px;word-break:break-word;overflow-wrap:anywhere;}
th{background:#f5f5f5;}
.section{margin-top:18px;padding:10px 12px;border-radius:10px;border:1px solid #e0e0e0;background:#fafafa;max-width:100%;box-sizing:border-box;}
.section h2{margin:0 0 8px;}
.section-collapsible{margin-top:18px;padding:10px 12px;border-radius:10px;border:1px solid #e0e0e0;background:#fafafa;max-width:100%;box-sizing:border-box;}
.section-collapsible > summary{cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px;list-style:none;}
.section-collapsible > summary::-webkit-details-marker{display:none;}
.section-collapsible > summary h2{margin:0;display:inline;}
.section-collapsible:not([open]) > *:not(summary){display:none;}
.collapse-hint{font-size:12px;color:#666;font-weight:600;}
.match-block{border:1px solid #d0d0d0;border-radius:10px;padding:8px 10px;margin:10px 0;background:#ffffff;max-width:100%;box-sizing:border-box;}
.match-block > summary{cursor:pointer;list-style:none;display:flex;align-items:center;gap:8px;}
.match-block > summary::-webkit-details-marker{display:none;}
.match-header{font-weight:600;margin-bottom:4px;}
.badge{display:inline-block;padding:2px 6px;border-radius:10px;font-size:11px;border:1px solid #ccc;background:#f5f5f5;margin-left:6px;}
.key{font-weight:600;white-space:nowrap;}
td.keycell{width:150px;background:#fafafa;}
.coverage-wrap{display:flex;flex-wrap:wrap;gap:20px;align-items:center;justify-content:center;margin-top:8px;}
.pie-wrap{text-align:center;min-width:0;width:100%;}
.pie-chart{width:min(230px,100%);aspect-ratio:1 / 1;height:auto;border-radius:50%;margin:0 auto;background:conic-gradient(#2e7d32 0deg, #2e7d32 VAR_MATCH_DEG, #d32f2f VAR_MATCH_DEG, #d32f2f 360deg);border:1px solid #d0d0d0;position:relative;box-shadow:inset 0 0 0 1px rgba(255,255,255,0.35);}
.pie-hole{position:absolute;inset:50%;transform:translate(-50%,-50%);width:110px;height:110px;border-radius:50%;background:#ffffff;border:1px solid #e0e0e0;display:flex;align-items:center;justify-content:center;text-align:center;font-weight:700;font-size:20px;line-height:1.1;}
.legend{margin-top:12px;display:flex;gap:14px;justify-content:center;flex-wrap:wrap;}
.legend-item{display:flex;align-items:center;gap:6px;font-size:13px;}
.legend-swatch{width:12px;height:12px;border-radius:3px;display:inline-block;}
.swatch-matched{background:#2e7d32;}
.swatch-unmatched{background:#d32f2f;}
.coverage-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;flex:1;min-width:0;max-width:100%;}
.stat-card{border:1px solid #e0e0e0;background:#ffffff;border-radius:10px;padding:12px;}
.stat-label{font-size:12px;color:#666;margin-bottom:4px;}
.stat-value{font-size:24px;font-weight:700;}
.note-list{margin:8px 0 0 18px;padding:0;}
.note-list li{margin:3px 0;}
.unmatched-details{margin-top:6px;}
.unmatched-details summary{cursor:pointer;font-weight:600;color:#333;}
.unmatched-sublist{margin:8px 0 0 18px;padding:0;}
.unmatched-sublist li{margin:6px 0;}
.unmatched-example{margin:6px 0 0 0;padding:8px;border:1px solid #e0e0e0;border-radius:8px;background:#fbfbfb;}
.unmatched-example-title{font-size:12px;color:#555;margin-bottom:6px;}
.unmatched-context{margin:0;padding:8px;border-radius:6px;background:#fff;border:1px solid #ececec;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;font-family:Consolas,monospace;font-size:12px;line-height:1.45;}
.unmatched-context .hit{background:#fff3cd;font-weight:700;display:block;}
.unmatched-context .ctx{display:block;}
.sev-ERROR,.sev-FATAL,.sev-EXCEPTION{color:#b00020;}
.sev-FAIL,.sev-TIMEOUT{color:#8e24aa;}
.sev-WARN,.sev-WARNING{color:#f57c00;}
.sev-UNAUTHORIZED,.sev-ACCESSDENIED{color:#b8860b;}

.date-age-1{background:#dcfce7;}
.date-age-2{background:#86efac;}
.date-age-3{background:#4ade80;}
.date-age-4{background:#22c55e;color:#fff;}
.date-age-5{background:#14532d;color:#fff;}

.hover-preview-row{cursor:help;}
.hover-preview-source{display:none;}
.hover-preview-flyout{
    position:fixed;
    z-index:5000;
    display:none;
    max-width:520px;
    min-width:280px;
    max-height:70vh;
    overflow:auto;
    background:#ffffff;
    border:1px solid #cfd8dc;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.18);
    padding:12px;
    pointer-events:none;
}
.hover-preview-flyout .hover-details-title{
    font-size:12px;
    font-weight:700;
    color:#555;
    margin-bottom:8px;
    text-transform:uppercase;
    letter-spacing:.04em;
}
.hover-preview-flyout table{margin:0 0 8px;}
.hover-preview-flyout .small{color:#666;}

.hover-preview-row.is-hovered td{box-shadow:inset 0 0 0 2px #d32f2f;}
.hover-preview-row.is-active td{box-shadow:inset 0 0 0 2px #b71c1c;}

.stat-card.stat-card-sm{padding:8px 10px;min-height:auto;}
.stat-card.clickable-tile{position:relative;transition:border-color .12s ease, box-shadow .12s ease, transform .12s ease;}
.stat-card.clickable-tile:hover,.top-error-card.clickable-tile:hover{box-shadow:0 0 0 2px #d32f2f inset;transform:translateY(-1px);}
.top-error-card.clickable-tile{position:relative;cursor:pointer;text-decoration:none;color:inherit;display:block;}
.tile-hover-hint{
    position:fixed;
    z-index:5200;
    display:none;
    pointer-events:none;
    background:#fff5f5;
    color:#b71c1c;
    border:1px solid #ef9a9a;
    border-radius:999px;
    padding:4px 8px;
    font-size:11px;
    font-weight:700;
    box-shadow:0 4px 14px rgba(0,0,0,0.12);
    white-space:nowrap;
}
.section.jump-target-flash{box-shadow:0 0 0 3px #d32f2f inset;border-radius:12px;transition:box-shadow .18s ease;}

.agent-info-block{margin-top:14px;}
.agent-info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;}
.agent-info-card{border:1px solid #e0e0e0;background:#ffffff;border-radius:10px;padding:10px 12px;}
.agent-info-label{font-size:12px;color:#666;margin-bottom:4px;}
.agent-info-value{font-size:14px;font-weight:600;line-height:1.35;word-break:break-word;overflow-wrap:anywhere;}
.agent-info-source{margin-top:8px;padding-top:8px;border-top:1px solid #ececec;}

@media (max-width: 900px){
.coverage-wrap{grid-template-columns:1fr !important;}
}

</style></head><body>')
    [void]$sb.AppendLine('<div id="hover-preview-flyout" class="hover-preview-flyout"></div>')
    [void]$sb.AppendLine('<div id="tile-hover-hint" class="tile-hover-hint">Click for details</div>')

    [void]$sb.AppendLine('<div class="sticky-nav">' +
                         '<a href="#summary-72h">72h Summary</a>' +
                         '<a href="#top-errors">72h Top 3 Unknown</a>' +
                         '<a href="#recent-matches">72h Matches</a>' +
                         '<a href="#recent-unmatched">72h Non-Matches</a>' +
                         '<a href="#summary-older">Older Than 72h Summary</a>' +
                         '<a href="#older-top-errors">Older Top 3 Unknown</a>' +
                         '<a href="#older-matches">Older Matches</a>' +
                         '<a href="#older-unmatched">Older Non-Matches</a>' +
                         '</div>')
    $AgentSummaryFromLogs = $null
    $script:AgentSummaryFromLogs = $null
    try {
        $AgentSummaryFromLogs = Get-AgentSummaryFromLogs -CollectDir $LogRoot
        $script:AgentSummaryFromLogs = $AgentSummaryFromLogs
    }
    catch {
        $AgentSummaryFromLogs = $null
        $script:AgentSummaryFromLogs = $null
    }

    [void]$sb.AppendLine('<div class="logo-wrap"><img src="' + $logoUrl + '" alt="ConnectSecure Logo" class="logo"></div>')
    [void]$sb.AppendLine('<h1>Agent Message Correlator</h1>')
    [void]$sb.AppendLine('<div class="small">Generated at ' + (HtmlEscape ($GeneratedAt.ToString('yyyy-MM-dd HH:mm:ss'))) + ' &mdash; Log root: ' + (HtmlEscape $LogRoot) + '</div>')
    [void]$sb.AppendLine('<div class="small">Message index: ' + (HtmlEscape $IndexPath) + '</div>')

    if ($AgentSummaryFromLogs) {
        [void]$sb.AppendLine('<div class="section agent-info-block" style="margin-top:14px;">')
        [void]$sb.AppendLine('<h2 style="margin-bottom:8px;">Agent Info</h2>')
        [void]$sb.AppendLine('<div class="agent-info-grid">')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Hostname</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.Hostname)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">IP</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.IP)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">MAC</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.MAC)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Agent Version</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.AgentVersion)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Agent ID</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.AgentID)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Tenant ID</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.TenantID)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Company ID</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.CompanyID)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">Agent Type</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.AgentType)) + '</div></div>')
        [void]$sb.AppendLine('<div class="agent-info-card"><div class="agent-info-label">PODID</div><div class="agent-info-value">' + (HtmlEscape ([string]$AgentSummaryFromLogs.PODID)) + '</div></div>')
        [void]$sb.AppendLine('</div>')
        if ($AgentSummaryFromLogs.SourceFile) {
            [void]$sb.AppendLine('<div class="small agent-info-source">Source: ' + (HtmlEscape ([string]$AgentSummaryFromLogs.SourceFile)) + '</div>')
        }
        [void]$sb.AppendLine('</div>')
    }

    $matchesArray = @($Matches)
    $script:HtmlNow = $GeneratedAt
    $script:fileLineCache = @{}
    $script:AgentSummaryFromLogs = $AgentSummaryFromLogs
    if (-not $CoverageStats) { $CoverageStats = [pscustomobject]@{ TotalEligible = 0; MatchedEligible = 0; MatchedGroupCount = 0; UnmatchedEligible = 0; UnmatchedGroupCount = 0; MatchedPercent = 0; UnmatchedPercent = 0; MatchedGroupPercent = 0; UnmatchedGroupPercent = 0; UnmatchedGroupedLines = @(); LatestTimestamp = $null } }
    if (-not $CoverageStats72Hours) { $CoverageStats72Hours = [pscustomobject]@{ TotalEligible = 0; MatchedEligible = 0; MatchedGroupCount = 0; UnmatchedEligible = 0; UnmatchedGroupCount = 0; MatchedPercent = 0; UnmatchedPercent = 0; MatchedGroupPercent = 0; UnmatchedGroupPercent = 0; UnmatchedGroupedLines = @(); LatestTimestamp = $null } }
    if (-not $CoverageStatsOlder) { $CoverageStatsOlder = [pscustomobject]@{ TotalEligible = 0; MatchedEligible = 0; MatchedGroupCount = 0; UnmatchedEligible = 0; UnmatchedGroupCount = 0; MatchedPercent = 0; UnmatchedPercent = 0; MatchedGroupPercent = 0; UnmatchedGroupPercent = 0; UnmatchedGroupedLines = @(); LatestTimestamp = $null } }

    $script:HtmlTopGroupRanks = @{}
    $OlderFirstUnmatchedTarget = 'older-unmatched'
    try {
        $olderFirstRow = @($CoverageStatsOlder.UnmatchedGroupedLines | Select-Object -First 1)[0]
        if ($olderFirstRow -and $olderFirstRow.Message) {
            $OlderFirstUnmatchedTarget = 'older-unmatched-detail-' + [string]([Math]::Abs(([string]$olderFirstRow.Message).GetHashCode()))
        }
    } catch {}

    $topHighlightRows = @($CoverageStats.UnmatchedGroupedLines | Select-Object -First 3)
    $topRankCounter = 0
    foreach ($topRow in $topHighlightRows) {
        $topRankCounter++
        $script:HtmlTopGroupRanks[[string]$topRow.Message] = $topRankCounter
    }

    $recentMatches = @()
    $olderMatches = @()
    if ($WindowStart72Hours -and $AnchorTimestamp) {
        $recentMatches = Get-MatchSummaryForWindow -Matches @($matchesArray) -WindowStart $WindowStart72Hours -WindowEnd $AnchorTimestamp -EligibleMatchedKeys $EligibleMatchedKeys -DoNotFilterToEligible
        $olderMatches = Get-MatchSummaryForWindow -Matches @($matchesArray) -WindowStart $WindowStart72Hours -IncludeOlderThanWindowStart -EligibleMatchedKeys $EligibleMatchedKeys -DoNotFilterToEligible
    }
    else {
        $recentMatches = Get-MatchSummaryForWindow -Matches @($matchesArray) -EligibleMatchedKeys $EligibleMatchedKeys -DoNotFilterToEligible
        $olderMatches = @()
    }

    $recentMatches = @($recentMatches | Sort-Object -Property @{Expression='Frequency';Descending=$true}, @{Expression='LastSeen';Descending=$true})
    $olderMatches = @($olderMatches | Sort-Object -Property @{Expression='Frequency';Descending=$true}, @{Expression='LastSeen';Descending=$true})
    $allMatchesForBreakdown = @()
    if ($matchesArray.Count -gt 0) {
        $allMatchesForBreakdown = Get-MatchSummaryForWindow -Matches @($matchesArray) -EligibleMatchedKeys $EligibleMatchedKeys -DoNotFilterToEligible
        $allMatchesForBreakdown = @($allMatchesForBreakdown | Sort-Object -Property @{Expression='Frequency';Descending=$true}, @{Expression='LastSeen';Descending=$true})
    }
    $recentBreakdownStats = Get-MatchBreakdownStats -MatchSummaries @($recentMatches) -EligibleMatchedCount ([int]$CoverageStats72Hours.MatchedEligible)
    $olderBreakdownStats = Get-MatchBreakdownStats -MatchSummaries @($olderMatches) -EligibleMatchedCount ([int]$CoverageStatsOlder.MatchedEligible)

    $OlderUnmatchedLookup = @{}
    foreach ($olderUnmatchedRow in @($CoverageStatsOlder.UnmatchedGroupedLines)) {
        if ($null -ne $olderUnmatchedRow) {
            $olderUnmatchedKey = [string]$olderUnmatchedRow.Message
            if (-not [string]::IsNullOrWhiteSpace($olderUnmatchedKey)) {
                $OlderUnmatchedLookup[$olderUnmatchedKey] = $olderUnmatchedRow
            }
        }
    }

    $OlderUnmatchedTotalForComparison = (Get-SafeIntSum -Items @($CoverageStatsOlder.UnmatchedGroupedLines) -PropertyName 'Count')
    if ($OlderUnmatchedTotalForComparison -lt 0) { $OlderUnmatchedTotalForComparison = 0 }

    $OlderUnmatchedCoverageDenominator = 0
    if ([int]$CoverageStatsOlder.MatchedEligible -gt 0 -and [int]$CoverageStatsOlder.UnmatchedEligible -gt 0) {
        $OlderUnmatchedCoverageDenominator = [int]([int]$CoverageStatsOlder.MatchedEligible + [int]$CoverageStatsOlder.UnmatchedEligible)
    }
    elseif ([int]$CoverageStatsOlder.TotalEligible -gt 0) {
        $OlderUnmatchedCoverageDenominator = [int]$CoverageStatsOlder.TotalEligible
    }

    $RecentUnmatchedOccurrenceDenominator = 0
    if ([int]$CoverageStats72Hours.MatchedEligible -gt 0 -and [int]$CoverageStats72Hours.UnmatchedEligible -gt 0) {
        $RecentUnmatchedOccurrenceDenominator = [int]([int]$CoverageStats72Hours.MatchedEligible + [int]$CoverageStats72Hours.UnmatchedEligible)
    }
    elseif ([int]$CoverageStats72Hours.TotalEligible -gt 0) {
        $RecentUnmatchedOccurrenceDenominator = [int]$CoverageStats72Hours.TotalEligible
    }

    $OlderMatchLookup = @{}
    foreach ($olderMatchRow in @($olderMatches)) {
        if ($null -ne $olderMatchRow) {
            $olderKey = [string]$olderMatchRow.Message
            if (-not [string]::IsNullOrWhiteSpace($olderKey)) {
                $OlderMatchLookup[$olderKey] = $olderMatchRow
            }
        }
    }

    $OlderPieTotalForComparison = (Get-SafeIntSum -Items @($olderMatches) -PropertyName 'PieFrequency')
    if ($OlderPieTotalForComparison -lt 0) { $OlderPieTotalForComparison = 0 }

    $OlderCoverageDenominator = 0
    if ($OlderPieTotalForComparison -gt 0 -and [int]$CoverageStatsOlder.UnmatchedEligible -gt 0) {
        $OlderCoverageDenominator = [int]($OlderPieTotalForComparison + [int]$CoverageStatsOlder.UnmatchedEligible)
    }
    elseif ([int]$CoverageStatsOlder.TotalEligible -gt 0) {
        $OlderCoverageDenominator = [int]$CoverageStatsOlder.TotalEligible
    }

    $RecentMatchLookup = @{}
    foreach ($recentMatchRow in @($recentMatches)) {
        if ($null -ne $recentMatchRow) {
            $recentKey = [string]$recentMatchRow.Message
            if (-not [string]::IsNullOrWhiteSpace($recentKey)) {
                $RecentMatchLookup[$recentKey] = $recentMatchRow
            }
        }
    }

    $RecentPieTotalForComparison = (Get-SafeIntSum -Items @($recentMatches) -PropertyName 'PieFrequency')
    if ($RecentPieTotalForComparison -lt 0) { $RecentPieTotalForComparison = 0 }

    $RecentCoverageDenominator = 0
    if ($RecentPieTotalForComparison -gt 0 -and [int]$CoverageStats72Hours.UnmatchedEligible -gt 0) {
        $RecentCoverageDenominator = [int]($RecentPieTotalForComparison + [int]$CoverageStats72Hours.UnmatchedEligible)
    }
    elseif ([int]$CoverageStats72Hours.TotalEligible -gt 0) {
        $RecentCoverageDenominator = [int]$CoverageStats72Hours.TotalEligible
    }

    $RecentUnmatchedLookup = @{}
    foreach ($recentUnmatchedRow in @($CoverageStats72Hours.UnmatchedGroupedLines)) {
        if ($null -ne $recentUnmatchedRow) {
            $recentUnmatchedKey = [string]$recentUnmatchedRow.Message
            if (-not [string]::IsNullOrWhiteSpace($recentUnmatchedKey)) {
                $RecentUnmatchedLookup[$recentUnmatchedKey] = $recentUnmatchedRow
            }
        }
    }
    $allBreakdownStats = Get-MatchBreakdownStats -MatchSummaries @($allMatchesForBreakdown) -EligibleMatchedCount ([int]$CoverageStats.MatchedEligible)

    if ($CheckCalc) {
        Invoke-CalculationChecks -CoverageStats72Hours $CoverageStats72Hours -CoverageStatsOlder $CoverageStatsOlder -RecentBreakdownStats $recentBreakdownStats -OlderBreakdownStats $olderBreakdownStats -RecentMatches @($recentMatches) -OlderMatches @($olderMatches) -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -AnalyzedLogRoot $LogRoot -LogFilesAnalyzed (@($logFiles).Count) -CheckCalcMaxAttempts $CheckCalcMaxAttempts
        return
    }

    $range72Text = 'Reviewed date range: unavailable'
    if ($AnchorTimestamp -and $WindowStart72Hours) {
        $range72Text = 'Reviewed date range: ' + $WindowStart72Hours.ToString('yyyy-MM-dd HH:mm:ss') + ' -> ' + $AnchorTimestamp.ToString('yyyy-MM-dd HH:mm:ss')
    }

    $olderRangeStart = Get-EarliestTimestampFromLogFiles -LogRoot $LogRoot -WindowStart $WindowStart72Hours -IncludeOlderThanWindowStart
    $olderRangeEnd = $null
    if ($WindowStart72Hours) {
        $olderRangeEnd = $WindowStart72Hours
    }
    elseif ($CoverageStatsOlder -and $CoverageStatsOlder.PSObject.Properties.Name -contains 'LatestTimestamp' -and $CoverageStatsOlder.LatestTimestamp) {
        $olderRangeEnd = $CoverageStatsOlder.LatestTimestamp
    }

    if (-not $olderRangeStart) {
        $olderAllTimes = @()
        foreach ($m in @($olderMatches)) {
            if ($m -and $m.PSObject.Properties.Name -contains 'LastSeen' -and $m.LastSeen) {
                $olderAllTimes += @($m.LastSeen)
            }
        }
        foreach ($u in @($CoverageStatsOlder.UnmatchedGroupedLines)) {
            if ($u -and $u.PSObject.Properties.Name -contains 'LastSeen' -and $u.LastSeen) {
                $olderAllTimes += @($u.LastSeen)
            }
        }
        if (@($olderAllTimes).Count -gt 0) {
            $olderRangeStart = (@($olderAllTimes) | Sort-Object | Select-Object -First 1)
        }
    }

    $olderRangeText = 'Older than 72hr reviewed date range: unavailable'
    $olderStartText = 'Older than 72hr start date: unavailable'
    $olderEndText = 'Older than 72hr end date: unavailable'
    if ($olderRangeStart) {
        $olderStartText = 'Older than 72hr start date: ' + $olderRangeStart.ToString('yyyy-MM-dd HH:mm:ss')
    }
    if ($olderRangeEnd) {
        $olderEndText = 'Older than 72hr end date: ' + $olderRangeEnd.ToString('yyyy-MM-dd HH:mm:ss')
    }
    if ($olderRangeStart -and $olderRangeEnd) {
        $olderRangeText = 'Older than 72hr reviewed date range: ' + $olderRangeStart.ToString('yyyy-MM-dd HH:mm:ss') + ' -> ' + $olderRangeEnd.ToString('yyyy-MM-dd HH:mm:ss')
    }
    elseif ($olderRangeStart) {
        $olderRangeText = 'Older than 72hr reviewed date range start: ' + $olderRangeStart.ToString('yyyy-MM-dd HH:mm:ss')
    }

    $AllTimeTotalEligible = 0
    try {
        $AllTimeTotalEligible = [int](($CoverageStats72Hours.TotalEligible) + ($CoverageStatsOlder.TotalEligible))
    }
    catch {
        $AllTimeTotalEligible = 0
    }

    if ($AnchorTimestamp -and $WindowStart72Hours) {
        $sub = 'Last 72 hours based on the most recent parsed log timestamp: ' + $AnchorTimestamp.ToString('yyyy-MM-dd HH:mm:ss') + '. Window start: ' + $WindowStart72Hours.ToString('yyyy-MM-dd HH:mm:ss') + ' | ' + $range72Text
        [void]$sb.AppendLine('<div id="summary-72h"></div>')
        Render-CoveragePanelHtml -Builder $sb -Title 'Indexed Coverage of Error/Failure-Type Log Lines (Last 72 Hours)' -CoverageStats $CoverageStats72Hours -Subtitle $sub -MatchBreakdown $recentBreakdownStats -SectionId 'summary-72h'
    }
    else {
        [void]$sb.AppendLine('<div id="summary-72h"></div>')
        Render-CoveragePanelHtml -Builder $sb -Title 'Indexed Coverage of Error/Failure-Type Log Lines (Last 72 Hours)' -CoverageStats $CoverageStats72Hours -Subtitle ('No parsed timestamps were available to calculate a 72-hour window. | ' + $range72Text) -MatchBreakdown $recentBreakdownStats -SectionId 'summary-72h'
    }
    Render-TopFrequentErrorsHtml -Builder $sb -GroupedLines @($CoverageStats72Hours.UnmatchedGroupedLines) -Title 'Last 72 Hours - Top 3 Unknown' -SectionId 'top-errors' -Subtitle $range72Text -TotalMessagesDenominator $AllTimeTotalEligible
    Render-MatchedSectionsHtml -Builder $sb -Matches @($recentMatches) -Title 'Last 72 Hours - Matches' -SectionId 'recent-matches' -PercentDenominator $CoverageStats72Hours.TotalEligible -SummaryPercentNumerator $CoverageStats72Hours.UnmatchedEligible -ComparisonLookup $OlderMatchLookup -ComparisonDenominator $OlderCoverageDenominator -ComparisonPieTotal $OlderPieTotalForComparison -ComparisonLabel '% 72hr+ Coverage'
    Render-UnmatchedGroupsHtml -Builder $sb -GroupedLines @($CoverageStats72Hours.UnmatchedGroupedLines) -Title 'Last 72 Hours - Non-Matches' -SectionId 'recent-unmatched' -TotalMessagesDenominator $AllTimeTotalEligible -ComparisonLookup $OlderUnmatchedLookup -ComparisonDenominator $OlderUnmatchedCoverageDenominator -ComparisonTotal $OlderUnmatchedTotalForComparison -ComparisonLabel '% 72hr+ Coverage' -OccurrenceDenominator $RecentUnmatchedOccurrenceDenominator

    [void]$sb.AppendLine('<div id="summary-older"></div>')
    Render-CoveragePanelHtml -Builder $sb -Title 'Indexed Coverage of Error/Failure-Type Log Lines (Older Than 72 Hours)' -CoverageStats $CoverageStatsOlder -Subtitle ('Filtered to entries older than the 72-hour window. | ' + $olderRangeText + ' | ' + $olderStartText + ' | ' + $olderEndText) -MatchBreakdown $olderBreakdownStats -SectionId 'summary-older'

    [void]$sb.AppendLine('<div class="section" id="older-summary">')
    [void]$sb.AppendLine('<h2>Anything Older Than 72 Hours</h2>')
    [void]$sb.AppendLine('<div class="small">Older than the 72-hour window anchored to the most recent parsed log timestamp. The two sections below are collapsed by default.</div>')
    [void]$sb.AppendLine('<div class="small">' + (HtmlEscape $olderRangeText) + '</div>')
    [void]$sb.AppendLine('<div class="small">' + (HtmlEscape $olderStartText) + '</div>')
    [void]$sb.AppendLine('<div class="small">' + (HtmlEscape $olderEndText) + '</div>')
    [void]$sb.AppendLine('</div>')

    Render-TopFrequentErrorsHtml -Builder $sb -GroupedLines @($CoverageStatsOlder.UnmatchedGroupedLines) -Title 'Older Than 72 Hours - Top 3 Unknown' -SectionId 'older-top-errors' -Subtitle ($olderRangeText + ' | ' + $olderStartText + ' | ' + $olderEndText) -TotalMessagesDenominator $AllTimeTotalEligible
    Render-MatchedSectionsHtml -Builder $sb -Matches @($olderMatches) -Title 'Anything Older / 72hr+ - Matches' -SectionId 'older-matches' -PercentDenominator $CoverageStatsOlder.TotalEligible -SummaryPercentNumerator $CoverageStatsOlder.UnmatchedEligible -ComparisonLookup @{} -ComparisonDenominator $CoverageStatsOlder.TotalEligible -ComparisonPieTotal $CoverageStatsOlder.MatchedEligible -ComparisonLabel '% total messages 72hr+'
    Render-UnmatchedGroupsHtml -Builder $sb -GroupedLines @($CoverageStatsOlder.UnmatchedGroupedLines) -Title 'Anything Older / 72hr+ - Non-Matches' -SectionId 'older-unmatched' -TotalMessagesDenominator $AllTimeTotalEligible -ComparisonLookup @{} -ComparisonDenominator $CoverageStatsOlder.TotalEligible -ComparisonTotal $CoverageStatsOlder.UnmatchedEligible -ComparisonLabel '% of total messages 72hr+' -OccurrenceDenominator $OlderUnmatchedCoverageDenominator

    [void]$sb.AppendLine('<script>(function(){' +
'var flyout=document.getElementById("hover-preview-flyout");var tileHint=document.getElementById("tile-hover-hint");if(!flyout){return;}' +
'function move(ev){if(flyout.style.display!=="block"){return;}var ox=18,oy=18,p=12;var x=ev.clientX+ox,y=ev.clientY+oy;var r=flyout.getBoundingClientRect();if(x+r.width+p>window.innerWidth){x=Math.max(p,ev.clientX-r.width-ox);}if(y+r.height+p>window.innerHeight){y=Math.max(p,ev.clientY-r.height-oy);}flyout.style.left=x+"px";flyout.style.top=y+"px";}' +
'function moveHint(ev){if(!tileHint||tileHint.style.display!=="block"){return;}var x=ev.clientX+14,y=ev.clientY+14;tileHint.style.left=x+"px";tileHint.style.top=y+"px";}' +
'function clearActive(){document.querySelectorAll(".hover-preview-row.is-active").forEach(function(r){r.classList.remove("is-active");});}' +
'function flashTarget(target){if(!target){return;}target.classList.add("jump-target-flash");setTimeout(function(){target.classList.remove("jump-target-flash");},1800);}' +
'function openTargetById(targetId,row){if(!targetId){return;}var target=document.getElementById(targetId);if(!target){return;}clearActive();if(row&&row.classList&&row.classList.contains("hover-preview-row")){row.classList.add("is-active");}var parent=target.parentElement;while(parent){if(parent.tagName&&parent.tagName.toLowerCase()==="details"){parent.open=true;}parent=parent.parentElement;}if(target.tagName&&target.tagName.toLowerCase()==="details"){target.open=true;}target.scrollIntoView({behavior:"smooth",block:"start"});flashTarget(target);}' +
'function openTarget(row){openTargetById(row.getAttribute("data-target-id"),row);}' +
'document.querySelectorAll(".hover-preview-row").forEach(function(row){row.addEventListener("mouseenter",function(ev){row.classList.add("is-hovered");var src=row.querySelector(".hover-preview-source");if(!src){return;}flyout.innerHTML=src.innerHTML;flyout.style.display="block";move(ev);});row.addEventListener("mousemove",move);row.addEventListener("mouseleave",function(){row.classList.remove("is-hovered");flyout.style.display="none";});row.addEventListener("click",function(ev){if(ev.target&&ev.target.closest("a")){return;}openTarget(row);});});' +
'function firstExistingId(ids){for(var i=0;i<ids.length;i++){if(document.getElementById(ids[i])){return ids[i];}}return null;}' +
'function firstIdByPrefix(prefix){var el=document.querySelector("[id^=\"" + prefix + "\"]");return el?el.id:null;}' +
'function resolveTileTarget(tile){var targetId=tile.getAttribute("data-target-id");var href=tile.getAttribute("href")||"";var labelEl=tile.querySelector(".stat-label");var label=labelEl?labelEl.textContent:"";var inOlder=!!(tile.closest&&tile.closest("#summary-older"));if(!targetId&&href.charAt(0)==="#"){targetId=href.substring(1);}if(inOlder){var isUnmatched=/unmatched|not indexed|total unmatched/i.test(label);var isMatched=/matched|indexed|total matched/i.test(label)&&!isUnmatched;if(isMatched){targetId=firstExistingId(["older-matches-detail-1","older-matches"])||firstIdByPrefix("older-matches-detail-")||"older-matches";}else if(isUnmatched){targetId=firstIdByPrefix("older-unmatched-detail-")||firstExistingId(["older-unmatched","older-top-errors"])||"older-unmatched";}}return targetId;}' +
'document.querySelectorAll(".js-tile-hover").forEach(function(tile){tile.addEventListener("mouseenter",function(ev){if(!tileHint){return;}tileHint.textContent=tile.getAttribute("data-hint")||"Click for details";tileHint.style.display="block";moveHint(ev);tile.classList.add("is-hovered");});tile.addEventListener("mousemove",moveHint);tile.addEventListener("mouseleave",function(){if(tileHint){tileHint.style.display="none";}tile.classList.remove("is-hovered");});tile.addEventListener("click",function(ev){var targetId=resolveTileTarget(tile);if(targetId){ev.preventDefault();openTargetById(targetId,null);} });});' +
'document.addEventListener("scroll",function(){flyout.style.display="none";if(tileHint){tileHint.style.display="none";}},true);' +
'})();</script>')
    [void]$sb.AppendLine('</body></html>')

    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($sb.ToString())
    [System.IO.File]::WriteAllBytes($htmlPath, $bytes)

    Write-LogInfo ("HTML report written to: {0}" -f $htmlPath)

    if ($Global:MsgCorrelatorOpenHtml) {
        try { Start-Process $htmlPath } catch { Write-LogWarn "Failed to open HTML report automatically: $($_.Exception.Message)" }
    } else {
        Write-LogInfo "HTML auto-generation requested; report was not opened automatically."
    }
}

# -----------------------------
# Correlation routine
# -----------------------------


function Write-CheckCalcTextLog {
    param([string]$Path,[string]$Message)
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
        Add-Content -LiteralPath $Path -Value $Message -Encoding UTF8
    } catch {}
}

function Write-CheckCalcJsonLog {
    param([string]$Path,[hashtable]$Data)
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
        Add-Content -LiteralPath $Path -Value ($Data | ConvertTo-Json -Compress -Depth 8) -Encoding UTF8
    } catch {}
}

function Get-CheckCalcEscalationStatus {
    param(
        [string]$CheckCalcJsonLogPath,
        [int]$MaxAttempts = 10
    )

    if ([string]::IsNullOrWhiteSpace($CheckCalcJsonLogPath)) { return $null }
    if (-not (Test-Path -LiteralPath $CheckCalcJsonLogPath)) { return $null }

    $events = @()
    try {
        $lines = @(Get-Content -LiteralPath $CheckCalcJsonLogPath -ErrorAction SilentlyContinue)
        foreach ($line in @($lines)) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            try { $events += ($line | ConvertFrom-Json) } catch {}
        }
    } catch {}

    $failedChecks = @($events | Where-Object { $_.event -eq 'check' -and $_.status -eq 'FAIL' })
    if ($failedChecks.Count -eq 0) { return $null }

    $latest = $failedChecks[-1]
    $signature = ('{0}|{1}' -f $latest.section, $latest.name)
    $sameFailures = @($failedChecks | Where-Object { ('{0}|{1}' -f $_.section, $_.name) -eq $signature })

    $attempts = $sameFailures.Count
    if ($attempts -lt $MaxAttempts) {
        return [pscustomobject]@{
            Escalate  = $false
            Attempts  = $attempts
            Signature = $signature
        }
    }

    $recent = @($sameFailures | Select-Object -Last $MaxAttempts)
    $firstDelta = 0.0
    $lastDelta  = 0.0
    try { $firstDelta = [math]::Abs(([double]$recent[0].right) - ([double]$recent[0].left)) } catch {}
    try { $lastDelta  = [math]::Abs(([double]$recent[-1].right) - ([double]$recent[-1].left)) } catch {}

    $trend = 'NO_IMPROVEMENT'
    if ($lastDelta -lt $firstDelta) { $trend = 'IMPROVING' }
    elseif ($lastDelta -gt $firstDelta) { $trend = 'WORSE' }

    $reason = ('Same failing check hit {0} times.' -f $attempts)
    if ($trend -eq 'NO_IMPROVEMENT') {
        $reason = ('Same failing check hit {0} times without improvement.' -f $attempts)
    } elseif ($trend -eq 'WORSE') {
        $reason = ('Same failing check hit {0} times and the mismatch got worse.' -f $attempts)
    } elseif ($trend -eq 'IMPROVING') {
        $reason = ('Same failing check hit {0} times and improved, but still does not pass.' -f $attempts)
    }

    $delta = 0.0
    try { $delta = [math]::Abs(([double]$latest.right) - ([double]$latest.left)) } catch {}

    return [pscustomobject]@{
        Escalate = $true
        Attempts = $attempts
        Section  = [string]$latest.section
        Check    = [string]$latest.name
        Left     = $latest.left
        Right    = $latest.right
        Delta    = $delta
        Trend    = $trend
        Reason   = $reason
    }
}

function Get-SectionCalculationCheck {
    param(
        [Parameter(Mandatory = $true)][string]$SectionName,
        [psobject]$CoverageStats,
        [psobject]$MatchBreakdown,
        [object[]]$MatchSummaries = @(),
        [object[]]$UnmatchedGroupedLines = @()
    )

    if (-not $CoverageStats) {
        $CoverageStats = [pscustomobject]@{
            TotalEligible         = 0
            MatchedEligible       = 0
            UnmatchedEligible     = 0
            UnmatchedGroupCount   = 0
            UnmatchedGroupedLines = @()
        }
    }
    if (-not $MatchBreakdown) {
        $MatchBreakdown = [pscustomobject]@{
            EligibleMatchedInChart      = [int]$CoverageStats.MatchedEligible
            MatchedGroupsInChart        = 0
            InformationalOrOtherMatched = 0
            TotalMatchedShownInTables   = 0
        }
    }

    $tablePieTotal = (Get-SafeIntSum -Items @($MatchSummaries) -PropertyName 'PieFrequency')
    if ($tablePieTotal -lt 0) { $tablePieTotal = 0 }
    $tableOtherTotal = (Get-SafeIntSum -Items @($MatchSummaries) -PropertyName 'OtherFrequency')
    if ($tableOtherTotal -lt 0) { $tableOtherTotal = 0 }
    $tableMatchTotal = (Get-SafeIntSum -Items @($MatchSummaries) -PropertyName 'Frequency')
    if ($tableMatchTotal -lt 0) { $tableMatchTotal = 0 }

    $tableUnmatchedGroupTotal = @($UnmatchedGroupedLines).Count
    $tableUnmatchedOccurrenceTotal = (Get-SafeIntSum -Items @($UnmatchedGroupedLines) -PropertyName 'Count')
    if ($tableUnmatchedOccurrenceTotal -lt 0) { $tableUnmatchedOccurrenceTotal = 0 }

    $pieOccurrenceMatched = [int]$(if ($MatchBreakdown.PSObject.Properties.Name -contains 'EligibleMatchedInChart') { $MatchBreakdown.EligibleMatchedInChart } else { $CoverageStats.MatchedEligible })
    $pieOccurrenceUnmatched = [int]$CoverageStats.UnmatchedEligible
    $pieGroupMatched = [int]$(if ($MatchBreakdown.PSObject.Properties.Name -contains 'MatchedGroupsInChart') { $MatchBreakdown.MatchedGroupsInChart } else { 0 })
    $pieGroupUnmatched = [int]$(if ($CoverageStats.PSObject.Properties.Name -contains 'UnmatchedGroupCount') { $CoverageStats.UnmatchedGroupCount } else { @($UnmatchedGroupedLines).Count })

    $checks = @(
        [pscustomobject]@{ Name='Occurrence pie matched equals match table PieFrequency total'; Left=$pieOccurrenceMatched; Right=$tablePieTotal; Pass=($pieOccurrenceMatched -eq $tablePieTotal) },
        [pscustomobject]@{ Name='Occurrence pie unmatched equals non-match occurrence total'; Left=$pieOccurrenceUnmatched; Right=$tableUnmatchedOccurrenceTotal; Pass=($pieOccurrenceUnmatched -eq $tableUnmatchedOccurrenceTotal) },
        [pscustomobject]@{ Name='Group pie unmatched equals non-match group count'; Left=$pieGroupUnmatched; Right=$tableUnmatchedGroupTotal; Pass=($pieGroupUnmatched -eq $tableUnmatchedGroupTotal) },
        [pscustomobject]@{ Name='Match table total equals PieFrequency + OtherFrequency'; Left=$tableMatchTotal; Right=($tablePieTotal + $tableOtherTotal); Pass=($tableMatchTotal -eq ($tablePieTotal + $tableOtherTotal)) },
        [pscustomobject]@{ Name='Coverage eligible total equals matched + unmatched occurrences'; Left=[int]$CoverageStats.TotalEligible; Right=($pieOccurrenceMatched + $pieOccurrenceUnmatched); Pass=([int]$CoverageStats.TotalEligible -eq ($pieOccurrenceMatched + $pieOccurrenceUnmatched)) }
    )

    [pscustomobject]@{
        SectionName                   = $SectionName
        PieOccurrenceMatched          = $pieOccurrenceMatched
        TablePieTotal                 = $tablePieTotal
        PieOccurrenceUnmatched        = $pieOccurrenceUnmatched
        TableUnmatchedOccurrenceTotal = $tableUnmatchedOccurrenceTotal
        PieGroupMatched               = $pieGroupMatched
        PieGroupUnmatched             = $pieGroupUnmatched
        TableUnmatchedGroupTotal      = $tableUnmatchedGroupTotal
        TableOtherTotal               = $tableOtherTotal
        TableMatchTotal               = $tableMatchTotal
        CoverageTotalEligible         = [int]$CoverageStats.TotalEligible
        Checks                        = @($checks)
        Passed                        = (@($checks | Where-Object { -not $_.Pass }).Count -eq 0)
    }
}


function Invoke-CalculationChecks {
    param(
        [psobject]$CoverageStats72Hours,
        [psobject]$CoverageStatsOlder,
        [psobject]$RecentBreakdownStats,
        [psobject]$OlderBreakdownStats,
        [object[]]$RecentMatches = @(),
        [object[]]$OlderMatches = @(),
        [string]$CheckCalcLogPath,
        [string]$CheckCalcJsonLogPath,
        [string]$AnalyzedLogRoot,
        [int]$LogFilesAnalyzed = 0,
        [int]$CheckCalcMaxAttempts = 10
    )

    $runTs = Get-Date
    $runId = $runTs.ToString('yyyy-MM-ddTHH:mm:ss.fffK')
    $attemptNumber = 1
    $recheckNumber = 1

    if (-not [string]::IsNullOrWhiteSpace($CheckCalcJsonLogPath) -and (Test-Path -LiteralPath $CheckCalcJsonLogPath)) {
        try {
            $existingLines = @(Get-Content -LiteralPath $CheckCalcJsonLogPath -ErrorAction SilentlyContinue)
            $priorResults = @($existingLines | Where-Object { $_ -match '"event":"run_result"' })
            if ($priorResults.Count -gt 0) {
                $attemptNumber = $priorResults.Count + 1
                $recheckNumber = $priorResults.Count + 1
            }
        } catch {}
    } elseif (-not [string]::IsNullOrWhiteSpace($CheckCalcLogPath) -and (Test-Path -LiteralPath $CheckCalcLogPath)) {
        try {
            $priorStarts = @(Get-Content -LiteralPath $CheckCalcLogPath -ErrorAction SilentlyContinue | Where-Object { $_ -match 'RUN_START' })
            if ($priorStarts.Count -gt 0) {
                $attemptNumber = $priorStarts.Count + 1
                $recheckNumber = $priorStarts.Count + 1
            }
        } catch {}
    }

    $results = @(
        (Get-SectionCalculationCheck -SectionName 'Last 72 Hours' -CoverageStats $CoverageStats72Hours -MatchBreakdown $RecentBreakdownStats -MatchSummaries @($RecentMatches) -UnmatchedGroupedLines @($CoverageStats72Hours.UnmatchedGroupedLines)),
        (Get-SectionCalculationCheck -SectionName 'Older Than 72 Hours' -CoverageStats $CoverageStatsOlder -MatchBreakdown $OlderBreakdownStats -MatchSummaries @($OlderMatches) -UnmatchedGroupedLines @($CoverageStatsOlder.UnmatchedGroupedLines))
    )

    $anyFail = $false
    $totalChecks = 0
    $passCount = 0
    $failCount = 0

    Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] RUN_START Attempt={1} Recheck={2} LogRoot={3}' -f $runTs.ToString('yyyy-MM-dd HH:mm:ss'), $attemptNumber, $recheckNumber, $AnalyzedLogRoot)
    Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] LOG_FILES_ANALYZED={1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $LogFilesAnalyzed)
    Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
        ts = $runId; event = 'run_start'; attempt = $attemptNumber; recheck = $recheckNumber; log_root = $AnalyzedLogRoot; log_files_analyzed = $LogFilesAnalyzed
    }

    Write-Host ''
    Write-Host 'CHECKCALC_RESULTS_BEGIN' -ForegroundColor Cyan

    foreach ($section in @($results)) {
        Write-Host ''
        Write-Host ('SECTION=' + $section.SectionName) -ForegroundColor Yellow
        Write-Host ('VALUE|PieOccurrenceMatched|{0}' -f $section.PieOccurrenceMatched)
        Write-Host ('VALUE|TablePieTotal|{0}' -f $section.TablePieTotal)
        Write-Host ('VALUE|PieOccurrenceUnmatched|{0}' -f $section.PieOccurrenceUnmatched)
        Write-Host ('VALUE|TableUnmatchedOccurrenceTotal|{0}' -f $section.TableUnmatchedOccurrenceTotal)
        Write-Host ('VALUE|PieGroupMatched|{0}' -f $section.PieGroupMatched)
        Write-Host ('VALUE|PieGroupUnmatched|{0}' -f $section.PieGroupUnmatched)
        Write-Host ('VALUE|TableUnmatchedGroupTotal|{0}' -f $section.TableUnmatchedGroupTotal)
        Write-Host ('VALUE|TableOtherTotal|{0}' -f $section.TableOtherTotal)
        Write-Host ('VALUE|TableMatchTotal|{0}' -f $section.TableMatchTotal)
        Write-Host ('VALUE|CoverageTotalEligible|{0}' -f $section.CoverageTotalEligible)

        Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] SECTION={1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $section.SectionName)
        Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
            ts=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'); event='section_start'; section=$section.SectionName;
            values=@{
                PieOccurrenceMatched=$section.PieOccurrenceMatched; TablePieTotal=$section.TablePieTotal; PieOccurrenceUnmatched=$section.PieOccurrenceUnmatched;
                TableUnmatchedOccurrenceTotal=$section.TableUnmatchedOccurrenceTotal; PieGroupMatched=$section.PieGroupMatched; PieGroupUnmatched=$section.PieGroupUnmatched;
                TableUnmatchedGroupTotal=$section.TableUnmatchedGroupTotal; TableOtherTotal=$section.TableOtherTotal; TableMatchTotal=$section.TableMatchTotal; CoverageTotalEligible=$section.CoverageTotalEligible
            }
        }

        foreach ($check in @($section.Checks)) {
            $totalChecks++
            $status = 'PASS'
            if (-not $check.Pass) {
                $status = 'FAIL'
                $anyFail = $true
                $failCount++
            } else {
                $passCount++
            }

            Write-Host ('CHECK|{0}|{1}|{2}|{3}' -f $status, $check.Name, $check.Left, $check.Right) -ForegroundColor $(if ($check.Pass) { 'Green' } else { 'Red' })
            Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] {1} {2} {3} {4}|{5}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $status, $section.SectionName, $check.Name, $check.Left, $check.Right)
            Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
                ts=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'); event='check'; section=$section.SectionName; status=$status; name=$check.Name; left=$check.Left; right=$check.Right
            }
        }

        $sectionStatus = $(if ($section.Passed) { 'PASS' } else { 'FAIL' })
        Write-Host ('SECTION_RESULT|{0}|{1}' -f $section.SectionName, $sectionStatus) -ForegroundColor $(if ($section.Passed) { 'Green' } else { 'Red' })
        Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] SECTION_RESULT {1} {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $section.SectionName, $sectionStatus)
        Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
            ts=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'); event='section_result'; section=$section.SectionName; status=$sectionStatus
        }
    }

    Write-Host ''
    $overallStatus = 'PASS'
    if ($anyFail) {
        $overallStatus = 'FAIL'
        Write-Host 'CHECKCALC_OVERALL=FAIL' -ForegroundColor Red
        $Global:CSExitCode = 1
    } else {
        Write-Host 'CHECKCALC_OVERALL=PASS' -ForegroundColor Green
        $Global:CSExitCode = 0
    }
    Write-Host 'CHECKCALC_RESULTS_END' -ForegroundColor Cyan

    Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] RUN_RESULT={1} TOTAL_CHECKS={2} PASS_COUNT={3} FAIL_COUNT={4}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $overallStatus, $totalChecks, $passCount, $failCount)
    Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
        ts=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'); event='run_result'; status=$overallStatus; total_checks=$totalChecks; pass_count=$passCount; fail_count=$failCount; attempt=$attemptNumber; recheck=$recheckNumber; log_root=$AnalyzedLogRoot; log_files_analyzed=$LogFilesAnalyzed
    }

    $escalation = Get-CheckCalcEscalationStatus -CheckCalcJsonLogPath $CheckCalcJsonLogPath -MaxAttempts $CheckCalcMaxAttempts
    if ($escalation -and $escalation.Escalate) {
        Write-Host ''
        Write-Host 'CHECKCALC_ESCALATION_BEGIN' -ForegroundColor Red
        Write-Host 'ESCALATE=TRUE'
        Write-Host ('ATTEMPTS={0}' -f $escalation.Attempts)
        Write-Host ('SECTION={0}' -f $escalation.Section)
        Write-Host ('CHECK={0}' -f $escalation.Check)
        Write-Host ('CURRENT_LEFT={0}' -f $escalation.Left)
        Write-Host ('CURRENT_RIGHT={0}' -f $escalation.Right)
        Write-Host ('DELTA={0}' -f $escalation.Delta)
        Write-Host ('TREND={0}' -f $escalation.Trend)
        Write-Host ('REASON={0}' -f $escalation.Reason)
        Write-Host 'RECOMMENDED_ACTION=Stop Cursor fixes and escalate to ChatGPT'
        Write-Host 'CHECKCALC_ESCALATION_END' -ForegroundColor Red

        Write-CheckCalcTextLog -Path $CheckCalcLogPath -Message ('[{0}] ESCALATION SECTION={1} CHECK={2} LEFT={3} RIGHT={4} ATTEMPTS={5} TREND={6} REASON={7}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $escalation.Section, $escalation.Check, $escalation.Left, $escalation.Right, $escalation.Attempts, $escalation.Trend, $escalation.Reason)
        Write-CheckCalcJsonLog -Path $CheckCalcJsonLogPath -Data @{
            ts=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'); event='escalation'; section=$escalation.Section; check=$escalation.Check; left=$escalation.Left; right=$escalation.Right; delta=$escalation.Delta; attempts=$escalation.Attempts; trend=$escalation.Trend; reason=$escalation.Reason
        }

        if ($Global:CSExitCode -eq 0) { $Global:CSExitCode = 2 }
    }
}

function Invoke-AgentCorrelation {
    param(
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [switch]$SkipHtmlPrompt,
        [switch]$CheckCalc,
        [string]$CheckCalcLogPath,
        [string]$CheckCalcJsonLogPath,
        [int]$CheckCalcMaxAttempts = 10
    )

    $now = Get-Date

    if (-not $Global:MsgCorrelatorQuiet) {
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  Agent Message Correlator' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''
        Write-LogInfo ("Local machine time: {0:u}" -f $now.ToUniversalTime())
        Write-Host ''
    }

    try {
        if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) { throw "Log root path does not exist: $LogRoot" }

        Write-LogInfo ("Enumerating *.log files under: {0}" -f $LogRoot)
        $logFiles = @(Get-ChildItem -Path $LogRoot -Filter *.log -File -Recurse -ErrorAction SilentlyContinue)
        if (-not $logFiles -or @($logFiles).Count -eq 0) { throw "No *.log files found under: $LogRoot" }
        Write-LogInfo ("Found {0} log file(s)." -f (@($logFiles).Count))

        $idxResult = Ensure-IndexFreshForCorrelation `
            -PrimaryUrl       $Global:MsgIndexPrimaryUrl `
            -SecondaryUrl     $Global:MsgIndexSecondaryUrl `
            -PrimaryHashUrl   $Global:MsgIndexPrimaryHashUrl `
            -SecondaryHashUrl $Global:MsgIndexSecondaryHashUrl `
            -LocalRoot        $Global:MsgIndexLocalRoot `
            -LocalFileName    $Global:MsgIndexLocalFileName

        $indexFile = $idxResult.Path
        $indexMeta = $idxResult.Metadata

        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host "------------------------------------------------------------"
            Write-Host "  Index Ready"
            Write-Host "------------------------------------------------------------"
        }
        Write-LogInfo ("Using index file: {0}" -f $indexFile)

        $csvPath = Get-IndexCsvPath -IndexFilePath $indexFile
        Write-LogInfo ("Importing CSV from: {0}" -f $csvPath)

        $patternEntries = @(Import-KnownIssuePatterns -Path $csvPath)

        Show-StartupSnapshot -LogRoot $LogRoot `
            -LogFileCount (@($logFiles).Count) `
            -IndexMeta $indexMeta `
            -CsvColumns $script:MsgIndexColumns `
            -PatternCount (@($patternEntries).Count)

        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host "------------------------------------------------------------"
            Write-Host "  Correlating Known Messages Against Agent Logs"
            Write-Host "------------------------------------------------------------"
        }

        $matchesSummary = @()
        $fileLineCache = @{}
        $matchedLineKeys = @{}

        foreach ($entry in $patternEntries) {
            try {
                $pattern = $entry.ErrorText
                if ([string]::IsNullOrWhiteSpace($pattern)) { continue }

                $patternMatches = Select-String -Path ($logFiles.FullName) -SimpleMatch -Pattern $pattern -ErrorAction SilentlyContinue
                if (-not $patternMatches) { continue }

                $count          = @($patternMatches).Count
                $lastSeen       = $null
                $severityCounts = @{}
                $timestamps     = New-Object 'System.Collections.Generic.List[datetime]'

                $latestCtx     = $null
                $latestKey     = $null

                foreach ($m in $patternMatches) {
                    $line = $m.Line

                    $matchedKey = ('{0}|{1}|{2}' -f $m.Path, $m.LineNumber, [string]$line)
                    if (-not $matchedLineKeys.ContainsKey($matchedKey)) {
                        $matchedLineKeys[$matchedKey] = [pscustomobject]@{
                            Pattern = [string]$pattern
                            CsvRow  = $entry.CsvRow
                        }
                    }

                    $sev = Get-SeverityFromLine -Line $line
                    if (-not $severityCounts.ContainsKey($sev)) { $severityCounts[$sev] = 0 }
                    $severityCounts[$sev]++

                    $ts = Get-LogLineTimestamp -Line $line
                    if ($ts) {
                        if (-not $lastSeen -or $ts -gt $lastSeen) { $lastSeen = $ts }
                        [void]$timestamps.Add($ts)
                    }

                    $fileTime = $null
                    try { $fileTime = (Get-Item -LiteralPath $m.Path -ErrorAction Stop).LastWriteTime } catch { $fileTime = $null }

                    if ($ts) {
                        $key = $ts
                    } elseif ($fileTime) {
                        $key = $fileTime.AddMilliseconds([Math]::Min(999, [int]($m.LineNumber % 1000)))
                    } else {
                        $key = [datetime]::MinValue
                    }

                    if (-not $latestKey -or $key -gt $latestKey) {
                        $latestKey = $key
                        try { $latestCtx = Get-LogContextSnippet -Cache $fileLineCache -Path $m.Path -LineNumber $m.LineNumber -Before 5 -After 5 }
                        catch { $latestCtx = $null }
                    }
                }

                $avgMinutes = $null
                $predicted  = $null

                if ($timestamps.Count -ge 2) {
                    $orderedTimes = $timestamps.ToArray() | Sort-Object
                    $totalDelta   = 0.0
                    for ($i = 1; $i -lt $orderedTimes.Length; $i++) {
                        $totalDelta += ($orderedTimes[$i] - $orderedTimes[$i-1]).TotalMinutes
                    }
                    $avgMinutes = $totalDelta / [double]($orderedTimes.Length - 1)
                    if ($lastSeen -and $avgMinutes -gt 0) { $predicted = $lastSeen.AddMinutes($avgMinutes) }
                }

                $timeAgo = $(if ($lastSeen) { Format-TimeAgo -LastTime $lastSeen -Now $now } else { 'N/A' })

                $sevOrder = @('FATAL','ERROR','EXCEPTION','FAIL','TIMEOUT','UNAUTHORIZED','ACCESS DENIED','WARN','WARNING','Unknown')
                $primarySeverity = 'Unknown'
                foreach ($s in $sevOrder) {
                    if ($severityCounts.ContainsKey($s) -and $severityCounts[$s] -gt 0) { $primarySeverity = $s; break }
                }

                $occurrences = @()
                foreach ($found in $patternMatches) {
                    $occTs = Get-LogLineTimestamp -Line $found.Line
                    $occurrences += [pscustomobject]@{
                        Path       = $found.Path
                        LineNumber = $found.LineNumber
                        Line       = $found.Line
                        Timestamp  = $occTs
                    }
                }

                $matchesSummary += [pscustomobject]@{
                    Severity              = $primarySeverity
                    SeverityBreakdown     = $severityCounts
                    Message               = $pattern
                    CsvRow                = $entry.CsvRow
                    Frequency             = $count
                    LastSeen              = $lastSeen
                    LastSeenAgo           = $timeAgo
                    AverageMinutesBetween = $avgMinutes
                    PredictedNext         = $predicted
                    LatestContext         = $latestCtx
                    Occurrences           = @($occurrences)
                }
            }
            catch {
                $patText = '<unknown>'
                try { $patText = [string]$entry.ErrorText } catch { }
                $lineNo = $null
                try { $lineNo = $_.InvocationInfo.ScriptLineNumber } catch { }
                Write-LogWarn ("Pattern processing failed" + $(if($lineNo){" at line $lineNo"}else{""}) + ": " + $_.Exception.Message + " | Pattern: " + $patText)
                continue
            }
        }

        $matchesSummary = @($matchesSummary)
        $coverageStats = Get-IndexedCoverageStats -LogFiles $logFiles -MatchedKeys $matchedLineKeys
        $anchorTimestamp = Get-LatestTimestampFromLogFiles -LogRoot $LogRoot
        $windowStart72Hours = $null
        $coverageStats72Hours = $null
        $coverageStatsOlder = $null
        if ($anchorTimestamp) {
            $windowStart72Hours = $anchorTimestamp.AddHours(-72)
            $coverageStats72Hours = Get-IndexedCoverageStats -LogFiles $logFiles -MatchedKeys $matchedLineKeys -WindowStart $windowStart72Hours -WindowEnd $anchorTimestamp
            $coverageStatsOlder = Get-IndexedCoverageStats -LogFiles $logFiles -MatchedKeys $matchedLineKeys -WindowStart $windowStart72Hours -IncludeOlderThanWindowStart
        }
        else {
            $coverageStats72Hours = [pscustomobject]@{ TotalEligible = 0; MatchedEligible = 0; MatchedGroupCount = 0; UnmatchedEligible = 0; UnmatchedGroupCount = 0; MatchedPercent = 0; UnmatchedPercent = 0; MatchedGroupPercent = 0; UnmatchedGroupPercent = 0; UnmatchedGroupedLines = @(); LatestTimestamp = $null }
            $coverageStatsOlder = $coverageStats
        }

        if (-not $matchesSummary -or @($matchesSummary).Count -eq 0) {
            if ($Global:MsgCorrelatorSilent -and $Global:MsgCorrelatorAutoHtml) {
                New-AgentMsgHtmlReport -Matches @() -IndexPath $csvPath -LogRoot $LogRoot -GeneratedAt $now -CoverageStats $coverageStats -CoverageStats72Hours $coverageStats72Hours -CoverageStatsOlder $coverageStatsOlder -AnchorTimestamp $anchorTimestamp -WindowStart72Hours $windowStart72Hours -EligibleMatchedKeys $matchedLineKeys -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts -LogFilesAnalyzed $logFiles
            }
            if (-not $Global:MsgCorrelatorSilent -and -not $Global:MsgCorrelatorQuiet) {
                Write-Host ''
                Write-Host "------------------------------------------------------------"
                Write-Host "  No matches from the index were found in the agent logs."
                Write-Host "------------------------------------------------------------"
            }
            if ($Global:MsgCorrelatorSilent) {
                exit 0
            }
            return
        }

        if (-not $Global:MsgCorrelatorSilent) {
            Write-Host ''
            Write-Host '============================================================'
            Write-Host '  All Matched Messages (Any Age) with Frequency'
            Write-Host '============================================================'
            Write-Host ''
        }

        $allSorted = $matchesSummary | Sort-Object -Property @{Expression='Frequency';Descending=$true}, @{Expression='LastSeen';Descending=$true}

        if (-not $Global:MsgCorrelatorSilent) {
            $allSorted |
                Select-Object Severity,
                    Frequency,
                    @{Name='LastSeen';Expression={ if ($_.LastSeen) { $_.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                    @{Name='LastSeenAgo';Expression={ $_.LastSeenAgo }},
                    @{Name='PredictedNext';Expression={ if ($_.PredictedNext) { $_.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                    @{Name='AvgMinutesBetween';Expression={
                        if ($_.AverageMinutesBetween -ne $null -and $_.AverageMinutesBetween -gt 0) { [Math]::Round([double]$_.AverageMinutesBetween,2) } else { $null }
                    }},
                    @{Name='Message';Expression={ $_.Message }} |
                Format-Table -AutoSize
        }

        if (-not $Global:MsgCorrelatorSilent) {
            Write-Host ''
            Write-Host '============================================================'
            Write-Host '  Detailed Matched Messages'
            Write-Host '============================================================'
            Write-Host ''
        }

        $indexCounter = 0
        if (-not $Global:MsgCorrelatorSilent) {
            foreach ($item in $allSorted) {
                $indexCounter++

                $lastSeenText = $(if ($item.LastSeen) { $item.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' })
                $predText = $(if ($item.PredictedNext) { $item.PredictedNext.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' })
                $avgText = $(if ($item.AverageMinutesBetween -ne $null -and $item.AverageMinutesBetween -gt 0) {
                    [Math]::Round([double]$item.AverageMinutesBetween,2).ToString()
                } else { 'N/A' })

                $sevColor = Get-SeverityColor -Severity $item.Severity

                Write-Host '============================================================' -ForegroundColor DarkGray
                Write-Host ("Match #{0}" -f $indexCounter) -ForegroundColor Gray
                Write-Host ("[{0}]  Count: {1}" -f $item.Severity, $item.Frequency) -ForegroundColor $sevColor
                Write-Host ("    Last: {0} ({1})" -f $lastSeenText, $item.LastSeenAgo) -ForegroundColor $sevColor
                Write-Host ("    Average gap between events: {0} minute(s)" -f $avgText) -ForegroundColor Cyan
                Write-Host ("    Predicted Reoccurrence: {0}" -f $predText) -ForegroundColor Green
                Write-Host '============================================================' -ForegroundColor DarkGray
                Write-Host ("MATCH: {0}" -f $item.Message) -ForegroundColor Cyan
                Write-Host ''
                Write-Host 'Matching Details:' -ForegroundColor Green
                Show-CsvRowDetails -Row $item.CsvRow
                Write-Host ''

                if ($item.LatestContext) {
                    Write-Host 'Most Recent Occurrence (match line with 5 lines before/after):' -ForegroundColor Yellow
                    $ctx = $item.LatestContext
                    Write-Host ("  File: {0}" -f $ctx.Path) -ForegroundColor Gray
                    Write-Host ("  Line: {0}" -f $ctx.MatchLine) -ForegroundColor Gray
                    foreach ($ln in @($ctx.Lines)) {
                        $prefix = "{0,6}: " -f $ln.LineNumber
                        if ($ln.IsMatch) {
                            Write-Host ($prefix + $ln.Text) -ForegroundColor Red
                        } else {
                            Write-Host ($prefix + $ln.Text) -ForegroundColor DarkGray
                        }
                    }
                    Write-Host ''
                }
            }
        }

        if (-not $Global:MsgCorrelatorSilent) {
            Write-Host ''
            Write-Host '============================================================'
            Write-Host '  Correlation Complete'
            Write-Host '============================================================'
        }

        if ($Global:MsgCorrelatorAutoHtml) {
            New-AgentMsgHtmlReport -Matches $allSorted -IndexPath $csvPath -LogRoot $LogRoot -GeneratedAt $now -CoverageStats $coverageStats -CoverageStats72Hours $coverageStats72Hours -CoverageStatsOlder $coverageStatsOlder -AnchorTimestamp $anchorTimestamp -WindowStart72Hours $windowStart72Hours -EligibleMatchedKeys $matchedLineKeys -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts -LogFilesAnalyzed $logFiles
        }
        elseif (-not $SkipHtmlPrompt.IsPresent) {
            Write-Host ''
            $ans = Read-Host "Create HTML output report? (Y/N) (press Enter after making selection)"
            if ($ans -and $ans.Trim().ToUpper() -eq 'Y') {
                New-AgentMsgHtmlReport -Matches $allSorted -IndexPath $csvPath -LogRoot $LogRoot -GeneratedAt $now -CoverageStats $coverageStats -CoverageStats72Hours $coverageStats72Hours -CoverageStatsOlder $coverageStatsOlder -AnchorTimestamp $anchorTimestamp -WindowStart72Hours $windowStart72Hours -EligibleMatchedKeys $matchedLineKeys -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts -LogFilesAnalyzed $logFiles
            }
        }
    }
    catch {
        $Global:CSExitCode = 1
        Write-LogErrorLine "Agent Message Correlator encountered an error: $($_.Exception.Message)"
        if ($Global:MsgCorrelatorSilent) {
            exit 1
        }
        if (-not $Global:MsgCorrelatorQuiet) {
            Write-Host ''
            Write-Host 'Press Enter to return to the main menu... (press Enter after making selection)'
            [void][System.Console]::ReadLine()
        }
    }
}


function Format-FileSizeString {
    param([long]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N2} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N2} KB' -f ($Bytes / 1KB)) }
    return ('{0} B' -f $Bytes)
}

function Invoke-MassLogCorrelator {
    param(
        [Parameter(Mandatory = $true)][string]$RootPath
    )

    if ([string]::IsNullOrWhiteSpace($RootPath)) {
        throw 'MLC requires -LogPath "root folder".'
    }
    if (-not (Test-Path -LiteralPath $RootPath -PathType Container)) {
        throw "MLC root path does not exist: $RootPath"
    }

    $origQuiet = $Global:MsgCorrelatorQuiet
    $origSilent = $Global:MsgCorrelatorSilent
    $origAutoHtml = $Global:MsgCorrelatorAutoHtml
    $origOpenHtml = $Global:MsgCorrelatorOpenHtml
    $origProgress = $ProgressPreference

    try {
        $Global:MsgCorrelatorQuiet = $false
        $Global:MsgCorrelatorSilent = $false
        $Global:MsgCorrelatorAutoHtml = $false
        $Global:MsgCorrelatorOpenHtml = $false
        $ProgressPreference = 'Continue'

        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  Mass Log Correlator (MLC)' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''

        $targets = @(Get-ChildItem -LiteralPath $RootPath -Filter 'cybercns.log' -File -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName)
        if ($targets.Count -eq 0) {
            throw "No cybercns.log files were found under: $RootPath"
        }

        Write-Host 'Discovered cybercns.log files:' -ForegroundColor Yellow
        Write-Host ''
        $i = 0
        foreach ($t in $targets) {
            $i++
            Write-Host ('[{0}] {1}  |  {2}' -f $i, $t.FullName, (Format-FileSizeString -Bytes $t.Length))
        }

        Write-Host ''
        Write-Host ('Total files found: {0}' -f $targets.Count) -ForegroundColor Green
        Write-Host ''

        $runAns = Read-Host 'Run correlator against each file and generate HTML reports? (Y/N) (press Enter after making selection)'
        if (-not $runAns -or $runAns.Trim().ToUpper() -ne 'Y') {
            Write-Host 'MLC cancelled.' -ForegroundColor Yellow
            $Global:CSExitCode = 0
            return
        }

        $scriptPath = $PSCommandPath
        if ([string]::IsNullOrWhiteSpace($scriptPath)) {
            try { $scriptPath = $MyInvocation.MyCommand.Path } catch { $scriptPath = $null }
        }
        if ([string]::IsNullOrWhiteSpace($scriptPath)) {
            throw 'Unable to resolve current script path for MLC child execution.'
        }

        $htmlOutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'
        Ensure-Directory -Path $htmlOutRoot

        $stageRoot = Join-Path $htmlOutRoot ('MLC-Staging-' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
        Ensure-Directory -Path $stageRoot

        $completed = 0
        $failed = 0
        $generatedReports = New-Object 'System.Collections.Generic.List[string]'

        for ($index = 0; $index -lt $targets.Count; $index++) {
            $target = $targets[$index]
            $percent = [int]((($index + 1) / [double][Math]::Max(1, $targets.Count)) * 100.0)
            Write-Progress -Activity 'Mass Log Correlator' -Status ('Processing {0} of {1}: {2}' -f ($index + 1), $targets.Count, $target.FullName) -PercentComplete $percent

            $jobDir = Join-Path $stageRoot ('Job-' + ('{0:D4}' -f ($index + 1)))
            Ensure-Directory -Path $jobDir
            Copy-Item -LiteralPath $target.FullName -Destination (Join-Path $jobDir 'cybercns.log') -Force

            $before = @{}
            foreach ($f in @(Get-ChildItem -LiteralPath $htmlOutRoot -Filter 'CS-AgentMsgCorrelator-*.html' -File -ErrorAction SilentlyContinue)) {
                $before[$f.FullName] = $true
            }

            $childOutput = $null
            $childExit = 0
            try {
                $childOutput = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $scriptPath -LogPath $jobDir 2>&1
                $childExit = $LASTEXITCODE
            }
            catch {
                $childExit = 1
                $childOutput = @($_.Exception.Message)
            }

            $newFiles = @()
            foreach ($f in @(Get-ChildItem -LiteralPath $htmlOutRoot -Filter 'CS-AgentMsgCorrelator-*.html' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime)) {
                if (-not $before.ContainsKey($f.FullName)) {
                    $newFiles += $f
                }
            }

            $reportPath = $null
            if ($newFiles.Count -gt 0) {
                $reportPath = $newFiles[-1].FullName
            }
            else {
                $latest = Get-ChildItem -LiteralPath $htmlOutRoot -Filter 'CS-AgentMsgCorrelator-*.html' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
                if ($latest) { $reportPath = $latest.FullName }
            }

            if ($childExit -eq 0 -and $reportPath) {
                $completed++
                $generatedReports.Add($reportPath) | Out-Null
                Write-Host ('[OK] {0}/{1}  {2}' -f ($index + 1), $targets.Count, $reportPath) -ForegroundColor Green
            }
            else {
                $failed++
                Write-Host ('[FAIL] {0}/{1}  {2}' -f ($index + 1), $targets.Count, $target.FullName) -ForegroundColor Red
                if ($childOutput) {
                    $childOutput | Select-Object -Last 5 | ForEach-Object { Write-Host ('       ' + $_) -ForegroundColor DarkYellow }
                }
            }
        }

        Write-Progress -Activity 'Mass Log Correlator' -Completed
        Write-Host ''
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  MLC Complete' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ('Completed: {0}' -f $completed) -ForegroundColor Green
        Write-Host ('Failed:    {0}' -f $failed) -ForegroundColor $(if ($failed -gt 0) { 'Yellow' } else { 'Green' })
        Write-Host ('Total:     {0}' -f $targets.Count) -ForegroundColor Cyan
        if ($generatedReports.Count -gt 0) {
            Write-Host ''
            Write-Host 'Generated HTML reports:' -ForegroundColor Yellow
            foreach ($rp in $generatedReports) {
                Write-Host (' - ' + $rp)
            }
        }

        $Global:CSExitCode = $(if ($failed -gt 0) { 1 } else { 0 })
    }
    finally {
        $Global:MsgCorrelatorQuiet = $origQuiet
        $Global:MsgCorrelatorSilent = $origSilent
        $Global:MsgCorrelatorAutoHtml = $origAutoHtml
        $Global:MsgCorrelatorOpenHtml = $origOpenHtml
        $ProgressPreference = $origProgress
    }
}

# -----------------------------
# MAIN MENU (interactive)
# -----------------------------
function Show-MainMenu {
    while ($true) {
        Clear-Host
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host '  Agent Message Correlator' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''

        $meta = Get-IndexMetadata -LocalRoot $Global:MsgIndexLocalRoot -LocalFileName $Global:MsgIndexLocalFileName
        if ($meta.Exists) {
            $ageTxt = $(if ($meta.AgeDays -ne $null) { ("{0:N2} day(s)" -f $meta.AgeDays) } else { 'n/a' })
            Write-Host "ConnectSecure Message Index: PRESENT" -ForegroundColor Green
            Write-Host ("  Path       : {0}" -f $meta.Path) -ForegroundColor Gray
            Write-Host ("  Last Update: {0}" -f $meta.LastWriteTime) -ForegroundColor Gray
            Write-Host ("  Age        : {0}" -f $ageTxt) -ForegroundColor Gray
        } else {
            Write-Host "ConnectSecure Message Index: MISSING" -ForegroundColor Red
            Write-Host ("  Expected at: {0}" -f $meta.Path) -ForegroundColor Gray
        }

        Write-Host ''
        Write-Host ' [1] Scan Default Agent Folder' -ForegroundColor White
        Write-Host ("     - {0}" -f $Global:DefaultAgentLogRoot) -ForegroundColor DarkGray
        Write-Host ' [2] Specify Alternate Log Location' -ForegroundColor White
        Write-Host ' [3] Force update ConnectSecure Message Index' -ForegroundColor White
        Write-Host ' [Q] Quit' -ForegroundColor White
        Write-Host ''
        $choice = Read-Host 'Select an option (1/2/3/Q) (press Enter after making selection)'

        switch ($choice.ToUpper()) {
            '1' {
                Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$false
                Write-Host ''
                Read-Host 'Done. Press Enter to return to the main menu... (press Enter after making selection)'
            }
            '2' {
                $folder = Select-FolderPath -InitialPath $Global:DefaultAgentLogRoot
                if (-not $folder -or -not (Test-Path -LiteralPath $folder -PathType Container)) {
                    Write-LogWarn ("Folder not found or invalid: {0}" -f $folder)
                    Write-Host ''
                    Read-Host 'Press Enter to return to the main menu... (press Enter after making selection)'
                    continue
                }
                Invoke-AgentCorrelation -LogRoot $folder -SkipHtmlPrompt:$false
                Write-Host ''
                Read-Host 'Done. Press Enter to return to the main menu... (press Enter after making selection)'
            }
            '3' {
                Write-Host ''
                Write-Host "------------------------------------------------------------"
                Write-Host "  Force update ConnectSecure Message Index"
                Write-Host "------------------------------------------------------------"
                try {
                    $null = Ensure-IndexFreshForCorrelation `
                        -PrimaryUrl       $Global:MsgIndexPrimaryUrl `
                        -SecondaryUrl     $Global:MsgIndexSecondaryUrl `
                        -PrimaryHashUrl   $Global:MsgIndexPrimaryHashUrl `
                        -SecondaryHashUrl $Global:MsgIndexSecondaryHashUrl `
                        -LocalRoot        $Global:MsgIndexLocalRoot `
                        -LocalFileName    $Global:MsgIndexLocalFileName `
                        -ForceRefresh
                    Write-Host ''
                    Write-Host 'Index update complete.'
                }
                catch {
                    Write-LogErrorLine "Force-update failed: $($_.Exception.Message)"
                }
                Write-Host ''
                Read-Host 'Press Enter to return to the main menu... (press Enter after making selection)'
            }
            'Q' {
                $launcher = $Global:LauncherPath
                if ($launcher -and (Test-Path -LiteralPath $launcher -PathType Leaf)) {
                    Write-LogInfo ("Returning to CS-Toolbox-Launcher: {0}" -f $launcher)
                    try { & $launcher } catch { Write-LogErrorLine ("Failed to launch CS-Toolbox-Launcher.ps1: {0}" -f $_.Exception.Message) }
                }
                return
            }
            Default {
                Write-LogWarn 'Invalid choice.'
                Start-Sleep -Seconds 1
            }
        }
    }
}

# -----------------------------
# ENTRYPOINT
# -----------------------------
try {
    if ($MLC) {
        if (-not ($LogPath -and $LogPath.Trim().Length -gt 0)) {
            throw 'MLC requires -LogPath "root folder".'
        }
        Invoke-MassLogCorrelator -RootPath $LogPath
        exit $Global:CSExitCode
    }
    elseif ($LogPath -and $LogPath.Trim().Length -gt 0) {
        Invoke-AgentCorrelation -LogRoot $LogPath -SkipHtmlPrompt:$true -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts
        exit $Global:CSExitCode
    }
    elseif ($CheckCalc) {
        Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$true -CheckCalc:$true -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts
        exit $Global:CSExitCode
    }
    elseif ($ExportOnly) {
        Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$true -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts
        exit $Global:CSExitCode
    }
    elseif ($DefaultLog) {
        Invoke-AgentCorrelation -LogRoot $Global:DefaultAgentLogRoot -SkipHtmlPrompt:$true -CheckCalc:$CheckCalc -CheckCalcLogPath $CheckCalcLogPath -CheckCalcJsonLogPath $CheckCalcJsonLogPath -CheckCalcMaxAttempts $CheckCalcMaxAttempts
        exit $Global:CSExitCode
    }
    else {
        Show-MainMenu
    }
}
finally {
    # Restore the caller's original ProgressPreference so we don't leak our setting into the session
    if ($null -ne $Global:MsgCorrelatorOrigProgressPreference) {
        $ProgressPreference = $Global:MsgCorrelatorOrigProgressPreference
    }
}