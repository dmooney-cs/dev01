#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

param(
  [Parameter(Mandatory=$true)][string]$CsbPath,
  [Parameter(Mandatory=$true)][string]$HtmlPath,
  [Parameter(Mandatory=$true)][string]$ManifestPath,
  [Parameter()][string]$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info',
  [Parameter()][string]$Company = '',
  [Parameter()][string]$Tenant  = '',
  [Parameter()][string]$Ticket  = '',
  [Parameter()][string]$To      = 'support@connectsecure.com',
  [Parameter()][string]$Cc      = '',
  [Parameter()][string]$Bcc     = '',
  [Parameter()][switch]$AlsoAttachManifest,
  [Parameter()][switch]$AlsoAttachHtml
)

function Write-Info ($m){ Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Cyan }
function Write-Ok   ($m){ Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Green }
function Write-Warn ($m){ Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Yellow }
function Write-Err  ($m){ Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Red }

function Resolve-OutlookPath {
  try {
    $candidates = @(
      "$Env:ProgramFiles\Microsoft Office\root\Office16\OUTLOOK.EXE",
      "$Env:ProgramFiles(x86)\Microsoft Office\root\Office16\OUTLOOK.EXE",
      "$Env:ProgramFiles\Microsoft Office\Office16\OUTLOOK.EXE",
      "$Env:ProgramFiles(x86)\Microsoft Office\Office16\OUTLOOK.EXE"
    )
    foreach ($p in $candidates) { if (Test-Path $p) { return $p } }
  } catch { }
  return $null
}

function Start-OutlookCompose {
  param(
    [Parameter(Mandatory=$true)][string]$To,
    [Parameter()][string]$Cc,
    [Parameter()][string]$Bcc,
    [Parameter(Mandatory=$true)][string]$Subject,
    [Parameter()][string]$Body = "",
    [Parameter()][string[]]$Attachments
  )

  # Try COM
  try {
    $ol = $null
    try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
    catch { $ol = New-Object -ComObject Outlook.Application }
    if ($null -eq $ol) { throw "Outlook COM unavailable." }

    $mail = $ol.CreateItem(0)
    $mail.To = $To
    if ($Cc)  { $mail.CC  = $Cc }
    if ($Bcc) { $mail.BCC = $Bcc }
    $mail.Subject = $Subject
    $mail.Body    = $Body
    if ($Attachments) {
      foreach ($a in $Attachments) { if ($a -and (Test-Path $a)) { $mail.Attachments.Add($a) | Out-Null } }
    }
    $mail.Display($true) | Out-Null
    Write-Ok "Outlook compose opened via COM."
    return
  } catch {
    Write-Warn ("Outlook COM failed: {0}" -f $_.Exception.Message)
  }

  # Fallback: OUTLOOK.EXE /a + populate via COM
  $outlookPath = Resolve-OutlookPath
  if ($outlookPath -and (Test-Path $outlookPath)) {
    $firstAttachment = $null
    if ($Attachments -and $Attachments.Count -gt 0) {
      $firstAttachment = $Attachments | Where-Object { Test-Path $_ } | Select-Object -First 1
    }
    if ($firstAttachment) {
      Start-Process -FilePath $outlookPath -ArgumentList @('/c','ipm.note','/a',"`"$firstAttachment`"") | Out-Null
      Start-Sleep -Seconds 2
      try {
        $ol2 = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
        if ($ol2) {
          $insp = $ol2.ActiveInspector()
          if ($insp -and $insp.CurrentItem) {
            $m2 = $insp.CurrentItem
            $m2.To = $To
            if ($Cc)  { $m2.CC  = $Cc }
            if ($Bcc) { $m2.BCC = $Bcc }
            $m2.Subject = $Subject
            $m2.Body    = $Body
            if ($Attachments.Count -gt 1) {
              foreach ($a in ($Attachments | Where-Object { $_ -ne $firstAttachment })) {
                if (Test-Path $a) { $m2.Attachments.Add($a) | Out-Null }
              }
            }
          }
        }
      } catch { Write-Warn ("Post-launch COM population failed: {0}" -f $_.Exception.Message) }
      Write-Ok "Outlook compose opened via OUTLOOK.EXE."
      return
    } else {
      Start-Process -FilePath $outlookPath | Out-Null
      Write-Ok "Outlook launched."
      return
    }
  }

  # Last-ditch mailto (no attachments)
  $mailto = "mailto:$To?subject=$( [uri]::EscapeDataString($Subject) )&body=$( [uri]::EscapeDataString($Body) )"
  Start-Process $mailto | Out-Null
  Write-Warn "Used mailto: fallback (attachments not added)."
}

# ---- Validate inputs ----
if (-not (Test-Path -LiteralPath $CsbPath))     { Write-Err "CSB not found: $CsbPath"; exit 1 }
if (-not (Test-Path -LiteralPath $HtmlPath))    { Write-Warn "Helper HTML not found: $HtmlPath" }
if (-not (Test-Path -LiteralPath $ManifestPath)){ Write-Warn "Manifest not found: $ManifestPath" }
if (-not (Test-Path -LiteralPath $ExportRoot))  { Write-Warn "ExportRoot not found: $ExportRoot" }

# ---- Subject / Body ----
$subjectParts = @('ConnectSecure Support Bundle','Secure')
if ($Company) { $subjectParts += $Company }
if ($Tenant)  { $subjectParts += $Tenant }
if ($Ticket)  { $subjectParts += $Ticket }
$subject = ($subjectParts -join ' | ')

$bodyLines = @(
  "Hello ConnectSecure Support.",
  "",
  "Please find the attached Secure support bundle.",
  ""
)
if ($Company) { $bodyLines += "Company: $Company" }
if ($Tenant)  { $bodyLines += "Tenant:  $Tenant"  }
if ($Ticket)  { $bodyLines += "Ticket:  $Ticket"  }
$bodyLines += ""
$bodyLines += "Paths:"
$bodyLines += " - CSB:     $CsbPath"
if (Test-Path $ManifestPath) { $bodyLines += " - Manifest: $ManifestPath" }
if (Test-Path $HtmlPath)     { $bodyLines += " - Helper:   $HtmlPath" }
if (Test-Path $ExportRoot)   { $bodyLines += " - Export:   $ExportRoot" }
$bodyLines += ""
$bodyLines += "Thanks,"
$body = ($bodyLines -join [Environment]::NewLine)

# ---- Attachments ----
$attachments = New-Object System.Collections.Generic.List[string]
$attachments.Add((Resolve-Path -LiteralPath $CsbPath).Path) | Out-Null
if ($AlsoAttachManifest -and (Test-Path $ManifestPath)) { $attachments.Add((Resolve-Path -LiteralPath $ManifestPath).Path) | Out-Null }
if ($AlsoAttachHtml -and (Test-Path $HtmlPath))         { $attachments.Add((Resolve-Path -LiteralPath $HtmlPath).Path)     | Out-Null }

Write-Info ("Composing Outlook message...")
Start-OutlookCompose -To $To -Cc $Cc -Bcc $Bcc -Subject $subject -Body $body -Attachments $attachments.ToArray()
