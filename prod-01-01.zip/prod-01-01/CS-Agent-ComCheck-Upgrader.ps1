<#
CS-Agent-ComCheck-Upgrader.ps1

Updates:
  - Always delete the STAGING EXE at the end:
      C:\CS-Toolbox-TEMP\Collected-Info\AgentComChecker\AgentComChecker-Staging\<RunStamp>\CSAgent_validation.exe

  - Added -Silent switch:
      * Runs end-to-end with no on-screen stdout display + no pauses
      * Still captures/export logs and artifacts
      * Deletes exported EXE + staging EXE at the end

Folder structure:
  Export:
    C:\CS-Toolbox-TEMP\Collected-Info\AgentComChecker\<RunStamp>\
  Staging:
    C:\CS-Toolbox-TEMP\Collected-Info\AgentComChecker\AgentComChecker-Staging\<RunStamp>\

#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$ExportOnly,
    [switch]$Silent,

    [string]$ValidationExeUrl = 'https://betadevtools.myconnectsecure.com/agents/CSA_validation/CSAgent_validation.exe',

    # Optional: paste a URL here if you want an additional download saved into prod-01-01
    [string]$AdditionalFileUrl = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -----------------------------
# Config
# -----------------------------
$script:TempRoot          = 'C:\CS-Toolbox-TEMP'
$script:CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:ToolboxRoot       = 'C:\CS-Toolbox-TEMP\prod-01-01'

$script:ExportRoot        = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentComChecker'
$script:StageRoot         = Join-Path $script:ExportRoot 'AgentComChecker-Staging'

$script:RunStamp          = (Get-Date).ToString('yyyyMMdd_HHmmss')
$script:RunExportDir      = Join-Path $script:ExportRoot $script:RunStamp
$script:RunStageDir       = Join-Path $script:StageRoot  $script:RunStamp

$script:TranscriptPath    = Join-Path $script:RunExportDir "CS-Agent-ComCheck-Upgrader_$($script:RunStamp).transcript.txt"
$script:StdOutPath        = Join-Path $script:RunExportDir "CSAgent_validation_stdout.txt"
$script:StdErrPath        = Join-Path $script:RunExportDir "CSAgent_validation_stderr.txt"
$script:RunMetaPath       = Join-Path $script:RunExportDir "run_info.txt"

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

function Write-Log {
    param([Parameter(Mandatory)][string]$Message)
    if (-not $Silent) {
        $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Write-Host "[$ts] $Message"
    }
}

function Enable-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
}

function Enable-UnicodeConsole {
    try { & chcp 65001 > $null } catch { }
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [Console]::OutputEncoding = $utf8NoBom
        [Console]::InputEncoding  = $utf8NoBom
        $global:OutputEncoding    = $utf8NoBom
    } catch { }
}

function Download-File {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][string]$OutFile
    )
    Enable-Tls12
    Ensure-Folder -Path (Split-Path -Parent $OutFile)

    Write-Log "Downloading: $Url"
    Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -ErrorAction Stop

    if (-not (Test-Path -LiteralPath $OutFile)) {
        throw "Download did not produce a file: $OutFile"
    }

    try {
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $OutFile).Hash
        Write-Log "Downloaded OK (SHA256: $hash)"
        return $hash
    } catch {
        Write-Log "Downloaded OK (hash unavailable): $OutFile"
        return ''
    }
}

function Show-File-OnScreen-WithPause {
    param([Parameter(Mandatory)][string]$Path)

    if ($Silent -or $ExportOnly) { return }

    Enable-UnicodeConsole

    Write-Host ""
    Write-Host "==================== BEGIN FILE ===================="
    Write-Host $Path
    Write-Host "----------------------------------------------------"

    if (Test-Path -LiteralPath $Path) {
        $content = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        Write-Host $content -NoNewline
    } else {
        Write-Host "[File not found]"
    }

    Write-Host ""
    Write-Host "===================== END FILE ====================="
    Write-Host ""
    Read-Host "Press ENTER to close this output view"
}

function Force-Delete {
    param([Parameter(Mandatory)][string]$Path)

    if (Test-Path -LiteralPath $Path) {
        try { attrib -R $Path 2>$null | Out-Null } catch { }
        try {
            Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            Write-Log "Deleted: $Path"
        } catch {
            # In Silent mode, still avoid crashing on cleanup
            Write-Log "WARNING: Failed to delete '$Path' : $($_.Exception.Message)"
        }
    } else {
        Write-Log "Delete skipped (not found): $Path"
    }
}

# -----------------------------
# Start
# -----------------------------
Ensure-Folder -Path $script:CollectedInfoRoot
Ensure-Folder -Path $script:ExportRoot
Ensure-Folder -Path $script:StageRoot
Ensure-Folder -Path $script:RunExportDir
Ensure-Folder -Path $script:RunStageDir
Ensure-Folder -Path $script:ToolboxRoot

# Transcript is still useful even in Silent mode
try { Start-Transcript -Path $script:TranscriptPath -Force | Out-Null } catch { }

Write-Log "CS-Agent-ComCheck-Upgrader.ps1"
Write-Log "Export folder: $script:RunExportDir"
Write-Log "Staging folder: $script:RunStageDir"

# Download validation EXE into staging
$exePath = Join-Path $script:RunStageDir 'CSAgent_validation.exe'
$exeHash = Download-File -Url $ValidationExeUrl -OutFile $exePath

# Optional: download additional file into toolbox root
$additionalSavedAs = ''
$additionalHash = ''
if ([string]::IsNullOrWhiteSpace($AdditionalFileUrl)) {
    Write-Log "AdditionalFileUrl not provided; skipping extra download to $script:ToolboxRoot"
} else {
    try {
        $leaf = Split-Path -Path $AdditionalFileUrl -Leaf
        if ([string]::IsNullOrWhiteSpace($leaf)) { $leaf = "download_$($script:RunStamp).bin" }
        $additionalSavedAs = Join-Path $script:ToolboxRoot $leaf
        $additionalHash = Download-File -Url $AdditionalFileUrl -OutFile $additionalSavedAs
        Write-Log "Additional file saved to: $additionalSavedAs"
    } catch {
        Write-Log "WARNING: Additional file download failed: $($_.Exception.Message)"
    }
}

# Run EXE (capture stdout/stderr into export folder)
Write-Log "Running: $exePath"
Write-Log "Working dir: $script:RunStageDir"

$exitCode = $null
try {
    $proc = Start-Process -FilePath $exePath `
        -WorkingDirectory $script:RunStageDir `
        -Wait -NoNewWindow -PassThru `
        -RedirectStandardOutput $script:StdOutPath `
        -RedirectStandardError  $script:StdErrPath
    $exitCode = $proc.ExitCode
    Write-Log "EXE finished. ExitCode=$exitCode"
} catch {
    Write-Log "ERROR: Failed to start or run the EXE: $($_.Exception.Message)"
}

# Move output.txt from staging to export folder
$stageOutputTxt  = Join-Path $script:RunStageDir 'output.txt'
$exportOutputTxt = Join-Path $script:RunExportDir 'output.txt'
if (Test-Path -LiteralPath $stageOutputTxt) {
    try {
        Move-Item -LiteralPath $stageOutputTxt -Destination $exportOutputTxt -Force
        Write-Log "Moved output.txt to: $exportOutputTxt"
    } catch {
        Write-Log "WARNING: Could not move output.txt; attempting copy: $($_.Exception.Message)"
        try { Copy-Item -LiteralPath $stageOutputTxt -Destination $exportOutputTxt -Force } catch { }
    }
} else {
    Write-Log "No output.txt found at: $stageOutputTxt"
}

# Export the EXE we ran into export folder (then delete it at end)
$exportedExePath = Join-Path $script:RunExportDir 'CSAgent_validation.exe'
try { Copy-Item -LiteralPath $exePath -Destination $exportedExePath -Force } catch { }

# Write run metadata
@(
    "RunStamp: $script:RunStamp"
    "Started:  $((Get-Date).ToString('o'))"
    "ValidationExeUrl: $ValidationExeUrl"
    "ValidationExe_SHA256: $exeHash"
    "ExitCode: $exitCode"
    "StageDir: $script:RunStageDir"
    "ExportDir: $script:RunExportDir"
    "StdOut: $script:StdOutPath"
    "StdErr: $script:StdErrPath"
    "Transcript: $script:TranscriptPath"
    "AdditionalFileUrl: $AdditionalFileUrl"
    "AdditionalSavedAs: $additionalSavedAs"
    "Additional_SHA256: $additionalHash"
) | Set-Content -LiteralPath $script:RunMetaPath -Encoding UTF8 -Force

Write-Log "Export complete."

# Stop transcript before any optional on-screen viewing
try { Stop-Transcript | Out-Null } catch { }

# Show stdout with icons + pause (only if not Silent and not ExportOnly)
Show-File-OnScreen-WithPause -Path $script:StdOutPath

# Cleanup (always)
# 1) delete exported EXE in run export folder
Force-Delete -Path $exportedExePath

# 2) delete staging EXE (your requested path pattern)
Force-Delete -Path $exePath

# Return to launcher (same window) if present (skip in Silent to truly be quiet)
if (-not $Silent) {
    $launcher = Join-Path $script:ToolboxRoot 'CS-Toolbox-Launcher.ps1'
    if (Test-Path -LiteralPath $launcher) {
        try { & $launcher } catch { }
    }
}

exit