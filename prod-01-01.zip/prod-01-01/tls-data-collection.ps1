# tls-data-collection.ps1
# -----------------------------------------------------------------------------
# Collects local SCHANNEL TLS/SSL policy from registry, displays a neat
# summary by TLS version (Workstation/Server), and exports CSV.
# Optionally reveals registry keys on request.
# Output CSV: C:\CS-Toolbox-TEMP\Collected-Info\TLS\TLS-Policy_<timestamp>.csv
# Compatible with Windows PowerShell 5.1.
# -----------------------------------------------------------------------------

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------- Paths ----------
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportTLS  = Join-Path $ExportRoot 'TLS'

# ---------- Helpers ----------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}
function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportTLS
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    try {
        Write-Host ""
        Write-Host "Press any key to return..." -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to return"
    }
}

function Show-Header {
    param([string]$Title = "TLS/SSL Policy (Local Host)")
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host " ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host " ==========================================================" -ForegroundColor DarkGray
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

function Status-FromValues {
    param($Exists, $Enabled, $DisabledByDefault)
    if ($Exists -and $Enabled -eq 0) { return 'Disabled (Enabled=0)' }
    if ($Exists -and $DisabledByDefault -eq 1) { return 'DisabledByDefault=1' }
    return 'Default/Enabled'
}

function Get-RowColor {
    param([string]$Status)
    if ($Status -like 'Disabled (Enabled=0)') { return 'Red' }
    if ($Status -like 'DisabledByDefault*')   { return 'Yellow' }
    return 'Green'
}

# ---------- Main ----------
Show-Header
Ensure-ExportFolder

$base       = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
$protoList  = @('TLS 1.0','TLS 1.1','TLS 1.2','TLS 1.3')
$roles      = @('Client','Server')

$rows = New-Object System.Collections.Generic.List[psobject]

foreach ($p in $protoList) {
    foreach ($r in $roles) {
        $path = Join-Path (Join-Path $base $p) $r
        $exists = Test-Path -LiteralPath $path
        $enabled = $null
        $disabledByDefault = $null

        if ($exists) {
            $props = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
            $enabled = $props.Enabled
            $disabledByDefault = $props.DisabledByDefault
        }

        $status = Status-FromValues -Exists:$exists -Enabled:$enabled -DisabledByDefault:$disabledByDefault

        $rows.Add([pscustomobject]@{
            Protocol          = $p
            Role              = $r
            Path              = $path
            Enabled           = $enabled
            DisabledByDefault = $disabledByDefault
            Status            = $status
        })
    }
}

# -------- Export CSV --------
$stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$out   = Join-Path $ExportTLS ("TLS-Policy_{0}.csv" -f $stamp)
$rows | Export-Csv -Path $out -NoTypeInformation -Encoding UTF8

# -------- On-screen Summary (by TLS version) --------
Write-Host " Summary by TLS version:" -ForegroundColor White
Write-Host "  Default/Enabled = expected OS defaults when keys are absent." -ForegroundColor DarkGray
Write-Host ""

foreach ($p in $protoList) {
    $clientObj = $rows | Where-Object { $_.Protocol -eq $p -and $_.Role -eq 'Client' }
    $serverObj = $rows | Where-Object { $_.Protocol -eq $p -and $_.Role -eq 'Server' }

    $clientStatus = if ($null -ne $clientObj) { $clientObj.Status } else { '' }
    $serverStatus = if ($null -ne $serverObj) { $serverObj.Status } else { '' }

    $cColor = Get-RowColor -Status $clientStatus
    $sColor = Get-RowColor -Status $serverStatus

    Write-Host (" {0}" -f $p) -ForegroundColor White
    Write-Host ("   Workstation (Client): {0}" -f $clientStatus) -ForegroundColor $cColor
    Write-Host ("   Server:               {0}" -f $serverStatus) -ForegroundColor $sColor
    Write-Host ""
}

Write-Host " CSV saved to:" -ForegroundColor Green
Write-Host "  $out" -ForegroundColor Yellow
Write-Host ""

# -------- Optional detailed view (with registry keys) --------
$choice = Read-Host "Press R to show corresponding registry keys, or press ENTER to skip"
if ($choice -match '^(r|R)$') {
    Write-Host ""
    Write-Host " Detailed Entries (with registry keys):" -ForegroundColor White
    Write-Host (" {0}  {1}  {2}  {3}  {4}  {5}" -f "Protocol".PadRight(7), "Role".PadRight(6), "Status".PadRight(24), "Enabled".PadRight(7), "DisabledByDefault".PadRight(18), "Registry Path") -ForegroundColor Gray
    Write-Host (" {0}" -f ('-' * 112)) -ForegroundColor DarkGray

    $rows | Sort-Object Protocol, Role | ForEach-Object {
        $color = Get-RowColor -Status $_.Status

        # Build padded text (PS 5.1 friendly)
        $eText = ''
        if ($null -ne $_.Enabled) { $eText = [string]$_.Enabled }
        $dText = ''
        if ($null -ne $_.DisabledByDefault) { $dText = [string]$_.DisabledByDefault }

        $pCol = $_.Protocol.PadRight(7)
        $rCol = $_.Role.PadRight(6)
        $sCol = $_.Status.PadRight(24)
        $eCol = $eText.PadRight(7)
        $dCol = $dText.PadRight(18)

        Write-Host (" {0}  {1}  {2}  {3}  {4}  {5}" -f $pCol, $rCol, $sCol, $eCol, $dCol, $_.Path) -ForegroundColor $color
    }

    Write-Host ""
    Write-Host " Legend:" -ForegroundColor White
    Write-Host "  Green  = Default/Enabled (no override keys present or enabled)" -ForegroundColor Green
    Write-Host "  Yellow = DisabledByDefault=1 (allowed but off by default)" -ForegroundColor Yellow
    Write-Host "  Red    = Disabled (Enabled=0)" -ForegroundColor Red
    Write-Host ""
}

Pause-Script
