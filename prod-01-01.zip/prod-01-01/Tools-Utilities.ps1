# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ==================
#  Utilities (Menu)
# ==================
$OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Utilities'
if (-not (Test-Path $OutRoot)) {
    New-Item -Path $OutRoot -ItemType Directory | Out-Null
}

function Get-Timestamp { Get-Date -Format 'yyyyMMdd_HHmmss' }

# ---------------------
# 1) Running Services
# ---------------------
function Run-RunningServices {
    Show-Header "Utilities - Running Services"
    $ts = Get-Timestamp
    $csvAll  = Join-Path $OutRoot ("Services_All_" + $ts + ".csv")
    $csvRun  = Join-Path $OutRoot ("Services_Running_" + $ts + ".csv")
    $csvStopped = Join-Path $OutRoot ("Services_Stopped_" + $ts + ".csv")

    try {
        $all = Get-Service | Select-Object Name, DisplayName, Status, StartType, ServiceType
        if ($all) {
            $all | Sort-Object Status, Name | Export-Csv -LiteralPath $csvAll -NoTypeInformation -Encoding UTF8

            $running = $all | Where-Object { $_.Status -eq 'Running' }
            $stopped = $all | Where-Object { $_.Status -ne 'Running' }

            if ($running) { $running | Sort-Object Name | Export-Csv -LiteralPath $csvRun -NoTypeInformation -Encoding UTF8 }
            if ($stopped) { $stopped | Sort-Object Name | Export-Csv -LiteralPath $csvStopped -NoTypeInformation -Encoding UTF8 }

            Write-Host ("Services total: {0}  Running: {1}  Not Running: {2}" -f ($all.Count), ($running.Count), ($stopped.Count)) -ForegroundColor Green
            $running | Select-Object Name, DisplayName | Sort-Object Name | Format-Table -AutoSize

            Write-Host "Saved:" -ForegroundColor Green
            Write-Host "  $csvAll" -ForegroundColor Green
            if ($running) { Write-Host "  $csvRun" -ForegroundColor Green }
            if ($stopped) { Write-Host "  $csvStopped" -ForegroundColor Green }
        } else {
            Write-Host "No services returned." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting service list: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

# ---------------
# 2) Disk Space
# ---------------
function Run-DiskSpace {
    Show-Header "Utilities - Disk Space"
    $ts = Get-Timestamp
    $csvVol = Join-Path $OutRoot ("Disk_Space_" + $ts + ".csv")

    try {
        $vols = Get-CimInstance -ClassName Win32_Volume -Filter "DriveType=3" -ErrorAction SilentlyContinue |
            Select-Object `
                DriveLetter,
                Label,
                FileSystem,
                @{n='CapacityGB';e={[math]::Round(($_.Capacity/1GB),2)}},
                @{n='FreeGB';e={[math]::Round(($_.FreeSpace/1GB),2)}},
                @{n='UsedGB';e={[math]::Round((($_.Capacity- $_.FreeSpace)/1GB),2)}},
                @{n='PctFree';e={ if ($_.Capacity){ [math]::Round(($_.FreeSpace/$_.Capacity*100),1) } else { $null } }}

        if ($vols) {
            $vols | Export-Csv -LiteralPath $csvVol -NoTypeInformation -Encoding UTF8
            Write-Host ("Volumes exported: {0}" -f ($vols.Count)) -ForegroundColor Green
            $vols | Sort-Object PctFree | Format-Table DriveLetter, Label, CapacityGB, FreeGB, UsedGB, PctFree -AutoSize
            Write-Host "Saved: $csvVol" -ForegroundColor Green
        } else {
            Write-Host "No fixed volumes found." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting disk space: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Show-Menu {
    Clear-Host
    Show-Header "Utilities"

    Write-Host ""
    Write-Host " [1] Running Services           - List/export (all, running, stopped)" -ForegroundColor White
    Write-Host " [2] Disk Space                 - Volume capacity and free space" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-RunningServices }
        '2' { Run-DiskSpace }
        'Q' {
            # Relaunch main CS Toolbox Launcher in the SAME window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
