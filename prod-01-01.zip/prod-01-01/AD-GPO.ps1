#requires -version 5.1

[CmdletBinding()]
param(
    [string]$OutPath = $null,
    [switch]$Quiet,
    [switch]$ExportOnly
)

# If -ExportOnly is supplied, force quiet output (still writes JSON).
if ($ExportOnly) { $Quiet = $true }

# Reduce non-essential console output when quiet
if ($Quiet) {
    $WarningPreference     = 'SilentlyContinue'
    $InformationPreference = 'SilentlyContinue'
}


# ---- Standard output directory bootstrap----
$CS_OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
New-Item -Path $CS_OutRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null

if ([string]::IsNullOrWhiteSpace($OutPath)) {
    $OutPath = Join-Path $CS_OutRoot 'AD-GPO_data.json'
}

# Ensure the parent folder of the final path exists (covers custom -OutPath values too)
$__parent = Split-Path -Parent $OutPath
if ($__parent) { New-Item -Path $__parent -ItemType Directory -Force -ErrorAction Stop | Out-Null }
# ---- end standard block ----

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

function Write-ResultJson {
    param([hashtable]$Payload, [string]$Path)

    $dir = Split-Path -Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    $Payload | ConvertTo-Json -Depth 5 -Compress |
        Out-File -FilePath $Path -Encoding UTF8

    try { $resolved = (Resolve-Path -Path $Path).Path } catch { $resolved = $Path }
    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host "JSON saved to: $resolved" -ForegroundColor Cyan }
}

try {
    try { Import-Module GroupPolicy -ErrorAction Stop } catch { throw "GroupPolicy module not found. Install GPMC/RSAT." }
    try { Import-Module ActiveDirectory -ErrorAction SilentlyContinue } catch { }

    $gpoData    = $null
    $serverUsed = $null

    # Probe local IPs first (tolerant to failures)
    try {
        foreach ($ip in Get-NetIPConfiguration) {
            $addr = $ip.IPv4Address.IPAddress
            if (-not $addr) { continue }
            try {
                $gpoData = Get-GPO -All -Server $addr -ErrorAction Stop
                $serverUsed = $addr
                break
            } catch { }
        }
    } catch { }

    # Fallback to domain default; try to name the DC
    if (-not $gpoData) {
        $gpoData = Get-GPO -All -ErrorAction Stop
        try { $serverUsed = (Get-ADDomain).PDCEmulator } catch {
            if (-not $serverUsed) { $serverUsed = ($env:LOGONSERVER -replace '\\','') }
            if (-not $serverUsed) { $serverUsed = $env:COMPUTERNAME }
        }
    }

    $aGpoDetails = foreach ($gpo in $gpoData) {
        if ($null -eq $gpo) { continue }
        [pscustomobject][ordered]@{
            guid            = $gpo.Id
            displayName     = $gpo.DisplayName
            domain          = $gpo.DomainName
            gpoStatus       = [string]$gpo.GpoStatus
            gpoCreatedTime  = $gpo.CreationTime.ToString('yyyy-MM-dd HH:mm:ss')
            gpoModifiedTime = $gpo.ModificationTime.ToString('yyyy-MM-dd HH:mm:ss')
            path            = $gpo.Path   # LDAP path
        }
    }

    $count       = ($aGpoDetails | Measure-Object).Count
    $serverShown = if ($serverUsed) { $serverUsed } else { 'n/a' }

    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host ("Discovered {0} GPO(s)  |  Server: {1}" -f $count, $serverShown) -ForegroundColor Green }

    if (-not $Quiet) {
        $aGpoDetails |
        Select-Object displayName, domain, gpoStatus, gpoCreatedTime, gpoModifiedTime, path |
        Sort-Object domain, displayName |
        Format-Table -Wrap -AutoSize
    }

    $payloadOk = @{
        status = $true
        server = $serverShown
        count  = $count
        data   = $aGpoDetails
    }
    Write-ResultJson -Payload $payloadOk -Path $OutPath
}
catch {
    $err = $_
    if (-not $Quiet) { Write-Warning $err.Exception.Message }

    $payloadFail = @{
        status     = $false
        msg        = $err.Exception.Message
        stackTrace = ($err | Out-String)
    }

    try {
        Write-ResultJson -Payload $payloadFail -Path $OutPath
    } catch {
        if (-not $Quiet) { Write-Host "" }
        if (-not $Quiet) { Write-Host "Failed to write JSON to: $OutPath" -ForegroundColor Red }
        if (-not $Quiet) { Write-Host ($payloadFail | ConvertTo-Json -Depth 5) -ForegroundColor Yellow }
    }
}