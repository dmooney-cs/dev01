﻿<# ========================================================================
  cs-agent-log-search.ps1
  ConnectSecure / CyberCNS Agent Log Search
  PowerShell 5.1 compatible + supports reading locked logs (FileShare.ReadWrite)

  Option B (auto mode):
    - If search input looks like IP/hostname/URL -> token mode (pre-indexed tokens)
    - Else -> full-text mode:
        * scans lines for the term
        * groups matches by normalized message signature
        * list sorted by: Count desc, then LastSeen desc
        * drilldown is the same (latest hit +/-10 context; pick from last 10 hits)

  Default:
    - If default logs folder exists, analyzes all *.log/*.txt in:
        C:\Program Files (x86)\CyberCNSAgent\logs

  Quick mode:
    - If total combined lines > 10,000 and -Full not used:
        * token indexing uses only last 10,000 combined lines
        * interactive prompt allows full indexing
        * full-text search respects the same scope (quick vs full)

  Cookbook:
    -ExportOnly exports metadata to .\collected-info\ and exits.
======================================================================== #>

[CmdletBinding()]
param(
    [string]$Path,
    [switch]$DefaultLog,

    # Option B input (auto token vs full-text)
    [string]$Search,

    [int]$DetectionGapSeconds = 30,
    [int]$ShowDetections = 15,

    [switch]$Full,
    [switch]$Quiet,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------- Config ----------------------
$script:QuickLineLimit = 10000
$script:DefaultLogsDir = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$script:DefaultLogFile = Join-Path $script:DefaultLogsDir 'cybercns.log'

# PowerShell 5.1: proper multi-key descending sort
$script:SortCountThenLast = @(
    @{ Expression = 'Count';    Descending = $true },
    @{ Expression = 'LastSeen'; Descending = $true }
)

# ---------------------- ExportOnly (cookbook metadata) ----------------------
function Write-ExportOnly {
    try {
        $root = Split-Path -Parent $PSCommandPath
        $outDir = Join-Path $root 'collected-info'
        if (-not (Test-Path $outDir)) { New-Item -Path $outDir -ItemType Directory | Out-Null }

        $meta = [ordered]@{
            ScriptName   = 'cs-agent-log-search.ps1'
            Purpose      = 'Auto-search: IP/host tokens OR full-text grouping. Lists results by occurrences then last occurrence; drilldown shows latest hit +/-10 context and selectable last 10 hits.'
            Switches     = @(
                '-Path <string>               : Log FILE path OR log FOLDER path (folder indexes all *.log/*.txt inside)',
                '-DefaultLog                  : Force default agent logs folder/file path (no browse)',
                '-Search <string>             : Auto: token-mode if IP/host/URL-like; else full-text grouped search',
                '-Full                        : Force indexing/search over entire input (no quick mode prompt)',
                '-Quiet                       : Reduce banner output',
                '-ExportOnly                  : Export this metadata to collected-info and exit'
            )
            Examples     = @(
                '.\cs-agent-log-search.ps1',
                '.\cs-agent-log-search.ps1 -Search "pod401.myconnectsecure.com"',
                '.\cs-agent-log-search.ps1 -Search "timeout"',
                '.\cs-agent-log-search.ps1 -Full -Search "certificate"',
                '.\cs-agent-log-search.ps1 -Path "C:\Program Files (x86)\CyberCNSAgent\logs" -Search "proxy"',
                '.\cs-agent-log-search.ps1 -DefaultLog -Full'
            )
        }

        $json = $meta | ConvertTo-Json -Depth 6
        $outFile = Join-Path $outDir 'cs-agent-log-search.json'
        Set-Content -Path $outFile -Value $json -Encoding UTF8
        Write-Host "Exported: $outFile"
        exit 0
    } catch {
        Write-Host "ExportOnly failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}
if ($ExportOnly) { Write-ExportOnly }

# ---------------------- Shared-safe log reader (handles locked files) -------
function Get-LogLinesShared {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$LogPath)

    if (-not (Test-Path $LogPath)) { throw "Log file not found: $LogPath" }

    $fs = $null
    $sr = $null
    try {
        $fs = New-Object System.IO.FileStream(
            $LogPath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
        )
        $sr = New-Object System.IO.StreamReader($fs)

        while (-not $sr.EndOfStream) {
            $line = $sr.ReadLine()
            if ($null -ne $line) { $line }
        }
    } finally {
        if ($sr) { $sr.Dispose() }
        if ($fs) { $fs.Dispose() }
    }
}

# ---------------------- UI helpers ----------------------
function Write-Header {
    param([string]$Title)
    if ($Quiet) { return }
    $w = 78
    $line = '=' * $w
    Write-Host $line -ForegroundColor Cyan
    Write-Host ("  {0}" -f $Title) -ForegroundColor Cyan
    Write-Host $line -ForegroundColor Cyan
}

function Resolve-DefaultLogFolderPath { $script:DefaultLogsDir }
function Resolve-DefaultLogPath       { $script:DefaultLogFile }

function Get-LogFilesFromFolder {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$FolderPath)

    if (-not (Test-Path $FolderPath)) { throw "Folder not found: $FolderPath" }
    $rp = (Resolve-Path $FolderPath).Path

    $files = @(
        Get-ChildItem -Path $rp -File -ErrorAction Stop |
            Where-Object { $_.Extension -match '^\.(log|txt)$' } |
            Sort-Object Name
    )

    if (-not $files -or $files.Count -eq 0) {
        throw "No *.log or *.txt files found in: $rp"
    }

    @($files.FullName)
}

function Select-LogSource {
    $defaultFolder = Resolve-DefaultLogFolderPath
    $defaultFile   = Resolve-DefaultLogPath

    if ($DefaultLog) {
        if (Test-Path $defaultFolder) {
            return @{ Type='Folder'; Paths=(Get-LogFilesFromFolder -FolderPath $defaultFolder); Display=$defaultFolder }
        }
        if (Test-Path $defaultFile) {
            return @{ Type='File'; Paths=@((Resolve-Path $defaultFile).Path); Display=$defaultFile }
        }
        throw "Default log folder/file not found: $defaultFolder / $defaultFile"
    }

    if ($Path) {
        if (-not (Test-Path $Path)) { throw "Path not found: $Path" }
        $rp = (Resolve-Path $Path).Path
        if (Test-Path $rp -PathType Container) {
            return @{ Type='Folder'; Paths=(Get-LogFilesFromFolder -FolderPath $rp); Display=$rp }
        }
        return @{ Type='File'; Paths=@($rp); Display=$rp }
    }

    if (Test-Path $defaultFolder) {
        return @{ Type='Folder'; Paths=(Get-LogFilesFromFolder -FolderPath $defaultFolder); Display=$defaultFolder }
    }
    if (Test-Path $defaultFile) {
        return @{ Type='File'; Paths=@((Resolve-Path $defaultFile).Path); Display=$defaultFile }
    }

    throw "No default logs found at: $defaultFolder or $defaultFile. Provide -Path <file|folder>."
}

function Write-ProgressInline {
    param([int]$Done,[int]$Total)
    if ($Quiet) { return }
    if ($Total -le 0) { return }

    $remain = $Total - $Done
    if ($remain -lt 0) { $remain = 0 }

    $pct = [math]::Floor(($Done / [double]$Total) * 100)
    if ($pct -gt 100) { $pct = 100 }
    if ($pct -lt 0) { $pct = 0 }

    $msg = ("Working: {0:n0}/{1:n0} done, {2:n0} remaining ({3}%)" -f $Done, $Total, $remain, $pct)
    Write-Host -NoNewline ("`r" + $msg.PadRight(78))
}

function Clear-ProgressInline {
    if ($Quiet) { return }
    Write-Host ""
}

# ---------------------- Parsing / extraction ----------------------
$TsRegex   = '^(?<ts>\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\s+(?<level>\w+)\s+\[(?<msg>.*)\]\s*$'
$IpRegex   = '\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b'
$HostRegex = '\b(?=.{1,253}\b)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+(?:[A-Za-z]{2,63})\b'
$UrlRegex  = '(?i)\bhttps?://[^\s\]]+'

function Try-ParseLine {
    param([string]$Line)

    $o = [ordered]@{
        Ts    = $null
        Level = $null
        Msg   = $Line
        Raw   = $Line
    }

    $m = [regex]::Match($Line, $TsRegex)
    if ($m.Success) {
        $o.Level = $m.Groups['level'].Value
        $o.Msg   = $m.Groups['msg'].Value

        $tsText  = $m.Groups['ts'].Value.Trim()
        try { $o.Ts = [datetime]::ParseExact($tsText, 'yyyy/MM/dd HH:mm:ss', $null) } catch { $o.Ts = $null }
    }

    [pscustomobject]$o
}

function Extract-TokensFromMessage {
    param([string]$Message)

    $tokens = New-Object System.Collections.Generic.List[string]

    foreach ($um in [regex]::Matches($Message, $UrlRegex)) {
        $u = $um.Value
        try {
            $uri = [uri]$u
            if ($uri.Host) { $tokens.Add($uri.Host.ToLowerInvariant()) }
        } catch { }
    }

    foreach ($im in [regex]::Matches($Message, $IpRegex)) { $tokens.Add($im.Value) }

    foreach ($hm in [regex]::Matches($Message, $HostRegex)) {
        $h = $hm.Value.ToLowerInvariant()
        if ($h -match '\.(dll|exe|msi|zip|cab|log|txt|json|xml|tmp)$') { continue }
        $tokens.Add($h)
    }

    ($tokens | Select-Object -Unique)
}

function Normalize-TextSignature {
    param([pscustomobject]$Parsed)
    $s = if ($Parsed -and $Parsed.Msg) { $Parsed.Msg } else { $Parsed.Raw }
    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    $s
}

function Get-ShortSummary {
    param([string]$RawLine)
    $s = $RawLine
    if ($s -match '\[(?<inner>.+?)\]\s*$') { $s = $Matches['inner'] }
    $s = $s -replace '^\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}\s+\w+\s+', ''
    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    if ($s.Length -gt 110) { $s = $s.Substring(0, 110) + '…' }
    $s
}

# ---------------------- Stats objects ----------------------
function New-Stats {
    [ordered]@{
        Total     = 0
        FirstSeen = $null
        LastSeen  = $null
        Occ       = New-Object System.Collections.Generic.List[object]
        Signature = $null
    }
}

function Add-Occ {
    param(
        [hashtable]$Index,
        [string]$Key,
        [pscustomobject]$Parsed,
        [int]$GlobalLineNo,
        [string]$FilePath,
        [int]$FileLineNo,
        [string]$Signature
    )

    if (-not $Index.ContainsKey($Key)) {
        $Index[$Key] = New-Stats
        if ($Signature) { $Index[$Key].Signature = $Signature }
    }

    $st = $Index[$Key]
    $st.Total++

    $ts = $Parsed.Ts
    if ($ts) {
        if (-not $st.FirstSeen -or $ts -lt $st.FirstSeen) { $st.FirstSeen = $ts }
        if (-not $st.LastSeen  -or $ts -gt $st.LastSeen)  { $st.LastSeen  = $ts }
    }

    $st.Occ.Add([pscustomobject]@{
        Ts           = $ts
        GlobalLineNo = $GlobalLineNo
        FilePath     = $FilePath
        FileLineNo   = $FileLineNo
        Summary      = (Get-ShortSummary -RawLine $Parsed.Raw)
        RawLine      = $Parsed.Raw
    })
}

function Get-LatestOcc {
    param([hashtable]$Index,[string]$Key)

    if (-not $Index.ContainsKey($Key)) { return $null }
    $occ = @($Index[$Key].Occ)
    if ($occ.Count -eq 0) { return $null }

    $withTs = @($occ | Where-Object { $_.Ts })
    if ($withTs.Count -gt 0) {
        return @($occ | Sort-Object Ts -Descending | Select-Object -First 1)[0]
    }
    return @($occ | Sort-Object GlobalLineNo -Descending | Select-Object -First 1)[0]
}

function Get-LastOccs {
    param([hashtable]$Index,[string]$Key,[int]$Max = 10)

    if (-not $Index.ContainsKey($Key)) { return @() }
    $occ = @($Index[$Key].Occ)
    if ($occ.Count -eq 0) { return @() }

    $withTs = @($occ | Where-Object { $_.Ts })
    if ($withTs.Count -gt 0) {
        return @($occ | Sort-Object Ts -Descending | Select-Object -First $Max)
    }
    return @($occ | Sort-Object GlobalLineNo -Descending | Select-Object -First $Max)
}

# ---------------------- Prepass: count lines + keep last N (combined) -------
function Get-LogPrepassCombined {
    param([string[]]$LogPaths,[int]$KeepLast)

    $q = New-Object System.Collections.Generic.Queue[object]
    $totalLineNo = 0
    $fileCount = 0

    foreach ($lp in $LogPaths) {
        $fileCount++
        if (-not $Quiet) {
            Write-Host -NoNewline ("`rScanning [{0}/{1}]: {2}".PadRight(78) -f $fileCount, $LogPaths.Count, (Split-Path -Leaf $lp))
        }

        $fileLineNo = 0
        foreach ($line in (Get-LogLinesShared -LogPath $lp)) {
            $fileLineNo++
            $totalLineNo++

            if ($KeepLast -gt 0) {
                $q.Enqueue([pscustomobject]@{
                    Line       = $line
                    FilePath   = $lp
                    FileLineNo = $fileLineNo
                    GlobalLine = $totalLineNo
                })
                while ($q.Count -gt $KeepLast) { [void]$q.Dequeue() }
            }

            if (-not $Quiet -and ($totalLineNo % 5000 -eq 0)) {
                Write-Host -NoNewline ("`rScanning lines: {0:n0}".PadRight(78) -f $totalLineNo)
            }
        }
    }

    if (-not $Quiet) { Write-Host "" }

    [pscustomobject]@{
        TotalLines = $totalLineNo
        LastItems  = @($q)
    }
}

# ---------------------- Token index build ----------------------------------
function Build-TokenIndexFromTailItems {
    param([object[]]$Items,[int]$TotalForProgress)

    Write-Header "Indexing tokens (IPs/hostnames) in Logs"
    $idx = @{}
    $done = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    foreach ($it in $Items) {
        $done++
        if (-not $Quiet -and ($done % 500 -eq 0)) { Write-ProgressInline -Done $done -Total $TotalForProgress }

        $parsed = Try-ParseLine -Line $it.Line
        $tokens = Extract-TokensFromMessage -Message $parsed.Msg
        foreach ($t in $tokens) {
            Add-Occ -Index $idx -Key $t -Parsed $parsed -GlobalLineNo $it.GlobalLine -FilePath $it.FilePath -FileLineNo $it.FileLineNo -Signature $null
        }
    }

    $sw.Stop()
    if (-not $Quiet) { Clear-ProgressInline }
    if (-not $Quiet) {
        Write-Host ("Done. Lines indexed: {0:n0}  Tokens: {1:n0}  Time: {2}" -f $done, $idx.Count, $sw.Elapsed) -ForegroundColor Green
    }

    return $idx
}

function Build-TokenIndexFullCombined {
    param([string[]]$LogPaths,[int]$TotalLines)

    Write-Header "Indexing tokens (IPs/hostnames) in Logs"
    $idx = @{}
    $done = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $fileNo = 0
    foreach ($lp in $LogPaths) {
        $fileNo++
        if (-not $Quiet) {
            Write-Host ""
            Write-Host ("Reading [{0}/{1}]: {2}" -f $fileNo, $LogPaths.Count, $lp) -ForegroundColor DarkGray
        }

        $fileLineNo = 0
        foreach ($line in (Get-LogLinesShared -LogPath $lp)) {
            $fileLineNo++
            $done++
            if (-not $Quiet -and ($done % 2000 -eq 0)) { Write-ProgressInline -Done $done -Total $TotalLines }

            $parsed = Try-ParseLine -Line $line
            $tokens = Extract-TokensFromMessage -Message $parsed.Msg
            foreach ($t in $tokens) {
                Add-Occ -Index $idx -Key $t -Parsed $parsed -GlobalLineNo $done -FilePath $lp -FileLineNo $fileLineNo -Signature $null
            }
        }
    }

    $sw.Stop()
    if (-not $Quiet) { Clear-ProgressInline }
    if (-not $Quiet) {
        Write-Host ("Done. Lines indexed: {0:n0}  Tokens: {1:n0}  Time: {2}" -f $done, $idx.Count, $sw.Elapsed) -ForegroundColor Green
    }

    return $idx
}

# ---------------------- Full-text grouped search ----------------------------
function Build-FullTextGroupsForTerm {
    param(
        [string]$Term,
        [switch]$UseTail,
        [object[]]$TailItems,
        [string[]]$LogPaths,
        [int]$TotalLines
    )

    $groups = @{}
    if ([string]::IsNullOrWhiteSpace($Term)) { return $groups }

    $t = $Term
    Write-Header ("Full-text search: '{0}' (grouped)" -f $t)

    if ($UseTail) {
        $done = 0
        foreach ($it in $TailItems) {
            $done++
            if (-not $Quiet -and ($done % 500 -eq 0)) { Write-ProgressInline -Done $done -Total $TailItems.Count }

            if ($it.Line -like "*$t*") {
                $parsed = Try-ParseLine -Line $it.Line
                $sig = Normalize-TextSignature -Parsed $parsed
                Add-Occ -Index $groups -Key $sig -Parsed $parsed -GlobalLineNo $it.GlobalLine -FilePath $it.FilePath -FileLineNo $it.FileLineNo -Signature $sig
            }
        }
        if (-not $Quiet) { Clear-ProgressInline }
        return $groups
    }

    $doneAll = 0
    $fileNo = 0
    foreach ($lp in $LogPaths) {
        $fileNo++
        if (-not $Quiet) {
            Write-Host ""
            Write-Host ("Searching [{0}/{1}]: {2}" -f $fileNo, $LogPaths.Count, $lp) -ForegroundColor DarkGray
        }

        $fileLineNo = 0
        foreach ($line in (Get-LogLinesShared -LogPath $lp)) {
            $fileLineNo++
            $doneAll++
            if (-not $Quiet -and ($doneAll % 2000 -eq 0)) { Write-ProgressInline -Done $doneAll -Total $TotalLines }

            if ($line -like "*$t*") {
                $parsed = Try-ParseLine -Line $line
                $sig = Normalize-TextSignature -Parsed $parsed
                Add-Occ -Index $groups -Key $sig -Parsed $parsed -GlobalLineNo $doneAll -FilePath $lp -FileLineNo $fileLineNo -Signature $sig
            }
        }
    }

    if (-not $Quiet) { Clear-ProgressInline }
    return $groups
}

# ---------------------- Context window (+/- 10) ----------------------------
function Get-ContextWindowForFileLine {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][int]$TargetLine,
        [int]$Before = 10,
        [int]$After  = 10
    )

    if (-not (Test-Path $FilePath)) { throw "File not found: $FilePath" }

    $start = [Math]::Max(1, $TargetLine - $Before)
    $end   = $TargetLine + $After

    $fs = $null
    $sr = $null
    $out = New-Object System.Collections.Generic.List[object]

    try {
        $fs = New-Object System.IO.FileStream(
            $FilePath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
        )
        $sr = New-Object System.IO.StreamReader($fs)

        $lineNo = 0
        while (-not $sr.EndOfStream) {
            $line = $sr.ReadLine()
            $lineNo++
            if ($lineNo -lt $start) { continue }
            if ($lineNo -gt $end) { break }

            $out.Add([pscustomobject]@{
                FileLine = $lineNo
                IsHit    = ($lineNo -eq $TargetLine)
                Text     = $line
            })
        }
    } finally {
        if ($sr) { $sr.Dispose() }
        if ($fs) { $fs.Dispose() }
    }

    return @($out)
}

function Show-ContextWindow {
    param(
        [pscustomobject]$Occurrence,
        [string]$Title
    )

    Write-Host ""
    Write-Header $Title

    $when = if ($Occurrence.Ts) { $Occurrence.Ts.ToString('yyyy-MM-dd HH:mm:ss') } else { '-' }

    [pscustomobject]@{
        When     = $when
        File     = $Occurrence.FilePath
        FileLine = $Occurrence.FileLineNo
    } | Format-List

    $ctx = @(Get-ContextWindowForFileLine -FilePath $Occurrence.FilePath -TargetLine $Occurrence.FileLineNo -Before 10 -After 10)
    if ($ctx.Count -eq 0) {
        Write-Host "(No context lines returned.)" -ForegroundColor Yellow
        return
    }

    Write-Host ""
    foreach ($c in $ctx) {
        $prefix = if ($c.IsHit) { '>>' } else { '  ' }
        Write-Host ("{0} {1,6}: {2}" -f $prefix, $c.FileLine, $c.Text)
    }
}

# ---------------------- Listing helpers ------------------------------------
function Make-IndexedListFromRows {
    param([object[]]$Rows)

    $i = 0
    $out = @()
    foreach ($r in $Rows) {
        $i++
        $o = $r | Select-Object *
        $o | Add-Member -NotePropertyName Index -NotePropertyValue $i -Force
        $out += $o
    }
    $out
}

function Show-ListPaged {
    param(
        [object[]]$IndexedRows,
        [string]$Title,
        [int]$PageSize = 35
    )

    if (-not $IndexedRows -or $IndexedRows.Count -eq 0) {
        Write-Host ""
        Write-Host "(No results.)" -ForegroundColor Yellow
        return
    }

    $page = 0
    $totalPages = [int][Math]::Ceiling($IndexedRows.Count / [double]$PageSize)

    while ($true) {
        $start = $page * $PageSize
        $slice = @($IndexedRows | Select-Object -Skip $start -First $PageSize)

        Write-Host ""
        Write-Header ("{0}  (Page {1}/{2}, Items {3}-{4} of {5})" -f $Title, ($page+1), $totalPages, ($start+1), ($start + $slice.Count), $IndexedRows.Count)
        $slice | Format-Table -AutoSize

        Write-Host ""
        Write-Host "N=Next  P=Prev  ENTER=Exit paging" -ForegroundColor DarkGray
        $c = Read-Host "Page"
        if ([string]::IsNullOrWhiteSpace($c)) { break }
        if ($c -match '^(?i)n$') { if ($page -lt ($totalPages - 1)) { $page++ }; continue }
        if ($c -match '^(?i)p$') { if ($page -gt 0) { $page-- }; continue }
        break
    }
}

# ---------------------- Option B decision ----------------------------------
function Is-TokenLike {
    param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return $false }
    if ($s -match '^(?i)https?://') { return $true }
    if ($s -match $IpRegex) { return $true }
    if ($s -match '\.' -and $s -match '[A-Za-z]') { return $true }
    return $false
}

# ---------------------- Token-mode rows ------------------------------------
function Get-TokenRows {
    param([hashtable]$TokenIndex)

    $TokenIndex.GetEnumerator() |
        ForEach-Object {
            [pscustomobject]@{
                Token    = $_.Key
                Count    = $_.Value.Total
                LastSeen = $_.Value.LastSeen
            }
        } |
        Sort-Object -Property $script:SortCountThenLast
}

function Find-MatchingTokens {
    param([hashtable]$TokenIndex,[string]$Partial)
    $p = $Partial.ToLowerInvariant()
    @($TokenIndex.Keys | Where-Object { $_.ToLowerInvariant().Contains($p) })
}

# ---------------------- Full-text rows -------------------------------------
function Get-FullTextGroupRows {
    param([hashtable]$Groups)

    $Groups.GetEnumerator() |
        ForEach-Object {
            $sig = $_.Key
            $st  = $_.Value
            $preview = $sig
            if ($preview.Length -gt 110) { $preview = $preview.Substring(0,110) + '…' }

            [pscustomobject]@{
                Message  = $preview
                Count    = $st.Total
                LastSeen = $st.LastSeen
            }
        } |
        Sort-Object -Property $script:SortCountThenLast
}

# ---------------------- Drilldown shared -----------------------------------
function Show-DetailForKey {
    param(
        [hashtable]$Index,
        [string]$Key,
        [string]$DisplayTitle
    )

    if (-not $Index.ContainsKey($Key)) {
        Write-Host "Not found." -ForegroundColor Yellow
        return
    }

    $st = $Index[$Key]

    Write-Host ""
    Write-Header $DisplayTitle
    [pscustomobject]@{
        Key       = $Key
        Count     = $st.Total
        FirstSeen = $st.FirstSeen
        LastSeen  = $st.LastSeen
    } | Format-List

    $latest = Get-LatestOcc -Index $Index -Key $Key
    if ($null -ne $latest) {
        Show-ContextWindow -Occurrence $latest -Title "Latest entry (+/- 10 lines)"
    } else {
        Write-Host ""
        Write-Host "(No occurrences stored.)" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Header "More"
    Write-Host "[O] Pick a different occurrence (last 10) + context" -ForegroundColor DarkGray
    Write-Host "ENTER=Return" -ForegroundColor DarkGray
    $c = Read-Host "Choice"

    if ($c -match '^(?i)o$') {
        $last = @(Get-LastOccs -Index $Index -Key $Key -Max 10)
        if ($last.Count -eq 0) {
            Write-Host "(No occurrences.)" -ForegroundColor Yellow
            return
        }

        Write-Host ""
        Write-Header "Last 10 occurrences"
        $rows = @()
        $i = 0
        foreach ($o in $last) {
            $i++
            $rows += [pscustomobject]@{
                Index    = $i
                When     = $(if ($o.Ts) { $o.Ts.ToString('yyyy-MM-dd HH:mm:ss') } else { '-' })
                File     = (Split-Path -Leaf $o.FilePath)
                FileLine = $o.FileLineNo
                Summary  = $o.Summary
            }
        }
        $rows | Format-Table -AutoSize

        $pick = Read-Host "Occurrence index (ENTER to cancel)"
        if ([string]::IsNullOrWhiteSpace($pick)) { return }
        if ($pick -notmatch '^\d+$') { Write-Host "Invalid index." -ForegroundColor Yellow; return }
        $n = [int]$pick
        if ($n -lt 1 -or $n -gt $last.Count) { Write-Host "Out of range." -ForegroundColor Yellow; return }

        Show-ContextWindow -Occurrence $last[$n-1] -Title "Selected occurrence (+/- 10 lines)"
        Read-Host "Press ENTER to return"
    }
}

# ---------------------- Main -----------------------------------------------
$source = Select-LogSource
$logPaths = @($source.Paths)

Write-Header "Scanning Logs (Prepass)"
if (-not $Quiet) {
    Write-Host ("Source: {0}" -f $source.Display) -ForegroundColor DarkGray
    if ($source.Type -eq 'Folder') { Write-Host ("Files:  {0}" -f $logPaths.Count) -ForegroundColor DarkGray }
}

$pre = Get-LogPrepassCombined -LogPaths $logPaths -KeepLast $script:QuickLineLimit
$totalLines = [int]$pre.TotalLines

$script:UsingQuickScope = $false
$script:TailItems = $pre.LastItems

$tokenIndex = $null
if ($Full) {
    $tokenIndex = Build-TokenIndexFullCombined -LogPaths $logPaths -TotalLines $totalLines
} else {
    if ($totalLines -gt $script:QuickLineLimit) {
        $script:UsingQuickScope = $true
        if (-not $Quiet) {
            Write-Host ""
            Write-Host ("Quick mode: total combined lines = {0:n0}. Indexing LAST {1:n0} lines only." -f $totalLines, $script:QuickLineLimit) -ForegroundColor Yellow
        }

        $tokenIndex = Build-TokenIndexFromTailItems -Items $script:TailItems -TotalForProgress $script:QuickLineLimit

        if (-not $Search) {
            Write-Host ""
            $ans = Read-Host "Analyze ALL lines now? (Y/N)"
            if ($ans -match '^(?i)y$') {
                $tokenIndex = Build-TokenIndexFullCombined -LogPaths $logPaths -TotalLines $totalLines
                $script:UsingQuickScope = $false
            }
        } else {
            if (-not $Quiet) {
                Write-Host ""
                Write-Host "NOTE: Quick mode is active (last 10,000 combined lines). Re-run with -Full for full scope." -ForegroundColor Yellow
            }
        }
    } else {
        $tokenIndex = Build-TokenIndexFullCombined -LogPaths $logPaths -TotalLines $totalLines
        $script:UsingQuickScope = $false
    }
}

# ---------------------- CLI: -Search (Option B) ----------------------------
if ($Search) {
    if (Is-TokenLike -s $Search) {
        if ($tokenIndex.ContainsKey($Search)) {
            Show-DetailForKey -Index $tokenIndex -Key $Search -DisplayTitle ("Token detail: {0}" -f $Search)
            exit 0
        }

        $matches = @(Find-MatchingTokens -TokenIndex $tokenIndex -Partial $Search | Sort-Object)
        if ($matches.Count -eq 0) {
            Write-Host "No tokens matched '$Search'." -ForegroundColor Yellow
            exit 1
        }

        $rows = @(
            $matches | ForEach-Object {
                [pscustomobject]@{
                    Token    = $_
                    Count    = $tokenIndex[$_].Total
                    LastSeen = $tokenIndex[$_].LastSeen
                }
            } | Sort-Object -Property $script:SortCountThenLast
        )

        $indexed = @(Make-IndexedListFromRows -Rows $rows)
        Write-Header ("Token matches for '{0}' (multiple)" -f $Search)
        $indexed | Select-Object Index, Token, Count, LastSeen | Format-Table -AutoSize
        exit 2
    } else {
        $groups = Build-FullTextGroupsForTerm -Term $Search -UseTail:($script:UsingQuickScope) -TailItems $script:TailItems -LogPaths $logPaths -TotalLines $totalLines
        if ($groups.Count -eq 0) {
            Write-Host "No full-text matches for '$Search'." -ForegroundColor Yellow
            exit 1
        }

        $rows = @(Get-FullTextGroupRows -Groups $groups)
        $indexed = @(Make-IndexedListFromRows -Rows $rows)
        Write-Header ("Full-text groups for '{0}'" -f $Search)
        $indexed | Select-Object Index, Count, LastSeen, Message | Format-Table -AutoSize
        exit 2
    }
}

# ---------------------- Interactive ----------------------------------------
$allTokenRows = @(Get-TokenRows -TokenIndex $tokenIndex)
$topTokenRows = @($allTokenRows | Select-Object -First 20)

$script:Mode = 'TopTokens'  # TopTokens / AllTokens / TokenMatches / TextGroups
$script:Current = @()
$script:LastTextGroups = $null

function Set-CurrentRows {
    param([object[]]$Rows,[string]$Mode)
    $script:Mode = $Mode
    $script:Current = @(Make-IndexedListFromRows -Rows $Rows)
}

Set-CurrentRows -Rows $topTokenRows -Mode 'TopTokens'

while ($true) {
    Write-Host ""

    switch ($script:Mode) {
        'TopTokens'    { Write-Header "Tokens (Top 20) - enter index for detail, A=All, or type a search term" }
        'AllTokens'    { Write-Header "Tokens (All) - enter index for detail, T=Top, or type a search term" }
        'TokenMatches' { Write-Header "Token matches - enter index for detail, T=Top, or type a new search term" }
        'TextGroups'   { Write-Header "Full-text groups - enter index for detail, T=Top, or type a new search term" }
        default        { Write-Header "Results - enter index for detail, or type a search term" }
    }

    if ($script:Current -and $script:Current.Count -gt 0) {
        if ($script:Mode -eq 'TextGroups') {
            $script:Current | Select-Object Index, Count, LastSeen, Message | Format-Table -AutoSize
        } else {
            $script:Current | Select-Object Index, Token, Count, LastSeen | Format-Table -AutoSize
        }
    } else {
        Write-Host "(No results.)" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Header "Search / Select (Option B)"
    Write-Host "Type: any term (auto token vs full-text), or an index number from current list." -ForegroundColor DarkGray
    Write-Host "A=All tokens  T=Top tokens  Q=Quit" -ForegroundColor DarkGray
    $in = Read-Host "Input"

    if ($in -match '^(?i)q$') { break }

    if ($in -match '^(?i)t$') {
        Set-CurrentRows -Rows $topTokenRows -Mode 'TopTokens'
        continue
    }

    if ($in -match '^(?i)a$') {
        Set-CurrentRows -Rows $allTokenRows -Mode 'AllTokens'
        Show-ListPaged -IndexedRows ($script:Current | Select-Object Index, Token, Count, LastSeen) -Title "All tokens"
        continue
    }

    if ($in -match '^\d+$') {
        $num = [int]$in
        $pick = @($script:Current | Where-Object { $_.Index -eq $num })
        if ($pick.Count -ne 1) {
            Write-Host "Index not found in current list: $num" -ForegroundColor Yellow
            continue
        }

        if ($script:Mode -eq 'TextGroups') {
            if (-not $script:LastTextGroups -or $script:LastTextGroups.Count -eq 0) {
                Write-Host "Text group context unavailable. Re-run the text search." -ForegroundColor Yellow
                continue
            }

            $selectedMessage = $pick[0].Message
            $key = $null
            foreach ($k in $script:LastTextGroups.Keys) {
                $preview = $k
                if ($preview.Length -gt 110) { $preview = $preview.Substring(0,110) + '…' }
                if ($preview -eq $selectedMessage) { $key = $k; break }
            }
            if (-not $key) {
                $key = @($script:LastTextGroups.Keys | Where-Object { $_ -like "$($selectedMessage.TrimEnd('…'))*" } | Select-Object -First 1)
            }
            if (-not $key) {
                Write-Host "Could not resolve group key. Re-run the text search." -ForegroundColor Yellow
                continue
            }

            Show-DetailForKey -Index $script:LastTextGroups -Key $key -DisplayTitle "Full-text group detail"
        } else {
            Show-DetailForKey -Index $tokenIndex -Key $pick[0].Token -DisplayTitle ("Token detail: {0}" -f $pick[0].Token)
        }

        continue
    }

    if ([string]::IsNullOrWhiteSpace($in)) { continue }

    if (Is-TokenLike -s $in) {
        $m = @(Find-MatchingTokens -TokenIndex $tokenIndex -Partial $in)
        if ($m.Count -eq 0) {
            Write-Host "No tokens matched '$in'." -ForegroundColor Yellow
            continue
        }

        $rows = @(
            $m | ForEach-Object {
                [pscustomobject]@{
                    Token    = $_
                    Count    = $tokenIndex[$_].Total
                    LastSeen = $tokenIndex[$_].LastSeen
                }
            } | Sort-Object -Property $script:SortCountThenLast
        )

        Set-CurrentRows -Rows $rows -Mode 'TokenMatches'
        continue
    } else {
        $script:LastTextGroups = Build-FullTextGroupsForTerm -Term $in -UseTail:($script:UsingQuickScope) -TailItems $script:TailItems -LogPaths $logPaths -TotalLines $totalLines

        if (-not $script:LastTextGroups -or $script:LastTextGroups.Count -eq 0) {
            Write-Host "No full-text matches for '$in'." -ForegroundColor Yellow
            continue
        }

        $rows = @(Get-FullTextGroupRows -Groups $script:LastTextGroups)
        Set-CurrentRows -Rows $rows -Mode 'TextGroups'
        continue
    }
}

Write-Host "Done." -ForegroundColor Green
exit 0