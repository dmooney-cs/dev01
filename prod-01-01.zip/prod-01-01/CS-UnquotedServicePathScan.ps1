<#
.SYNOPSIS
  ConnectSecure Toolbox - Unquoted Service Path Scan

.DESCRIPTION
  Scans AUTO_START Windows services for unquoted executable paths containing spaces.
  Uses CyberCNSAgent osqueryi.exe when available, with a PowerShell CIM fallback.

  Interactive toolbox mode includes a menu, on-screen results, and export support.
  -ExportOnly runs silently and writes exports to C:\CS-Toolbox-TEMP\Collected-Info.

.PARAMETER ExportOnly
  Runs scan without prompts and exports results to Collected-Info.

.PARAMETER Gui
  Displays results in Out-GridView when available. In -ExportOnly mode this is ignored.

.PARAMETER OutputRoot
  Optional export root. Defaults to C:\CS-Toolbox-TEMP\Collected-Info.

.PARAMETER NoHtmlOpen
  Prevents automatic opening of the HTML report in interactive runs.

.EXAMPLE
  .\CS-UnquotedServicePathScan.ps1

.EXAMPLE
  .\CS-UnquotedServicePathScan.ps1 -ExportOnly

.EXAMPLE
  .\CS-UnquotedServicePathScan.ps1 -Gui
#>

[CmdletBinding()]
param(
    [switch]$ExportOnly,
    [switch]$Gui,
    [string]$OutputRoot = 'C:\CS-Toolbox-TEMP\Collected-Info',
    [switch]$NoHtmlOpen
)

$ErrorActionPreference = 'Continue'
$Script:ToolName = 'CS-UnquotedServicePathScan'
$Script:LastRun = $null
$Script:LastOutDir = $null

function Write-Info {
    param([string]$Message)
    if (-not $ExportOnly) { Write-Host "[INFO]  $Message" -ForegroundColor Cyan }
}

function Write-Warn {
    param([string]$Message)
    if (-not $ExportOnly) { Write-Host "[WARN]  $Message" -ForegroundColor Yellow }
}

function Write-Bad {
    param([string]$Message)
    if (-not $ExportOnly) { Write-Host "[ERROR] $Message" -ForegroundColor Red }
}

function Ensure-Folder {
    param([string]$Path)
    if (-not [string]::IsNullOrWhiteSpace($Path) -and -not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function New-RunFolder {
    Ensure-Folder -Path $OutputRoot
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $outDir = Join-Path $OutputRoot "$($Script:ToolName)_$stamp"
    Ensure-Folder -Path $outDir
    $Script:LastOutDir = $outDir
    return $outDir
}

function Get-OsqueryPath {
    $candidates = @(
        'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe',
        'C:\Program Files\CyberCNSAgent\osqueryi.exe',
        'C:\Program Files (x86)\ConnectSecureAgent\osqueryi.exe',
        'C:\Program Files\ConnectSecureAgent\osqueryi.exe'
    )

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }

    $fromPath = Get-Command osqueryi.exe -ErrorAction SilentlyContinue
    if ($fromPath -and $fromPath.Source) { return $fromPath.Source }

    return $null
}

function ConvertTo-SafeHtml {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function ConvertTo-ServiceFinding {
    param(
        [string]$Name,
        [string]$DisplayName,
        [string]$StartType,
        [string]$Path,
        [string]$Source
    )

    $rawPath = ([string]$Path).Trim()
    $exePath = $rawPath
    $arguments = ''

    $exeMatch = [regex]::Match($rawPath, '(?i)^(.+?\.exe)(\s+.*)?$')
    if ($exeMatch.Success) {
        $exePath = $exeMatch.Groups[1].Value.Trim()
        $arguments = $exeMatch.Groups[2].Value.Trim()
    }

    $risk = 'Review'
    if ($rawPath -match '(?i)^\s*[A-Z]:\\Program Files( \(x86\))?\\' -and $rawPath -notmatch '^\s*"') { $risk = 'High' }
    elseif ($rawPath -match '(?i)^\s*[A-Z]:\\.+\s.+\.exe' -and $rawPath -notmatch '^\s*"') { $risk = 'Medium' }

    [pscustomobject]@{
        Name             = $Name
        DisplayName      = $DisplayName
        StartType        = $StartType
        Risk             = $risk
        ExecutablePath   = $exePath
        Arguments        = $arguments
        RawPath          = $rawPath
        RecommendedPath  = if ($arguments) { '"' + $exePath + '" ' + $arguments } else { '"' + $exePath + '"' }
        Source           = $Source
    }
}

function Invoke-OsqueryScan {
    param([string]$OsqueryPath)

    $query = @'
SELECT
  name,
  display_name,
  start_type,
  path
FROM services
WHERE
  start_type = 'AUTO_START'
  AND path != ''
  AND TRIM(path) NOT LIKE '"%'
  AND path LIKE '% %'
  AND LOWER(path) LIKE '%.exe%'
  AND path NOT LIKE 'C:\Windows%'
;
'@

    $output = & $OsqueryPath --json $query 2>$null
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace(($output | Out-String))) {
        return $null
    }

    $rows = $output | Out-String | ConvertFrom-Json -ErrorAction SilentlyContinue
    if ($null -eq $rows) { return $null }

    $findings = @()
    foreach ($row in @($rows)) {
        $findings += ConvertTo-ServiceFinding -Name $row.name -DisplayName $row.display_name -StartType $row.start_type -Path $row.path -Source 'osquery'
    }
    return $findings
}

function Invoke-PowerShellFallbackScan {
    $allServices = Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue |
        Where-Object {
            $_.StartMode -eq 'Auto' -and
            -not [string]::IsNullOrWhiteSpace($_.PathName) -and
            $_.PathName.ToLowerInvariant() -like '*.exe*' -and
            $_.PathName -notlike 'C:\Windows*'
        }

    $findings = @()
    $nonMatches = @()
    foreach ($svc in @($allServices)) {
        $isUnquoted = $svc.PathName.Trim() -notlike '"*' -and $svc.PathName -like '* *'
        if ($isUnquoted) {
            $findings += ConvertTo-ServiceFinding -Name $svc.Name -DisplayName $svc.DisplayName -StartType $svc.StartMode -Path $svc.PathName -Source 'PowerShell CIM fallback'
        } else {
            $nonMatches += [pscustomobject]@{
                Name            = $svc.Name
                DisplayName     = $svc.DisplayName
                StartType       = $svc.StartMode
                Risk            = 'Clean'
                ExecutablePath  = $svc.PathName.Trim()
                Arguments       = ''
                RawPath         = $svc.PathName.Trim()
                RecommendedPath = ''
                Source          = 'PowerShell CIM fallback'
            }
        }
    }
    return @($findings) + @($nonMatches)
}

function Get-UnquotedServicePathFindings {
    Write-Info 'Starting unquoted service path scan...'

    $osqueryPath = Get-OsqueryPath
    $findings = $null

    if ($osqueryPath) {
        Write-Info "Using osquery: $osqueryPath"
        $findings = Invoke-OsqueryScan -OsqueryPath $osqueryPath
    }

    if ($null -eq $findings -or $findings.Count -eq 0) {
        Write-Warn 'osquery was unavailable or returned no usable data. Using PowerShell CIM fallback.'
        $findings = Invoke-PowerShellFallbackScan
    }

    if ($null -eq $findings) { $findings = @() }
    $matches    = @($findings | Where-Object { $_.Risk -ne 'Clean' } | Sort-Object Risk, Name)
    $nonMatches = @($findings | Where-Object { $_.Risk -eq 'Clean' } | Sort-Object Name)
    return @($matches) + @($nonMatches)
}

function Show-ResultsTable {
    param([object[]]$Findings)

    if ($Findings.Count -eq 0) {
        Write-Host ''
        Write-Host 'No matching unquoted AUTO_START service paths were found.' -ForegroundColor Green
        return
    }

    Write-Host ''
    Write-Host "Unquoted AUTO_START service paths found: $($Findings.Count)" -ForegroundColor Yellow
    Write-Host ''
    $Findings |
        Select-Object Risk, Name, DisplayName, StartType, ExecutablePath, Arguments, Source |
        Format-Table -AutoSize | Out-Host

    Write-Host ''
    Write-Host 'Recommended remediation: quote the executable path while preserving arguments.' -ForegroundColor Cyan
}

function New-HtmlReport {
    param(
        [object[]]$Findings,
        [string]$OutDir,
        [string]$CsvPath,
        [string]$JsonPath,
        [string]$TxtPath
    )

    $generated = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $computer = $env:COMPUTERNAME
    $count = $Findings.Count

    $rows = foreach ($item in $Findings) {
        $riskClass = switch ($item.Risk) {
            'High' { 'risk-high' }
            'Medium' { 'risk-medium' }
            default { 'risk-review' }
        }
        "<tr><td class='$riskClass'>$(ConvertTo-SafeHtml $item.Risk)</td><td>$(ConvertTo-SafeHtml $item.Name)</td><td>$(ConvertTo-SafeHtml $item.DisplayName)</td><td>$(ConvertTo-SafeHtml $item.StartType)</td><td><code>$(ConvertTo-SafeHtml $item.RawPath)</code></td><td><code>$(ConvertTo-SafeHtml $item.RecommendedPath)</code></td><td>$(ConvertTo-SafeHtml $item.Source)</td></tr>"
    }

    if ($count -eq 0) {
        $rows = "<tr><td colspan='7' class='clean'>No matching unquoted AUTO_START service paths were found.</td></tr>"
    }

    $html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CS Unquoted Service Path Scan</title>
<style>
body { font-family: Segoe UI, Arial, sans-serif; margin: 24px; background: #f7f9fc; color: #1f2937; }
h1 { margin-bottom: 4px; }
.summary { display: flex; gap: 12px; flex-wrap: wrap; margin: 18px 0; }
.card { background: #fff; border: 1px solid #d8dee9; border-radius: 8px; padding: 12px 16px; min-width: 180px; box-shadow: 0 1px 2px rgba(0,0,0,.04); }
.card .label { font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: .04em; }
.card .value { font-size: 20px; font-weight: 700; margin-top: 4px; }
table { border-collapse: collapse; width: 100%; background: #fff; border: 1px solid #d8dee9; }
th, td { border-bottom: 1px solid #e5e7eb; padding: 9px 10px; text-align: left; vertical-align: top; }
th { background: #eaf0f7; font-size: 13px; }
code { white-space: pre-wrap; word-break: break-word; }
.risk-high { color: #991b1b; font-weight: 700; }
.risk-medium { color: #92400e; font-weight: 700; }
.risk-review { color: #1d4ed8; font-weight: 700; }
.clean { color: #166534; font-weight: 700; text-align: center; padding: 24px; }
.note { background: #fff7ed; border: 1px solid #fed7aa; border-radius: 8px; padding: 12px 16px; margin: 18px 0; }
.footer { color: #64748b; margin-top: 16px; font-size: 12px; }
</style>
</head>
<body>
<h1>CS Unquoted Service Path Scan</h1>
<div>Generated: $(ConvertTo-SafeHtml $generated)</div>
<div>Computer: $(ConvertTo-SafeHtml $computer)</div>
<div class="summary">
  <div class="card"><div class="label">Findings</div><div class="value">$count</div></div>
  <div class="card"><div class="label">Scan Type</div><div class="value">AUTO_START</div></div>
  <div class="card"><div class="label">Exports</div><div class="value">HTML / CSV / JSON / TXT</div></div>
</div>
<div class="note">
  This scan identifies automatic services whose executable path contains spaces but does not begin with a quote. Review before changing service paths. When remediating, quote only the executable path and preserve any service arguments.
</div>
<table>
<thead>
<tr>
<th>Risk</th><th>Service Name</th><th>Display Name</th><th>Start Type</th><th>Current Path</th><th>Recommended Quoted Path</th><th>Source</th>
</tr>
</thead>
<tbody>
$($rows -join "`n")
</tbody>
</table>
<div class="footer">
CSV: $(ConvertTo-SafeHtml $CsvPath)<br>
JSON: $(ConvertTo-SafeHtml $JsonPath)<br>
TXT: $(ConvertTo-SafeHtml $TxtPath)
</div>
</body>
</html>
"@

    $htmlPath = Join-Path $OutDir "$($Script:ToolName).html"
    $html | Set-Content -Path $htmlPath -Encoding UTF8
    return $htmlPath
}

function Export-Results {
    param([object[]]$Findings)

    $outDir = New-RunFolder
    $csvPath = Join-Path $outDir "$($Script:ToolName).csv"
    $jsonPath = Join-Path $outDir "$($Script:ToolName).json"
    $txtPath = Join-Path $outDir "$($Script:ToolName).txt"

    $Findings | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    $Findings | ConvertTo-Json -Depth 5 | Set-Content -Path $jsonPath -Encoding UTF8

    $lines = @()
    $lines += 'CS Unquoted Service Path Scan'
    $lines += "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $lines += "Computer: $env:COMPUTERNAME"
    $lines += "Findings: $($Findings.Count)"
    $lines += ''
    if ($Findings.Count -eq 0) {
        $lines += 'No matching unquoted AUTO_START service paths were found.'
    } else {
        foreach ($item in $Findings) {
            $lines += '------------------------------------------------------------'
            $lines += "Risk            : $($item.Risk)"
            $lines += "Name            : $($item.Name)"
            $lines += "Display Name    : $($item.DisplayName)"
            $lines += "Start Type      : $($item.StartType)"
            $lines += "Current Path    : $($item.RawPath)"
            $lines += "Recommended     : $($item.RecommendedPath)"
            $lines += "Source          : $($item.Source)"
        }
    }
    $lines | Set-Content -Path $txtPath -Encoding UTF8

    $htmlPath = New-HtmlReport -Findings $Findings -OutDir $outDir -CsvPath $csvPath -JsonPath $jsonPath -TxtPath $txtPath

    [pscustomobject]@{
        OutputFolder = $outDir
        Html         = $htmlPath
        Csv          = $csvPath
        Json         = $jsonPath
        Txt          = $txtPath
        Count        = $Findings.Count
    }
}

function Invoke-ScanAndExport {
    $findings = Get-UnquotedServicePathFindings
    $Script:LastRun = Export-Results -Findings $findings

    if (-not $ExportOnly) {
        Show-ResultsTable -Findings $findings
        Write-Host ''
        Write-Host "Exports written to: $($Script:LastRun.OutputFolder)" -ForegroundColor Green
        Write-Host "HTML report       : $($Script:LastRun.Html)" -ForegroundColor Green

        if ($Gui -and (Get-Command Out-GridView -ErrorAction SilentlyContinue)) {
            $findings | Out-GridView -Title 'CS Unquoted Service Path Scan Results'
        } elseif ($Gui) {
            Write-Warn 'Out-GridView is not available on this system. Results were shown in console and exported.'
        }

        if (-not $NoHtmlOpen -and (Test-Path -LiteralPath $Script:LastRun.Html)) {
            Start-Process $Script:LastRun.Html | Out-Null
        }
    }

    return $Script:LastRun
}

function Open-LastOutputFolder {
    if ($Script:LastOutDir -and (Test-Path -LiteralPath $Script:LastOutDir)) {
        Start-Process explorer.exe $Script:LastOutDir | Out-Null
    } else {
        Write-Warn 'No output folder exists yet. Run the scan first.'
    }
}

function Pause-Return {
    Write-Host ''
    Read-Host 'Press Enter to return to the menu'
}

function Show-MainMenu {
    do {
        Clear-Host
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ' ConnectSecure Toolbox - Unquoted Service Path Scan' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor Cyan
        Write-Host ''
        Write-Host '1. Run scan and export results'
        Write-Host '2. Run scan, export results, and show GUI table'
        Write-Host '3. Open last output folder'
        Write-Host '4. Exit / return to launcher'
        Write-Host ''
        $choice = Read-Host 'Select an option'

        switch ($choice) {
            '1' {
                $script:Gui = $false
                Invoke-ScanAndExport | Out-Null
                Pause-Return
            }
            '2' {
                $script:Gui = $true
                Invoke-ScanAndExport | Out-Null
                Pause-Return
            }
            '3' {
                Open-LastOutputFolder
                Pause-Return
            }
            '4' {
                return
            }
            default {
                Write-Warn 'Invalid selection.'
                Pause-Return
            }
        }
    } while ($true)
}

try {
    Ensure-Folder -Path $OutputRoot

    if ($ExportOnly) {
        Invoke-ScanAndExport | Out-Null
        exit 0
    }

    Show-MainMenu
    exit 0
} catch {
    Write-Bad $_.Exception.Message
    if (-not $ExportOnly) {
        Write-Host ''
        Read-Host 'Press Enter to return to the launcher'
    }
    exit 1
}
