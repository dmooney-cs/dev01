<#
.SYNOPSIS
  ConnectSecure Performance Collector - HTML only baseline.

.DESCRIPTION
  Collects ConnectSecure performance, crash, interference, access, and correlation data
  into memory first, then writes one branded HTML report as the only file in the run folder.

  Build marker: PerformanceCollector_HTML_LOGREVIEW_STYLE_BASELINE_EXPORTONLY_TARGETEDCHECKS_2026-06-03

.PARAMETER ExportOnly
  Runs collection and exports the HTML report without interactive prompts.

.NOTES
  Output root:
    C:\CS-Toolbox-TEMP\Collected-Info\ConnectSecure-Performance-Collector
#>

[CmdletBinding()]
param(
    [switch]$ExportOnly,
    [switch]$Silent
)

# In toolbox/script-menu usage, -ExportOnly must be fully non-interactive and quiet.
# It still writes the HTML report to Collected-Info, but suppresses the map, progress, and open-report prompt.
if ($ExportOnly) {
    $Silent = $true
}

# Basic fresh collector: no menu, map first, collect only after Y, HTML-only first output.
$ErrorActionPreference = 'Continue'
$script:BuildMarker = 'PerformanceCollector_HTML_LOGREVIEW_STYLE_BASELINE_EXPORTONLY_TARGETEDCHECKS_2026-06-03'
$script:LogoUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$script:ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\ConnectSecure-Performance-Collector'
$script:RunStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:RunFolder = Join-Path $script:ExportRoot $script:RunStamp
$script:HtmlPath = Join-Path $script:RunFolder ("ConnectSecure_Performance_Collector_Summary_{0}.html" -f $script:RunStamp)
$script:Results = [ordered]@{}
$script:SectionStatus = New-Object System.Collections.ArrayList

function Write-CSLine {
    param([AllowEmptyString()][string]$Message = '')
    if (-not $Silent) { Write-Host $Message }
}

function HtmlEncode {
    param($Value)
    if ($null -eq $Value) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Add-SectionStatus {
    param(
        [string]$Name,
        [string]$Status,
        [string]$Detail = ''
    )
    [void]$script:SectionStatus.Add([pscustomobject]@{
        Section = $Name
        Status  = $Status
        Detail  = $Detail
    })
}

function Show-ProgressLine {
    param(
        [int]$Index,
        [int]$Total,
        [string]$Name,
        [string]$State
    )
    if ($Silent) { return }
    $filled = [Math]::Max(1, [Math]::Floor(($Index / $Total) * 22))
    $empty = 22 - $filled
    $bar = ('#' * $filled) + ('-' * $empty)
    Write-Host ("[{0}] {1,2}/{2}  {3,-62} {4}" -f $bar, $Index, $Total, $Name, $State)
}

function Invoke-SafeCollect {
    param(
        [int]$Index,
        [int]$Total,
        [string]$Name,
        [scriptblock]$ScriptBlock
    )
    Show-ProgressLine -Index $Index -Total $Total -Name $Name -State 'Collecting'
    try {
        $data = & $ScriptBlock
        $script:Results[$Name] = $data
        Add-SectionStatus -Name $Name -Status 'Done' -Detail ''
        Show-ProgressLine -Index $Index -Total $Total -Name $Name -State 'Done'
    }
    catch {
        $err = $_.Exception.Message
        $script:Results[$Name] = [pscustomobject]@{
            Error = $err
            Category = $_.CategoryInfo.ToString()
            Command = $_.InvocationInfo.Line
            Line = $_.InvocationInfo.ScriptLineNumber
        }
        Add-SectionStatus -Name $Name -Status 'Error' -Detail $err
        Show-ProgressLine -Index $Index -Total $Total -Name $Name -State 'Error'
    }
}

function Get-SystemBaseline {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    [pscustomobject]@{
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        OS = $os.Caption
        Version = $os.Version
        BuildNumber = $os.BuildNumber
        Architecture = $os.OSArchitecture
        InstallDate = $os.InstallDate
        LastBootUpTime = $os.LastBootUpTime
        Manufacturer = $cs.Manufacturer
        Model = $cs.Model
        Domain = $cs.Domain
        TotalMemoryGB = [math]::Round(($cs.TotalPhysicalMemory / 1GB), 2)
        CPU = if ($cpu) { $cpu.Name } else { 'Not detected' }
        LogicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { $null }
    }
}

function Get-AgentServices {
    $names = @('CyberCNSAgent','CyberCNSAgentMonitor','CyberCNSAgentMonitorSvc','CyberCNSMonitor','CyberCNSAgentV2')
    $services = foreach ($name in $names) {
        $svc = Get-CimInstance -ClassName Win32_Service -Filter "Name='$name'" -ErrorAction SilentlyContinue
        if ($svc) {
            [pscustomobject]@{
                Name = $svc.Name
                DisplayName = $svc.DisplayName
                State = $svc.State
                StartMode = $svc.StartMode
                StartName = $svc.StartName
                ProcessId = $svc.ProcessId
                PathName = $svc.PathName
            }
        }
    }
    if (-not $services) {
        $services = Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match 'CyberCNS|ConnectSecure' -or $_.DisplayName -match 'CyberCNS|ConnectSecure' } |
            Select-Object Name,DisplayName,State,StartMode,StartName,ProcessId,PathName
    }
    @($services)
}

function Get-AgentFiles {
    $paths = @(
        'C:\Program Files (x86)\CyberCNSAgent',
        'C:\Program Files\CyberCNSAgent',
        'C:\ProgramData\CyberCNSAgent',
        'C:\Program Files (x86)\ConnectSecure',
        'C:\Program Files\ConnectSecure'
    )
    $items = foreach ($path in $paths) {
        if (Test-Path -LiteralPath $path) {
            Get-ChildItem -LiteralPath $path -File -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match 'cybercns|connectsecure|agent|monitor|osquery|\.exe$|\.dll$' } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 80 |
                ForEach-Object {
                    $ver = $null
                    try { $ver = $_.VersionInfo.FileVersion } catch { }
                    [pscustomobject]@{
                        Name = $_.Name
                        FullName = $_.FullName
                        Length = $_.Length
                        LastWriteTime = $_.LastWriteTime
                        FileVersion = $ver
                    }
                }
        }
    }
    @($items)
}

function Get-System7031Events {
    $start = (Get-Date).AddDays(-7)
    $events = Get-WinEvent -FilterHashtable @{ LogName='System'; Id=7031; StartTime=$start } -ErrorAction SilentlyContinue
    @($events | ForEach-Object {
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated
            ProviderName = $_.ProviderName
            Id = $_.Id
            Message = $_.Message
        }
    })
}

function Get-AgentSystem7031CrashSummary {
    $start = (Get-Date).AddDays(-7)
    $agentPattern = 'CyberCNS|ConnectSecure|CyberCNSAgent|CyberCNSAgentMonitor|CyberCNSMonitor'
    $events = @(Get-WinEvent -FilterHashtable @{ LogName='System'; Id=7031; StartTime=$start } -ErrorAction SilentlyContinue |
        Where-Object { $_.Message -match $agentPattern -or $_.ProviderName -match $agentPattern } |
        Sort-Object TimeCreated -Descending)

    $eventRows = @($events | ForEach-Object {
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated
            ProviderName = $_.ProviderName
            Id = $_.Id
            Message = $_.Message
        }
    })

    $dailyCounts = @($events |
        Group-Object { $_.TimeCreated.ToString('yyyy-MM-dd') } |
        Sort-Object Name -Descending |
        ForEach-Object {
            [pscustomobject]@{
                Date = $_.Name
                CrashCount = $_.Count
            }
        })

    $lastTen = @($events | Select-Object -First 10 | ForEach-Object {
        $message = [string]$_.Message
        if ($message.Length -gt 700) { $message = $message.Substring(0,700) + '...' }
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated
            ProviderName = $_.ProviderName
            Id = $_.Id
            MessageSnippet = $message
        }
    })

    [pscustomobject]@{
        CyberCNS7031Events = $eventRows
        CrashCountByDay = $dailyCounts
        Last10CyberCNSCrashSnippets = $lastTen
    }
}

function Get-ApplicationErrorEvents {
    $start = (Get-Date).AddDays(-7)
    $events = Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$start } -ErrorAction SilentlyContinue |
        Where-Object { $_.LevelDisplayName -in @('Error','Critical') -or $_.Id -in 1000,1001,1026 }
    @($events | Select-Object -First 200 | ForEach-Object {
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated
            ProviderName = $_.ProviderName
            Id = $_.Id
            Level = $_.LevelDisplayName
            Message = $_.Message
        }
    })
}


function Get-AgentApplicationErrorEvents {
    $start = (Get-Date).AddDays(-7)
    $agentPattern = 'cybercnsagent|cybercns|connectsecure'
    $events = Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$start } -ErrorAction SilentlyContinue |
        Where-Object {
            ($_.LevelDisplayName -in @('Error','Critical') -or $_.Id -in 1000,1001,1026) -and
            (
                $_.Message -match $agentPattern -or
                $_.ProviderName -match $agentPattern -or
                ($_.ProviderName -match 'Application Error' -and $_.Message -match $agentPattern)
            )
        }
    @($events | Select-Object -First 100 | ForEach-Object {
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated
            ProviderName = $_.ProviderName
            Id = $_.Id
            Level = $_.LevelDisplayName
            Message = $_.Message
        }
    })
}

function Get-WerAndDumps {
    $paths = @(
        'C:\ProgramData\Microsoft\Windows\WER\ReportArchive',
        'C:\ProgramData\Microsoft\Windows\WER\ReportQueue',
        "$env:LOCALAPPDATA\CrashDumps",
        'C:\Windows\Minidump',
        'C:\ProgramData\CyberCNSAgent',
        'C:\Program Files (x86)\CyberCNSAgent'
    )
    $items = foreach ($path in $paths) {
        if (Test-Path -LiteralPath $path) {
            Get-ChildItem -LiteralPath $path -Recurse -ErrorAction SilentlyContinue |
                Where-Object { -not $_.PSIsContainer -and ($_.Name -match '\.dmp$|\.mdmp$|Report\.wer$|cybercns|connectsecure') } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 100 |
                ForEach-Object {
                    [pscustomobject]@{
                        Name = $_.Name
                        FullName = $_.FullName
                        Length = $_.Length
                        LastWriteTime = $_.LastWriteTime
                    }
                }
        }
    }
    @($items)
}

function Get-AvEdrDefender {
    $products = @()
    foreach ($ns in @('root\SecurityCenter2','root\SecurityCenter')) {
        try {
            $products += Get-CimInstance -Namespace $ns -ClassName AntiVirusProduct -ErrorAction Stop |
                Select-Object displayName,pathToSignedProductExe,pathToSignedReportingExe,productState
        } catch { }
    }

    $defender = $null
    $defenderAssessment = $null
    try {
        $mp = Get-MpPreference -ErrorAction Stop
        $exclusionPaths = @($mp.ExclusionPath)
        $exclusionProcesses = @($mp.ExclusionProcess)
        $combinedExclusions = @($exclusionPaths + $exclusionProcesses) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }
        $agentExclusions = @($combinedExclusions | Where-Object { [string]$_ -match 'CyberCNS|ConnectSecure' })
        $defender = [pscustomobject]@{
            ExclusionPath = ($exclusionPaths -join '; ')
            ExclusionProcess = ($exclusionProcesses -join '; ')
            DisableRealtimeMonitoring = $mp.DisableRealtimeMonitoring
            PUAProtection = $mp.PUAProtection
        }
        $defenderAssessment = [pscustomobject]@{
            Check = 'Defender CyberCNS / ConnectSecure exclusion'
            Status = if ($agentExclusions.Count -gt 0) { 'Present' } else { 'Missing or not detected' }
            MatchingExclusions = if ($agentExclusions.Count -gt 0) { ($agentExclusions -join '; ') } else { '' }
            Guidance = if ($agentExclusions.Count -gt 0) { 'At least one Defender exclusion references CyberCNS or ConnectSecure.' } else { 'No Defender exclusion path or process referencing CyberCNS or ConnectSecure was detected. Validate partner policy before adding exclusions.' }
        }
    } catch {
        $defender = [pscustomobject]@{ Error = $_.Exception.Message }
        $defenderAssessment = [pscustomobject]@{
            Check = 'Defender CyberCNS / ConnectSecure exclusion'
            Status = 'Unknown'
            MatchingExclusions = ''
            Guidance = 'Get-MpPreference failed or Defender cmdlets are unavailable: ' + $_.Exception.Message
        }
    }

    $knownProcesses = Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match 'Sentinel|Crowd|Sophos|Defender|MsMpEng|Carbon|Cylance|Traps|Tanium|Nable|Huntress|Webroot|Bitdefender|ESET|Forti|Palo|Cortex|Elastic|Malwarebytes' } |
        Select-Object ProcessName,Id,Path

    $servicePatterns = 'Sentinel|SentinelOne|CrowdStrike|CSFalcon|Cylance|Defender|WinDefend|Malwarebytes|MBAM|Sophos|Bitdefender|Webroot|CarbonBlack|CbDefense|Traps|Cortex|Tanium|Huntress|ESET|Forti|Elastic|Palo Alto|PaloAlto'
    $knownServices = @('SentinelAgent','CSFalconService','CylanceSvc','WinDefend','MBAMService','Sophos Endpoint Defense Service','Sophos MCS Agent','Sophos AutoUpdate Service','bdservicehost','WRCoreService','CarbonBlack','CbDefense','Tanium Client','HuntressAgent','ekrn','FortiESNAC','ElasticEndpoint')
    $securityServices = @()
    try {
        $allServices = Get-CimInstance -ClassName Win32_Service -ErrorAction Stop
        $securityServices = @($allServices | Where-Object {
            $_.Name -match $servicePatterns -or $_.DisplayName -match $servicePatterns -or $knownServices -contains $_.Name -or $knownServices -contains $_.DisplayName
        } | Sort-Object DisplayName | Select-Object Name,DisplayName,State,StartMode,StartName,ProcessId,PathName)
    } catch {
        $securityServices = @([pscustomobject]@{ Error = $_.Exception.Message })
    }

    [pscustomobject]@{
        SecurityCenterProducts = @($products)
        DefenderPreference = $defender
        DefenderExclusionAssessment = $defenderAssessment
        SecurityProcesses = @($knownProcesses)
        SecurityServices = @($securityServices)
    }
}

function Get-NetworkProxyFirewall {
    $targets = @('api.myconnectsecure.com','prod.myconnectsecure.com','myconnectsecure.com','app.myconnectsecure.com','cybercns.com','www.google.com')
    $dns = foreach ($target in $targets) {
        try {
            $r = Resolve-DnsName -Name $target -ErrorAction Stop | Select-Object -First 3
            [pscustomobject]@{ Target=$target; Status='OK'; Result=($r.IPAddress -join ', '); Error='' }
        } catch { [pscustomobject]@{ Target=$target; Status='Error'; Result=''; Error=$_.Exception.Message } }
    }
    $https = foreach ($target in $targets) {
        $uri = "https://$target"
        try {
            $req = [System.Net.WebRequest]::Create($uri)
            $req.Method = 'HEAD'
            $req.Timeout = 8000
            $resp = $req.GetResponse()
            $code = [int]$resp.StatusCode
            $resp.Close()
            [pscustomobject]@{ Uri=$uri; Status='OK'; Method='HEAD'; Code=$code; Error='' }
        } catch { [pscustomobject]@{ Uri=$uri; Status='Error'; Method='HEAD'; Code=''; Error=$_.Exception.Message } }
    }
    $proxy = @()
    try { $proxy += netsh winhttp show proxy 2>&1 } catch { $proxy += $_.Exception.Message }

    $dotNetProxy = @()
    try {
        foreach ($target in @('https://cybercns.com','https://app.myconnectsecure.com','https://api.myconnectsecure.com')) {
            $proxyObj = [System.Net.WebRequest]::DefaultWebProxy
            $proxyUri = $null
            if ($proxyObj) { $proxyUri = $proxyObj.GetProxy([Uri]$target) }
            $isBypassed = $false
            if ($proxyObj) { $isBypassed = $proxyObj.IsBypassed([Uri]$target) }
            $dotNetProxy += [pscustomobject]@{
                Target = $target
                ProxyUri = if ($proxyUri) { [string]$proxyUri } else { '' }
                IsBypassed = $isBypassed
            }
        }
    } catch {
        $dotNetProxy = @([pscustomobject]@{ Error = $_.Exception.Message })
    }

    $fw = @()
    try {
        $rules = @(Get-NetFirewallRule -ErrorAction Stop |
            Where-Object { $_.DisplayName -match 'CyberCNS|ConnectSecure|Agent' -or $_.Name -match 'CyberCNS|ConnectSecure|Agent' })
        $fw = foreach ($rule in $rules) {
            $programs = @()
            try {
                $programs = @(Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $rule -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Program)
            } catch { $programs = @() }
            [pscustomobject]@{
                DisplayName = $rule.DisplayName
                Name = $rule.Name
                Enabled = $rule.Enabled
                Direction = $rule.Direction
                Action = $rule.Action
                Profile = $rule.Profile
                Program = if ($programs.Count -gt 0) { ($programs -join '; ') } else { '' }
            }
        }
    } catch { $fw = @([pscustomobject]@{ Error = $_.Exception.Message }) }
    [pscustomobject]@{
        Dns = @($dns)
        Https = @($https)
        WinHttpProxy = ($proxy -join "`n")
        DotNetDefaultProxy = @($dotNetProxy)
        FirewallRules = @($fw)
    }
}

function Get-MemoryDiskSnapshot {
    # CPU note:
    # Get-Process.CPU is cumulative processor time in seconds since the process started.
    # That value can be much higher than 100 and is not a live CPU percentage.
    # To make the report easier to read, collect both cumulative CPU seconds and a short live CPU sample percentage.
    $logicalProcessorCount = 1
    try {
        $cpuInfo = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
        if ($cpuInfo.NumberOfLogicalProcessors -and $cpuInfo.NumberOfLogicalProcessors -gt 0) {
            $logicalProcessorCount = [int]$cpuInfo.NumberOfLogicalProcessors
        }
    } catch { $logicalProcessorCount = 1 }

    $sample1Time = Get-Date
    $sample1 = @{}
    foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
        $cpuSeconds = 0
        try { if ($null -ne $p.CPU) { $cpuSeconds = [double]$p.CPU } } catch { $cpuSeconds = 0 }
        $sample1[[int]$p.Id] = $cpuSeconds
    }

    Start-Sleep -Milliseconds 1000

    $sample2Time = Get-Date
    $elapsedSeconds = ($sample2Time - $sample1Time).TotalSeconds
    if ($elapsedSeconds -le 0) { $elapsedSeconds = 1 }

    $processes = foreach ($p in @(Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending)) {
        $cpuSeconds = 0
        try { if ($null -ne $p.CPU) { $cpuSeconds = [double]$p.CPU } } catch { $cpuSeconds = 0 }

        $priorCpuSeconds = $null
        $cpuSamplePercent = $null
        if ($sample1.ContainsKey([int]$p.Id)) {
            $priorCpuSeconds = [double]$sample1[[int]$p.Id]
            $deltaCpu = $cpuSeconds - $priorCpuSeconds
            if ($deltaCpu -lt 0) { $deltaCpu = 0 }
            $cpuSamplePercent = [math]::Round((($deltaCpu / $elapsedSeconds) / $logicalProcessorCount) * 100, 2)
        }

        $path = ''
        try { $path = $p.Path } catch { $path = '' }

        [pscustomobject]@{
            ProcessName = $p.ProcessName
            Id = $p.Id
            MemoryMB = [math]::Round($p.WorkingSet64 / 1MB, 2)
            Threads = @($p.Threads).Count
            CpuSamplePercent = $cpuSamplePercent
            CpuSeconds = [math]::Round($cpuSeconds, 2)
            CpuMetricNote = 'CpuSamplePercent is an approx live 1-second sample normalized across logical processors. CpuSeconds is cumulative CPU time since process start.'
            Path = $path
        }
    }

    $disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue |
        ForEach-Object {
            [pscustomobject]@{
                DeviceID = $_.DeviceID
                SizeGB = [math]::Round($_.Size / 1GB, 2)
                FreeGB = [math]::Round($_.FreeSpace / 1GB, 2)
                FreePercent = if ($_.Size) { [math]::Round(($_.FreeSpace / $_.Size) * 100, 2) } else { $null }
            }
        }
    [pscustomobject]@{ TopProcessesByMemory = @($processes); Disks = @($disks) }
}

function Get-RecentWindowsUpdates {
    $cutoff = (Get-Date).AddDays(-30)
    $items = Get-HotFix -ErrorAction SilentlyContinue |
        Where-Object { $_.InstalledOn -and $_.InstalledOn -ge $cutoff } |
        Sort-Object InstalledOn -Descending |
        Select-Object HotFixID,Description,InstalledBy,InstalledOn
    @($items)
}

function Get-AppLockerWdac {
    $applocker = @()
    try { $applocker = Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop } catch { $applocker = "AppLocker check failed or unavailable: $($_.Exception.Message)" }
    $ci = @()
    try {
        $ciPaths = @('C:\Windows\System32\CodeIntegrity\CiPolicies\Active','C:\Windows\System32\CodeIntegrity')
        foreach ($p in $ciPaths) {
            if (Test-Path -LiteralPath $p) {
                $ci += Get-ChildItem -LiteralPath $p -ErrorAction SilentlyContinue | Select-Object Name,FullName,Length,LastWriteTime
            }
        }
    } catch { $ci = @([pscustomobject]@{ Error = $_.Exception.Message }) }
    [pscustomobject]@{ AppLockerEffectiveXmlOrError = $applocker; CodeIntegrityPolicyFiles = @($ci) }
}


function Convert-ObjectToHtmlTable {
    param(
        $Data,
        [int]$InitialRows = 20
    )

    if ($null -eq $Data) { return '<p class="muted">No data collected.</p>' }

    if ($Data -is [string]) {
        if ([string]::IsNullOrWhiteSpace($Data)) { return '<p class="muted">No data collected.</p>' }
        return '<pre>' + (HtmlEncode $Data) + '</pre>'
    }

    if ($Data -is [System.Collections.IDictionary]) {
        $dictRows = @()
        foreach ($key in $Data.Keys) {
            $dictRows += [pscustomobject]@{ Key = [string]$key; Value = $Data[$key] }
        }
        return Convert-ObjectToHtmlTable -Data $dictRows -InitialRows $InitialRows
    }

    $arr = @($Data)
    if ($arr.Count -eq 0) { return '<p class="muted">No matching items found.</p>' }

    $first = $arr | Where-Object { $null -ne $_ } | Select-Object -First 1
    if ($null -eq $first) { return '<p class="muted">No matching items found.</p>' }

    if ($first -is [string]) { return '<pre>' + (HtmlEncode ($arr -join "`n")) + '</pre>' }

    $props = @($first.PSObject.Properties | ForEach-Object { $_.Name })
    if ($props.Count -eq 0) {
        return '<pre>' + (HtmlEncode ($arr -join "`n")) + '</pre>'
    }

    function New-TableHtml {
        param($Rows, [string[]]$Properties)
        $tsb = New-Object System.Text.StringBuilder
        [void]$tsb.AppendLine('<table>')
        [void]$tsb.AppendLine('<tr>' + (($Properties | ForEach-Object { '<th>' + (HtmlEncode $_) + '</th>' }) -join '') + '</tr>')
        foreach ($row in @($Rows)) {
            $cells = foreach ($prop in $Properties) {
                $value = $null
                try { $value = $row.PSObject.Properties[$prop].Value } catch { $value = '' }
                if ($value -is [System.Array]) { $value = ($value -join '; ') }
                elseif ($value -is [System.Collections.IDictionary]) { $value = ($value | ConvertTo-Json -Depth 5 -Compress) }
                '<td>' + (HtmlEncode $value) + '</td>'
            }
            [void]$tsb.AppendLine('<tr>' + ($cells -join '') + '</tr>')
        }
        [void]$tsb.AppendLine('</table>')
        return $tsb.ToString()
    }

    $visible = @($arr | Select-Object -First $InitialRows)
    $remaining = @($arr | Select-Object -Skip $InitialRows)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<div class="table-note">Showing first ' + $visible.Count + ' of ' + $arr.Count + ' row(s). Remaining rows are included below when present.</div>')
    [void]$sb.AppendLine((New-TableHtml -Rows $visible -Properties $props))

    if ($remaining.Count -gt 0) {
        [void]$sb.AppendLine('<details class="expand-block"><summary>Show remaining ' + $remaining.Count + ' row(s)</summary>')
        [void]$sb.AppendLine((New-TableHtml -Rows $remaining -Properties $props))
        [void]$sb.AppendLine('</details>')
    }

    return $sb.ToString()
}


function Format-ReportValue {
    param($Value)
    if ($null -eq $Value) { return '' }
    if ($Value -is [datetime]) { return $Value.ToString('yyyy-MM-dd HH:mm:ss') }
    return [string]$Value
}

function Add-InfoCard {
    param(
        [string]$Title,
        [object[]]$Rows
    )
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<div class="info-card">')
    if (-not [string]::IsNullOrWhiteSpace($Title)) {
        [void]$sb.AppendLine('<h3>' + (HtmlEncode $Title) + '</h3>')
    }
    [void]$sb.AppendLine('<div class="kv-grid">')
    foreach ($row in @($Rows)) {
        $label = $row.Label
        $value = Format-ReportValue $row.Value
        if ([string]::IsNullOrWhiteSpace($value)) { $value = 'Not detected' }
        [void]$sb.AppendLine('<div class="kv-item"><div class="kv-label">' + (HtmlEncode $label) + '</div><div class="kv-value">' + (HtmlEncode $value) + '</div></div>')
    }
    [void]$sb.AppendLine('</div></div>')
    return $sb.ToString()
}

function Add-SystemBaselineHtml {
    param($Data)
    if ($null -eq $Data) { return '<p class="muted">No system baseline data collected.</p>' }

    $rows = @(
        [pscustomobject]@{ Label='Computer name'; Value=$Data.ComputerName },
        [pscustomobject]@{ Label='Logged-on user'; Value=$Data.UserName },
        [pscustomobject]@{ Label='Operating system'; Value=$Data.OS },
        [pscustomobject]@{ Label='OS version'; Value=$Data.Version },
        [pscustomobject]@{ Label='Build number'; Value=$Data.BuildNumber },
        [pscustomobject]@{ Label='Architecture'; Value=$Data.Architecture },
        [pscustomobject]@{ Label='Install date'; Value=$Data.InstallDate },
        [pscustomobject]@{ Label='Last boot time'; Value=$Data.LastBootUpTime },
        [pscustomobject]@{ Label='Manufacturer'; Value=$Data.Manufacturer },
        [pscustomobject]@{ Label='Model'; Value=$Data.Model },
        [pscustomobject]@{ Label='Domain / workgroup'; Value=$Data.Domain },
        [pscustomobject]@{ Label='Total memory'; Value=('{0} GB' -f $Data.TotalMemoryGB) },
        [pscustomobject]@{ Label='CPU'; Value=$Data.CPU },
        [pscustomobject]@{ Label='Logical processors'; Value=$Data.LogicalProcessors }
    )

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<section><h2>Windows version, hardware, RAM, CPU</h2>')
    [void]$sb.AppendLine('<div class="baseline-summary">')
    [void]$sb.AppendLine('<div class="metric-note"><b>Baseline cleanup:</b> Install date and last boot time are shown as simple date/time values. The previous raw DateTime object expansion was intentionally removed because it exposed internal fields like Ticks, DayOfYear, and TimeOfDay that are not useful for support review.</div>')
    [void]$sb.AppendLine((Add-InfoCard -Title 'System baseline' -Rows $rows))
    [void]$sb.AppendLine('</div></section>')
    return $sb.ToString()
}

function Add-HtmlSection {
    param([string]$Title, $Data)

    if ($Title -eq 'Windows version, hardware, RAM, CPU') {
        return Add-SystemBaselineHtml -Data $Data
    }

    $content = ''
    if ($null -eq $Data) {
        $content = '<p class="muted">No data collected.</p>'
    }
    elseif ($Data -is [string]) {
        $content = Convert-ObjectToHtmlTable -Data $Data
    }
    elseif ($Data -is [System.Collections.IDictionary]) {
        $content = Convert-ObjectToHtmlTable -Data $Data
    }
    else {
        $props = @($Data.PSObject.Properties)
        $hasError = ($props | Where-Object { $_.Name -eq 'Error' } | Select-Object -First 1)
        if ($hasError) {
            $content = '<div class="alert"><b>Collection error:</b> ' + (HtmlEncode $hasError.Value) + '</div>'
        }
        elseif (($Data -is [System.Array]) -or (@($Data).Count -gt 1)) {
            $content = Convert-ObjectToHtmlTable -Data $Data
        }
        elseif ($props.Count -gt 0) {
            $parts = New-Object System.Text.StringBuilder
            foreach ($p in $props) {
                $v = $p.Value
                [void]$parts.AppendLine('<div class="subsection"><h3>' + (HtmlEncode $p.Name) + '</h3>')
                if ($p.Name -eq 'TopProcessesByMemory') {
                    [void]$parts.AppendLine('<div class="metric-note"><b>CPU metric legend:</b> <b>CpuSamplePercent</b> is an approximate live CPU percentage measured over a short 1-second sample and normalized across logical processors. <b>CpuSeconds</b> is total cumulative CPU time used by the process since it started, so it can be much higher than 100 and should not be read as a percentage. <b>MemoryMB</b> is current working set memory in MB. <b>Threads</b> is the current process thread count. The table is sorted by MemoryMB descending.</div>')
                }
                if ($null -eq $v) {
                    [void]$parts.AppendLine('<p class="muted">No data collected.</p>')
                }
                elseif ($v -is [string]) {
                    if ($v.Length -gt 250 -or $v.Contains("`n")) {
                        [void]$parts.AppendLine('<pre>' + (HtmlEncode $v) + '</pre>')
                    } else {
                        [void]$parts.AppendLine('<div>' + (HtmlEncode $v) + '</div>')
                    }
                }
                elseif ($v -is [System.Collections.IDictionary]) {
                    [void]$parts.AppendLine((Convert-ObjectToHtmlTable -Data $v -InitialRows 20))
                }
                elseif (($v -is [System.Array]) -or (@($v).Count -gt 1)) {
                    [void]$parts.AppendLine((Convert-ObjectToHtmlTable -Data $v -InitialRows 20))
                }
                else {
                    [void]$parts.AppendLine((Convert-ObjectToHtmlTable -Data @($v) -InitialRows 20))
                }
                [void]$parts.AppendLine('</div>')
            }
            $content = $parts.ToString()
        }
        else {
            $content = Convert-ObjectToHtmlTable -Data $Data
        }
    }

    return '<section><h2>' + (HtmlEncode $Title) + '</h2>' + $content + '</section>'
}

function Get-CollectorActionSummary {
    $rows = New-Object System.Collections.ArrayList

    $agent7031 = $script:Results['CyberCNS targeted 7031 crash summary']
    $agent7031Count = 0
    try { $agent7031Count = @($agent7031.CyberCNS7031Events).Count } catch { $agent7031Count = 0 }
    [void]$rows.Add([pscustomobject]@{
        Check = 'CyberCNS / ConnectSecure 7031 crashes, last 7 days'
        Status = if ($agent7031Count -gt 0) { 'Review' } else { 'OK' }
        Detail = if ($agent7031Count -gt 0) { "$agent7031Count targeted 7031 crash event(s) found. Review CrashCountByDay and Last10CyberCNSCrashSnippets." } else { 'No targeted CyberCNS / ConnectSecure 7031 service crash events found.' }
    })

    $agentAppErrors = @($script:Results['CyberCNS and ConnectSecure Application errors'])
    [void]$rows.Add([pscustomobject]@{
        Check = 'CyberCNS / ConnectSecure Application errors, last 7 days'
        Status = if ($agentAppErrors.Count -gt 0) { 'Review' } else { 'OK' }
        Detail = if ($agentAppErrors.Count -gt 0) { "$($agentAppErrors.Count) targeted Application error event(s) found." } else { 'No targeted CyberCNS / ConnectSecure Application errors found.' }
    })

    $av = $script:Results['AV / EDR / Defender exclusions']
    $secSvcCount = 0
    try { $secSvcCount = @($av.SecurityServices | Where-Object { -not $_.PSObject.Properties['Error'] }).Count } catch { $secSvcCount = 0 }
    $secProcCount = 0
    try { $secProcCount = @($av.SecurityProcesses).Count } catch { $secProcCount = 0 }
    [void]$rows.Add([pscustomobject]@{
        Check = 'Security tools detected'
        Status = if (($secSvcCount + $secProcCount) -gt 0) { 'Review' } else { 'Not detected' }
        Detail = "$secSvcCount security service(s) and $secProcCount security process(es) detected. Review for AV/EDR interference when crashes or high resource use are present."
    })

    $defStatus = 'Unknown'
    $defDetail = 'Defender exclusion assessment was not available.'
    try {
        $defStatus = [string]$av.DefenderExclusionAssessment.Status
        $defDetail = [string]$av.DefenderExclusionAssessment.Guidance
    } catch { }
    [void]$rows.Add([pscustomobject]@{
        Check = 'Defender CyberCNS / ConnectSecure exclusion'
        Status = $defStatus
        Detail = $defDetail
    })

    $net = $script:Results['DNS / HTTPS / proxy / firewall']
    $dnsFail = 0
    $httpsFail = 0
    try { $dnsFail = @($net.Dns | Where-Object { $_.Status -ne 'OK' }).Count } catch { $dnsFail = 0 }
    try { $httpsFail = @($net.Https | Where-Object { $_.Status -ne 'OK' }).Count } catch { $httpsFail = 0 }
    [void]$rows.Add([pscustomobject]@{
        Check = 'Network endpoint checks'
        Status = if (($dnsFail + $httpsFail) -gt 0) { 'Review' } else { 'OK' }
        Detail = "$dnsFail DNS failure(s), $httpsFail HTTPS failure(s). Includes cybercns.com and app.myconnectsecure.com."
    })

    $fwCount = 0
    try { $fwCount = @($net.FirewallRules | Where-Object { -not $_.PSObject.Properties['Error'] }).Count } catch { $fwCount = 0 }
    [void]$rows.Add([pscustomobject]@{
        Check = 'Firewall rule program paths'
        Status = if ($fwCount -gt 0) { 'Review' } else { 'Not detected' }
        Detail = if ($fwCount -gt 0) { "$fwCount matching firewall rule(s) found with Program path column when available." } else { 'No CyberCNS / ConnectSecure / Agent named firewall rules detected.' }
    })

    $appLocker = $script:Results['AppLocker and WDAC policies']
    $policyHint = 'Review AppLockerEffectiveXmlOrError and CodeIntegrityPolicyFiles when application control interference is suspected.'
    try {
        if (@($appLocker.CodeIntegrityPolicyFiles).Count -gt 0) { $policyHint = "$(@($appLocker.CodeIntegrityPolicyFiles).Count) Code Integrity policy file(s) detected. Review WDAC impact." }
    } catch { }
    [void]$rows.Add([pscustomobject]@{
        Check = 'AppLocker / WDAC'
        Status = 'Review'
        Detail = $policyHint
    })

    return @($rows)
}

function Show-GuiActionSummary {
    if ($Silent) { return }
    $rows = @(Get-CollectorActionSummary)
    Write-CSLine ''
    Write-CSLine 'Support review summary'
    Write-CSLine '----------------------'
    foreach ($row in $rows) {
        Write-CSLine ("[{0}] {1}" -f $row.Status, $row.Check)
        Write-CSLine ("  {0}" -f $row.Detail)
    }
    Write-CSLine ''
}

function New-PerformanceHtmlReport {
    if (-not (Test-Path -LiteralPath $script:RunFolder)) {
        New-Item -ItemType Directory -Path $script:RunFolder -Force | Out-Null
    }

    $statusRows = Convert-ObjectToHtmlTable -Data @($script:SectionStatus) -InitialRows 20
    $errorCount = @($script:SectionStatus | Where-Object { $_.Status -eq 'Error' }).Count
    $doneCount = @($script:SectionStatus | Where-Object { $_.Status -eq 'Done' }).Count
    $eventCount = @($script:Results['System Event ID 7031 crash events']).Count
    $agentAppErrCount = @($script:Results['CyberCNS and ConnectSecure Application errors']).Count
    $appErrCount = @($script:Results['Application crash and error events']).Count
    $agent7031Count = 0
    try { $agent7031Count = @($script:Results['CyberCNS targeted 7031 crash summary'].CyberCNS7031Events).Count } catch { $agent7031Count = 0 }
    $actionSummaryRows = Convert-ObjectToHtmlTable -Data @(Get-CollectorActionSummary) -InitialRows 20

    $sections = New-Object System.Text.StringBuilder
    foreach ($key in $script:Results.Keys) {
        [void]$sections.AppendLine((Add-HtmlSection -Title $key -Data $script:Results[$key]))
    }

    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>ConnectSecure Performance Collector Summary</title>
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:10px;margin:6px 0 10px;}
.summary{background:#fff7e6;border:1px solid #ffd699;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.summary h2{margin:4px 0 8px 0;}
.summary table{width:auto;border-collapse:separate;border-spacing:0 4px;}
.summary td{border:none;padding:2px 10px 2px 0;}
.key{color:#555;font-weight:600;white-space:nowrap;}
.val{color:#000;}
.src{color:#888;font-size:12px;margin-top:4px;}
.servers{background:#f4f9ff;border:1px solid #cfe6ff;padding:10px 12px;border-radius:10px;margin:8px 0 16px;}
.section-heading{margin-top:18px;border-bottom:2px solid #ddd;padding-bottom:4px;}
.group-box{background:#fcfcff;border:1px solid #e6e6f2;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.group-box ul{margin:6px 0 0 18px;}
.member-meta{color:#666;font-size:12px;}
.subsection{background:#f7fbff;border:1px solid #d7ecff;padding:10px 12px;border-radius:10px;margin:10px 0;}
.subsection h3{margin:2px 0 6px 0;}
.cutoff{color:#333;font-size:12px;margin:0 0 6px 0;}
.alert{background:#fff4e5;border:1px solid #ffd699;border-left:5px solid #f0a202;padding:10px 12px;border-radius:8px;margin:8px 0;}
.muted{color:#888;}
.table-note{color:#888;font-size:12px;margin:6px 0 8px 0;}
.metric-note{background:#eef7ff;border:1px solid #cfe6ff;border-left:5px solid #2f80ed;padding:10px 12px;border-radius:8px;margin:8px 0 10px;color:#333;}
.metric-note b{color:#111;}
.baseline-summary{margin:8px 0 14px;}
.info-card{background:#fcfcff;border:1px solid #e6e6f2;padding:12px 14px;border-radius:10px;margin:10px 0 14px;}
.info-card h3{margin:0 0 10px 0;}
.kv-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px 14px;}
.kv-item{background:#fff;border:1px solid #eee;border-radius:8px;padding:9px 10px;}
.kv-label{font-size:12px;color:#666;font-weight:600;text-transform:uppercase;letter-spacing:.02em;margin-bottom:4px;}
.kv-value{font-size:14px;color:#111;word-break:break-word;}
details.expand-block{background:#f4f9ff;border:1px solid #cfe6ff;padding:10px 12px;border-radius:10px;margin:8px 0 16px;}
details.expand-block summary{color:#333;}
.map{font-family:Consolas,monospace;white-space:pre;background:#f9f9f9;padding:10px 12px;border:1px solid #ddd;border-radius:10px;}
.footer{color:#888;font-size:12px;margin:20px 0 0;}
</style></head><body>
<div class="logo-wrap"><img src="$(HtmlEncode $script:LogoUrl)" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Performance Collector</h1>
<div class="kicker">
<b>Run stamp:</b> $(HtmlEncode $script:RunStamp)<br>
<b>Computer:</b> $(HtmlEncode $env:COMPUTERNAME)<br>
<span class="small">Build: $(HtmlEncode $script:BuildMarker)</span>
</div>
<div class="summary">
<h2>Collection Summary</h2>
<table>
<tr><td class="key">Sections completed</td><td class="val">$doneCount</td></tr>
<tr><td class="key">Sections with collection errors</td><td class="val">$errorCount</td></tr>
<tr><td class="key">System 7031 events</td><td class="val">$eventCount</td></tr>
<tr><td class="key">Targeted CyberCNS / ConnectSecure 7031 events</td><td class="val">$agent7031Count</td></tr>
<tr><td class="key">CyberCNS / ConnectSecure Application errors</td><td class="val">$agentAppErrCount</td></tr>
<tr><td class="key">All Application errors</td><td class="val">$appErrCount</td></tr>
<tr><td class="key">Export folder</td><td class="val">$(HtmlEncode $script:RunFolder)</td></tr>
</table>
</div>
<h2 class="section-heading">Support Review Summary</h2>
<div class="subsection">
$actionSummaryRows
</div>
<h2 class="section-heading">Collection Map</h2>
<div class="servers">
<div class="map">System baseline
  |-- Windows / hardware inventory
  |-- Agent services
  |-- Agent file versions
Crash evidence
  |-- System Event 7031, last 7 days
  |-- CyberCNS targeted 7031 crash summary, last 7 days
  |-- CyberCNS / ConnectSecure Application errors, last 7 days
  |-- Application errors, last 7 days
  |-- WER reports and dump files
Interference and access checks
  |-- AV / EDR / Defender exclusions
  |-- DNS / HTTPS / proxy / firewall
  |-- AppLocker / WDAC
Correlation data
  |-- Memory and disk snapshot
  |-- Recent Windows updates</div>
</div>
<h2 class="section-heading">Section Status</h2>
<div class="subsection">
$statusRows
</div>
<h2 class="section-heading">Collected Details</h2>
$($sections.ToString())
<div class="footer">HTML-only baseline. Supporting individual exports can be added after this report flow is confirmed.</div>
</body></html>
"@
    [System.IO.File]::WriteAllBytes($script:HtmlPath, [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html))
    if (-not (Test-Path -LiteralPath $script:HtmlPath)) {
        throw "HTML report was not created: $script:HtmlPath"
    }
    return $script:HtmlPath
}

function Show-CollectionMap {
    Write-CSLine 'Collection map'
    Write-CSLine '--------------'
    Write-CSLine '  System baseline'
    Write-CSLine '    |-- Windows / hardware inventory'
    Write-CSLine '    |-- Agent services'
    Write-CSLine '    |-- Agent file versions'
    Write-CSLine '  Crash evidence'
    Write-CSLine '    |-- System Event 7031, last 7 days'
    Write-CSLine '    |-- CyberCNS targeted 7031 crash summary, last 7 days'
    Write-CSLine '    |-- CyberCNS / ConnectSecure Application errors, last 7 days'
    Write-CSLine '    |-- Application errors, last 7 days'
    Write-CSLine '    |-- WER reports and dump files'
    Write-CSLine '  Interference and access checks'
    Write-CSLine '    |-- AV / EDR / Defender exclusions'
    Write-CSLine '    |-- DNS / HTTPS / proxy / firewall'
    Write-CSLine '    |-- AppLocker / WDAC'
    Write-CSLine '  Correlation data'
    Write-CSLine '    |-- Memory and disk snapshot'
    Write-CSLine '    |-- Recent Windows updates'
    Write-CSLine ''
}

function Invoke-PerformanceCollectorHtmlOnly {
    Write-CSLine ''
    Write-CSLine 'Collection starting...'
    Write-CSLine ''
    Invoke-SafeCollect -Index 1 -Total 13 -Name 'Windows version, hardware, RAM, CPU' -ScriptBlock { Get-SystemBaseline }
    Invoke-SafeCollect -Index 2 -Total 13 -Name 'CyberCNSAgent service status and account' -ScriptBlock { Get-AgentServices }
    Invoke-SafeCollect -Index 3 -Total 13 -Name 'Agent file versions and recent files' -ScriptBlock { Get-AgentFiles }
    Invoke-SafeCollect -Index 4 -Total 13 -Name 'System Event ID 7031 crash events' -ScriptBlock { Get-System7031Events }
    Invoke-SafeCollect -Index 5 -Total 13 -Name 'CyberCNS targeted 7031 crash summary' -ScriptBlock { Get-AgentSystem7031CrashSummary }
    Invoke-SafeCollect -Index 6 -Total 13 -Name 'CyberCNS and ConnectSecure Application errors' -ScriptBlock { Get-AgentApplicationErrorEvents }
    Invoke-SafeCollect -Index 7 -Total 13 -Name 'Application crash and error events' -ScriptBlock { Get-ApplicationErrorEvents }
    Invoke-SafeCollect -Index 8 -Total 13 -Name 'WER reports and crash dumps' -ScriptBlock { Get-WerAndDumps }
    Invoke-SafeCollect -Index 9 -Total 13 -Name 'AV / EDR / Defender exclusions' -ScriptBlock { Get-AvEdrDefender }
    Invoke-SafeCollect -Index 10 -Total 13 -Name 'DNS / HTTPS / proxy / firewall' -ScriptBlock { Get-NetworkProxyFirewall }
    Invoke-SafeCollect -Index 11 -Total 13 -Name 'Memory and disk usage snapshot' -ScriptBlock { Get-MemoryDiskSnapshot }
    Invoke-SafeCollect -Index 12 -Total 13 -Name 'Windows updates from last 30 days' -ScriptBlock { Get-RecentWindowsUpdates }
    Invoke-SafeCollect -Index 13 -Total 13 -Name 'AppLocker and WDAC policies' -ScriptBlock { Get-AppLockerWdac }

    Show-GuiActionSummary
    Write-CSLine ''
    Write-CSLine 'Creating HTML report now...'
    $html = New-PerformanceHtmlReport
    Write-CSLine 'HTML CREATED AND VERIFIED:'
    Write-CSLine "  $html"
    Write-CSLine ''
    Write-CSLine 'Collection complete.'
    Write-CSLine "Export folder: $script:RunFolder"
    Write-CSLine "HTML report:   $html"
    Write-CSLine ''

    if (-not $ExportOnly -and -not $Silent) {
        $answer = Read-Host 'Would you like to open the generated report? (Y/N) (press Enter after selection)'
        if ($answer -match '^(Y|y)$') {
            Start-Process -FilePath $html
        }
    }
}

function Start-CollectorFlow {
    if ($ExportOnly) {
        Invoke-PerformanceCollectorHtmlOnly
        return
    }

    Clear-Host
    Write-CSLine 'ConnectSecure Performance Collector - HTML Only'
    Write-CSLine '================================================'
    Write-CSLine $script:BuildMarker
    Write-CSLine ''
    Show-CollectionMap

    $answer = Read-Host 'Begin collection now? (Y/N) (press Enter after selection)'
    if ($answer -notmatch '^(Y|y)$') {
        Write-CSLine 'Collection cancelled. Returning to toolbox launcher / exiting.'
        return
    }

    Invoke-PerformanceCollectorHtmlOnly
}

Start-CollectorFlow
