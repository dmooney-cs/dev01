<#
.SYNOPSIS
  ConnectSecure Performance Collector toolbox subscript.
.DESCRIPTION
  Menu-driven collector for CyberCNSAgent / ConnectSecure Agent crash and performance context.
  Exports all collected artifacts to:
    C:\CS-Toolbox-TEMP\Collected-Info\ConnectSecure-Performance-Collector\<RunStamp>

  Designed for toolbox script menu usage and supports -ExportOnly for cookbook/launcher commands.
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$ExportOnly,
    [switch]$Silent,
    [switch]$NoReturnToLauncher
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

$script:ToolName = 'ConnectSecure Performance Collector'
$script:TempRoot = 'C:\CS-Toolbox-TEMP'
$script:ToolboxRoot = 'C:\CS-Toolbox-TEMP\prod-01-01'
$script:CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:ExportRoot = Join-Path $script:CollectedInfoRoot 'ConnectSecure-Performance-Collector'
$script:RunStamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$script:RunExportDir = Join-Path $script:ExportRoot $script:RunStamp
$script:ReportPath = Join-Path $script:RunExportDir "ConnectSecure_Performance_Collector_$($script:RunStamp).txt"
$script:JsonPath = Join-Path $script:RunExportDir "ConnectSecure_Performance_Collector_$($script:RunStamp).json"
$script:CsvSummaryPath = Join-Path $script:RunExportDir "ConnectSecure_Performance_Collector_Summary_$($script:RunStamp).csv"
$script:TranscriptPath = Join-Path $script:RunExportDir "ConnectSecure_Performance_Collector_$($script:RunStamp).transcript.txt"
$script:EventSystemCsv = Join-Path $script:RunExportDir "System_Event7031_Last7Days_$($script:RunStamp).csv"
$script:EventApplicationCsv = Join-Path $script:RunExportDir "Application_Errors_Last7Days_$($script:RunStamp).csv"
$script:HotfixCsv = Join-Path $script:RunExportDir "Windows_Updates_Last30Days_$($script:RunStamp).csv"
$script:ProcessCsv = Join-Path $script:RunExportDir "Top_Processes_By_Memory_$($script:RunStamp).csv"
$script:DiskCsv = Join-Path $script:RunExportDir "Disk_Snapshot_$($script:RunStamp).csv"
$script:FirewallCsv = Join-Path $script:RunExportDir "Firewall_Rules_CyberCNS_$($script:RunStamp).csv"
$script:Result = [ordered]@{}
$script:SummaryRows = New-Object System.Collections.Generic.List[object]

function Enable-ToolboxConsole {
    try { & chcp 65001 > $null } catch { }
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [Console]::OutputEncoding = $utf8NoBom
        [Console]::InputEncoding = $utf8NoBom
        $global:OutputEncoding = $utf8NoBom
    } catch { }
}

function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

function Write-Screen {
    param(
        [Parameter(Mandatory=$false)][AllowEmptyString()][string]$Message = '',
        [ConsoleColor]$Color = [ConsoleColor]::Gray
    )
    if ($Silent) { return }
    if ([string]::IsNullOrEmpty($Message)) { Write-Host ''; return }
    Write-Host $Message -ForegroundColor $Color
}

function Write-BlankLine {
    if ($Silent) { return }
    Write-Host ''
}

function Pause-Toolbox {
    param([string]$Prompt = 'Press Enter to return to the menu')
    if ($Silent -or $ExportOnly) { return }
    Write-Host ''
    Read-Host "$Prompt (press Enter after selection)" | Out-Null
}

function Write-ReportLine {
    param([string]$Text = '')
    $Text | Out-File -LiteralPath $script:ReportPath -Append -Encoding UTF8
}

function Write-ReportSection {
    param([Parameter(Mandatory)][string]$Title)
    $sep = '=' * 78
    Write-ReportLine ''
    Write-ReportLine $sep
    Write-ReportLine "  $Title"
    Write-ReportLine $sep
}

function Add-SummaryRow {
    param(
        [Parameter(Mandatory)][string]$Section,
        [Parameter(Mandatory)][string]$Status,
        [Parameter(Mandatory)][string]$Details
    )
    $script:SummaryRows.Add([pscustomobject]@{
        Section = $Section
        Status = $Status
        Details = $Details
    }) | Out-Null
}

function Safe-String {
    param($Value)
    if ($null -eq $Value) { return '' }
    return [string]$Value
}

function Truncate-Text {
    param(
        [AllowNull()]$Text,
        [int]$MaxLength = 700
    )
    $s = Safe-String $Text
    if ($s.Length -le $MaxLength) { return $s }
    return $s.Substring(0, $MaxLength) + '...'
}

function Write-FeatureList {
    Clear-Host
    Write-Screen 'ConnectSecure Performance Collector' Cyan
    Write-Screen '=====================================' Cyan
    Write-BlankLine
    Write-Screen 'This collector exports the following support data:' Yellow
    Write-BlankLine
    Write-Screen '  [01] Windows version, architecture, install date, boot time, RAM, CPU'
    Write-Screen '  [02] CyberCNSAgent service state, startup type, path, account, PID'
    Write-Screen '  [03] Agent file versions and recent agent files on disk'
    Write-Screen '  [04] Last 7 days of System Event ID 7031 crash events and daily counts'
    Write-Screen '  [05] Last 7 days of Application log crash/error details'
    Write-Screen '  [06] Windows Error Reporting and crash dump artifacts'
    Write-Screen '  [07] Antivirus/EDR products and Defender exclusions for agent paths'
    Write-Screen '  [08] HTTPS/DNS reachability, proxy settings, and CyberCNS firewall rules'
    Write-Screen '  [09] Current top memory processes and disk usage snapshot'
    Write-Screen '  [10] Windows updates installed in the last 30 days'
    Write-Screen '  [11] AppLocker and Windows Defender Application Control policy status'
    Write-BlankLine
    Write-Screen 'Exports are written under:' Yellow
    Write-Screen "  $script:ExportRoot"
    Write-BlankLine
}

function Show-CollectionMap {
    Write-BlankLine
    Write-Screen 'Collection map' Cyan
    Write-Screen '--------------' Cyan
    Write-Screen '  System baseline'
    Write-Screen '    |-- Windows / hardware inventory'
    Write-Screen '    |-- Agent services'
    Write-Screen '    |-- Agent file versions'
    Write-Screen '  Crash evidence'
    Write-Screen '    |-- System Event 7031, last 7 days'
    Write-Screen '    |-- Application errors, last 7 days'
    Write-Screen '    |-- WER reports and dump files'
    Write-Screen '  Interference and access checks'
    Write-Screen '    |-- AV / EDR / Defender exclusions'
    Write-Screen '    |-- DNS / HTTPS / proxy / firewall'
    Write-Screen '    |-- AppLocker / WDAC'
    Write-Screen '  Correlation data'
    Write-Screen '    |-- Memory and disk snapshot'
    Write-Screen '    |-- Recent Windows updates'
    Write-BlankLine
}

function Write-ProgressLine {
    param(
        [int]$Number,
        [int]$Total,
        [string]$Name,
        [string]$Status
    )
    if ($Silent) { return }
    $barWidth = 22
    $done = [math]::Floor(($Number / $Total) * $barWidth)
    $left = $barWidth - $done
    $bar = ('#' * $done) + ('-' * $left)
    Write-Host ("[{0}] {1,2}/{2}  {3,-62} {4}" -f $bar, $Number, $Total, $Name, $Status)
}

function Initialize-Export {
    Ensure-Folder -Path $script:TempRoot
    Ensure-Folder -Path $script:CollectedInfoRoot
    Ensure-Folder -Path $script:ExportRoot
    Ensure-Folder -Path $script:RunExportDir
    "ConnectSecure Performance Collector" | Set-Content -LiteralPath $script:ReportPath -Encoding UTF8 -Force
    Write-ReportLine "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-ReportLine "Computer:  $env:COMPUTERNAME"
    Write-ReportLine "User:      $env:USERDOMAIN\$env:USERNAME"
    Write-ReportLine "ExportDir: $script:RunExportDir"
    try { Start-Transcript -Path $script:TranscriptPath -Force | Out-Null } catch { }
}

function Complete-Export {
    try {
        $script:Result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:JsonPath -Encoding UTF8 -Force
    } catch {
        Write-ReportLine "JSON export failed: $($_.Exception.Message)"
    }
    try {
        $script:SummaryRows | Export-Csv -LiteralPath $script:CsvSummaryPath -NoTypeInformation -Encoding UTF8 -Force
    } catch { }
    Write-ReportSection 'EXPORT COMPLETE'
    Write-ReportLine "Report:     $script:ReportPath"
    Write-ReportLine "JSON:       $script:JsonPath"
    Write-ReportLine "SummaryCSV: $script:CsvSummaryPath"
    Write-ReportLine "Folder:     $script:RunExportDir"
    try { Stop-Transcript | Out-Null } catch { }
}

function Collect-SystemInformation {
    $section = '01 System Information'
    Write-ReportSection $section
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
        $memTotalGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
        $memFreeGB = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
        $item = [ordered]@{
            OS = $os.Caption
            Version = $os.Version
            BuildNumber = $os.BuildNumber
            Architecture = $os.OSArchitecture
            InstallDate = $os.InstallDate
            LastBootUpTime = $os.LastBootUpTime
            TotalRAMGB = $memTotalGB
            FreeRAMGB = $memFreeGB
            CPU = if ($cpu) { $cpu.Name } else { '' }
            LogicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { '' }
        }
        $script:Result.SystemInformation = $item
        foreach ($k in $item.Keys) { Write-ReportLine ("{0,-20}: {1}" -f $k, $item[$k]) }
        Add-SummaryRow -Section $section -Status 'OK' -Details "$($os.Caption) build $($os.BuildNumber); RAM ${memTotalGB}GB"
    } catch {
        Write-ReportLine "ERROR: $($_.Exception.Message)"
        Add-SummaryRow -Section $section -Status 'ERROR' -Details $_.Exception.Message
    }
}

function Collect-AgentServices {
    $section = '02 Agent Services'
    Write-ReportSection $section
    $svcNames = @('CyberCNSAgent','CyberCNSAgentV2','CyberCNSAgentMonitor','CyberCNSMonitor')
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($svcName in $svcNames) {
        try {
            $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
            $wmiSvc = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
            if ($svc) {
                $row = [pscustomobject]@{
                    Name = $svcName
                    Status = [string]$svc.Status
                    StartType = [string]$svc.StartType
                    PathName = if ($wmiSvc) { $wmiSvc.PathName } else { '' }
                    StartName = if ($wmiSvc) { $wmiSvc.StartName } else { '' }
                    ProcessId = if ($wmiSvc) { $wmiSvc.ProcessId } else { '' }
                }
            } else {
                $row = [pscustomobject]@{
                    Name = $svcName
                    Status = 'NOT FOUND'
                    StartType = ''
                    PathName = ''
                    StartName = ''
                    ProcessId = ''
                }
            }
            $rows.Add($row) | Out-Null
        } catch {
            $rows.Add([pscustomobject]@{ Name=$svcName; Status='ERROR'; StartType=''; PathName=$_.Exception.Message; StartName=''; ProcessId='' }) | Out-Null
        }
    }
    $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    $script:Result.AgentServices = @($rows)
    $found = @($rows | Where-Object { $_.Status -ne 'NOT FOUND' -and $_.Status -ne 'ERROR' }).Count
    Add-SummaryRow -Section $section -Status 'OK' -Details "Detected $found service record(s)"
}

function Collect-AgentFiles {
    $section = '03 Agent File Details'
    Write-ReportSection $section
    $agentPaths = @('C:\Program Files (x86)\CyberCNSAgent','C:\Program Files\CyberCNSAgent','C:\ProgramData\CyberCNSAgent')
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($path in $agentPaths) {
        if (Test-Path -LiteralPath $path) {
            Write-ReportLine "Found path: $path"
            try {
                Get-ChildItem -LiteralPath $path -Recurse -File -ErrorAction SilentlyContinue |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 40 |
                    ForEach-Object {
                        $ver = ''
                        try { $ver = (Get-Item -LiteralPath $_.FullName).VersionInfo.FileVersion } catch { }
                        $rows.Add([pscustomobject]@{
                            FullName = $_.FullName
                            Length = $_.Length
                            LastWriteTime = $_.LastWriteTime
                            Version = $ver
                        }) | Out-Null
                    }
            } catch {
                Write-ReportLine "  ERROR scanning $path : $($_.Exception.Message)"
            }
        } else {
            Write-ReportLine "Path not found: $path"
        }
    }
    if ($rows.Count -gt 0) {
        $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    }
    $script:Result.AgentFiles = @($rows)
    Add-SummaryRow -Section $section -Status 'OK' -Details "Captured $($rows.Count) recent agent file record(s)"
}

function Collect-SystemCrashEvents {
    $section = '04 Event 7031 Crashes Last 7 Days'
    Write-ReportSection $section
    $startDate = (Get-Date).AddDays(-7)
    $rows = @()
    try {
        $events = Get-WinEvent -FilterHashtable @{ LogName='System'; Id=7031; StartTime=$startDate } -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -match 'CyberCNS|ConnectSecure' }
        $rows = @($events | Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, @{N='Message';E={ Truncate-Text $_.Message 900 }})
        if ($rows.Count -gt 0) {
            $rows | Export-Csv -LiteralPath $script:EventSystemCsv -NoTypeInformation -Encoding UTF8 -Force
            Write-ReportLine "Total matching Event 7031 records: $($rows.Count)"
            Write-ReportLine ''
            Write-ReportLine 'Crash count by day:'
            $events | Group-Object { $_.TimeCreated.Date.ToString('yyyy-MM-dd') } | Sort-Object Name | ForEach-Object {
                Write-ReportLine ("  {0}: {1}" -f $_.Name, $_.Count)
            }
            Write-ReportLine ''
            Write-ReportLine 'Last 10 matching events:'
            $rows | Select-Object -First 10 | Format-List | Out-String | ForEach-Object { Write-ReportLine $_ }
        } else {
            Write-ReportLine 'No CyberCNS/ConnectSecure Event 7031 records found in the last 7 days.'
        }
        $script:Result.SystemEvent7031 = @($rows)
        Add-SummaryRow -Section $section -Status 'OK' -Details "Found $($rows.Count) matching crash event(s)"
    } catch {
        Write-ReportLine "ERROR: $($_.Exception.Message)"
        Add-SummaryRow -Section $section -Status 'ERROR' -Details $_.Exception.Message
    }
}

function Collect-ApplicationErrors {
    $section = '05 Application Errors Last 7 Days'
    Write-ReportSection $section
    $startDate = (Get-Date).AddDays(-7)
    $rows = @()
    try {
        $events = Get-WinEvent -FilterHashtable @{ LogName='Application'; Level=@(1,2); StartTime=$startDate } -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -match 'CyberCNS|ConnectSecure|CyberCNSAgent' }
        $rows = @($events | Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, @{N='Message';E={ Truncate-Text $_.Message 1200 }})
        if ($rows.Count -gt 0) {
            $rows | Export-Csv -LiteralPath $script:EventApplicationCsv -NoTypeInformation -Encoding UTF8 -Force
            Write-ReportLine "Total matching Application error records: $($rows.Count)"
            $rows | Select-Object -First 15 | Format-List | Out-String | ForEach-Object { Write-ReportLine $_ }
        } else {
            Write-ReportLine 'No CyberCNS/ConnectSecure Application error records found in the last 7 days.'
        }
        $script:Result.ApplicationErrors = @($rows)
        Add-SummaryRow -Section $section -Status 'OK' -Details "Found $($rows.Count) matching application error(s)"
    } catch {
        Write-ReportLine "ERROR: $($_.Exception.Message)"
        Add-SummaryRow -Section $section -Status 'ERROR' -Details $_.Exception.Message
    }
}

function Collect-CrashDumps {
    $section = '06 WER Crash Dumps'
    Write-ReportSection $section
    $paths = New-Object System.Collections.Generic.List[string]
    if ($env:LOCALAPPDATA) { $paths.Add((Join-Path $env:LOCALAPPDATA 'CrashDumps')) | Out-Null }
    if ($env:ProgramData) {
        $paths.Add((Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportArchive')) | Out-Null
        $paths.Add((Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportQueue')) | Out-Null
    }
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($path in $paths) {
        if (Test-Path -LiteralPath $path) {
            try {
                Get-ChildItem -LiteralPath $path -Recurse -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -match 'CyberCNS|ConnectSecure' -or $_.FullName -match 'CyberCNS|ConnectSecure' } |
                    ForEach-Object {
                        $rows.Add([pscustomobject]@{
                            FullName = $_.FullName
                            Length = if ($_.PSIsContainer) { '' } else { $_.Length }
                            LastWriteTime = $_.LastWriteTime
                            IsDirectory = $_.PSIsContainer
                        }) | Out-Null
                    }
            } catch {
                Write-ReportLine "ERROR scanning $path : $($_.Exception.Message)"
            }
        } else {
            Write-ReportLine "Path not found: $path"
        }
    }
    if ($rows.Count -gt 0) {
        $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    } else {
        Write-ReportLine 'No CyberCNS/ConnectSecure WER dump/report artifacts found.'
    }
    $script:Result.CrashDumps = @($rows)
    Add-SummaryRow -Section $section -Status 'OK' -Details "Found $($rows.Count) crash artifact(s)"
}

function Collect-AvEdr {
    $section = '07 AV EDR and Defender Exclusions'
    Write-ReportSection $section
    $result = [ordered]@{
        SecurityCenterProducts = @()
        DetectedServices = @()
        DefenderExclusionPath = @()
        DefenderExclusionProcess = @()
        DefenderExclusionExtension = @()
    }
    try {
        $avProducts = Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop
        $result.SecurityCenterProducts = @($avProducts | Select-Object displayName, pathToSignedReportingExe, productState)
        Write-ReportLine 'SecurityCenter2 AntiVirusProduct:'
        $result.SecurityCenterProducts | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    } catch {
        Write-ReportLine "SecurityCenter2 query unavailable or failed: $($_.Exception.Message)"
    }

    $edrServices = @(
        @{Name='SentinelAgent'; Label='SentinelOne'},
        @{Name='CSFalconService'; Label='CrowdStrike Falcon'},
        @{Name='CylanceSvc'; Label='Cylance'},
        @{Name='WinDefend'; Label='Microsoft Defender Antivirus'},
        @{Name='MsMpSvc'; Label='Microsoft Defender legacy'},
        @{Name='MBAMService'; Label='Malwarebytes'},
        @{Name='SophosSafeStore'; Label='Sophos'},
        @{Name='Sophos Endpoint Defense Service'; Label='Sophos Endpoint Defense'},
        @{Name='EPSecurityService'; Label='Bitdefender GravityZone'},
        @{Name='EPProtectedService'; Label='Bitdefender Endpoint Protected Service'},
        @{Name='naborion'; Label='Webroot'},
        @{Name='CarbonBlack'; Label='VMware Carbon Black'},
        @{Name='CbDefense'; Label='Carbon Black Defense'},
        @{Name='Traps'; Label='Palo Alto Cortex XDR'},
        @{Name='CybereasonActiveProbe'; Label='Cybereason'},
        @{Name='Sense'; Label='Microsoft Defender for Endpoint'}
    )
    foreach ($edr in $edrServices) {
        $svc = Get-Service -Name $edr.Name -ErrorAction SilentlyContinue
        if ($svc) {
            $result.DetectedServices += [pscustomobject]@{ Label=$edr.Label; Name=$edr.Name; Status=[string]$svc.Status; StartType=[string]$svc.StartType }
        }
    }
    Write-ReportLine ''
    Write-ReportLine 'Detected AV/EDR services:'
    if ($result.DetectedServices.Count -gt 0) {
        $result.DetectedServices | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    } else {
        Write-ReportLine 'No listed AV/EDR services detected by service name.'
    }

    try {
        $mp = Get-MpPreference -ErrorAction Stop
        $result.DefenderExclusionPath = @($mp.ExclusionPath)
        $result.DefenderExclusionProcess = @($mp.ExclusionProcess)
        $result.DefenderExclusionExtension = @($mp.ExclusionExtension)
        Write-ReportLine ''
        Write-ReportLine 'Defender exclusion paths:'
        if ($result.DefenderExclusionPath.Count -gt 0) { $result.DefenderExclusionPath | ForEach-Object { Write-ReportLine "  $_" } } else { Write-ReportLine '  None configured.' }
        $agentExcluded = @($result.DefenderExclusionPath | Where-Object { $_ -match 'CyberCNS|ConnectSecure' }).Count -gt 0
        if (-not $agentExcluded) { Write-ReportLine 'WARNING: No Defender path exclusion mentioning CyberCNS or ConnectSecure was found.' }
    } catch {
        Write-ReportLine "Defender preference query failed: $($_.Exception.Message)"
    }
    $script:Result.AvEdr = $result
    Add-SummaryRow -Section $section -Status 'OK' -Details "Detected $($result.DetectedServices.Count) listed AV/EDR service(s)"
}

function Collect-NetworkConnectivity {
    $section = '08 Network Connectivity'
    Write-ReportSection $section
    $endpoints = @('cybercns.com','app.myconnectsecure.com','api.myconnectsecure.com','toolsdev.myconnectsecure.com')
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($ep in $endpoints) {
        $dnsStatus = 'Unknown'
        $dnsAddress = ''
        $httpsStatus = 'Unknown'
        $httpsDetail = ''
        try {
            $dns = Resolve-DnsName -Name $ep -ErrorAction Stop | Select-Object -First 1
            $dnsStatus = 'Resolved'
            $dnsAddress = Safe-String $dns.IPAddress
        } catch {
            $dnsStatus = 'Failed'
            $dnsAddress = $_.Exception.Message
        }
        try {
            $resp = Invoke-WebRequest -Uri "https://$ep" -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
            $httpsStatus = 'Connected'
            $httpsDetail = "HTTP $($resp.StatusCode)"
        } catch {
            $httpsStatus = 'Failed'
            $httpsDetail = $_.Exception.Message
        }
        $rows.Add([pscustomobject]@{ Endpoint=$ep; DNS=$dnsStatus; DNSAddress=$dnsAddress; HTTPS=$httpsStatus; HTTPSDetail=$httpsDetail }) | Out-Null
    }
    $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    Write-ReportLine ''
    Write-ReportLine 'Proxy settings:'
    try {
        $proxy = [System.Net.WebRequest]::DefaultWebProxy
        if ($proxy) {
            $proxyUri = $proxy.GetProxy([Uri]'https://cybercns.com')
            Write-ReportLine "  Proxy for cybercns.com: $proxyUri"
        } else {
            Write-ReportLine '  No system proxy object detected.'
        }
    } catch {
        Write-ReportLine "  Proxy check failed: $($_.Exception.Message)"
    }

    $fwRows = @()
    try {
        $fwRows = @(Get-NetFirewallRule -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -match 'CyberCNS|ConnectSecure' } |
            ForEach-Object {
                $filter = $_ | Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue
                [pscustomobject]@{
                    DisplayName = $_.DisplayName
                    Enabled = $_.Enabled
                    Direction = $_.Direction
                    Action = $_.Action
                    Program = if ($filter) { $filter.Program } else { '' }
                }
            })
        if ($fwRows.Count -gt 0) {
            $fwRows | Export-Csv -LiteralPath $script:FirewallCsv -NoTypeInformation -Encoding UTF8 -Force
            Write-ReportLine ''
            Write-ReportLine 'Firewall rules mentioning CyberCNS or ConnectSecure:'
            $fwRows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
        } else {
            Write-ReportLine ''
            Write-ReportLine 'No firewall rules mentioning CyberCNS or ConnectSecure found.'
        }
    } catch {
        Write-ReportLine "Firewall check failed: $($_.Exception.Message)"
    }
    $script:Result.NetworkConnectivity = [ordered]@{ Endpoints=@($rows); FirewallRules=@($fwRows) }
    $failed = @($rows | Where-Object { $_.DNS -eq 'Failed' -or $_.HTTPS -eq 'Failed' }).Count
    Add-SummaryRow -Section $section -Status 'OK' -Details "$failed endpoint check(s) had DNS or HTTPS failures"
}

function Collect-ResourceSnapshot {
    $section = '09 Current Resource Snapshot'
    Write-ReportSection $section
    $processRows = @()
    $diskRows = @()
    try {
        $processRows = @(Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | Select-Object -First 20 ProcessName, Id, @{N='WorkingSetMB';E={[math]::Round($_.WorkingSet64 / 1MB, 2)}}, CPU, StartTime)
        $processRows | Export-Csv -LiteralPath $script:ProcessCsv -NoTypeInformation -Encoding UTF8 -Force
        Write-ReportLine 'Top processes by memory:'
        $processRows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    } catch {
        Write-ReportLine "Process snapshot failed: $($_.Exception.Message)"
    }
    try {
        $diskRows = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue | Select-Object DeviceID, VolumeName, @{N='FreeGB';E={[math]::Round($_.FreeSpace / 1GB, 2)}}, @{N='TotalGB';E={[math]::Round($_.Size / 1GB, 2)}}, @{N='PercentFree';E={ if ($_.Size) { [math]::Round(($_.FreeSpace / $_.Size) * 100, 2) } else { 0 } }})
        $diskRows | Export-Csv -LiteralPath $script:DiskCsv -NoTypeInformation -Encoding UTF8 -Force
        Write-ReportLine ''
        Write-ReportLine 'Disk space:'
        $diskRows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
    } catch {
        Write-ReportLine "Disk snapshot failed: $($_.Exception.Message)"
    }
    $script:Result.ResourceSnapshot = [ordered]@{ Processes=@($processRows); Disks=@($diskRows) }
    Add-SummaryRow -Section $section -Status 'OK' -Details "Captured $($processRows.Count) process row(s), $($diskRows.Count) disk row(s)"
}

function Collect-RecentWindowsUpdates {
    $section = '10 Recent Windows Updates Last 30 Days'
    Write-ReportSection $section
    $rows = @()
    try {
        $cutoff = (Get-Date).AddDays(-30)
        $rows = @(Get-HotFix -ErrorAction Stop | ForEach-Object {
            $installed = $null
            try { $installed = [datetime]$_.InstalledOn } catch { }
            if ($installed -and $installed -gt $cutoff) {
                [pscustomobject]@{ HotFixID=$_.HotFixID; Description=$_.Description; InstalledBy=$_.InstalledBy; InstalledOn=$installed }
            }
        } | Sort-Object InstalledOn -Descending)
        if ($rows.Count -gt 0) {
            $rows | Export-Csv -LiteralPath $script:HotfixCsv -NoTypeInformation -Encoding UTF8 -Force
            $rows | Format-Table -AutoSize | Out-String | ForEach-Object { Write-ReportLine $_ }
        } else {
            Write-ReportLine 'No updates found with InstalledOn in the last 30 days.'
        }
        $script:Result.RecentWindowsUpdates = @($rows)
        Add-SummaryRow -Section $section -Status 'OK' -Details "Found $($rows.Count) recent update(s)"
    } catch {
        Write-ReportLine "Get-HotFix failed: $($_.Exception.Message)"
        Add-SummaryRow -Section $section -Status 'ERROR' -Details $_.Exception.Message
    }
}

function Collect-AppControlPolicy {
    $section = '11 AppLocker and WDAC Policy Check'
    Write-ReportSection $section
    $result = [ordered]@{ AppLocker='Unknown'; AppLockerDetails=''; WDAC='Unknown'; WDACDetails='' }
    try {
        $policy = Get-AppLockerPolicy -Effective -ErrorAction Stop
        $collections = @($policy.RuleCollections | Where-Object { @($_).Count -gt 0 })
        if ($collections.Count -gt 0) {
            $result.AppLocker = 'Active'
            $result.AppLockerDetails = "Rule collections with rules: $($collections.Count)"
        } else {
            $result.AppLocker = 'No effective rules detected'
            $result.AppLockerDetails = 'No rule collections with rules were returned.'
        }
    } catch {
        $result.AppLocker = 'Unavailable or not configured'
        $result.AppLockerDetails = $_.Exception.Message
    }
    Write-ReportLine "AppLocker: $($result.AppLocker)"
    Write-ReportLine "  $($result.AppLockerDetails)"

    try {
        $ciPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
        if (Test-Path -LiteralPath $ciPath) {
            $ciProps = Get-ItemProperty -LiteralPath $ciPath -ErrorAction Stop
            $result.WDAC = 'Policy key present'
            $result.WDACDetails = ($ciProps | Out-String).Trim()
        } else {
            $result.WDAC = 'Policy key not found'
            $result.WDACDetails = $ciPath
        }
    } catch {
        $result.WDAC = 'Check failed'
        $result.WDACDetails = $_.Exception.Message
    }
    Write-ReportLine "WDAC: $($result.WDAC)"
    Write-ReportLine "  $($result.WDACDetails)"
    $script:Result.AppControlPolicy = $result
    Add-SummaryRow -Section $section -Status 'OK' -Details "AppLocker=$($result.AppLocker); WDAC=$($result.WDAC)"
}

function Invoke-PerformanceCollector {
    Initialize-Export
    Show-CollectionMap
    $steps = @(
        @{Name='Windows version, hardware, RAM, CPU'; Action={ Collect-SystemInformation }},
        @{Name='CyberCNSAgent service status and account'; Action={ Collect-AgentServices }},
        @{Name='Agent file versions and recent files'; Action={ Collect-AgentFiles }},
        @{Name='System Event ID 7031 crash events'; Action={ Collect-SystemCrashEvents }},
        @{Name='Application crash and error events'; Action={ Collect-ApplicationErrors }},
        @{Name='WER reports and crash dumps'; Action={ Collect-CrashDumps }},
        @{Name='AV / EDR / Defender exclusions'; Action={ Collect-AvEdr }},
        @{Name='DNS / HTTPS / proxy / firewall'; Action={ Collect-NetworkConnectivity }},
        @{Name='Memory and disk usage snapshot'; Action={ Collect-ResourceSnapshot }},
        @{Name='Windows updates from last 30 days'; Action={ Collect-RecentWindowsUpdates }},
        @{Name='AppLocker and WDAC policies'; Action={ Collect-AppControlPolicy }}
    )
    $total = $steps.Count
    for ($i = 0; $i -lt $total; $i++) {
        $n = $i + 1
        Write-ProgressLine -Number $n -Total $total -Name $steps[$i].Name -Status 'Collecting'
        try {
            & $steps[$i].Action
            Write-ProgressLine -Number $n -Total $total -Name $steps[$i].Name -Status 'Done'
        } catch {
            Write-ReportLine "UNHANDLED STEP ERROR: $($_.Exception.Message)"
            Add-SummaryRow -Section $steps[$i].Name -Status 'ERROR' -Details $_.Exception.Message
            Write-ProgressLine -Number $n -Total $total -Name $steps[$i].Name -Status 'Error'
        }
    }
    Complete-Export
    Write-BlankLine
    Write-Screen 'Collection complete.' Green
    Write-Screen "Export folder: $script:RunExportDir" Green
    Write-Screen "Report:        $script:ReportPath" Green
}

function Open-ExportRoot {
    Ensure-Folder -Path $script:ExportRoot
    try { Start-Process explorer.exe $script:ExportRoot | Out-Null } catch { Write-Screen "Could not open folder: $($_.Exception.Message)" Red }
}

function Return-ToLauncher {
    if ($NoReturnToLauncher -or $Silent) { exit }
    $launcher = Join-Path $script:ToolboxRoot 'CS-Toolbox-Launcher.ps1'
    if (Test-Path -LiteralPath $launcher) {
        try { & $launcher } catch { }
    }
    exit
}

function Show-MainMenu {
    while ($true) {
        Clear-Host
        Write-Screen 'ConnectSecure Performance Collector' Cyan
        Write-Screen '=====================================' Cyan
        Write-BlankLine
        Write-Screen '1. Show collector features'
        Write-Screen '2. Show visual collection map'
        Write-Screen '3. Run collector and export to Collected-Info'
        Write-Screen '4. Open export root folder'
        Write-Screen '0. Return to toolbox launcher'
        Write-BlankLine
        $choice = Read-Host 'Select an option (press Enter after selection)'
        switch ($choice) {
            '1' { Write-FeatureList; Pause-Toolbox }
            '2' { Clear-Host; Show-CollectionMap; Pause-Toolbox }
            '3' { Clear-Host; Invoke-PerformanceCollector; Pause-Toolbox }
            '4' { Open-ExportRoot; Pause-Toolbox }
            '0' { Return-ToLauncher }
            default { Write-Screen 'Invalid selection.' Yellow; Start-Sleep -Seconds 1 }
        }
    }
}

Enable-ToolboxConsole
Ensure-Folder -Path $script:CollectedInfoRoot
Ensure-Folder -Path $script:ExportRoot

if ($ExportOnly -or $Silent) {
    Invoke-PerformanceCollector
    Return-ToLauncher
}

Write-FeatureList
$runNow = Read-Host 'Run the ConnectSecure Performance Collector now? (Y/N) (press Enter after selection)'
if ($runNow -match '^(Y|y)$') {
    Clear-Host
    Invoke-PerformanceCollector
    Pause-Toolbox
}

Show-MainMenu
