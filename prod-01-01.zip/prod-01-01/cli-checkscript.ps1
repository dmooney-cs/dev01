﻿# -------- Shared test values --------
$AppName     = 'Chrome'
$TestCompany = 4750
$TestTenant  = 246915044162428931
$TestSecret  = 'mbCL1qEfvniYXvdf3_XF7T0OVzfi-xast8BRPHusOaUWPFw84VpcFXU6JRMEZ_0UOawKA9s8dvL0JT9kjDrCVlKXVFA59BNzc1XFvw'

# -------- Agent install (all switches / logic paths) --------
#.\Agent-Install-Tool.ps1 -reinstall -silent -j $TestSecret
#.\Agent-Install-Tool.ps1 -reinstall -silent -quiet -c $TestCompany -e $TestTenant -j $TestSecret

# -------- Agent uninstall / update --------
#.\Agent-Uninstall-Tool.ps1 -Quiet
#.\Agent-Update-Tool.ps1 -ForceUpdate -Quiet

# -------- Log review & correlator (DefaultLogs + html) --------
.\Agent-Log-Review.ps1 -DefaultLogs
.\Agent-msg-Correlator.ps1 -DefaultLogs -html

# -------- OSQuery / patch / updates --------
.\OSQuery-WMIC-Patch-Audit.ps1 -ExportOnly
.\Windows-Update-Details.ps1 -TableView -App $AppName
.\Windows-Update-Details.ps1 -ExportOnly -App $AppName

# -------- Modern app & registry app search --------
.\Windows-Modern-App-Discovery.ps1 -ListAll
.\Windows-Modern-App-Discovery.ps1 -ExportOnly
.\Registry-Search.ps1 -App $AppName -nomenu

# -------- AD tools full pack --------
.\Active-Directory-Tools.ps1 -All -Quiet

# -------- Cookbook-only scripts without switches --------
.\Osquery-Data-Collection.ps1
.\Browser-Extensions-Details.ps1
