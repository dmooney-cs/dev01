<# =================================================================================================
  ConnectSecure Technicians Toolbox - OSQuery Application Inventory (Block Views + Paging)

  Script:  Osquery-Applications.ps1

  CHANGE (per request):
    - All interactive prompts now remind techs: "(press Enter after selection/entry)"
    - Silent modes (-App / -All / -ExportOnly) remain COMPLETELY silent (no terminal output)

  Switches / Parameters:
    -App "App name"
        Quick lookup mode. Skips the menu and exports JSON/CSV for matching rows.
        SILENT: shows nothing in terminal.

    -All
        Full inventory mode. Skips the menu and exports JSON/CSV for all apps.
        SILENT: shows nothing in terminal.

    -ExportOnly
        Cookbook mode. Same behavior as -All (silent export) and exits.
================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
    [string]$App,
    [switch]$All,
    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# -------------------------------------------------------------------------------------------------
# Mode flags
# -------------------------------------------------------------------------------------------------
$Script:Silent = $false
if ($App -or $All -or $ExportOnly) { $Script:Silent = $true }
if ($ExportOnly) { $All = $true }

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

# -------------------------------------------------------------------------------------------------
# Helpers (fully inlined)
# -------------------------------------------------------------------------------------------------
function Write-UI {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ConsoleColor]$Color = [ConsoleColor]::Gray
    )
    if (-not $Script:Silent) {
        Write-Host $Message -ForegroundColor $Color
    }
}

function Write-UIBlank { if (-not $Script:Silent) { Write-Host "" } }

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue... (press Enter after selection)")
    if ($Script:Silent) { return }
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue (press Enter after selection)"
    }
}

function Show-Header {
    param([string]$Title = "OSQuery - Applications")
    if ($Script:Silent) { return }
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $HostName = $env:COMPUTERNAME
    $UserName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $HostName, $UserName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# -------------------------------------------------------------------------------------------------
# Console utilities
# -------------------------------------------------------------------------------------------------
function Get-WindowWidth {
    try {
        $raw = $Host.UI.RawUI
        if ($raw -and $raw.BufferSize.Width -gt 0) { return $raw.BufferSize.Width }
        if ($raw -and $raw.WindowSize.Width -gt 0) { return $raw.WindowSize.Width }
        return 120
    } catch { return 120 }
}

function Write-LabelLine {
    param([string]$Label, [string]$Value, [int]$LabelWidth = 12)
    if ($Script:Silent) { return }
    $lbl = ($Label + ":").PadRight($LabelWidth)
    Write-Host ("{0} {1}" -f $lbl, $Value) -ForegroundColor Gray
}

# -------------------------------------------------------------------------------------------------
# Block renderer (interactive only)
# -------------------------------------------------------------------------------------------------
function Render-AppBlocks {
    param(
        [Parameter(Mandatory)][object[]]$Items,
        [bool]$HasInstallType = $false,
        [bool]$HasInstallSource = $false,
        [int]$PageSize = 3
    )

    if ($Script:Silent) { return } # hard stop: silent modes show nothing

    if (-not $Items -or $Items.Count -eq 0) {
        Write-Host "No applications returned." -ForegroundColor Yellow
        return
    }

    $i = 0
    $total = [int]$Items.Count
    $labelWidth = 12

    while ($i -lt $total) {
        $batchEnd = [Math]::Min($i + $PageSize, $total)
        for ($j = $i; $j -lt $batchEnd; $j++) {
            $app = $Items[$j]

            $name   = [string]$app.name
            $ver    = [string]$app.version
            $inst   = [string]$app.install_date
            $path   = [string]$app.install_location
            $uninst = $null
            if ($app.PSObject.Properties.Match('uninstall_string').Count -gt 0) { $uninst = [string]$app.uninstall_string }

            $itype = $null
            if ($HasInstallType -and ($app.PSObject.Properties.Match('install_type').Count -gt 0)) {
                $itype = [string]$app.install_type
            }

            $isrc = $null
            if ($HasInstallSource -and ($app.PSObject.Properties.Match('install_source').Count -gt 0)) {
                $isrc = [string]$app.install_source
            }

            # Title divider (ASCII-only)
            $win = Get-WindowWidth
            $title = "-- $name "
            $dashCount = [Math]::Max(0, $win - $title.Length)
            $divider  = $title + ("-" * $dashCount)
            Write-Host $divider -ForegroundColor Cyan

            # Body
            Write-LabelLine -Label "Version"      -Value $ver           -LabelWidth $labelWidth
            Write-LabelLine -Label "Installed"    -Value $inst          -LabelWidth $labelWidth
            if ($HasInstallType -and $itype) {
                Write-LabelLine -Label "Type"     -Value $itype         -LabelWidth $labelWidth
            }
            Write-LabelLine -Label "Install Path" -Value $path          -LabelWidth $labelWidth
            if ($HasInstallSource -and $isrc) {
                Write-LabelLine -Label "Source"   -Value $isrc          -LabelWidth $labelWidth
            }
            if ($uninst) {
                Write-LabelLine -Label "Uninstall" -Value $uninst       -LabelWidth $labelWidth
            }

            Write-Host ""
        }

        $i = $batchEnd
        if ($i -lt $total -and $PageSize -lt $total) {
            $ans = (Read-Host "[ENTER] next 3   |   [A] show ALL   |   [Q] back (press Enter after selection)").Trim()
            switch -regex ($ans) {
                '^(?i)q$' { break }
                '^(?i)a$' { $PageSize = [int]($total - $i) }
                default   { }
            }
        }
    }
}

# =========================
#   OSQuery Data Collection
# =========================
$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\OSQuery'

function Initialize-OsqOutput {
    Ensure-ExportFolder
    Ensure-Directory -Path $Global:OsqOutRoot
}

function Test-OsqueryPresent {
    if (-not (Test-Path -LiteralPath $Global:OsqBinPath)) {
        if (-not $Script:Silent) {
            Write-UIBlank
            Write-UI "osqueryi.exe not found:" Red
            Write-UI "  $Global:OsqBinPath" Yellow
            Write-UI "This tool requires ConnectSecure's osquery installation." Yellow
            Pause-Script "Press any key to return... (press Enter after selection)"
        }
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory=$true)][string]$Sql,
        [Parameter(Mandatory=$true)][string]$BaseName,
        [switch]$QuietExport,   # suppress "Saved:" chatter (interactive only)
        [switch]$NoFiles        # run query but do NOT write JSON/CSV (used for schema checks)
    )
    Initialize-OsqOutput

    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.json')
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.csv')

    if (-not $Script:Silent) {
        Write-UIBlank
        Write-UI "Running osquery query:" Cyan
        Write-UI ("  " + $Sql) DarkGray
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $Global:OsqBinPath
    $psi.Arguments = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()

    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if (-not $Script:Silent) {
        if ($stderr -and $stderr.Trim().Length -gt 0) {
            Write-UI "osquery stderr:" Yellow
            Write-UI ("  " + $stderr) DarkYellow
        }
        if (-not $stdout) {
            Write-UI "No output received from osquery." Red
        }
    }

    if (-not $stdout) { return @() }

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    if (-not $NoFiles) {
        try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

        try {
            if (@($objs).Count -gt 0) {
                $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
                if (-not $QuietExport -and -not $Script:Silent) {
                    Write-UIBlank
                    Write-UI "Saved:" Green
                    Write-UI "  JSON: $jsonPath" Green
                    Write-UI "  CSV : $csvPath"  Green
                }
            } else {
                if (-not $QuietExport -and -not $Script:Silent) {
                    Write-UI "No rows returned from query." DarkCyan
                    Write-UI "  JSON saved: $jsonPath" DarkCyan
                }
            }
        } catch { }
    }

    return $objs
}

# Detect if a column exists in a table for this osquery build (NO file exports for schema checks)
function Test-OsqColumnPresent {
    param(
        [Parameter(Mandatory=$true)][string]$Table,
        [Parameter(Mandatory=$true)][string]$Column
    )
    $sql  = "SELECT name FROM pragma_table_info('$Table') WHERE name = '$Column';"
    $rows = Invoke-OsqueryJson -Sql $sql -BaseName "OSQ_SCHEMA_${Table}_$Column" -NoFiles -QuietExport
    return (@($rows).Count -gt 0 -and $rows[0].name -eq $Column)
}

# -------------------------
# Applications (1 & 2)
# -------------------------
function Run-OsqApplicationsFull {
    param(
        [switch]$QuietMode = $false,   # if true, no Pause-Script and quiet export (interactive)
        [int]$PageSize = 3,
        [switch]$NoRender = $false     # if true, do not print blocks (used for silent modes)
    )

    if (-not (Test-OsqueryPresent)) { return }
    if (-not $QuietMode -and -not $Script:Silent) {
        Show-Header "OSQuery - Applications (Full Inventory)"
    }

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
ORDER BY name;
"@

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications' -QuietExport:$QuietMode
    if (-not $NoRender -and -not $Script:Silent) {
        if (@($objs).Count -gt 0) {
            $sorted = $objs | Sort-Object name
            Render-AppBlocks -Items $sorted -HasInstallType:$hasInstallType -HasInstallSource:$hasInstallSource -PageSize $PageSize
        } else {
            Write-UI "No rows returned from query." Yellow
        }
        if (-not $QuietMode) { Pause-Script "Press any key to continue... (press Enter after selection)" }
    }
}

function Run-OsqApplicationsSearch {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Search Applications"

    $term = Read-Host "Enter name or install path (partial OK) (press Enter after entry)"
    if (-not $term) {
        Write-UI "No search term entered." Yellow
        Pause-Script "Press any key to return... (press Enter after selection)"
        return
    }

    $like = $term.Replace('[','[[]').Replace('%','[%]').Replace('_','[_]')

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
WHERE name LIKE '%LIKE_PLACEHOLDER%' OR install_location LIKE '%LIKE_PLACEHOLDER%'
ORDER BY name;
"@
    $sql = $sql.Replace('LIKE_PLACEHOLDER', $like)

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications_Search'
    if (@($objs).Count -gt 0) {
        $sorted = $objs | Sort-Object name
        Render-AppBlocks -Items $sorted -HasInstallType:$hasInstallType -HasInstallSource:$hasInstallSource -PageSize 3
    } else {
        Write-UI "No matches." Yellow
    }
    Pause-Script "Press any key to return to menu... (press Enter after selection)"
}

# -------------------------------------------------------------------------------------------------
# SILENT MODES: -App, -All, -ExportOnly  (NO terminal output at all)
# -------------------------------------------------------------------------------------------------
function Run-Silent-AppExport {
    param([Parameter(Mandatory)][string]$Term)

    if (-not (Test-OsqueryPresent)) { return }

    $escaped = $Term.Replace('[','[[]').Replace('%','[%]').Replace('_','[_]')

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
WHERE name LIKE '%$escaped%' OR install_location LIKE '%$escaped%'
ORDER BY name;
"@

    $null = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications_Quick' -QuietExport
}

function Run-Silent-AllExport {
    if (-not (Test-OsqueryPresent)) { return }
    Run-OsqApplicationsFull -QuietMode -NoRender -PageSize 999999
}

# Entrypoint for silent modes
if ($App) {
    Run-Silent-AppExport -Term $App
    return
}
if ($All) {
    Run-Silent-AllExport
    return
}

# -------------------------
# Menu (interactive only)
# -------------------------
function Show-Menu {
    Clear-Host
    Show-Header "OSQuery - Applications"

    Write-Host ""
    Write-Host " [1] Applications (Full Inventory)    - name, version, path, date, type*, source*, uninstall*" -ForegroundColor White
    Write-Host " [2] Search for Specific Application  - match on name or install path" -ForegroundColor White
    Write-Host ""
    Write-Host " * 'Type' shown only if 'install_type' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host " * 'Source' shown only if 'install_source' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host " * 'Uninstall' shown only if 'uninstall_string' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop (interactive only if no -App / -All / -ExportOnly)
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice (press Enter after selection)"
    if (-not $choice) { continue }

    switch ($choice.ToUpperInvariant()) {
        '1' { Run-OsqApplicationsFull }
        '2' { Run-OsqApplicationsSearch }
        'Q' {
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path -LiteralPath $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection. (press Enter after selection)" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}