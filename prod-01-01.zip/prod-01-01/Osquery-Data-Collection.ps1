# -------------------------------------------------------------------------------------------------
# ConnectSecure Technicians Toolbox - OSQuery Application Inventory (Block Views + Paging)
# PS 5.1-safe: no ternary, ASCII-only dividers
# -------------------------------------------------------------------------------------------------

param(
    [string]$App  # Optional quick mode: .\Osquery-Data-Collection.ps1 -App "Notepad++"
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

# -------------------------------------------------------------------------------------------------
# Helpers (fully inlined)
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title = "OSQuery - Applications")
    Clear-Host
    $isAdmin  = Get-IsAdmin
    $HostName = $env:COMPUTERNAME
    $UserName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $HostName, $UserName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# -------------------------------------------------------------------------------------------------
# Console utilities
# -------------------------------------------------------------------------------------------------
function Get-WindowWidth {
    try {
        $raw = $Host.UI.RawUI
        if ($raw -and $raw.BufferSize.Width -gt 0) { return $raw.BufferSize.Width }
        if ($raw -and $raw.WindowSize.Width -gt 0) { return $raw.WindowSize.Width }
        return 120
    } catch { return 120 }
}

function Trunc-Text {
    param([string]$Text, [int]$MaxLen)
    if ($null -eq $Text) { return "" }
    $s = [string]$Text
    if ($MaxLen -le 1) { return ($s.Substring(0, [Math]::Min(1, $s.Length))) }
    if ($s.Length -le $MaxLen) { return $s }
    return $s.Substring(0, $MaxLen - 1) + '…'
}

function Scale-Widths {
    param([int[]]$Desired)
    $win = Get-WindowWidth
    $gutter = 3
    $rightMargin = 2
    $minCol = 8

    $desiredSum = ($Desired | Measure-Object -Sum).Sum
    $full = $desiredSum + (($Desired.Count - 1) * $gutter)

    if ($full -le ($win - $rightMargin)) { return $Desired }

    $target = [math]::Max(($Desired.Count * $minCol), ($win - $rightMargin - (($Desired.Count - 1) * $gutter)))
    $scale  = $target / [double][Math]::Max(1, $desiredSum)

    $scaled = @()
    foreach ($d in $Desired) {
        $w = [int][math]::Floor($d * $scale)
        if ($w -lt $minCol) { $w = $minCol }
        $scaled += $w
    }

    $sum = ($scaled | Measure-Object -Sum).Sum + (($scaled.Count - 1) * $gutter)
    while ($sum -gt ($win - $rightMargin)) {
        $maxVal = ($scaled | Sort-Object -Descending | Select-Object -First 1)
        $i = [Array]::IndexOf($scaled, $maxVal)
        if ($i -ge 0 -and $scaled[$i] -gt $minCol) { $scaled[$i]-- } else { break }
        $sum = ($scaled | Measure-Object -Sum).Sum + (($scaled.Count - 1) * $gutter)
    }
    return $scaled
}

function Write-LabelLine {
    param([string]$Label, [string]$Value, [int]$LabelWidth = 12)
    $lbl = ($Label + ":").PadRight($LabelWidth)
    Write-Host ("{0} {1}" -f $lbl, $Value) -ForegroundColor Gray
}

# -------------------------------------------------------------------------------------------------
# Block renderer (Layout B) with paging: 3 at a time, ENTER/All/Quit
# -------------------------------------------------------------------------------------------------
function Render-AppBlocks {
    param(
        [Parameter(Mandatory)][object[]]$Items,
        [bool]$HasInstallType = $false,
        [bool]$HasInstallSource = $false,
        [int]$PageSize = 3
    )

    if (-not $Items -or $Items.Count -eq 0) {
        Write-Host "No applications returned." -ForegroundColor Yellow
        return
    }

    $i = 0
    $total = [int]$Items.Count
    $labelWidth = 12

    while ($i -lt $total) {
        $batchEnd = [Math]::Min($i + $PageSize, $total)
        for ($j = $i; $j -lt $batchEnd; $j++) {
            $app = $Items[$j]

            $name   = [string]$app.name
            $ver    = [string]$app.version
            $inst   = [string]$app.install_date
            $path   = [string]$app.install_location
            $uninst = [string]$app.uninstall_string

            $itype = $null
            if ($HasInstallType)   { $itype = [string]$app.install_type }

            $isrc = $null
            if ($HasInstallSource) { $isrc = [string]$app.install_source }

            # Title divider (ASCII-only)
            $win = Get-WindowWidth
            $title = "-- $name "
            $dashCount = [Math]::Max(0, $win - $title.Length)
            $divider  = $title + ("-" * $dashCount)
            Write-Host $divider -ForegroundColor Cyan

            # Body
            Write-LabelLine -Label "Version"      -Value $ver           -LabelWidth $labelWidth
            Write-LabelLine -Label "Installed"    -Value $inst          -LabelWidth $labelWidth
            if ($HasInstallType -and $itype) {
                Write-LabelLine -Label "Type"     -Value $itype         -LabelWidth $labelWidth
            }
            Write-LabelLine -Label "Install Path" -Value $path          -LabelWidth $labelWidth
            if ($HasInstallSource -and $isrc) {
                Write-LabelLine -Label "Source"   -Value $isrc          -LabelWidth $labelWidth
            }
            if ($uninst) {
                Write-LabelLine -Label "Uninstall" -Value $uninst       -LabelWidth $labelWidth
            }

            Write-Host ""
        }

        $i = $batchEnd
        if ($i -lt $total) {
            $ans = (Read-Host "[ENTER] next 3   |   [A] show ALL   |   [Q] back").Trim()
            switch -regex ($ans) {
                '^(?i)q$' { break }
                '^(?i)a$' { $PageSize = [int]($total - $i) }
                default   { }
            }
        }
    }
}

# =========================
#   OSQuery Data Collection
# =========================

$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\OSQuery'

function Initialize-OsqOutput {
    if (-not (Test-Path $Global:OsqOutRoot)) {
        New-Item -Path $Global:OsqOutRoot -ItemType Directory | Out-Null
    }
}

function Test-OsqueryPresent {
    if (-not (Test-Path $Global:OsqBinPath)) {
        Write-Host ""
        Write-Host "osqueryi.exe not found:" -ForegroundColor Red
        Write-Host "  $Global:OsqBinPath" -ForegroundColor Yellow
        Write-Host "This tool requires ConnectSecure's osquery installation." -ForegroundColor Yellow
        Pause-Script "Press any key to return..."
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory=$true)][string]$Sql,
        [Parameter(Mandatory=$true)][string]$BaseName
    )
    Initialize-OsqOutput

    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.json')
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.csv')

    Write-Host ""
    Write-Host "Running osquery query:" -ForegroundColor Cyan
    Write-Host "  $Sql" -ForegroundColor DarkGray

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $Global:OsqBinPath
    $psi.Arguments = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()

    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stderr -and $stderr.Trim().Length -gt 0) {
        Write-Host "osquery stderr:" -ForegroundColor Yellow
        Write-Host "  $stderr" -ForegroundColor DarkYellow
    }

    if (-not $stdout) {
        Write-Host "No output received from osquery." -ForegroundColor Red
        return @()
    }

    try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    try {
        if (@($objs).Count -gt 0) {
            $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
            Write-Host ""
            Write-Host "Saved:" -ForegroundColor Green
            Write-Host "  JSON: $jsonPath" -ForegroundColor Green
            Write-Host "  CSV : $csvPath"  -ForegroundColor Green
        } else {
            Write-Host "No rows returned from query." -ForegroundColor DarkCyan
            Write-Host "  JSON saved: $jsonPath" -ForegroundColor DarkCyan
        }
    } catch {}

    return $objs
}

# Detect if a column exists in a table for this osquery build
function Test-OsqColumnPresent {
    param(
        [Parameter(Mandatory=$true)][string]$Table,
        [Parameter(Mandatory=$true)][string]$Column
    )
    $sql = "SELECT name FROM pragma_table_info('$Table') WHERE name = '$Column';"
    $rows = Invoke-OsqueryJson -Sql $sql -BaseName "OSQ_SCHEMA_${Table}_$Column"
    return (@($rows).Count -gt 0 -and $rows[0].name -eq $Column)
}

# -------------------------
# Applications (1 & 2)
# -------------------------
function Run-OsqApplicationsFull {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Applications (Full Inventory)"

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
ORDER BY name;
"@

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications'
    if (@($objs).Count -gt 0) {
        $sorted = $objs | Sort-Object name
        Render-AppBlocks -Items $sorted -HasInstallType:$hasInstallType -HasInstallSource:$hasInstallSource -PageSize 3
    } else {
        Write-Host "No rows returned from query." -ForegroundColor Yellow
    }
    Pause-Script
}

function Run-OsqApplicationsSearch {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Search Applications"

    $term = Read-Host "Enter name or install path (partial OK)"
    if (-not $term) {
        Write-Host "No search term entered." -ForegroundColor Yellow
        Pause-Script
        return
    }

    $like = $term.Replace('[','[[]').Replace('%','[%]').Replace('_','[_]')

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
WHERE name LIKE '%LIKE_PLACEHOLDER%' OR install_location LIKE '%LIKE_PLACEHOLDER%'
ORDER BY name;
"@
    $sql = $sql.Replace('LIKE_PLACEHOLDER', $like)

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications_Search'
    if (@($objs).Count -gt 0) {
        $sorted = $objs | Sort-Object name
        Render-AppBlocks -Items $sorted -HasInstallType:$hasInstallType -HasInstallSource:$hasInstallSource -PageSize 3
    } else {
        Write-Host "No matches." -ForegroundColor Yellow
    }
    Pause-Script
}

# -------------------------
# QUICK MODE: -App "Name"
# -------------------------
if ($App) {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Application Detail: $App"

    $escaped = $App.Replace('[','[[]').Replace('%','[%]').Replace('_','[_]')

    $hasInstallType   = Test-OsqColumnPresent -Table 'programs' -Column 'install_type'
    $hasUninstall     = Test-OsqColumnPresent -Table 'programs' -Column 'uninstall_string'
    $hasInstallSource = Test-OsqColumnPresent -Table 'programs' -Column 'install_source'

    $cols = @('name','version','install_location','install_date')
    if ($hasInstallType)   { $cols += 'install_type' }
    if ($hasInstallSource) { $cols += 'install_source' }
    if ($hasUninstall)     { $cols += 'uninstall_string' }

    $select = ($cols -join ",`n  ")
    $sql = @"
SELECT
  $select
FROM programs
WHERE name LIKE '%$escaped%' OR install_location LIKE '%$escaped%'
ORDER BY name;
"@

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications_Quick'
    if (@($objs).Count -gt 0) {
        # Show all results at once in block view
        Render-AppBlocks -Items $objs -HasInstallType:$hasInstallType -HasInstallSource:$hasInstallSource -PageSize 9999
    } else {
        Write-Host "No application found matching: $App" -ForegroundColor Yellow
    }

    Pause-Script
    return
}

# -------------------------
# Menu (1 & 2 only)
# -------------------------
function Show-Menu {
    Clear-Host
    Show-Header "OSQuery - Applications"

    Write-Host ""
    Write-Host " [1] Applications (Full Inventory)    - name, version, path, date, type*, source*, uninstall*" -ForegroundColor White
    Write-Host " [2] Search for Specific Application  - match on name or install path" -ForegroundColor White
    Write-Host ""
    Write-Host " * 'Type' shown only if 'install_type' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host " * 'Source' shown only if 'install_source' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host " * 'Uninstall' shown only if 'uninstall_string' column exists on this osquery build." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-OsqApplicationsFull }
        '2' { Run-OsqApplicationsSearch }
        'Q' {
            # Explicitly relaunch the main CS Toolbox Launcher in the SAME window, if present
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
