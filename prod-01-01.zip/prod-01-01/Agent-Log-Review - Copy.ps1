<# ====================================================
  Agent-Log-Review.ps1  (v4b - perf-guarded + error summaries, param at top)
  - [1] Local Agent ConnectSecure Logs
  - [2] Custom folder (COM folder picker)
  - Progress messages, size caps, merge line caps, and -NoMerge
====================================================== #>

param(
    [switch]$NoMerge,
    [int]$MaxMergeMB = 25,
    [int]$MaxLinesPerFileHead = 2500,
    [int]$MaxLinesPerFileTail = 2500
)

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -------- Common bootstrap (safe / back-compat) --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try { . $commonPath } catch { Write-Verbose "Functions-Common load failed: $($_.Exception.Message)" }
}

if (-not $global:CS_TempRoot -or [string]::IsNullOrWhiteSpace($global:CS_TempRoot)) {
    $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP'
}

# Minimal helpers if missing
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = 'ConnectSecure Technicians Toolbox')
        Write-Host ''
        Write-Host (' ' + $Title) -ForegroundColor Cyan
        Write-Host ('=' * 58)
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        $hostName = $env:COMPUTERNAME
        $userName = "$env:USERDOMAIN\$env:USERNAME"
        Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
        Write-Host ('=' * 58)
        Write-Host ''
    }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Write-Err  -ErrorAction SilentlyContinue)) { function Write-Err  { param([string]$Msg) Write-Host ("[ERROR] {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -ForegroundColor Red } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) {
    function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } }
}

# -------- Folder picker (COM Shell; no STA required) --------
function Select-Folder {
    param(
        [string]$Description = 'Select a folder',
        [string]$InitialDirectory = 'C:\'
    )
    try {
        $shell = New-Object -ComObject Shell.Application
        $folder = $shell.BrowseForFolder(0, $Description, 0, $InitialDirectory)
        if ($folder) { return $folder.Self.Path }
    } catch {
        Write-Warn ("Folder picker unavailable: {0}" -f $_.Exception.Message)
    }
    return $null
}

# -------- Error Analysis --------
function Analyze-ErrorSummary {
    param(
        [Parameter(Mandatory)][string]$CollectDir
    )
    Write-Info "Analyzing logs for recurring errors/warnings..."
    $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
    $stampRegexes = @('\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?','\b\d{2}:\d{2}:\d{2}\b')
    $guidRegex = '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b'
    $hexRegex  = '\b0x[0-9A-Fa-f]+\b'

    $countsByPattern = @{}
    $countsByLevel   = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
    $textFiles = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.log', '.txt', '.json' }
    $totalLines = 0

    foreach ($file in $textFiles) {
        try {
            Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue | ForEach-Object {
                $line = $_; $totalLines++
                if ($line -match $levelRegex) {
                    $upper = $Matches[1].ToUpperInvariant()
                    switch -Regex ($upper) {
                        '^ERROR$'      { $countsByLevel.ERROR++ }
                        '^FATAL$'      { $countsByLevel.FATAL++ }
                        '^EXCEPTION$'  { $countsByLevel.EXCEPTION++ }
                        '^WARN$'       { $countsByLevel.WARN++ }
                        '^WARNING$'    { $countsByLevel.WARNING++ }
                        '^FAIL(ED)?$'  { $countsByLevel.FAIL++ }
                        '^TIMEOUT$'    { $countsByLevel.TIMEOUT++ }
                        '^UNAUTHORIZED$' { $countsByLevel.UNAUTHORIZED++ }
                        'ACCESS DENIED' { $countsByLevel.ACCESSDENIED++ }
                    }
                    $norm = $line
                    foreach ($rx in $stampRegexes) { $norm = ($norm -replace $rx, '') }
                    $norm = $norm -replace $guidRegex, '{GUID}'
                    $norm = $norm -replace $hexRegex, '{HEX}'
                    $norm = $norm -replace '\[[^\]]+\]', ''
                    $norm = $norm -replace '\b\d+\b', '#'
                    $norm = $norm -replace '\s+', ' '
                    $norm = $norm.Trim()
                    if ($norm.Length -gt 180) { $norm = $norm.Substring(0,180) }
                    if ($countsByPattern.ContainsKey($norm)) { $countsByPattern[$norm]++ } else { $countsByPattern[$norm] = 1 }
                }
            }
        } catch { Write-Warn ("Could not analyze {0}: {1}" -f $file.FullName, $_.Exception.Message) }
    }

    $csvPath = Join-Path $CollectDir 'ErrorSummary.csv'
    $countsByPattern.GetEnumerator() | Sort-Object -Property Value -Descending | Select-Object @{n='Pattern';e={$_.Key}}, @{n='Count';e={$_.Value}} | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

    Write-Host ''
    Write-Host ' ===== Error/Warning Summary ===== ' -ForegroundColor Cyan
    Write-Host (" Total text lines scanned : {0}" -f $totalLines)
    foreach ($k in 'ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED') {
        Write-Host ('  {0,-12} : {1}' -f $k, $countsByLevel[$k])
    }
    Write-Host ''
    $top = $countsByPattern.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 15
    if ($top) {
        Write-Host ' Top recurring messages:' -ForegroundColor Cyan
        $i=1; foreach ($entry in $top) { Write-Host (" {0,2}. ({1,4}x) {2}" -f $i, $entry.Value, $entry.Key); $i++ }
    } else {
        Write-Host ' No recurring error/warning lines detected.'
    }
    Write-OK ("Wrote CSV summary: {0}" -f $csvPath)
}

# -------- Collection + merge --------
function Collect-FromRoots {
    param([Parameter(Mandatory)][string[]]$Roots)

    $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
    Ensure-Folder $outDir

    $timestamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
    $collectDir = Join-Path $outDir ('Collect_{0}' -f $timestamp)
    Ensure-Folder $collectDir

    $patterns = @('*.log','*.txt','*.json','*.evtx','*.zip','*.gz')
    $foundAny = $false

    foreach ($root in ($Roots | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -Unique)) {
        Write-Info ("Scanning {0} ..." -f $root)
        $safeLeaf = (Split-Path $root -Leaf); if (-not $safeLeaf) { $safeLeaf = ($root -replace '[:\\\/]','_') }
        $dest = Join-Path $collectDir ($safeLeaf -replace '[^\w\.-]','_')
        Ensure-Folder $dest
        try {
            $items = Get-ChildItem -Path (Join-Path $root '*') -Recurse -File -Include $patterns -ErrorAction SilentlyContinue
            if ($items -and $items.Count -gt 0) {
                $foundAny = $true
                $i = 0
                foreach ($f in $items) {
                    $i++
                    if ($i % 50 -eq 0) { Write-Info (" Copying files... {0}/{1}" -f $i, $items.Count) }
                    $relative = try { $f.FullName.Substring($root.Length).TrimStart('\') } catch { $f.Name }
                    $target   = Join-Path $dest $relative
                    Ensure-Folder (Split-Path $target -Parent)
                    Copy-Item -LiteralPath $f.FullName -Destination $target -Force -ErrorAction SilentlyContinue
                }
                Write-OK ("Copied {0} files from {1}" -f $items.Count, $root)
            } else {
                Write-Warn ("No matching files found under {0}" -f $root)
            }
        } catch {
            Write-Warn ("Scan error on {0}: {1}" -f $root, $_.Exception.Message)
        }
    }

    if (-not $foundAny) {
        Write-Warn 'No logs found in selected locations.'
        New-Item -ItemType File -Path (Join-Path $collectDir 'NO_LOGS_FOUND.txt') -Force | Out-Null
    } else {
        Write-OK ('Collected logs to: {0}' -f $collectDir)
    }

    if (-not $NoMerge) {
        Write-Info ("Merging text logs (<= {0} MB per file; head {1} + tail {2} lines) ..." -f $MaxMergeMB, $MaxLinesPerFileHead, $MaxLinesPerFileTail)
        $merged = Join-Path $collectDir ('Merged_Agent_Logs_{0}.txt' -f $timestamp)
        try {
            $capBytes = [int64]$MaxMergeMB * 1MB
            $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.log', '.txt', '.json' }
            $j = 0; $skipped = 0
            foreach ($tf in $textFiles) {
                $j++
                if ($j % 50 -eq 0) { Write-Info (" Merging file {0}/{1}..." -f $j, $textFiles.Count) }
                Add-Content -Path $merged -Value ("===== FILE: {0} =====" -f $tf.FullName)
                if ($tf.Length -gt $capBytes) {
                    Add-Content -Path $merged -Value ("[Skipped full merge due to size > {0} MB; including first {1} and last {2} lines]" -f $MaxMergeMB, $MaxLinesPerFileHead, $MaxLinesPerFileTail)
                    $head = Get-Content -LiteralPath $tf.FullName -TotalCount $MaxLinesPerFileHead -ErrorAction SilentlyContinue
                    $tail = Get-Content -LiteralPath $tf.FullName -Tail $MaxLinesPerFileTail -ErrorAction SilentlyContinue
                    $head | Out-File -FilePath $merged -Append -Encoding UTF8
                    Add-Content -Path $merged -Value '----- TAIL -----'
                    $tail | Out-File -FilePath $merged -Append -Encoding UTF8
                    $skipped++
                } else {
                    Get-Content -LiteralPath $tf.FullName -ErrorAction SilentlyContinue | Out-File -FilePath $merged -Append -Encoding UTF8
                }
                Add-Content -Path $merged -Value ''
            }
            Write-OK ("Merged view: {0}  (Skipped full merge for {1} large file(s))" -f $merged, $skipped)
        } catch {
            Write-Warn ("Could not build merged view: {0}" -f $_.Exception.Message)
        }
    } else {
        Write-Warn "Skipping merge (-NoMerge set)."
    }

    # After collecting, run error analysis
    try { Analyze-ErrorSummary -CollectDir $collectDir } catch { Write-Warn ("Error summary failed: {0}" -f $_.Exception.Message) }

    # Bundle
    if (Get-Command Invoke-ZipAndEncrypt -ErrorAction SilentlyContinue) {
        Write-Info 'Bundling with v9 zip/encrypt flow...'
        Invoke-ZipAndEncrypt -SourcePath $collectDir -ToolName 'Agent-Log-Review'
    } else {
        Write-Info 'Compressing results to ZIP...'
        $zipPath = Join-Path $outDir ('AgentLogs_{0}.zip' -f $timestamp)
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue | Out-Null
        if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue }
        Compress-Archive -Path (Join-Path $collectDir '*') -DestinationPath $zipPath -Force
        Write-OK ('Wrote ZIP: {0}' -f $zipPath)
    }

    return $collectDir
}

# -------- Main --------
function Start-AgentLogReview {
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' [1] Local Agent ConnectSecure Logs' -ForegroundColor White
    Write-Host '     - Scans: C:\Program Files (x86)\CyberCNSAgent\logs' -ForegroundColor DarkGray
    Write-Host ' [2] Specify custom scan directory...' -ForegroundColor White
    Write-Host ' [Q] Quit' -ForegroundColor White
    Write-Host ''
    $choice = Read-Host 'Select an option (1/2/Q)'

    switch ($choice.ToUpper()) {
        '1' {
            $defaultPath = 'C:\Program Files (x86)\CyberCNSAgent\logs'
            if (-not (Test-Path -LiteralPath $defaultPath)) { Write-Warn ("Default path not found: {0}" -f $defaultPath) }
            $dir = Collect-FromRoots -Roots @($defaultPath)
            Write-Host ''; Write-Host (" Results in: {0}" -f $dir) -ForegroundColor Gray
        }
        '2' {
            $picked = Select-Folder -Description 'Choose agent logs folder to scan' -InitialDirectory 'C:\Program Files (x86)\CyberCNSAgent\logs'
            if (-not $picked) { $picked = Read-Host 'No folder picked. Enter a folder path (or press Enter to cancel)' }
            if ($picked -and (Test-Path -LiteralPath $picked)) {
                $dir = Collect-FromRoots -Roots @($picked)
                Write-Host ''; Write-Host (" Results in: {0}" -f $dir) -ForegroundColor Gray
            } else {
                Write-Warn 'No valid folder provided. Nothing to do.'
            }
        }
        'Q' { return }
        Default { Write-Warn 'Invalid choice.' }
    }

    Write-Host ''
    Read-Host 'Press Enter to return...'
}

Start-AgentLogReview
