<# ====================================================
  Agent-Log-Review.ps1  (v7g - PS5.1-safe null handling; Device Summary; loops; Q runs launcher)
====================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables ----
$ContextBefore          = 3
$ContextAfter           = 3
$MaxExamplesPerPattern  = 12
$LargeFileContextMB     = 25
$FoldUrlToHost          = $true
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$RecentWindowMinutes    = 5
$DefaultLogsRoot        = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$SearchPatterns         = @('*.log','*.txt','*.json','*.evtx','*.zip','*.gz')  # copy-only: evtx/zip/gz
$AnalyzeExts            = @('.log','.txt','.json')

# ---- Paths ----
$LauncherPath           = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# -------- Bootstrap (optional common lib) --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) { try { . $commonPath } catch { } }
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

# -------- Console helpers --------
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header { param([string]$Title='ConnectSecure Technicians Toolbox')
    Write-Host ("`n $Title") -ForegroundColor Cyan
    Write-Host ('='*58)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME,"$env:USERDOMAIN\$env:USERNAME",$isAdmin) -ForegroundColor Gray
    Write-Host ('='*58); Write-Host ''
  }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

# -------- Utility helpers --------
function HtmlEscape($s) { return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }

function Normalize-PathInput {
  param([Parameter(Mandatory)][string]$Raw)
  $t = $Raw.Trim()
  if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  if ($t.StartsWith("'") -and $t.EndsWith("'") -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  [Environment]::ExpandEnvironmentVariables($t).Trim()
}

function Read-FileLines {
  param([Parameter(Mandatory)][string]$Path)
  try {
    $c = Get-Content -LiteralPath $Path -ErrorAction Stop
    if ($null -eq $c) { return @() }
    if ($c -is [string]) { return @($c) }
    return @($c)
  } catch {
    Write-Warn ("Failed to read file: {0}" -f $_.Exception.Message)
    return @()
  }
}

# PS5.1-safe "value or fallback"
function ValueOr { param($v,$fallback) if ($null -eq $v) { return $fallback } $sv = [string]$v; if ([string]::IsNullOrWhiteSpace($sv)) { return $fallback } return $sv }

# -------- Timestamp parsing --------
function TryParse-LineDateTime {
  param([string]$Line,[datetime]$FallbackDate)
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success -and $FallbackDate) {
    try {
      $h=[int]$m.Groups[1].Value.Substring(0,2)
      $mi=[int]$m.Groups[1].Value.Substring(3,2)
      $s=[int]$m.Groups[1].Value.Substring(6,2)
      return (Get-Date -Date $FallbackDate.Date -Hour $h -Minute $mi -Second $s)
    } catch {}
  }
  return $null
}

# -------- Pattern normalization --------
function Normalize-LineForPattern {
  param([string]$Line)
  if ($null -eq $Line) { return '' }
  $norm = $Line
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
  if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()
  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

# -------- Analysis --------
function Analyze-File {
  param([string]$FilePath)

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $patterns = @{}
  $contexts = @{}

  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false
  if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

  $lines = Read-FileLines -Path $FilePath
  $lines = @($lines)
  if ($lines.Count -eq 0) {
    Write-Warn ("Skipping empty or unreadable file: {0}" -f $FilePath)
    $now = Get-Date
    return [PSCustomObject]@{
      File=$FilePath; Total=0; Counts=$countsByLevel; Patterns=$patterns; Contexts=$contexts; Limited=$limitCtx;
      RecentWindow=@{Start=$now;End=$now};
      RecentCounts=@{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 };
      RecentSnippets=@()
    }
  }

  # Determine latest timestamp for "last N minutes" window
  $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }
  $latestInFile = $null
  foreach ($ln in $lines) { $dt = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate; if ($dt) { if ($null -eq $latestInFile -or $dt -gt $latestInFile) { $latestInFile = $dt } } }
  if (-not $latestInFile) { $latestInFile = $fallbackDate }

  $windowEnd   = $latestInFile
  $windowStart = $windowEnd.AddMinutes(-$RecentWindowMinutes)

  # Pre-pass to find indices in recent window
  $recentIdxs = New-Object System.Collections.Generic.List[int]
  for ($ri=0; $ri -lt $lines.Count; $ri++) {
    $dt = TryParse-LineDateTime -Line $lines[$ri] -FallbackDate $fallbackDate
    if ($dt -and $dt -ge $windowStart -and $dt -le $windowEnd) { $recentIdxs.Add($ri) }
  }

  # Full pass for patterns and contexts
  for ($i=0;$i -lt $lines.Count;$i++) {
    $line = [string]$lines[$i]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }

      $norm = Normalize-LineForPattern -Line $line
      if (-not $patterns.ContainsKey($norm)) { $patterns[$norm] = 0 }
      $patterns[$norm]++
      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }

      $maxCtx = if ($limitCtx) { [Math]::Min($MaxExamplesPerPattern,3) } else { $MaxExamplesPerPattern }
      if ($contexts[$norm].Count -lt $maxCtx) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        # capture any blank/indented continuation lines
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($null -eq $n -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx="Context for line $($i+1) (+/-$ContextBefore/$ContextAfter)`n"
        for($p=$start;$p -le $end;$p++){
          $prefix=('   '); if($p -eq $i){ $prefix='>> ' }
          $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
        }
        $contexts[$norm] += $ctx
      }
    }
  }

  # Recent window: short contexts + counts
  $recentCounts = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $recentSnippets = New-Object System.Collections.Generic.List[string]
  foreach ($idx in $recentIdxs) {
    $line = [string]$lines[$idx]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$recentCounts.ERROR++}
        '^FATAL$'        {$recentCounts.FATAL++}
        '^EXCEPTION$'    {$recentCounts.EXCEPTION++}
        '^WARN$'         {$recentCounts.WARN++}
        '^WARNING$'      {$recentCounts.WARNING++}
        '^FAIL(ED)?$'    {$recentCounts.FAIL++}
        '^TIMEOUT$'      {$recentCounts.TIMEOUT++}
        '^UNAUTHORIZED$' {$recentCounts.UNAUTHORIZED++}
        'ACCESS DENIED'  {$recentCounts.ACCESSDENIED++}
      }
      $rStart=[Math]::Max(0,$idx-1); $rEnd=[Math]::Min($lines.Count-1,$idx+1)
      $ctx="Recent match at line $($idx+1)`n"
      for($p=$rStart;$p -le $rEnd;$p++){
        $prefix=('   '); if($p -eq $idx){ $prefix='>> ' }
        $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
      }
      $recentSnippets.Add($ctx)
    }
  }

  return [PSCustomObject]@{
    File           = $FilePath
    Total          = $lines.Count
    Counts         = $countsByLevel
    Patterns       = $patterns
    Contexts       = $contexts
    Limited        = $limitCtx
    RecentWindow   = @{ Start=$windowStart; End=$windowEnd; Anchored='FileLastTimestamp' }
    RecentCounts   = $recentCounts
    RecentSnippets = $recentSnippets
  }
}

# -------- Agent Summary Parser --------
function Get-AgentSummaryFromLogs {
  param([Parameter(Mandatory)][string]$CollectDir)

  # Prefer a CyberCNS log; fallback to any text log containing "AGENT INFO"
  $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in $AnalyzeExts } |
               Sort-Object FullName | Where-Object { $_.Name -match 'cybercns' } | Select-Object -First 1
  if (-not $candidate) {
    $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.Extension -in $AnalyzeExts } |
                 Where-Object { Select-String -Path $_.FullName -Pattern 'AGENT INFO' -SimpleMatch -ErrorAction SilentlyContinue } |
                 Select-Object -First 1
  }
  if (-not $candidate) { return $null }

  $meta = [ordered]@{
    Hostname     = $null
    IP           = $null
    MAC          = $null
    AgentVersion = $null
    AgentID      = $null
    TenantID     = $null
    CompanyID    = $null
    AgentType    = $null
    PODID        = $null
    SourceFile   = $candidate.FullName
  }

  $lines = Read-FileLines -Path $candidate.FullName
  foreach ($ln in $lines) {
    # IP / MAC / Hostname from the "IP ADDRESS" pattern
    if (-not $meta.IP -and $ln -match 'IP ADDRESS') {
      $ipm  = [regex]::Match($ln,'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)')
      if ($ipm.Success) { $meta.IP = $ipm.Groups[1].Value }
      $macm = [regex]::Match($ln,'\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b')
      if ($macm.Success) { $meta.MAC = $macm.Groups[1].Value.ToLower() }
      $hostm = [regex]::Match($ln,'HostName.?s\s*\[([^\]]+)\]')
      if ($hostm.Success) { $meta.Hostname = $hostm.Groups[1].Value }
      if (-not $meta.Hostname) {
        $uidm = [regex]::Match($ln,"UniqueId.?s\s*\[([^\]]+)\]")
        if ($uidm.Success) {
          $maybe = ($uidm.Groups[1].Value -split '[\s,]') | Where-Object { $_ -and ($_ -notmatch ':') } | Select-Object -First 1
          if ($maybe) { $meta.Hostname = $maybe }
        }
      }
    }

    # AGENT INFO fields
    if ($ln -match '\[Agent Version\s*:-\s*([^\]]+)\]') { $meta.AgentVersion = $Matches[1].Trim() }
    if ($ln -match '\[Agent ID\s*:-\s*([^\]]+)\]')      { $meta.AgentID      = $Matches[1].Trim() }
    if ($ln -match '\[Tenant ID\s*:-\s*([^\]]+)\]')     { $meta.TenantID     = $Matches[1].Trim() }
    if ($ln -match '\[Company ID\s*:-\s*([^\]]+)\]')    { $meta.CompanyID    = $Matches[1].Trim() }
    if ($ln -match '\[Agent Type\s*:-\s*([^\]]+)\]')    { $meta.AgentType    = $Matches[1].Trim() }
    if ($ln -match '\[PODID\s*:-\s*([^\]]+)\]')         { $meta.PODID        = $Matches[1].Trim() }
  }

  return $meta
}

# -------- Report builder --------
function Collect-And-Report {
  param([string[]]$Roots)

  $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
  Ensure-Folder $outDir
  $ts=Get-Date -Format 'yyyyMMdd_HHmmss'
  $collectDir=Join-Path $outDir ('Collect_'+$ts)
  Ensure-Folder $collectDir

  $found=$false

  foreach($root in ($Roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) })) {
    Write-Info "Scanning $root ..."
    if (Test-Path -LiteralPath $root -PathType Leaf) {
      $found = $true
      $dest = Join-Path $collectDir 'SelectedFiles'
      Ensure-Folder $dest
      Copy-Item -LiteralPath $root -Destination (Join-Path $dest (Split-Path $root -Leaf)) -Force -ErrorAction SilentlyContinue
      Write-OK ("Copied file: {0}" -f $root)
    } else {
      $dest=Join-Path $collectDir ((Split-Path $root -Leaf)-replace'[^\w\.-]','_'); Ensure-Folder $dest
      try {
        $items = Get-ChildItem -Path (Join-Path $root '*') -Recurse -File -Include $SearchPatterns -ErrorAction SilentlyContinue
        if ($items) {
          $found=$true
          $i=0; foreach($f in $items){ $i++; if($i%50 -eq 0){ Write-Info (" Copying files... {0}/{1}" -f $i,$items.Count) }
            $rel=try{$f.FullName.Substring($root.Length).TrimStart('\','/')}catch{$f.Name}
            $tgt=Join-Path $dest $rel; Ensure-Folder (Split-Path $tgt -Parent)
            Copy-Item -LiteralPath $f.FullName -Destination $tgt -Force -ErrorAction SilentlyContinue
          }
          Write-OK ("Copied {0} files from {1}" -f $items.Count,$root)
        } else { Write-Warn ("No matching files found under {0}" -f $root) }
      } catch { Write-Warn ("Scan error on {0}: {1}" -f $root,$_.Exception.Message) }
    }
  }

  if(-not $found){
    Write-Warn 'No logs found'
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
.kicker{background:#fff4d6;border:1px solid #ffd27a;padding:10px;border-radius:8px;}
</style></head><body>
<div class="logo-wrap"><img src="$LogoUrl" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Agent Log Review</h1>
<div class="kicker">
  <h3>No logs were collected</h3>
  <p>We did not find any files matching *.log, *.txt, *.json, *.evtx, *.zip, or *.gz in the selected location(s).</p>
</div>
</body></html>
"@
    $htmlPath=Join-Path $collectDir 'index.html'
    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html)
    [System.IO.File]::WriteAllBytes($htmlPath, $bytes)
    Write-OK ("Wrote HTML report: $htmlPath")
    try{ Start-Process $htmlPath }catch{}
    return
  }

  # Build HTML
  $html=[System.Text.StringBuilder]::new()
  $null=$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>')
  $null=$html.AppendLine('<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:8px;margin:6px 0 10px;}
.kicker h3{margin:0 0 6px 0;}
.badge{display:inline-block;padding:2px 6px;border:1px solid #aaa;border-radius:6px;font-size:12px;color:#555;background:#fafafa;margin-left:6px;}
.summary{background:#fff7e6;border:1px solid #ffd699;padding:10px 12px;border-radius:10px;margin:8px 0 16px;}
.summary h2{margin:4px 0 8px 0;}
.summary table{width:auto;border-collapse:separate;border-spacing:0 4px;}
.summary td{border:none;padding:2px 10px 2px 0;}
.key{color:#555;font-weight:600;white-space:nowrap;}
.val{color:#000;}
.src{color:#888;font-size:12px;margin-top:4px;}
</style></head><body>')
  $null=$html.AppendLine('<div class="logo-wrap"><img src="'+ (HtmlEscape $LogoUrl) +'" alt="ConnectSecure logo"></div>')
  $null=$html.AppendLine('<h1>ConnectSecure - Agent Log Review</h1>')

  # ---- Device Summary (from CyberCNS log) ----
  $agentMeta = Get-AgentSummaryFromLogs -CollectDir $collectDir
  if ($agentMeta) {
    $h = HtmlEscape( (ValueOr $agentMeta.Hostname '-') )
    $ip= HtmlEscape( (ValueOr $agentMeta.IP       '-') )
    $mc= HtmlEscape( (ValueOr $agentMeta.MAC      '-') )
    $av= HtmlEscape( (ValueOr $agentMeta.AgentVersion '-') )
    $aid=HtmlEscape( (ValueOr $agentMeta.AgentID      '-') )
    $tid=HtmlEscape( (ValueOr $agentMeta.TenantID     '-') )
    $cid=HtmlEscape( (ValueOr $agentMeta.CompanyID    '-') )
    $aty=HtmlEscape( (ValueOr $agentMeta.AgentType    '-') )
    $pod=HtmlEscape( (ValueOr $agentMeta.PODID        '-') )
    $src=HtmlEscape( (ValueOr $agentMeta.SourceFile   '') )

    $null=$html.AppendLine('<div class="summary">')
    $null=$html.AppendLine('<h2>Device Summary</h2>')
    $null=$html.AppendLine('<table>')
    $null=$html.AppendLine("<tr><td class='key'>Hostname</td><td class='val'>$h</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>IP Address</td><td class='val'>$ip</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>MAC Address</td><td class='val'>$mc</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Version</td><td class='val'>$av</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent ID</td><td class='val'>$aid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Tenant ID</td><td class='val'>$tid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Company ID</td><td class='val'>$cid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Type</td><td class='val'>$aty</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>PODID</td><td class='val'>$pod</td></tr>")
    $null=$html.AppendLine('</table>')
    if ($src) { $null=$html.AppendLine("<div class='src'>Parsed from: $src</div>") }
    $null=$html.AppendLine('</div>')
  }

  # ---- Per-file analysis sections ----
  $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in '.log','.txt','.json' }

  foreach($tf in $textFiles){
    Write-Info ("Analyzing " + $tf.FullName)
    $res=Analyze-File -FilePath $tf.FullName
    if ($null -eq $res) { continue }
    $fname=Split-Path $tf.FullName -Leaf

    $null=$html.AppendLine("<details><summary>"+(HtmlEscape $fname)+" - "+$res.Total+" lines<span class=""badge"">Recent window anchored to last timestamp</span></summary>")

    $wStart = $res.RecentWindow.Start.ToString('yyyy-MM-dd HH:mm:ss')
    $wEnd   = $res.RecentWindow.End.ToString('yyyy-MM-dd HH:mm:ss')
    $null=$html.AppendLine('<div class="kicker">')
    $null=$html.AppendLine('<h3>Last '+$RecentWindowMinutes+' minutes only</h3>')
    $null=$html.AppendLine('<div class="small">Window: '+ (HtmlEscape $wStart) +' &rarr; '+ (HtmlEscape $wEnd) +' (anchored to last timestamp in this file)</div>')
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count (recent)</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.RecentCounts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')
    $maxRecent = [Math]::Min(25, $res.RecentSnippets.Count)
    if ($maxRecent -gt 0) {
      for ($ri=0; $ri -lt $maxRecent; $ri++) { $null=$html.AppendLine("<pre>"+ (HtmlEscape $res.RecentSnippets[$ri]) +"</pre>") }
      if ($res.RecentSnippets.Count -gt $maxRecent) { $null=$html.AppendLine('<div class="small">...'+($res.RecentSnippets.Count - $maxRecent)+' more recent matches omitted for brevity.</div>') }
    } else {
      $null=$html.AppendLine('<div class="small">No severity matches within the recent window.</div>')
    }
    $null=$html.AppendLine('</div>')

    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.Counts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')

    $ordered=$res.Patterns.GetEnumerator()|Sort-Object Value -Descending
    foreach($entry in $ordered){
      $pat=(HtmlEscape $entry.Key); $cnt=$entry.Value
      $null=$html.AppendLine('<details><summary>'+ $pat +' - <span class="small">'+$cnt+' occurrence(s)</span></summary>')
      $idx=1
      if ($res.Contexts.ContainsKey($entry.Key)) {
        foreach($ctx in $res.Contexts[$entry.Key]){ $null=$html.AppendLine("<h4>Example "+$idx+"</h4><pre>"+(HtmlEscape $ctx)+"</pre>"); $idx++ }
      }
      $null=$html.AppendLine('</details>')
    }
    $null=$html.AppendLine('</details>')

    $csvPath=Join-Path $collectDir ($fname+'_ErrorSummary.csv')
    $res.Patterns.GetEnumerator()|Sort-Object Value -Descending|
      Select-Object @{n='Pattern';e={$_.Key}},@{n='Count';e={$_.Value}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath

    $csvRecent = Join-Path $collectDir ($fname+'_Recent_'+$RecentWindowMinutes+'min_anchored.csv')
    [pscustomobject]@($res.RecentCounts) |
      Select-Object @{n='ERROR';e={$_.ERROR}},
                    @{n='FATAL';e={$_.FATAL}},
                    @{n='EXCEPTION';e={$_.EXCEPTION}},
                    @{n='WARN';e={$_.WARN}},
                    @{n='WARNING';e={$_.WARNING}},
                    @{n='FAIL';e={$_.FAIL}},
                    @{n='TIMEOUT';e={$_.TIMEOUT}},
                    @{n='UNAUTHORIZED';e={$_.UNAUTHORIZED}},
                    @{n='ACCESSDENIED';e={$_.ACCESSDENIED}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvRecent
  }

  $null=$html.AppendLine('</body></html>')
  $htmlPath=Join-Path $collectDir 'index.html'
  $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html.ToString())
  [System.IO.File]::WriteAllBytes($htmlPath, $bytes)
  Write-OK ("Wrote HTML report: $htmlPath")
  try{ Start-Process $htmlPath }catch{}
}

# -------- UI (loops back; Q runs launcher) --------
function Start-AgentLogReview {
  while ($true) {
    Clear-Host
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' [1] Scan default agent log folder' -ForegroundColor White
    Write-Host ("     - {0}" -f $DefaultLogsRoot) -ForegroundColor DarkGray
    Write-Host ' [2] Scan another FOLDER' -ForegroundColor White
    Write-Host ' [Q] Quit to Toolbox Launcher' -ForegroundColor White
    Write-Host ''
    $choice=Read-Host 'Select an option (1/2/Q)'

    switch($choice.ToUpper()) {
      '1'{
        Collect-And-Report -Roots @($DefaultLogsRoot)
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
        continue
      }
      '2'{
        $folder = Read-Host ("Enter folder to scan (Enter for default: {0})" -f $DefaultLogsRoot)
        if ([string]::IsNullOrWhiteSpace($folder)) { $folder = $DefaultLogsRoot }
        $folder = Normalize-PathInput -Raw $folder
        if (Test-Path -LiteralPath $folder -PathType Container) {
          Collect-And-Report -Roots @($folder)
        } else {
          Write-Warn ("Folder not found: {0}" -f $folder)
        }
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
        continue
      }
      'Q'{
        if (Test-Path -LiteralPath $LauncherPath) {
          Write-Info ("Launching: {0}" -f $LauncherPath)
          & $LauncherPath
        } else {
          Write-Warn ("Launcher not found: {0}" -f $LauncherPath)
        }
        return
      }
      Default{
        Write-Warn 'Invalid choice.'
        Start-Sleep -Milliseconds 900
        continue
      }
    }
  }
}

Start-AgentLogReview
