# =========================
# Functions-Common.ps1  (R7.4 - PS 5.1 safe)
# - All ZIPs -> C:\CS-Toolbox-TEMP\ZIP
# - Zip-Results: quiesce services, stage-copy logs, zip logs + published_data, optional summary
# - Email-Results: can reuse Zip-Results output to avoid re-zipping; prints summary only if needed
# =========================

# --- Globals / Paths ---
$global:CS_TempRoot    = 'C:\CS-Toolbox-TEMP'
$global:CS_ExportRoot  = Join-Path $global:CS_TempRoot 'Collected-Info'
$global:CS_ZipRoot     = Join-Path $global:CS_TempRoot 'ZIP'
$global:CS_SupportMail = 'support@connectsecure.com'
$global:CS_CommonTag   = 'Common-2025-08-15 R7.4'

# Known agent paths / services
$script:AgentLogsPath          = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$script:AgentPublishedDataPath = 'C:\Program Files (x86)\CyberCNSAgent\results_data\published_data'
$script:SvcAgentName           = 'CyberCNSAgent'
$script:SvcMonitorName         = 'CyberCNSAgentMonitor'
$script:LogsStagingPath        = Join-Path $global:CS_TempRoot '_AgentLogs_Staging'

# --- Load zip assembly ---
try { Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction Stop } catch {}

# --- Helpers: logging, pause, sizes ---
function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO',
        [string]$LogFile = $(Join-Path $global:CS_ExportRoot ('Toolbox_Log_{0:yyyyMMdd_HHmmss}.txt' -f (Get-Date)))
    )
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message
    Write-Host $line
    try {
        $parent = Split-Path -Parent $LogFile
        if ($parent -and -not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent | Out-Null }
        Add-Content -Path $LogFile -Value $line -Encoding UTF8
    } catch {}
}

function Write-Utf8NoBom { param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Content)
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Pause-Script { param([string]$Message = 'Press ENTER to continue...')
    Write-Host $Message -ForegroundColor Yellow
    try { $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown') } catch { Read-Host | Out-Null }
}

function Format-SizeKB { param([double]$KB)
    if ($KB -ge 1024) { '{0:N1} MB' -f ($KB/1024.0) } else { '{0:N1} KB' -f $KB }
}

# --- Header banner (PS 5.1 safe) ---
function Show-Header {
    param([Parameter(Mandatory=$true)][string]$Title)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $adminStr = if ($isAdmin) { 'True' } else { 'False' }
    Write-Host ''
    Write-Host ('   {0}' -f $Title)
    Write-Host '========================================================='
    Write-Host (' Host: {0}   User: {1}   Admin: {2}   Common: {3}' -f $env:COMPUTERNAME,$env:USERNAME,$adminStr,$global:CS_CommonTag)
    Write-Host ''
}

# --- Ensure export + zip folders ---
function Ensure-ExportFolder {
    if (-not (Test-Path $global:CS_TempRoot))   { New-Item -ItemType Directory -Path $global:CS_TempRoot -Force | Out-Null }
    if (-not (Test-Path $global:CS_ExportRoot)) { New-Item -ItemType Directory -Path $global:CS_ExportRoot -Force | Out-Null }
    if (-not (Test-Path $global:CS_ZipRoot))    { New-Item -ItemType Directory -Path $global:CS_ZipRoot -Force | Out-Null }
}

# --- Session summary ---
function Write-SessionSummary {
    param(
        [string]$SummaryPath = $(Join-Path $global:CS_ExportRoot ('SessionSummary_{0:yyyyMMdd_HHmmss}.txt' -f (Get-Date))),
        [hashtable]$Facts
    )
    try {
        $lines = @(
            'ConnectSecure Toolbox Session Summary',
            '====================================',
            ('Date: {0:yyyy-MM-dd HH:mm:ss}' -f (Get-Date)),
            ('Host: {0}' -f $env:COMPUTERNAME),
            ('User: {0}' -f $env:USERNAME),
            ('Common: {0}' -f $global:CS_CommonTag)
        )
        if ($Facts) {
            $lines += ''
            $lines += 'Details:'
            foreach ($k in $Facts.Keys) { $lines += (' - {0}: {1}' -f $k, $Facts[$k]) }
        }
        Write-Utf8NoBom -Path $SummaryPath -Content ($lines -join [Environment]::NewLine)
        Write-Host ('[INFO] Session summary written: {0}' -f $SummaryPath)
    } catch {
        Write-Host ('[WARN] Failed to write session summary: {0}' -f $_.Exception.Message) -ForegroundColor Yellow
    }
}

# --- File stats helper ---
function Get-DirectoryStats {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path $Path)) { return [pscustomobject]@{Files=0; KB=0} }
    $files = Get-ChildItem -LiteralPath $Path -Recurse -File -Force -ErrorAction SilentlyContinue
    $kb = [math]::Round(($files | Measure-Object -Property Length -Sum).Sum / 1KB, 2)
    [pscustomobject]@{Files=$files.Count; KB=$kb}
}

# --- Zipping helpers ---
function New-Zip {
    param([Parameter(Mandatory=$true)][string]$SourcePath,[Parameter(Mandatory=$true)][string]$BaseName,[switch]$Quiet)
    Ensure-ExportFolder
    if (-not (Test-Path $SourcePath)) { if (-not $Quiet) { Write-Host "[INFO] Source missing, skip: $SourcePath" }; return $null }
    $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
    $name = '{0}_{1}.zip' -f $BaseName, $ts
    $zip  = Join-Path $global:CS_ZipRoot $name
    try {
        if (Test-Path $zip) { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue }
        [System.IO.Compression.ZipFile]::CreateFromDirectory($SourcePath, $zip)
        if (-not $Quiet) {
            $stats = Get-DirectoryStats -Path $SourcePath
            Write-Host ('[OK]  Zipped {0} -> {1} (Files: {2}, Size: {3})' -f $SourcePath,$zip,$stats.Files,(Format-SizeKB $stats.KB)) -ForegroundColor Green
        }
        return $zip
    } catch {
        if (-not $Quiet) { Write-Host ('[ERROR] Failed to zip {0}: {1}' -f $SourcePath, $_.Exception.Message) -ForegroundColor Red }
        return $null
    }
}

# --- Service control ---
function Stop-ServiceAndWait {
    param([Parameter(Mandatory=$true)][string]$Name,[int]$TimeoutSec=25,[switch]$Quiet)
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { return $false }
    $wasRunning = $svc.Status -eq 'Running'
    if ($svc.Status -ne 'Stopped') {
        try { if (-not $Quiet) { Write-Host "[INFO] Stopping service: $Name" } ; Stop-Service -Name $Name -Force -ErrorAction SilentlyContinue } catch {}
        $sw = [Diagnostics.Stopwatch]::StartNew()
        do {
            $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
            if ($svc -and $svc.Status -eq 'Stopped') { break }
            Start-Sleep -Milliseconds 400
        } while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec)
        if ($svc -and $svc.Status -ne 'Stopped' -and -not $Quiet) { Write-Host "[WARN] Service did not stop within $TimeoutSec s: $Name" -ForegroundColor Yellow }
    }
    return $wasRunning
}

function Start-ServiceAndWait {
    param([Parameter(Mandatory=$true)][string]$Name,[int]$TimeoutSec=25,[switch]$Quiet)
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { return }
    try { if (-not $Quiet) { Write-Host "[INFO] Starting service: $Name" } ; Start-Service -Name $Name -ErrorAction SilentlyContinue } catch {}
    $sw = [Diagnostics.Stopwatch]::StartNew()
    do {
        $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq 'Running') { break }
        Start-Sleep -Milliseconds 400
    } while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec)
    if ($svc -and $svc.Status -ne 'Running' -and -not $Quiet) { Write-Host "[WARN] Service did not start within $TimeoutSec s: $Name" -ForegroundColor Yellow }
}

function Enter-AgentQuiesce { param([switch]$Quiet)
    $state = @{ AgentWasRunning=$false; MonitorWasRunning=$false }
    if (Test-Path $script:AgentLogsPath) {
        $state.AgentWasRunning   = Stop-ServiceAndWait -Name $script:SvcAgentName   -TimeoutSec 25 -Quiet:$Quiet
        $state.MonitorWasRunning = Stop-ServiceAndWait -Name $script:SvcMonitorName -TimeoutSec 25 -Quiet:$Quiet
        Start-Sleep -Seconds 2
    }
    return $state
}

function Exit-AgentQuiesce { param([Parameter(Mandatory=$true)][hashtable]$State,[switch]$Quiet)
    if ($State.AgentWasRunning)   { Start-ServiceAndWait -Name $script:SvcAgentName   -TimeoutSec 25 -Quiet:$Quiet }
    if ($State.MonitorWasRunning) { Start-ServiceAndWait -Name $script:SvcMonitorName -TimeoutSec 25 -Quiet:$Quiet }
}

# Robust folder copy (0–7 exit codes = success)
function Copy-FolderRobust { param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Dest,[switch]$Quiet)
    if (Test-Path $Dest) { Remove-Item -LiteralPath $Dest -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    $args = @($Source,$Dest,"/E","/COPY:DAT","/R:2","/W:1","/NFL","/NDL","/NP")
    $null = & robocopy @args
    $code = $LASTEXITCODE
    if ($code -le 7) { return $true } else { if (-not $Quiet) { Write-Host "[WARN] robocopy exit code $code while copying $Source" -ForegroundColor Yellow }; return $false }
}

# Find a recent ZIP (avoid regenerating CI if launcher already created one)
function Get-RecentZip { param([Parameter(Mandatory=$true)][string]$Prefix,[int]$MaxAgeMinutes=10)
    if (-not (Test-Path $global:CS_ZipRoot)) { return $null }
    $files = Get-ChildItem -Path $global:CS_ZipRoot -Filter ($Prefix + '*.zip') -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    if ($files -and ((New-TimeSpan -Start $files[0].LastWriteTime -End (Get-Date)).TotalMinutes -le $MaxAgeMinutes)) { $files[0].FullName } else { $null }
}

# Human-friendly description per archive
function DescribeZip { param([Parameter(Mandatory=$true)][string]$ZipPath)
    $name = Split-Path -Leaf $ZipPath
    if ($name -like 'Collected-Info_*')           { 'Toolbox exports (CSV/JSON, reports, summaries)' }
    elseif ($name -like 'Agent-Logs_*')           { 'CyberCNS Agent & Monitor logs' }
    elseif ($name -like 'Agent-PublishedData_*')  { 'Published data payloads (inventory/scan JSON)' }
    else                                          { 'Misc toolbox archive' }
}

function Show-ZipSummary { param([string[]]$ZipPaths)
    Write-Host ''
    Write-Host ("All files are saved to: {0}" -f $global:CS_ZipRoot) -ForegroundColor White
    foreach ($z in $ZipPaths) { if ($z -and (Test-Path $z)) { Write-Host (' - {0} — {1}' -f (Split-Path -Leaf $z),(DescribeZip -ZipPath $z)) } }
    Write-Host ''
}

# Simple wrapper
function Zip-CollectedInfo { param([switch]$Quiet) New-Zip -SourcePath $global:CS_ExportRoot -BaseName 'Collected-Info' -Quiet:$Quiet }

# --- CORE: Zip-Results (back-compat for launcher) ---
function Zip-Results {
    param([switch]$Quiet,[switch]$QuiesceAgentDuringZip,[switch]$ShowSummary)

    Ensure-ExportFolder
    $results = @{
        CollectedInfoZip = $null
        AgentLogsZip     = $null
        AgentDataZip     = $null
        AllZips          = @()
    }

    # Reuse recent CI zip if present; else create it
    $ciZip = Get-RecentZip -Prefix 'Collected-Info_' -MaxAgeMinutes 10
    if (-not $ciZip) { $ciZip = Zip-CollectedInfo -Quiet:$Quiet }
    if ($ciZip) { $results.CollectedInfoZip = $ciZip; $results.AllZips += $ciZip }

    $state = $null
    if ($QuiesceAgentDuringZip) { if (-not $Quiet) { Write-Host '[INFO] Temporarily stopping CyberCNS services for log capture...' } ; $state = Enter-AgentQuiesce -Quiet:$Quiet }

    try {
        if (Test-Path $script:AgentLogsPath) {
            $copied = Copy-FolderRobust -Source $script:AgentLogsPath -Dest $script:LogsStagingPath -Quiet:$Quiet
            if ($copied -and (Test-Path $script:LogsStagingPath)) {
                $logsZip = New-Zip -SourcePath $script:LogsStagingPath -BaseName 'Agent-Logs' -Quiet:$Quiet
            } else {
                if (-not $Quiet) { Write-Host '[WARN] Could not stage-copy agent logs; attempting direct zip...' -ForegroundColor Yellow }
                $logsZip = New-Zip -SourcePath $script:AgentLogsPath -BaseName 'Agent-Logs' -Quiet:$Quiet
            }
            if ($logsZip) { $results.AgentLogsZip = $logsZip; $results.AllZips += $logsZip }

            if (Test-Path $script:AgentPublishedDataPath) {
                $dataZip = New-Zip -SourcePath $script:AgentPublishedDataPath -BaseName 'Agent-PublishedData' -Quiet:$true
                if ($dataZip) { $results.AgentDataZip = $dataZip; $results.AllZips += $dataZip }
            }
        } elseif (-not $Quiet) {
            Write-Host "[INFO] Agent logs not found: $script:AgentLogsPath"
        }
    }
    finally {
        if ($QuiesceAgentDuringZip) { if (-not $Quiet) { Write-Host '[INFO] Restarting CyberCNS services...' } ; Exit-AgentQuiesce -State $state -Quiet:$Quiet }
        if (Test-Path $script:LogsStagingPath) { Remove-Item -LiteralPath $script:LogsStagingPath -Recurse -Force -ErrorAction SilentlyContinue }
    }

    if ($ShowSummary) { Show-ZipSummary -ZipPaths $results.AllZips }
    return $results
}

# --- Email compose helpers (Outlook-first, safe fallbacks) ---
function Start-OutlookCompose {
    param(
        [Parameter(Mandatory=$true)][string]$Subject,
        [Parameter(Mandatory=$true)][string]$To,
        [string]$Cc,
        [Parameter(Mandatory=$true)][string]$Body,
        [string[]]$Attachments
    )
    try {
        $ol = New-Object -ComObject Outlook.Application -ErrorAction Stop
        $mail = $ol.CreateItem(0)
        $mail.Subject = $Subject
        $mail.To = $To
        if ($Cc) { $mail.CC = $Cc }
        $mail.Body = $Body
        if ($Attachments) { foreach ($a in $Attachments) { if ($a -and (Test-Path $a)) { $mail.Attachments.Add($a) | Out-Null } } }
        $mail.Display($true) | Out-Null
        return $true
    } catch {
        try {
            if ($Attachments -and (Test-Path $Attachments[0])) {
                Start-Process -FilePath 'OUTLOOK.EXE' -ArgumentList ('/c ipm.note /a "{0}"' -f $Attachments[0]) | Out-Null
                Start-Sleep -Seconds 1
            } else {
                Start-Process -FilePath 'OUTLOOK.EXE' -ArgumentList '/c ipm.note' | Out-Null
            }
            return $true
        } catch {
            $mailto = 'mailto:{0}?subject={1}' -f ($To), [uri]::EscapeDataString($Subject)
            Start-Process $mailto | Out-Null
            if ($Attachments) { foreach ($a in $Attachments) { if ($a -and (Test-Path $a)) { Start-Process 'explorer.exe' -ArgumentList ('/select,"{0}"' -f $a) | Out-Null } } }
            return $false
        }
    }
}

function Email-Results {
    param(
        [string]$Company,
        [string]$Tenant,
        [string]$Ticket,
        [string]$To = $global:CS_SupportMail,
        [string]$Cc,
        [hashtable]$ZipInfo,
        [switch]$SkipSummary
    )
    Ensure-ExportFolder

    if (-not $ZipInfo) {
        # Build zips and show on-screen list here
        $ZipInfo = Zip-Results -Quiet:$false -QuiesceAgentDuringZip -ShowSummary
    } elseif (-not $SkipSummary) {
        # Caller prebuilt zips; still show on-screen list before email
        Show-ZipSummary -ZipPaths $ZipInfo.AllZips
    }

    # Subject/body
    $companyText = if ([string]::IsNullOrWhiteSpace($Company)) { 'Company' } else { $Company }
    $tenantText  = if ([string]::IsNullOrWhiteSpace($Tenant))  { 'Tenant'  } else { $Tenant }
    $ticketText  = if ([string]::IsNullOrWhiteSpace($Ticket))  { 'Ticket'  } else { $Ticket }
    $subject = '{0} | {1} | {2} | CS Toolbox Files' -f $companyText, $tenantText, $ticketText

    $ciStats   = Get-DirectoryStats -Path $global:CS_ExportRoot
    $logsStats = Get-DirectoryStats -Path $script:AgentLogsPath
    $dataStats = Get-DirectoryStats -Path $script:AgentPublishedDataPath

    $bodyLines = @()
    $bodyLines += 'CS Toolbox Results Summary'
    $bodyLines += '=========================='
    $bodyLines += ('Host: {0}    User: {1}' -f $env:COMPUTERNAME, $env:USERNAME)
    $bodyLines += ('Date: {0:yyyy-MM-dd HH:mm:ss}' -f (Get-Date))
    $bodyLines += ''
    $bodyLines += ('Collected-Info: {0} files, {1}' -f $ciStats.Files, (Format-SizeKB $ciStats.KB))
    $bodyLines += ('Agent Logs:     {0} files, {1}' -f $logsStats.Files, (Format-SizeKB $logsStats.KB))
    $bodyLines += ('Published Data:  {0} files, {1}' -f $dataStats.Files, (Format-SizeKB $dataStats.KB))
    $bodyLines += ''
    $bodyLines += 'Attached ZIP files (saved under C:\CS-Toolbox-TEMP\ZIP):'
    foreach ($z in $ZipInfo.AllZips) { $bodyLines += (' - {0} — {1}' -f (Split-Path -Leaf $z), (DescribeZip -ZipPath $z)) }

    $ok = Start-OutlookCompose -Subject $subject -To $To -Cc $Cc -Body ($bodyLines -join [Environment]::NewLine) -Attachments $ZipInfo.AllZips
    if ($ok) { Write-Host '[OK]  Email compose opened.' -ForegroundColor Green } else { Write-Host '[WARN] Email compose fallback used. Check Explorer windows for attachments.' -ForegroundColor Yellow }
    return $ZipInfo
}

# --- Final cleanup and exit ---
function Invoke-FinalCleanupAndExit {
    try {
        $tempRoot = $global:CS_TempRoot
        $cleanupScriptName = 'Toolbox-Cleanup-SelfDestruct.ps1'
        $src = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) $cleanupScriptName
        $dst = Join-Path $tempRoot $cleanupScriptName
        if (Test-Path $src) {
            Copy-Item -LiteralPath $src -Destination $dst -Force
        } else {
            $cleanup = @'
param([string]$Target='C:\CS-Toolbox-TEMP')
Start-Sleep -Seconds 5
try { $procs = Get-Process | Where-Object { $_.Path -and $_.Path -like "$Target*" }; foreach ($p in $procs) { try { $p.Kill(); $p.WaitForExit(3000) } catch {} } } catch {}
try { Remove-Item -LiteralPath $Target -Recurse -Force -ErrorAction SilentlyContinue } catch {}
'@
            Write-Utf8NoBom -Path $dst -Content $cleanup
        }
        Write-Host 'Cleanup will run in a new elevated window in 5 seconds...'
        Start-Sleep -Seconds 5
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}" -Target "{1}"' -f $dst, $tempRoot)
    } catch {
        Write-Host ('[WARN] Cleanup launcher failed: {0}' -f $_.Exception.Message) -ForegroundColor Yellow
    }
    exit
}

# --- Tool launcher ---
function Launch-Tool {
    param([Parameter(Mandatory=$true)][string]$ScriptName)
    $root = $global:CSLauncherRoot
    if (-not $root -or [string]::IsNullOrWhiteSpace($root)) { $root = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $path = Join-Path $root $ScriptName
    if (Test-Path $path) { & $path } else { Write-Host ('ERROR launching {0}: Not found.' -f $ScriptName) -ForegroundColor Red }
}

# --- VC++ Runtime validation (lightweight) ---
function Run-VcppValidation {
    param([string]$ExportFolder = (Join-Path $global:CS_ExportRoot 'VCpp'),[switch]$Quiet)
    Ensure-ExportFolder
    if (-not (Test-Path $ExportFolder)) { New-Item -ItemType Directory -Path $ExportFolder -Force | Out-Null }
    $paths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $items = foreach ($p in $paths) {
        Get-ItemProperty -Path $p -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -like 'Microsoft Visual C++*' -or $_.DisplayName -like 'Visual C++*'
        } | Select-Object @{n='DisplayName';e={$_.DisplayName}},
                           @{n='DisplayVersion';e={$_.DisplayVersion}},
                           @{n='Publisher';e={$_.Publisher}},
                           @{n='InstallDate';e={$_.InstallDate}},
                           @{n='UninstallString';e={$_.UninstallString}},
                           @{n='Arch';e={ if ($p -like '*WOW6432Node*') { 'x86' } else { 'x64' } }}
    }
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv = Join-Path $ExportFolder ('VCpp-Runtimes_{0}.csv' -f $ts)
    try {
        $items | Sort-Object DisplayName, DisplayVersion | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        if (-not $Quiet) { Write-Host ('[OK]  VC++ runtime report: {0} item(s). Saved to {1}' -f ($items.Count), $csv) -ForegroundColor Green }
    } catch {
        if (-not $Quiet) { Write-Host ('[ERROR] Failed to write VC++ report: {0}' -f $_.Exception.Message) -ForegroundColor Red }
    }
    ,$items
}

# --- OSQuery helper (basic) ---
function Invoke-OSQuery {
    param([Parameter(Mandatory=$true)][string]$Sql,[string]$OsqueryPath,[switch]$ReturnRawJson)
    $pathsToTry = @($OsqueryPath,'C:\Program Files\osquery\osqueryi.exe','C:\Program Files (x86)\osquery\osqueryi.exe') | Where-Object { $_ -and (Test-Path $_) }
    if (-not $pathsToTry) { Write-Host '[ERROR] osqueryi.exe not found.' -ForegroundColor Red; return $null }
    $exe = $pathsToTry[0]
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = '--json "{0}"' -f $Sql.Replace('"','\"')
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()
    $out = $p.StandardOutput.ReadToEnd()
    $err = $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    if ($p.ExitCode -ne 0 -and $err) { Write-Host ('[WARN] osquery error: {0}' -f $err.Trim()) -ForegroundColor Yellow }
    if ($ReturnRawJson) { return $out }
    try { $out | ConvertFrom-Json } catch { $null }
}

# --- Legacy alias ---
Set-Alias EnsureExportFolder Ensure-ExportFolder -Force | Out-Null
