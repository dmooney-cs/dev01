# CS-Toolbox-Launcher.ps1 (strict-mode safe)
# -----------------------------------------------------------------------------
# Ensures globals without referencing undefined variables (works with StrictMode).
# Dot-sources Functions-Common.ps1, unblocks tree, renders menu, runs tools.
# -----------------------------------------------------------------------------

# ===== Minimal Bootstrap (StrictMode-safe) =====
$script:LauncherRoot = Split-Path -Parent $PSCommandPath

# Guarded setters that won't read undefined vars
if (-not (Get-Variable -Name CSLauncherRoot -Scope Global -ErrorAction SilentlyContinue)) {
    Set-Variable -Name CSLauncherRoot -Scope Global -Value $script:LauncherRoot -Force
}
if (-not (Get-Variable -Name CS_TempRoot -Scope Global -ErrorAction SilentlyContinue)) {
    Set-Variable -Name CS_TempRoot -Scope Global -Value (Join-Path $env:SystemDrive 'CS-Toolbox-TEMP') -Force
}

$CommonPath = Join-Path $script:LauncherRoot 'Functions-Common.ps1'
if (Test-Path -LiteralPath $CommonPath) {
    try { Unblock-File -LiteralPath $CommonPath -ErrorAction SilentlyContinue } catch {}
    . $CommonPath
} else {
    # Lightweight fallbacks so the launcher can render even without the common file
    function Ensure-ExportFolder { param([string]$Path) if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null } (Resolve-Path $Path).Path }
    function Show-Header { param([string]$Title) $line = '=' * 52; Write-Host ""; Write-Host " $Title"; Write-Host $line }
    function Run-ToolSameWindow { param([string]$Path,[string]$Title=$(Split-Path -Leaf $Path)) if (-not (Test-Path $Path)) { Write-Host "[ERROR] Not found: $Path"; return } try { Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue } catch {}; . $Path }
    function Return-To-Launcher { . $PSCommandPath }
    function Preflight-Unblock { param([string]$Root=$(Split-Path -Parent $PSCommandPath)) Get-ChildItem -LiteralPath $Root -Recurse -File -EA SilentlyContinue | % { try { Unblock-File -LiteralPath $_.FullName -EA SilentlyContinue } catch {} } }
}

# Unblock the toolbox tree once at startup to prevent prompts
Preflight-Unblock -Root $script:LauncherRoot

# Paths to tools
$ToolDir = $script:LauncherRoot
$Tools = @{
  "1" = @{ Path = Join-Path $ToolDir 'Osquery-Data-Collection.ps1' ; Title = 'OSQuery Data Collection' }
  "2" = @{ Path = Join-Path $ToolDir 'Nmap-Data-Collection.ps1'    ; Title = 'Nmap Data Collection' }
  "3" = @{ Path = Join-Path $ToolDir 'Secondary-Validation-Tools.ps1'; Title= 'Secondary Validation Tools' }
  "4" = @{ Path = Join-Path $ToolDir 'Windows-Modern-App-Discovery.ps1'; Title= 'Windows Modern App Discovery' }
  "5" = @{ Path = Join-Path $ToolDir 'Active-Directory-Tools.ps1'  ; Title = 'Active Directory Tools' }
  "6" = @{ Path = Join-Path $ToolDir 'SystemInfo-A.ps1'            ; Title = 'System Info A' }
  "7" = @{ Path = Join-Path $ToolDir 'SystemInfo-B.ps1'            ; Title = 'System Info B' }
  "8" = @{ Path = Join-Path $ToolDir 'Machine-Utilities.ps1'       ; Title = 'Machine Utilities' }
  "9" = @{ Path = Join-Path $ToolDir 'Agent-Menu-Tool.ps1'         ; Title = 'Agent Action Menu' }
  "Z" = @{ Path = Join-Path $ToolDir 'zip-encrypt-htmltemplate.ps1'; Title = 'Zip + Encrypt + Compose Helper' }
  "C" = @{ Path = Join-Path $ToolDir 'Toolbox-Cleanup-SelfDestruct.ps1'; Title = 'Cleanup & Self-Destruct' }
}

function Show-MainMenu {
    Clear-Host
    Show-Header "ConnectSecure Technicians Toolbox"

    Write-Host ""
    Write-Host " [1] OSQuery Data Collection      - Apps, Browser Ext, Windows Update Audit"
    Write-Host " [2] Nmap Data Collection         - Network Detection & CIDR Scan of Local Host/Network"
    Write-Host " [3] Secondary Validation Tools   - WMI Patch Audit, TLS/SSL, VC++ Runtimes"
    Write-Host "                                  - Registry Search, Log Analysis, Dependency Check"
    Write-Host "                                  - Roaming/Stale User App Sweep"
    Write-Host " [4] Windows Modern App Discovery - Enumerate & Search Modern/Store Apps"
    Write-Host " [5] Active Directory Tools       - Users, Groups, OUs, GPOs"
    Write-Host " [6] System Info A                - Firewall, Defender, SMART Disk Audit"
    Write-Host " [7] System Info B                - Pending Reboot, Log Capture, Startup Services"
    Write-Host " [8] Machine Utilities            - Running Services and Disk Space"
    Write-Host " [9] Agent Action Menu            - Install, Reinstall, Update, or Uninstall"
    Write-Host ""
    Write-Host " [Z] Zip + Encrypt + Compose Helper (HTML template)"
    Write-Host " [C] Cleanup & Self-Destruct (launches in new window, then closes this one)"
    Write-Host ""
}

# Main loop
while ($true) {
    Show-MainMenu
    $choice = Read-Host "Select an option"
    if ([string]::IsNullOrWhiteSpace($choice)) { continue }
    $key = $choice.Trim().ToUpper()

    if ($key -eq "Q") { break }

    if ($key -eq "C") {
        $tool = $Tools[$key]
        if ($tool) {
            Start-Process powershell.exe -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$($tool.Path)`"")
            break
        } else { Write-Host "[ERROR] Tool not found for key: C" }
        continue
    }

    if ($Tools.ContainsKey($key)) {
        $tool = $Tools[$key]
        try {
            Run-ToolSameWindow -Path $tool.Path -Title $tool.Title
        } catch {
            Write-Host ""
            Write-Host "=== ERROR launching $($tool.Title) ===" -ForegroundColor Red
            Write-Host $_.Exception.Message
            if ($_.ScriptStackTrace) { Write-Host "`nStack:`n$($_.ScriptStackTrace)" }
            Write-Host ""
            Read-Host "Press Enter to return to the menu" | Out-Null
        }
    } else {
        Write-Host "[WARN] Invalid selection."
        Start-Sleep -Milliseconds 900
    }
}
