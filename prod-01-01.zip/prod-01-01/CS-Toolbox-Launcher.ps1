#requires -Version 5.1
<#
  CS-Toolbox-Launcher.ps1  (PS 5.1–safe, resilient)
  - Same-window launches with '&' + try/catch + pause
  - Optional load of Functions-Common.ps1 (non-fatal if missing)
  - Option 9 preflight seeds CS_TempRoot and folders to avoid import errors
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- Local UI helpers (safe even if Functions-Common.ps1 is missing) ----------------
function Show-Header {
    param([string]$Title = "ConnectSecure Toolbox")
    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host (" {0}" -f $Title) -ForegroundColor Yellow
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Pause-Return {
    param([string]$Message = "Press Enter to return to the menu")
    Read-Host $Message | Out-Null
}

# ---------------- Optional: load shared helpers (do not fail the launcher if missing) ----------------
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try {
        $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
        Invoke-Expression $code
    } catch {
        Write-Host ("[WARN] Failed to load Functions-Common.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
} else {
    Write-Host "[INFO] Functions-Common.ps1 not found; using built-in header/pause helpers." -ForegroundColor DarkYellow
}

# ---------------- Paths ----------------
$BASE = 'C:\CS-TOOLBOX-TEMP\prod-01-01'
$PathMap = [ordered]@{
    '1' = (Join-Path $BASE 'Osquery-Data-Collection.ps1')
    '2' = (Join-Path $BASE 'Nmap-Data-Collection.ps1')
    '3' = (Join-Path $BASE 'Secondary-Validation-Tools.ps1')           # Patch, TLS, VC++, Uninstall, Logs
    '4' = (Join-Path $BASE 'Windows-Modern-App-Discovery.ps1')
    '5' = (Join-Path $BASE 'ValidationTool-AD.ps1')
    '6' = (Join-Path $BASE 'SystemInfo-A.ps1')
    '7' = (Join-Path $BASE 'SystemInfo-B.ps1')
    '8' = (Join-Path $BASE 'Tools-Utilities.ps1')

    # Option 9: OneDrive copy per your request
    '9' = (Join-Path $BASE 'Agent-Menu-Tool.ps1')

    'Z' = (Join-Path $BASE 'zip-encrypt-htmltemplate.ps1')
    'C' = (Join-Path $BASE 'Toolbox-Cleanup-SelfDestruct.ps1')
}

# ---------------- Utility: ensure directory exists ----------------
function Ensure-Dir {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    (Resolve-Path -LiteralPath $Path).Path
}

# ---------------- Option-9 preflight: StrictMode-safe seeding of globals ----------------
function Seed-CommonGlobals-ForAgent {
    # Safely read global var even under StrictMode
    $crt = $null
    try {
        $v = Get-Variable -Name 'CS_TempRoot' -Scope Global -ErrorAction Stop
        $crt = $v.Value
    } catch {
        $crt = $null
    }

    if ([string]::IsNullOrWhiteSpace([string]$crt)) {
        $crt = 'C:\CS-Toolbox-TEMP'
        Set-Variable -Name 'CS_TempRoot' -Scope Global -Value $crt -Force
    }

    if ([string]::IsNullOrWhiteSpace([string]$env:CS_TempRoot)) {
        $env:CS_TempRoot = $crt
    }

    # Create expected folder structure ahead of time
    $out = Ensure-Dir -Path $crt
    $null = Ensure-Dir -Path (Join-Path $out 'LOGS')
    $null = Ensure-Dir -Path (Join-Path $out 'Collected-Info')
    $null = Ensure-Dir -Path (Join-Path $out 'Downloads')
}

# ---------------- Single, robust runner (same window) ----------------
function Run-ToolSameWindow {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Title = '',
        [switch]$SeedAgentGlobals  # preflight for agent menu/tools that expect CS_TempRoot
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host ("ERROR: Target script not found: {0}" -f $Path) -ForegroundColor Red
        Pause-Return
        return
    }

    if ($SeedAgentGlobals.IsPresent) {
        Seed-CommonGlobals-ForAgent
    }

    try {
        # Run in the SAME window so errors are visible here
        & $Path
    } catch {
        Write-Host ""
        $displayTitle = $Title
        if (-not $displayTitle -or [string]::IsNullOrWhiteSpace($displayTitle)) {
            $displayTitle = Split-Path $Path -Leaf
        }
        Write-Host ("=== ERROR launching {0} ===" -f $displayTitle) -ForegroundColor Red
        Write-Host ($_.Exception.Message) -ForegroundColor Yellow
        if ($_.ScriptStackTrace) {
            Write-Host ""
            Write-Host "Stack:" -ForegroundColor DarkYellow
            Write-Host ($_.ScriptStackTrace) -ForegroundColor DarkGray
        }
    } finally {
        Pause-Return
    }
}

# ---------------- Cleanup in NEW window, then exit ----------------
function Run-CleanupNewWindow {
    param([Parameter(Mandatory)][string]$SourcePath)

    Write-Host "`n[INFO] Preparing self-destruct cleanup..."
    $candidates = @("C:\Temp", $env:TEMP)
    $dest = $null
    foreach ($t in $candidates) {
        try {
            if (-not (Test-Path -LiteralPath $t)) { New-Item -ItemType Directory -Path $t -Force | Out-Null }
            $candidate = Join-Path $t "Toolbox-Cleanup-SelfDestruct.ps1"
            Copy-Item -Path $SourcePath -Destination $candidate -Force
            $dest = $candidate
            break
        } catch {
            Write-Host ("[WARN] Could not copy to {0} : {1}" -f $t, $_.Exception.Message) -ForegroundColor Yellow
        }
    }
    if (-not $dest) {
        Write-Host "[FATAL] Could not copy script to any temp location. Aborting." -ForegroundColor Red
        Pause-Return
        return
    }
    try { Unblock-File -LiteralPath $dest -ErrorAction SilentlyContinue } catch {}
    Write-Host ("[INFO] Launching cleanup from {0} ..." -f $dest)
    Start-Process -FilePath "powershell.exe" `
        -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$dest`"") `
        -WorkingDirectory (Split-Path $dest -Parent) `
        -Verb RunAs
    Write-Host "[INFO] Exiting launcher..."
    exit
}

# ---------------- Menu UI ----------------
function Write-Menu {
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' [1] OSQuery Data Collection      - Apps, search, browser extensions'
    Write-Host ' [2] Nmap Data Collection         - Local network scan profiles'
    Write-Host ' [3] Secondary Validation Tools   - Patch, TLS, VC++, Uninstall, Logs'
    Write-Host ' [4] Windows Modern App Discovery - Enumerate & search Modern/Store apps'
    Write-Host ' [5] Active Directory Tools       - Users, Groups, OUs, GPOs'
    Write-Host ' [6] System Info A                - Firewall, Defender, Services'
    Write-Host ' [7] System Info B                - Networking, Shares, Schedules'
    Write-Host ' [8] Machine Utilities            - Running Services and Disk Space'
    Write-Host ' [9] Agent Action Menu            - Install, Reinstall, Update, or Uninstall'
    Write-Host ''
    Write-Host ' [Z] Zip + Encrypt + Compose Helper (HTML template)'
    Write-Host ' [C] Cleanup & Self-Destruct (launches in new window, then closes this one)'
    Write-Host ''
}

# ---------------- Main loop ----------------
while ($true) {
    Write-Menu
    $choice = Read-Host 'Select an option'
    if ([string]::IsNullOrWhiteSpace($choice)) { continue }
    $key = $choice.Trim().ToUpperInvariant()

    switch ($key) {
        '1' { Run-ToolSameWindow -Path $PathMap['1'] -Title 'OSQuery Data Collection';                                continue }
        '2' { Run-ToolSameWindow -Path $PathMap['2'] -Title 'Nmap Data Collection';                                   continue }
        '3' { Run-ToolSameWindow -Path $PathMap['3'] -Title 'Secondary Validation Tools';                             continue }
        '4' { Run-ToolSameWindow -Path $PathMap['4'] -Title 'Windows Modern App Discovery';                           continue }
        '5' { Run-ToolSameWindow -Path $PathMap['5'] -Title 'Active Directory Tools';                                 continue }
        '6' { Run-ToolSameWindow -Path $PathMap['6'] -Title 'System Info A';                                          continue }
        '7' { Run-ToolSameWindow -Path $PathMap['7'] -Title 'System Info B';                                          continue }
        '8' { Run-ToolSameWindow -Path $PathMap['8'] -Title 'Machine Utilities';                                      continue }

        # Option 9: seed CS_TempRoot + folders before launching your OneDrive Agent menu
        '9' { Run-ToolSameWindow -Path $PathMap['9'] -Title 'Agent Install, Reinstall, Update, and Uninstall' -SeedAgentGlobals; continue }

        'Z' { Run-ToolSameWindow -Path $PathMap['Z'] -Title 'Zip + Encrypt + Compose Helper (HTML)';                  continue }
        'C' { Run-CleanupNewWindow -SourcePath $PathMap['C'];                                                         continue }
        'Q' { break }
        default {
            Write-Host 'Please choose 1-9, Z, C, or Q.' -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
