<# ========================================================================
  CS-Toolbox-Launcher.ps1  (All-in-One Menu Framework, Colored Header)
  Version: AAMenu-Short-v1.14 (2025-11-24)
  - StrictMode-safe, ASCII only
  - ALL menus and submenus sorted alphabetically by label
  - Agent Actions: Agent Log Review – Single-Agent, Agent Message Correlator – Single-Agent,
                   ConnectSecure Log Correlator – Multi-Agent, Install, Uninstall, Update
  - Network Validation: NMAP + TLS collector
  - Software Validation: App Registry Search, Browser Ext, Stale Profile Scan,
                         Validate Installed Software (Osquery), Windows Store Apps, Windows Update
  - Windows Machine Utilities: AD Validation, Dependency Validation, Machine Utilities, System Info A/B,
                               Windows Application - Cleanup S&D
  - Each option launches an external script (no inline logic)
  - Search root limited to current toolbox folder to avoid stale matches
========================================================================= #>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- Configurable Roots ----------------
if (-not (Get-Variable -Name CS_ToolRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ToolRoot = Split-Path -Parent $PSCommandPath
}
if (-not (Get-Variable -Name CS_TempRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP'
}
if (-not (Get-Variable -Name CS_ScriptSearchRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ScriptSearchRoot = $script:CS_ToolRoot
}

# Mirror key script-scoped roots into globals for child tools that expect them
$global:CS_ToolRoot         = $script:CS_ToolRoot
$global:CS_TempRoot         = $script:CS_TempRoot
$global:CS_ScriptSearchRoot = $script:CS_ScriptSearchRoot
$global:CSLauncherRoot      = $script:CS_ToolRoot   # for Nmap / other tools expecting launcher root

# Global exit flag for the main loop
$script:ExitTool = $false

# ---------------- Hard Script Name References ----------------
$ScriptNames = [ordered]@{
    # Labels
    AgentActions_MenuLabel         = 'ConnectSecure Agent Actions'
    NetworkValidation_MenuLabel    = 'Network Validation'
    PackageLogs_MenuLabel          = 'Package Logs and Collected Information'
    SoftwareValidation_MenuLabel   = 'Software Validation'
    WindowsUtilities_MenuLabel     = 'Windows Machine Utilities'

    # Agent Actions scripts
    Agent_LogReview                = 'Agent-Log-Review.ps1'                                   # Single-Agent
    Agent_MessageCorrelator        = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-msg-Correlator.ps1' # Single-Agent (absolute)
    Agent_LogCorrelator            = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Log-Correlator.ps1' # Multi-Agent (absolute)
    Agent_InstallOrReinstall       = 'Agent-Install-Tool.ps1'
    Agent_Uninstall                = 'Agent-Uninstall-Tool.ps1'
    Agent_Update                   = 'Agent-Update-Tool.ps1'

    # Network Validation
    NetworkValidation              = 'NMAP-Data-Collection.ps1'
    TLS_DataCollection             = 'tls-data-collection.ps1'

    # Software Validation
    Software_AppRegistrySearch     = 'Registry-Search.ps1'              # A
    Software_BrowserExtensions     = 'Browser-Extensions-Details.ps1'   # B
    Software_StaleProfileScan      = 'Windows-UserProfile-AppSweep.ps1' # S
    Software_ValidatedApps         = 'Osquery-Data-Collection.ps1'      # V
    Software_StoreApps             = 'Windows-Modern-App-Discovery.ps1' # W (Store)
    Software_WindowsUpdate         = 'Windows-Update-Details.ps1'       # W (Update)

    # Windows Machine Utilities
    WinUtil_ADValidation           = 'Active-Directory-Tools.ps1'                       # A
    WinUtil_DependencyValidation   = 'Dependency-Validation-Tools.ps1'                  # D
    WinUtil_MachineUtilities       = 'Machine-Utilities.ps1'                            # M
    WinUtil_SystemInfoA            = 'SystemInfo-A.ps1'                                 # S (A)
    WinUtil_SystemInfoB            = 'SystemInfo-B.ps1'                                 # S (B)
    WinUtil_AppCleanup             = 'C:\CS-Toolbox-TEMP\prod-01-01\Application-Cleanup-Script.ps1' # W (Windows App Cleanup S&D)

    # Other
    ExitAndCleanup                 = 'C:\CS-Toolbox-TEMP\prod-01-01\Toolbox-Cleanup-SelfDestruct.ps1'
    PackageLogs                    = 'zip-encrypt-htmltemplate.ps1'
}

# ---------------- Helpers ----------------
function Ensure-ExportFolder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    (Resolve-Path -LiteralPath $Path).Path
}

function Preflight-Unblock {
    param([string]$Root = $script:CS_ToolRoot)
    Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue |
        ForEach-Object { try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {} }
}

function Get-IsAdmin {
    try {
        $id  = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pri = New-Object Security.Principal.WindowsPrincipal($id)
        return $pri.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Show-TopHeader {
    param([string]$SectionTitle = $null)
    Clear-Host
    $line = ('=' * 58)
    $hostName = $env:COMPUTERNAME
    $userName = ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    $isAdmin  = Get-IsAdmin
    $basePath = $script:CS_ToolRoot

    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox  - Launcher v1.14" -ForegroundColor Cyan
    Write-Host " $line" -ForegroundColor DarkGray
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Base: {0}" -f $basePath) -ForegroundColor Gray
    Write-Host " $line" -ForegroundColor DarkGray

    if ($SectionTitle) {
        Write-Host (" {0}" -f $SectionTitle) -ForegroundColor White
        Write-Host ""
    }
}

function Footer-Prompt {
    param([string]$OptionsDisplay)
    Write-Host ""
    Write-Host ("Press ({0}) to make your selection." -f $OptionsDisplay) -ForegroundColor DarkGray
}

function Write-Info     { param([string]$m) Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Write-Warn     { param([string]$m) Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Write-ErrorMsg { param([string]$m) Write-Host "[ERROR] $m" -ForegroundColor Red }

function Resolve-ToolScript {
    param([Parameter(Mandatory)][string]$FileName)
    # If an absolute/rooted path was provided, use it directly
    if ([System.IO.Path]::IsPathRooted($FileName)) {
        if (Test-Path -LiteralPath $FileName) {
            return (Get-Item -LiteralPath $FileName)
        } else {
            Write-Warn ("Absolute path not found: {0}" -f $FileName)
            return $null
        }
    }
    # Otherwise, search under the configured root
    $hit = Get-ChildItem -Path $script:CS_ScriptSearchRoot -Recurse -File -Filter $FileName -ErrorAction SilentlyContinue |
           Select-Object -First 1
    if (-not $hit) {
        $hit = Get-ChildItem -Path $script:CS_ScriptSearchRoot -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -ieq $FileName } | Select-Object -First 1
    }
    if (-not $hit) { Write-Warn ("Could not resolve '{0}' under {1}" -f $FileName, $script:CS_ScriptSearchRoot) }
    return $hit
}

function Launch-Tool {
    param(
        [Parameter(Mandatory)][string]$FileName,
        [string[]]$Args = @(),
        [switch]$PauseAfter
    )

    $scriptFile = Resolve-ToolScript -FileName $FileName
    if (-not $scriptFile) {
        Write-ErrorMsg ("Tool not found: {0}" -f $FileName)
        Write-Host ""
        Read-Host "Press Enter to return to the launcher"
        return
    }

    $hadError = $false

    try {
        Write-Info ("Launching: {0}" -f $scriptFile.FullName)
        try { Unblock-File -LiteralPath $scriptFile.FullName -ErrorAction SilentlyContinue } catch {}
        if ($Args.Count -gt 0) {
            & $scriptFile.FullName @Args
        } else {
            & $scriptFile.FullName
        }
    }
    catch {
        $hadError = $true
        Write-ErrorMsg $_.Exception.Message
        if ($_.ScriptStackTrace) {
            Write-Host "Stack:`n$($_.ScriptStackTrace)"
        }
        Write-Host ""
        Read-Host "Press Enter to return to the launcher"
    }
    finally {
        # Only honor -PauseAfter on *successful* runs to avoid double prompts
        if ($PauseAfter.IsPresent -and -not $hadError) {
            Write-Host ""
            Read-Host "Press Enter to return"
        }
    }
}

# ---------------- Bootstrap ----------------
$null = Ensure-ExportFolder -Path $script:CS_TempRoot
Preflight-Unblock -Root $script:CS_ToolRoot

# ---------------- Menus ----------------
function Invoke-ExitAndCleanup {
    Show-TopHeader -SectionTitle "Exit and Cleanup"
    Write-Host " Launching Toolbox-Cleanup-SelfDestruct in this window..." -ForegroundColor Gray
    Write-Host ""
    Launch-Tool -FileName $ScriptNames.ExitAndCleanup

    Write-Host ""
    Write-Host " Cleanup script has finished (or returned control)." -ForegroundColor Cyan
    [void](Read-Host " Press Enter to exit the toolbox and clear this PowerShell window")
    Clear-Host

    # Signal the main loop to stop
    $script:ExitTool = $true
}

function Show-AgentActionsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.AgentActions_MenuLabel
    Write-Host " You are in: ConnectSecure Agent Actions" -ForegroundColor Yellow
    Write-Host ""

    # Alphabetical-style grouping for Agent tools
    Write-Host " 1) Agent Log Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogReview) -ForegroundColor DarkGray
    Write-Host "    Parses agent logs; shows last 5-minute window anchored to last entry;" -ForegroundColor DarkGray
    Write-Host "    groups common messages and examples; exports HTML." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Agent Message Correlator - Single-Agent" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_MessageCorrelator) -ForegroundColor DarkGray
    Write-Host "    Correlates agent messages for a single device across time windows;" -ForegroundColor DarkGray
    Write-Host "    highlights repeating error patterns, call-home issues, and key status changes;" -ForegroundColor DarkGray
    Write-Host "    exports a focused HTML summary to share with engineering or the customer." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Agent Log Correlator - Multi-Agent" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogCorrelator) -ForegroundColor DarkGray
    Write-Host "    Correlates agent/patch/system logs across multiple folders." -ForegroundColor DarkGray
    Write-Host "    - Groups common messages with total and 'Last 24h' counts per file (anchored to each file's last timestamp)" -ForegroundColor DarkGray
    Write-Host "    - Shows newest and oldest examples for each common error." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Install or Reinstall Agent" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_InstallOrReinstall) -ForegroundColor DarkGray
    Write-Host "    Detects, downloads, installs, and verifies." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Uninstall Agent (with Portal Reminder)" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_Uninstall) -ForegroundColor DarkGray
    Write-Host "    Clean removal; reminds to remove device records in portal if needed." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Update Agent" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_Update) -ForegroundColor DarkGray
    Write-Host "    Triggers agent update via specific updater script." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt -OptionsDisplay '1/2/3/4/5/6/B'
    $in  = Read-Host "Selection"
    switch ($in.Trim().ToUpper()) {
        '1' { Launch-Tool -FileName $ScriptNames.Agent_LogReview }
        '2' { Launch-Tool -FileName $ScriptNames.Agent_MessageCorrelator -PauseAfter }
        '3' { Launch-Tool -FileName $ScriptNames.Agent_LogCorrelator -PauseAfter }
        '4' { Launch-Tool -FileName $ScriptNames.Agent_InstallOrReinstall }
        '5' { Launch-Tool -FileName $ScriptNames.Agent_Uninstall }
        '6' { Launch-Tool -FileName $ScriptNames.Agent_Update -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}

function Show-NetworkValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.NetworkValidation_MenuLabel
    Write-Host " You are in: Network Validation" -ForegroundColor Yellow
    Write-Host ""

    # Alphabetical: Scan..., TLS...
    Write-Host " 1) Scan Networks or Local Machine" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.NetworkValidation) -ForegroundColor DarkGray
    Write-Host "    Run NMAP profiles (Fast / Extended / Deep) for hosts or CIDR; summarize and export." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 2) TLS/SSL Policy (Local Host)" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.TLS_DataCollection) -ForegroundColor DarkGray
    Write-Host "    Collect SCHANNEL protocol policy; show status-first view; export CSV; optional registry view." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt -OptionsDisplay '1/2/B'
    $in  = Read-Host "Selection"
    switch ($in.Trim().ToUpper()) {
        '1' { Launch-Tool -FileName $ScriptNames.NetworkValidation }
        '2' { Launch-Tool -FileName $ScriptNames.TLS_DataCollection -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}

function Show-PackageLogsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.PackageLogs_MenuLabel
    Write-Host " You are in: Package Logs and Collected Information" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Open Packager / Encrypt Helper" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.PackageLogs) -ForegroundColor DarkGray
    Write-Host "    Select sources, zip, encrypt to .csb, and generate HTML helper for handoff." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt -OptionsDisplay '1/B'
    $in = Read-Host "Selection"
    switch ($in.Trim().ToUpper()) {
        '1' { Launch-Tool -FileName $ScriptNames.PackageLogs }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}

function Show-SoftwareValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.SoftwareValidation_MenuLabel
    Write-Host " You are in: Software Validation" -ForegroundColor Yellow
    Write-Host ""

    # Alphabetical: Application Registry Search, Browser Extension Details, Stale Profile..., Validate..., Windows Store..., Windows Update...
    Write-Host " 1) Application Registry Search" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_AppRegistrySearch) -ForegroundColor DarkGray
    Write-Host "    Search Uninstall and related registry keys for target apps; export findings to CSV." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 2) Browser Extension Details" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_BrowserExtensions) -ForegroundColor DarkGray
    Write-Host "    Collect Chrome/Edge/Firefox extensions (ID, name, version, enabled state, user scope)." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 3) Stale Profile Application Scan" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_StaleProfileScan) -ForegroundColor DarkGray
    Write-Host "    Scan user profiles for stale/roaming app data; size, last write, candidate cleanup list." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 4) Validate Installed Software" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_ValidatedApps) -ForegroundColor DarkGray
    Write-Host "    Enumerate and validate installed applications using Osquery; exportable for analysis." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 5) Windows Store Application Inventory" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_StoreApps) -ForegroundColor DarkGray
    Write-Host "    Enumerate Microsoft Store (UWP) apps: name, package family, version, install scope." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 6) Windows Update Details" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.Software_WindowsUpdate) -ForegroundColor DarkGray
    Write-Host "    Inventory Windows Update history (KB, date, category, result) for compliance review." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt -OptionsDisplay '1/2/3/4/5/6/B'
    $in = Read-Host "Selection"
    switch ($in.Trim().ToUpper()) {
        '1' { Launch-Tool -FileName $ScriptNames.Software_AppRegistrySearch }
        '2' { Launch-Tool -FileName $ScriptNames.Software_BrowserExtensions }
        '3' { Launch-Tool -FileName $ScriptNames.Software_StaleProfileScan }
        '4' { Launch-Tool -FileName $ScriptNames.Software_ValidatedApps }
        '5' { Launch-Tool -FileName $ScriptNames.Software_StoreApps }
        '6' { Launch-Tool -FileName $ScriptNames.Software_WindowsUpdate }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}

function Show-WindowsUtilitiesMenu {
    Show-TopHeader -SectionTitle $ScriptNames.WindowsUtilities_MenuLabel
    Write-Host " You are in: Windows Machine Utilities" -ForegroundColor Yellow
    Write-Host ""

    # Alphabetical: Active Directory..., Dependency Validation..., Machine Utilities..., System Info A..., System Info B..., Windows Application - Cleanup S&D...
    Write-Host " 1) Active Directory Collection / Validation" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_ADValidation) -ForegroundColor DarkGray
    Write-Host "    Enumerate AD users, groups, OUs, and GPO inheritance; export to CSV for review." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 2) Dependency Validation Tools" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_DependencyValidation) -ForegroundColor DarkGray
    Write-Host "    Inspect missing DLLs/runtimes for binaries; validate dependencies for troubleshooting." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 3) Machine Utilities - Services & Disk Space" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_MachineUtilities) -ForegroundColor DarkGray
    Write-Host "    Show services and disk usage; quick operational health snapshot." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 4) System Info A - Firewall, Defender, SMART" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoA) -ForegroundColor DarkGray
    Write-Host "    Collect firewall and Defender status, and disk SMART health." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 5) System Info B - Reboot, Startup, Logs" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoB) -ForegroundColor DarkGray
    Write-Host "    Check pending reboot, startup services, and event log snippets." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 6) Windows Application - Cleanup S&D" -ForegroundColor White
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_AppCleanup) -ForegroundColor DarkGray
    Write-Host "    Search and select installed applications; stop related services, run uninstall," -ForegroundColor DarkGray
    Write-Host "    optionally delete leftover folders and uninstall registry keys, verify removal," -ForegroundColor DarkGray
    Write-Host "    and stream a live log of all actions to the toolbox folder." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt -OptionsDisplay '1/2/3/4/5/6/B'
    $in = Read-Host "Selection"
    switch ($in.Trim().ToUpper()) {
        '1' { Launch-Tool -FileName $ScriptNames.WinUtil_ADValidation }
        '2' { Launch-Tool -FileName $ScriptNames.WinUtil_DependencyValidation }
        '3' { Launch-Tool -FileName $ScriptNames.WinUtil_MachineUtilities }
        '4' { Launch-Tool -FileName $ScriptNames.WinUtil_SystemInfoA }
        '5' { Launch-Tool -FileName $ScriptNames.WinUtil_SystemInfoB }
        '6' { Launch-Tool -FileName $ScriptNames.WinUtil_AppCleanup }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}

# ---------------- Main Menu (alphabetical already: C, E, N, P, V, W) ----------------
function Show-MainMenu {
    Show-TopHeader -SectionTitle "Main Menu"

    Write-Host " 1) ConnectSecure Agent Actions" -ForegroundColor White
    Write-Host "    Install / Update / Uninstall / Single- and Multi-Agent log/message review and correlation." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 2) Exit Toolbox and Cleanup Files" -ForegroundColor White
    Write-Host "    Safely remove temporary working data and close this session." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 3) Network Validation" -ForegroundColor White
    Write-Host "    NMAP scan profiles for hosts/CIDR and local TLS/SSL policy collection." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 4) Package Logs and Collected Information" -ForegroundColor White
    Write-Host "    Bundle artifacts, encrypt to .csb, and generate an HTML handoff helper." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 5) Validate Installed Software" -ForegroundColor White
    Write-Host "    Osquery app inventory, browser extension details, Windows Update history," -ForegroundColor DarkGray
    Write-Host "    Microsoft Store (UWP) app inventory, stale profile app scan, and registry search." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " 6) Windows Machine Utilities" -ForegroundColor White
    Write-Host "    AD validation, dependency validation, machine utilities, system info A/B," -ForegroundColor DarkGray
    Write-Host "    and Windows application cleanup S&D." -ForegroundColor DarkGray
    Write-Host ""

    Footer-Prompt -OptionsDisplay '1/2/3/4/5/6'
}

# ---------------- Loop ----------------
while (-not $script:ExitTool) {
    Show-MainMenu
    $choice = Read-Host "Selection"
    if ([string]::IsNullOrWhiteSpace($choice)) { continue }

    switch ($choice.Trim().ToUpper()) {
        '1' { Show-AgentActionsMenu }
        '2' { Invoke-ExitAndCleanup }
        '3' { Show-NetworkValidationMenu }
        '4' { Show-PackageLogsMenu }
        '5' { Show-SoftwareValidationMenu }
        '6' { Show-WindowsUtilitiesMenu }
        'Q' { $script:ExitTool = $true }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 900 }
    }
}
