<# ============================
   ConnectSecure - Functions-Common.ps1 (R9-restored)
   Baseline: “zip-encrypt-email-functions.ps1” v9 behavior
   - Per-folder zips then final bundle
   - OutDir: C:\CS-Toolbox-TEMP\ZIP (absolute)
   - Robust EnsureFolders
   - transfer.sh upload (file.io removed)
   - Safe logging
   - Restored cleanup launcher (UAC self-destruct)
   ============================ #>

#region Globals & Init

# Root temp (overridable by caller before dot-sourcing)
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

$global:CS_ZipRoot      = Join-Path $global:CS_TempRoot 'ZIP'
$global:CS_LogsRoot     = Join-Path $global:CS_TempRoot 'LOGS'
$global:CS_StagingLogs  = Join-Path $global:CS_TempRoot '_AgentLogs_Staging'
$global:CS_Collected    = Join-Path $global:CS_TempRoot 'Collected-Info'
$global:CS_SessionId    = (Get-Date).ToString('yyyyMMdd_HHmmss')
$global:CS_LogFile      = Join-Path $global:CS_LogsRoot ("Run_{0}.log" -f $global:CS_SessionId)

#endregion Globals & Init

#region Utilities

function CSx-WriteLog {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','OK','FATAL')][string]$Level = 'INFO'
    )
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[{0}]  {1}  {2}" -f $Level, $ts, $Message
    try {
        if (-not (Test-Path -LiteralPath $global:CS_LogsRoot)) {
            New-Item -ItemType Directory -Path $global:CS_LogsRoot -Force | Out-Null
        }
        Add-Content -LiteralPath $global:CS_LogFile -Value $line
    } catch {}
    switch ($Level) {
        'OK'    { Write-Host $line -ForegroundColor Green }
        'INFO'  { Write-Host $line -ForegroundColor Gray }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'FATAL' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line }
    }
}

function CSx-GetTimestamp { (Get-Date).ToString('yyyyMMdd_HHmmss') }

function CSx-EnsureFolders {
    param(
        [string]$Path,            # optional: ensure one path
        [switch]$InitStandard     # ensure standard tree
    )
    try {
        if ($InitStandard) {
            foreach ($p in @($global:CS_TempRoot,$global:CS_ZipRoot,$global:CS_LogsRoot,$global:CS_StagingLogs,$global:CS_Collected)) {
                if (-not (Test-Path -LiteralPath $p)) {
                    New-Item -ItemType Directory -Path $p -Force | Out-Null
                }
            }
            CSx-WriteLog "Ensured standard folders under $($global:CS_TempRoot)" 'OK'
            return
        }
        if ($Path) {
            if (-not (Test-Path -LiteralPath $Path)) {
                New-Item -ItemType Directory -Path $Path -Force | Out-Null
            }
            CSx-WriteLog "Ensured folder: $Path" 'OK'
        }
    } catch {
        CSx-WriteLog "EnsureFolders failed: $($_.Exception.Message)" 'ERROR'
    }
}

function CSx-FormatSize {
    param([long]$Bytes)
    $sizes = 'B','KB','MB','GB','TB'
    $i=0; $n=[double]$Bytes
    while ($n -ge 1024 -and $i -lt $sizes.Length-1) { $n/=1024; $i++ }
    '{0:N1} {1}' -f $n, $sizes[$i]
}

function CSx-ListFolderManifest {
    param(
        [Parameter(Mandatory)][string]$Folder
    )
    $items = @()
    $totalBytes = 0L
    $fileCount = 0
    if (Test-Path -LiteralPath $Folder) {
        Get-ChildItem -LiteralPath $Folder -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            $items += [pscustomobject]@{
                Path        = $_.FullName
                Relative    = $_.FullName.Substring($Folder.Length).TrimStart('\','/')
                Bytes       = $_.Length
                Size        = CSx-FormatSize($_.Length)
                Modified    = $_.LastWriteTime
            }
            $totalBytes += $_.Length
            $fileCount++
        }
    }
    [pscustomobject]@{
        Folder     = $Folder
        FileCount  = $fileCount
        TotalBytes = $totalBytes
        TotalSize  = CSx-FormatSize($totalBytes)
        Files      = $items
    }
}

#endregion Utilities

#region Zipping

function CSx-ZipFolder {
    param(
        [Parameter(Mandatory)][string]$SourceFolder,
        [Parameter(Mandatory)][string]$ZipOutDir,
        [string]$ZipNamePrefix = ''
    )
    CSx-EnsureFolders -Path $ZipOutDir
    if (-not (Test-Path -LiteralPath $SourceFolder)) {
        CSx-WriteLog "ZipFolder: source missing: $SourceFolder" 'WARN'
        return $null
    }
    $ts = CSx-GetTimestamp
    $base = (Split-Path $SourceFolder -Leaf)
    $zipName = if ($ZipNamePrefix) { "{0}_{1}_{2}.zip" -f $ZipNamePrefix,$base,$ts } else { "{0}_{1}.zip" -f $base,$ts }
    $zipPath = Join-Path $ZipOutDir $zipName
    try {
        if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue }
        Compress-Archive -Path (Join-Path $SourceFolder '*') -DestinationPath $zipPath -CompressionLevel Optimal -Force
        $manifest = CSx-ListFolderManifest -Folder $SourceFolder
        CSx-WriteLog ("Zipped {0} -> {1} (Files: {2}, Size: {3})" -f $SourceFolder,$zipPath,$manifest.FileCount,$manifest.TotalSize) 'OK'
        return [pscustomobject]@{
            ZipPath   = $zipPath
            Source    = $SourceFolder
            FileCount = $manifest.FileCount
            TotalSize = $manifest.TotalSize
            Manifest  = $manifest
        }
    } catch {
        CSx-WriteLog "ZipFolder failed: $($_.Exception.Message)" 'ERROR'
        return $null
    }
}

function CSx-NewCombinedZipFromFiles {
    param(
        [Parameter(Mandatory)][string[]]$InputPaths,
        [Parameter(Mandatory)][string]$ZipOutDir,
        [string]$ZipName = $null
    )
    CSx-EnsureFolders -Path $ZipOutDir
    $ts = CSx-GetTimestamp
    if (-not $ZipName) { $ZipName = "CS-SupportBundle_{0}.zip" -f $ts }
    $outPath = Join-Path $ZipOutDir $ZipName

    $tmpDir = Join-Path $global:CS_TempRoot ("_tmp_bundle_{0}" -f [guid]::NewGuid())
    New-Item -ItemType Directory -Path $tmpDir -Force | Out-Null
    try {
        foreach ($p in $InputPaths) {
            if (-not (Test-Path -LiteralPath $p)) { continue }
            $leaf = Split-Path $p -Leaf
            Copy-Item -LiteralPath $p -Destination (Join-Path $tmpDir $leaf) -Force
        }
        if (Test-Path -LiteralPath $outPath) { Remove-Item -LiteralPath $outPath -Force -ErrorAction SilentlyContinue }
        Compress-Archive -Path (Join-Path $tmpDir '*') -DestinationPath $outPath -CompressionLevel Optimal -Force
        $size = (Get-Item $outPath).Length
        CSx-WriteLog ("Built combined bundle -> {0} (Size: {1})" -f $outPath,(CSx-FormatSize $size)) 'OK'
        return $outPath
    } catch {
        CSx-WriteLog "NewCombinedZipFromFiles failed: $($_.Exception.Message)" 'ERROR'
        return $null
    } finally {
        Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

#endregion Zipping

#region Bundle Builder (per-folder zips, then final)

function CSx-BuildSupportBundle {
    param(
        [string]$CollectedPath   = $global:CS_Collected,
        [string]$AgentLogsPath   = $global:CS_StagingLogs,
        [string]$ZipRoot         = $global:CS_ZipRoot
    )
    CSx-EnsureFolders -InitStandard
    $parts = @()
    $manifests = @()

    if (Test-Path -LiteralPath $CollectedPath) {
        $z = CSx-ZipFolder -SourceFolder $CollectedPath -ZipOutDir $ZipRoot -ZipNamePrefix 'Collected-Info'
        if ($z) { $parts += $z.ZipPath; $manifests += $z.Manifest }
    } else {
        CSx-WriteLog "No Collected-Info at $CollectedPath" 'WARN'
    }

    if (Test-Path -LiteralPath $AgentLogsPath) {
        $z = CSx-ZipFolder -SourceFolder $AgentLogsPath -ZipOutDir $ZipRoot -ZipNamePrefix 'Agent-Logs'
        if ($z) { $parts += $z.ZipPath; $manifests += $z.Manifest }
    } else {
        CSx-WriteLog "No Agent Logs staging at $AgentLogsPath" 'WARN'
    }

    if ($parts.Count -eq 0) {
        CSx-WriteLog "No parts to bundle." 'ERROR'
        return $null
    }

    $finalZip = CSx-NewCombinedZipFromFiles -InputPaths $parts -ZipOutDir $ZipRoot -ZipName ("CS-SupportBundle_{0}.zip" -f (CSx-GetTimestamp))
    if (-not $finalZip) { return $null }

    [pscustomobject]@{
        FinalZip   = $finalZip
        Parts      = $parts
        Manifests  = $manifests
    }
}

#endregion Bundle Builder

#region CMS/GPG Encryption (best-effort, safe fallback)

function CSx-EnsurePkcsTypes {
    # Make sure PKCS types are present (for manual CMS if Protect-CmsMessage is missing)
    try {
        $null = [System.Security.Cryptography.Pkcs.ContentInfo]
        return $true
    } catch {
        try { Add-Type -AssemblyName 'System.Security'; $null = [System.Security.Cryptography.Pkcs.ContentInfo]; return $true }
        catch { return $false }
    }
}

function CSx-EncryptForRecipients {
    param(
        [Parameter(Mandatory)][string]$InputFile,
        [Parameter(Mandatory)][string]$OutputP7M,
        [Parameter(Mandatory)][System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate
    )
    try {
        if (Get-Command Protect-CmsMessage -ErrorAction SilentlyContinue) {
            Protect-CmsMessage -Path $InputFile -To $Certificate -OutFile $OutputP7M -Force
            CSx-WriteLog "Wrote CMS envelope: $OutputP7M" 'OK'
            return $OutputP7M
        } elseif (CSx-EnsurePkcsTypes) {
            # Manual PKCS (SignedCms/EnvelopedCms)
            $data = [System.IO.File]::ReadAllBytes($InputFile)
            $contentInfo = New-Object System.Security.Cryptography.Pkcs.ContentInfo ([byte[]]$data)
            $env = New-Object System.Security.Cryptography.Pkcs.EnvelopedCms $contentInfo
            $recip = New-Object System.Security.Cryptography.Pkcs.CmsRecipient ($Certificate)
            $env.Encrypt($recip)
            [System.IO.File]::WriteAllBytes($OutputP7M, $env.Encode())
            CSx-WriteLog "Wrote CMS envelope (manual): $OutputP7M" 'OK'
            return $OutputP7M
        } else {
            CSx-WriteLog "CMS not available on this host; skipping encryption." 'WARN'
            return $null
        }
    } catch {
        CSx-WriteLog "EncryptForRecipients failed: $($_.Exception.Message)" 'ERROR'
        return $null
    }
}

#endregion CMS/GPG

#region transfer.sh Upload

function CSx-UploadToTransferSh {
    param(
        [Parameter(Mandatory)][string]$FilePath
    )
    if (-not (Test-Path -LiteralPath $FilePath)) { CSx-WriteLog "Upload: file missing $FilePath" 'ERROR'; return $null }
    $fileName = [System.IO.Path]::GetFileName($FilePath)
    $uri = "https://transfer.sh/$fileName"
    $maxAttempts = 3
    for ($i=1; $i -le $maxAttempts; $i++) {
        try {
            $resp = Invoke-WebRequest -Uri $uri -Method Put -InFile $FilePath -UseBasicParsing -TimeoutSec 120
            $url  = ($resp.Content.Trim())
            if ($url -and $url -like 'http*') {
                CSx-WriteLog "Uploaded to transfer.sh: $url" 'OK'
                return $url
            }
            throw "Unexpected response: $($resp.StatusCode) $($resp.Content)"
        } catch {
            CSx-WriteLog "Upload attempt $i failed: $($_.Exception.Message)" 'WARN'
            Start-Sleep -Seconds ([Math]::Min(8, 2*$i))
        }
    }
    CSx-WriteLog "All upload attempts failed for $FilePath" 'ERROR'
    return $null
}

#endregion transfer.sh Upload

#region Compose Helper (HTML + Outlook)

function CSx-WriteComposeHelperHtml {
    param(
        [Parameter(Mandatory)][string]$OutDir,
        [Parameter(Mandatory)][string]$Subject,
        [Parameter(Mandatory)][string]$To,
        [string]$Cc = '',
        [string]$BodyIntro = '',
        [string[]]$ZipParts = @(),
        $Manifests = @(),
        [string]$FinalZip = ''
    )
    CSx-EnsureFolders -Path $OutDir
    $ts = CSx-GetTimestamp
    $htmlPath = Join-Path $OutDir ("Compose_Helper_{0}.html" -f $ts)

    # Build manifest HTML blocks
    $manifestBlocks = @()
    foreach ($m in $Manifests) {
        $rows = ($m.Files | ForEach-Object {
            "<tr><td style='padding:4px 6px;border-bottom:1px solid #eee;'>{0}</td><td style='padding:4px 6px;border-bottom:1px solid #eee;text-align:right;'>{1}</td></tr>" -f ([System.Web.HttpUtility]::HtmlEncode($_.Relative)),([System.Web.HttpUtility]::HtmlEncode($_.Size))
        }) -join "`n"
        if (-not $rows) { $rows = "<tr><td colspan='2' style='padding:6px;color:#777;'>No files found.</td></tr>" }
        $manifestBlocks += @"
<div style="margin:14px 0 24px 0;">
  <div style="font-weight:600;margin-bottom:4px;">Folder: $( [System.Web.HttpUtility]::HtmlEncode($m.Folder) )</div>
  <div style="color:#555;margin-bottom:8px;">Files: $($m.FileCount) · Total: $($m.TotalSize)</div>
  <table style="border-collapse:collapse;width:100%;font-size:12px;">$rows</table>
</div>
"@
    }

@"
<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Compose Helper</title>
</head>
<body style="font-family:Segoe UI, Arial, sans-serif; color:#222; line-height:1.4; padding:24px; max-width:1000px; margin:auto;">
  <div style="text-align:center; margin-bottom:18px;">
    <!-- Placeholder simple CS logo (SVG). Swap if you prefer an external <img>. -->
    <svg width="160" height="40" viewBox="0 0 160 40" role="img" aria-label="ConnectSecure">
      <rect x="0" y="0" width="160" height="40" fill="#0a0a0a" rx="6" ry="6"></rect>
      <text x="80" y="26" text-anchor="middle" font-family="Segoe UI, Arial" font-size="18" fill="#ffffff">ConnectSecure</text>
    </svg>
  </div>

  <h2 style="margin:0 0 8px 0;">Support Bundle Compose Helper</h2>
  <div style="margin-bottom:12px;color:#555;">Generated: $(Get-Date)</div>

  <div style="background:#f7f7f9;border:1px solid #e6e6ef;padding:12px;border-radius:8px;margin-bottom:16px;">
    <div><strong>To:</strong> $( [System.Web.HttpUtility]::HtmlEncode($To) )</div>
    <div><strong>Cc:</strong> $( [System.Web.HttpUtility]::HtmlEncode($Cc) )</div>
    <div><strong>Subject:</strong> $( [System.Web.HttpUtility]::HtmlEncode($Subject) )</div>
  </div>

  <p style="margin:12px 0 20px 0;">$( [System.Web.HttpUtility]::HtmlEncode($BodyIntro) )</p>

  <h3 style="margin:18px 0 6px 0;">Bundles</h3>
  <ul>
    $( ($ZipParts + @($FinalZip | ? { $_ })) | ForEach-Object { "<li>" + [System.Web.HttpUtility]::HtmlEncode($_) + "</li>" } | Out-String )
  </ul>

  <h3 style="margin:18px 0 6px 0;">Contents by Folder</h3>
  $($manifestBlocks -join "`n")
</body>
</html>
"@ | Set-Content -LiteralPath $htmlPath -Encoding UTF8

    CSx-WriteLog "Wrote compose helper HTML: $htmlPath" 'OK'
    return $htmlPath
}

function CSx-StartOutlookComposeHtml {
    param(
        [Parameter(Mandatory)][string]$Subject,
        [Parameter(Mandatory)][string]$To,
        [string]$Cc = '',
        [string]$HtmlBodyPath,
        [string[]]$Attachments = @()
    )
    # Try COM first (best experience if available)
    try {
        $ol = New-Object -ComObject Outlook.Application -ErrorAction Stop
        $mail = $ol.CreateItem(0)
        $mail.Subject = $Subject
        $mail.To      = $To
        if ($Cc) { $mail.CC = $Cc }
        if ($HtmlBodyPath -and (Test-Path -LiteralPath $HtmlBodyPath)) {
            $html = Get-Content -LiteralPath $HtmlBodyPath -Raw -Encoding UTF8
            $mail.HTMLBody = $html
        }
        foreach ($a in $Attachments) {
            if (Test-Path -LiteralPath $a) { $mail.Attachments.Add($a) | Out-Null }
        }
        $mail.Display($true)
        CSx-WriteLog "Opened Outlook compose via COM." 'OK'
        return $true
    } catch {
        CSx-WriteLog "Outlook COM not available: $($_.Exception.Message)" 'WARN'
    }

    # Fallback: open Outlook and let user attach manually
    try {
        Start-Process outlook.exe '/c ipm.note' | Out-Null
        CSx-WriteLog "Opened Outlook via command line." 'INFO'
        return $true
    } catch {
        CSx-WriteLog "Failed to launch Outlook: $($_.Exception.Message)" 'ERROR'
        return $false
    }
}

#endregion Compose Helper

#region Pre-send Summary (console)

function CSx-ShowPreSendSummary {
    param(
        [Parameter(Mandatory)][string]$FinalZip,
        [string[]]$Parts = @(),
        $Manifests = @()
    )
    Write-Host "`n=== ConnectSecure - Support Bundle Summary ===`n" -ForegroundColor Cyan
    Write-Host (" Final zip : {0}" -f $FinalZip)
    foreach ($p in $Parts) { Write-Host (" Part      : {0}" -f $p) }
    foreach ($m in $Manifests) {
        Write-Host (" Folder    : {0}" -f $m.Folder)
        Write-Host ("   Files   : {0}" -f $m.FileCount)
        Write-Host ("   Total   : {0}" -f $m.TotalSize)
    }
    Write-Host ""
}

#endregion Pre-send Summary

#region Session Summary & Cleanup

function Write-SessionSummary {
    try {
        CSx-WriteLog "Session complete for $env:USERNAME on $(Get-Date)." 'INFO'
    } catch {}
}

function Invoke-FinalCleanupAndExit {
    param(
        [string]$TargetRoot = $global:CS_TempRoot  # usually C:\CS-Toolbox-TEMP
    )
    try {
        if ([string]::IsNullOrWhiteSpace($TargetRoot)) { $TargetRoot = 'C:\CS-Toolbox-TEMP' }

        # Write a self-destruct cleanup script inside the temp root
        $cleanupName = 'Toolbox-Cleanup-SelfDestruct.ps1'
        $cleanupPath = Join-Path $TargetRoot $cleanupName

$cleanupScript = @'
param([string]$Target = "C:\CS-Toolbox-TEMP")

Start-Sleep -Seconds 5

# Best-effort: close and kill PowerShell/Pwsh instances that may be tied to the target folder
foreach ($p in Get-Process powershell, pwsh -ErrorAction SilentlyContinue) {
    try {
        # If we can get a main module path, just try graceful close/kill
        try { $null = $p.CloseMainWindow(); Start-Sleep -Milliseconds 800 } catch {}
        if (-not $p.HasExited) { try { $p.Kill(); $null = $p.WaitForExit(3000) } catch {} }
    } catch {}
}

# Remove temp tree
try {
    Remove-Item -LiteralPath $Target -Recurse -Force -ErrorAction Stop
} catch {}

# Try to delete ourselves if still present
try {
    $self = $MyInvocation.MyCommand.Path
    if (Test-Path -LiteralPath $self) { Remove-Item -LiteralPath $self -Force -ErrorAction SilentlyContinue }
} catch {}
'@

        if (-not (Test-Path -LiteralPath $TargetRoot)) {
            New-Item -ItemType Directory -Path $TargetRoot -Force | Out-Null
        }
        Set-Content -LiteralPath $cleanupPath -Value $cleanupScript -Encoding UTF8 -NoNewline

        Write-Host 'Cleanup will run in a new elevated window in 5 seconds...' -ForegroundColor Cyan
        Start-Sleep -Seconds 5

        $args = @(
            '-NoProfile','-ExecutionPolicy','Bypass',
            '-File',"`"$cleanupPath`"",
            '-Target',"`"$TargetRoot`""
        )
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args | Out-Null
    } catch {
        Write-Host ('[WARN] Cleanup launcher failed: {0}' -f $_.Exception.Message) -ForegroundColor Yellow
    }

    # Exit the current toolbox session so the cleanup can remove the tree
    exit
}

#endregion Session Summary & Cleanup
