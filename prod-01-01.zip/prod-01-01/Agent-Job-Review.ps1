﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$LogPath,
    [string]$OutputHtml,

    [Alias('NoPopup')]
    [switch]$NoOpen,

    [switch]$AllLogs,

    [switch]$Silent
)

<# =====================================================================
 Agent-Job-Review.ps1  (Menu + HTML Job Run Report with Quick Mode + Grouped Views)

 FIXES INCLUDED (for your latest errors):
  1) If -LogPath points to a FOLDER in single-file mode, the script now auto-selects:
       - cybercns.log if present
       - otherwise the first *.log in that folder
     (This fixes: "property 'Length' cannot be found" caused by passing a folder.)
  2) -AllLogs forces FULL DATASET analysis (no 3MB quick mode) by passing -FullDataset.
  3) adscan grouping uses VerifyCreds (not Verify) to avoid StrictMode error.
  4) No stray backtick lines.

 Switches:
   -LogPath <file-or-folder>   single file OR folder (folder used with -AllLogs or auto-select in single mode)
   -OutputHtml <path>          override output html path (single mode only)
   -AllLogs                    process all *.log in folder (default agent log folder if none given)
   -NoOpen / -NoPopup          don’t launch browser
   -Silent                     suppress console/menu/progress output; implies NoOpen
===================================================================== #>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms | Out-Null

# ---------------- Standard paths ----------------
$script:Silent = [bool]$Silent

$DefaultLogFolder = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$DefaultLogFile   = Join-Path $DefaultLogFolder 'cybercns.log'

$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPath = Join-Path $ExportRoot 'AgentLogs'

if (-not (Test-Path -LiteralPath $ExportPath)) {
    New-Item -ItemType Directory -Path $ExportPath -Force | Out-Null
}

# ---------------- Silent-aware wrappers ----------------
function Write-HostSafe {
    param([string]$Message)
    if (-not $script:Silent) { Write-Host $Message }
}
function Write-WarningSafe {
    param([string]$Message)
    if (-not $script:Silent) { Write-Warning $Message }
}
function Write-ProgressSafe {
    param(
        [string]$Activity,
        [string]$Status,
        [int]$PercentComplete
    )
    if (-not $script:Silent) {
        Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete
    }
}

# ---------------- Helpers ----------------
function Html-Encode {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    [System.Net.WebUtility]::HtmlEncode($Text)
}

function New-JobAnchorId {
    param([Parameter(Mandatory)][string]$JobName)
    $slug = ($JobName -replace '[^a-zA-Z0-9]+','-').ToLower().Trim('-')
    if (-not $slug) { $slug = 'job' }
    "job-$slug"
}

function Get-CountSafe {
    param($Value)
    if ($null -eq $Value) { return 0 }
    if ($Value -is [System.Array] -or $Value -is [System.Collections.ICollection]) { return $Value.Count }
    1
}

function Resolve-LogPathToFile {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "LogPath not found: $Path"
    }

    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        return (Resolve-Path -LiteralPath $Path).Path
    }

    if (Test-Path -LiteralPath $Path -PathType Container) {
        $candidate = Join-Path $Path 'cybercns.log'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }

        $firstLog = Get-ChildItem -LiteralPath $Path -Filter '*.log' -File -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -First 1
        if ($null -ne $firstLog) {
            return $firstLog.FullName
        }

        throw "No .log files found in folder: $Path"
    }

    throw "LogPath is neither a file nor a folder: $Path"
}

function Highlight-StatusText {
    param([string]$HtmlLine)
    if ([string]::IsNullOrEmpty($HtmlLine)) { return $HtmlLine }

    $HtmlLine = [regex]::Replace(
        $HtmlLine,
        '(?i)\b(error|failed|failure|exception|panic)\b',
        { '<span class="hl-failure">' + $args[0].Value + '</span>' }
    )

    $HtmlLine = [regex]::Replace(
        $HtmlLine,
        '(?i)\bwarn(ing)?\b',
        { '<span class="hl-warning">' + $args[0].Value + '</span>' }
    )

    $HtmlLine
}

function Get-TrimmedLinesForRun {
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Lines,
        [int]$MaxLines
    )

    if ($null -eq $Lines) { return @() }

    $arr   = @($Lines)
    $total = Get-CountSafe $arr
    if ($total -eq 0 -or $total -le $MaxLines -or $MaxLines -le 0) { return $arr }

    $headCount = [int]([math]::Round($MaxLines * 0.7))
    if ($headCount -lt 1) { $headCount = 1 }
    if ($headCount -gt ($MaxLines - 1)) { $headCount = $MaxLines - 1 }
    $tailCount = $MaxLines - $headCount
    if ($tailCount -lt 1) { $tailCount = 1 }

    $trimmed = New-Object 'System.Collections.Generic.List[string]'
    for ($i = 0; $i -lt $headCount; $i++) { $trimmed.Add([string]$arr[$i]) }

    $marker = "----- OUTPUT TRIMMED: showing first {0} lines and last {1} of {2} total lines -----" -f $headCount, $tailCount, $total
    $trimmed.Add($marker)

    for ($i = $total - $tailCount; $i -lt $total; $i++) { $trimmed.Add([string]$arr[$i]) }
    $trimmed
}

function Parse-PPJobName {
    param([string]$JobName)
    $assetId = $null
    $suffix  = $null
    if ($JobName -match '^ProcessPendingRecords with assetid:\s*(?<assetid>\S+)\s+and\s+(?<suffix>.+)$') {
        $assetId = $matches['assetid']
        $suffix  = $matches['suffix']
    }
    [PSCustomObject]@{ AssetId = $assetId; Suffix = $suffix }
}

function Parse-FullScanJobName {
    param([string]$JobName)
    $jobId = $null
    if ($JobName -match '^task FULLSCAN with jobId\s+(?<jobid>[0-9a-fA-F-]+)$') { $jobId = $matches['jobid'] }
    [PSCustomObject]@{ JobId = $jobId }
}

function Parse-AdScanJobName {
    param([string]$JobName)
    $ip = $null
    $verify = $null
    if ($JobName -match '^adscan for :\s*(?<ip>\S+)\s+inputParams\.VerifyCreds\s+(?<verify>\S+)$') {
        $ip = $matches['ip']
        $verify = $matches['verify']
    }
    [PSCustomObject]@{ Ip = $ip; VerifyCreds = $verify }
}

function Format-TimeSpanShort {
    param([TimeSpan]$Span)
    if (-not $Span) { return '' }

    $parts = @()
    if ($Span.Days -ne 0)    { $parts += ("{0}d" -f $Span.Days) }
    if ($Span.Hours -ne 0)   { $parts += ("{0}h" -f $Span.Hours) }
    if ($Span.Minutes -ne 0) { $parts += ("{0}m" -f $Span.Minutes) }
    if ($Span.Seconds -ne 0 -and (Get-CountSafe $parts) -lt 2) { $parts += ("{0}s" -f $Span.Seconds) }

    if ((Get-CountSafe $parts) -eq 0) { '0s' } else { $parts -join ' ' }
}

function Find-PrimaryIssueLine {
    param([Parameter(Mandatory)][string[]]$Lines)

    for ($i = 0; $i -lt $Lines.Count; $i++) {
        $line = $Lines[$i]

        if ($line -match 'CyberCNSAgent service failed: An instance of the service is already running\.') { continue }
        if ($line -match 'Error in opening eventlog The RPC server is unavailable\.  Continuing without event log') { continue }

        if ($line -match '(?i)\b(error|failed|failure|exception|panic)\b' -or $line -match '(?i)\bwarn(ing)?\b') {
            return [PSCustomObject]@{ Index = $i; Line = $line }
        }
    }
    $null
}

# ---------------- Menu & log selection ----------------
function Select-LogFile {
    while ($true) {
        Clear-Host
        Write-Host "============================================================"
        Write-Host "  Agent Job Review"
        Write-Host "============================================================"
        Write-Host "  1) Scan default log folder"
        Write-Host "     ($DefaultLogFolder)"
        Write-Host ""
        Write-Host "  2) Choose another folder (GUI folder picker)"
        Write-Host ""
        Write-Host "  Q) Quit"
        Write-Host "============================================================"
        $choice = Read-Host "Select an option (1/2/Q)"

        $folder = $null
        switch ($choice.ToUpper()) {
            '1' {
                if (-not (Test-Path -LiteralPath $DefaultLogFolder)) {
                    Write-Warning "Default folder not found: $DefaultLogFolder"
                    Read-Host "Press Enter to return to the menu..."
                    continue
                }
                $folder = $DefaultLogFolder
            }
            '2' {
                $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
                $dialog.Description = "Select folder containing log files"
                $dialog.ShowNewFolderButton = $false
                $result = $dialog.ShowDialog()
                if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
                    Write-Host "No folder selected. Returning to menu..."
                    Start-Sleep -Seconds 1
                    continue
                }
                $folder = $dialog.SelectedPath
            }
            'Q' { return $null }
            default {
                Write-Host "Invalid selection. Please enter 1, 2, or Q." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
                continue
            }
        }

        $logs = @(Get-ChildItem -LiteralPath $folder -Filter '*.log' -File -ErrorAction SilentlyContinue | Sort-Object Name)
        if (-not $logs -or (Get-CountSafe $logs) -eq 0) {
            Write-Warning "No .log files found in: $folder"
            Read-Host "Press Enter to return to the menu..."
            continue
        }

        Clear-Host
        Write-Host "============================================================"
        Write-Host "  Log files in: $folder"
        Write-Host "============================================================"
        $index = 1
        foreach ($log in $logs) {
            Write-Host ("  {0}) {1}" -f $index, $log.Name)
            $index++
        }
        Write-Host "============================================================"
        $sel = Read-Host "Select a log file by number (or Q to cancel)"
        if ($sel.ToUpper() -eq 'Q') { continue }

        [int]$selIndex = 0
        if (-not [int]::TryParse($sel, [ref]$selIndex)) {
            Write-Host "Invalid selection. Must be a number or Q." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            continue
        }

        $logCount = Get-CountSafe $logs
        if ($selIndex -lt 1 -or $selIndex -gt $logCount) {
            Write-Host "Selection out of range." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            continue
        }

        return $logs[$selIndex - 1].FullName
    }
}

# ---------------- Core parsing functions ----------------
function Parse-LogLine {
    param([string]$Line,[int]$Index)

    $pattern = '^(?<ts>\d{4}/\d{2}\/\d{2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+\[(?<msg>.*)\]\s*$'
    $time = $null
    $rawTime = $null
    $message = $Line.Trim()

    if ($Line -match $pattern) {
        $rawTime = $matches['ts']
        try { $time = [datetime]::ParseExact($rawTime, 'yyyy/MM/dd HH:mm:ss', $null) } catch { $time = $null }
        $message = $matches['msg'].Trim()
    }

    [PSCustomObject]@{
        Index   = $Index
        Time    = $time
        RawTime = $rawTime
        Message = $message
        RawLine = $Line
    }
}

function Get-JobBoundary {
    param($Entry)

    $msg = $Entry.Message
    $startJob = $null
    $endJob = $null

    if ($msg -match '^(?<job>.+?)\s+(Scan\s+)?Started$') { $startJob = $matches['job'] }
    elseif ($msg -match '^Starting\s+(?<job>.+)$') { $startJob = $matches['job'] }

    if ($msg -match '^(?<job>.+?)\s+(Scan\s+)?Completed$') { $endJob = $matches['job'] }
    elseif ($msg -imatch '^(?<job>.+?)\s+completed\b') { $endJob = $matches['job'] }

    [PSCustomObject]@{ StartJobName = $startJob; EndJobName = $endJob }
}

function Classify-RunStatus {
    param([string]$Text)

    if ($null -eq $Text) { return 'Success' }

    $cleanText = $Text
    $cleanText = $cleanText -replace 'CyberCNSAgent service failed: An instance of the service is already running\.', ''
    $cleanText = $cleanText -replace 'Error in opening eventlog The RPC server is unavailable\.  Continuing without event log', ''

    if ($cleanText -match '(?i)\b(error|failed|failure|exception|panic)\b') { 'Failure' }
    elseif ($cleanText -match '(?i)\bwarn(ing)?\b') { 'Warning' }
    else { 'Success' }
}

# ---------------- Main analyzer ----------------
function Analyze-LogFile {
    param(
        [Parameter(Mandatory)][string]$LogPath,
        [string]$OutputHtml,
        [switch]$NoOpen,
        [switch]$FullDataset
    )

    # FIX: if a folder got passed down here, resolve to an actual file
    if (Test-Path -LiteralPath $LogPath -PathType Container) {
        $LogPath = Resolve-LogPathToFile -Path $LogPath
    }

    if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        throw "Log file not found: $LogPath"
    }

    $logDir      = Split-Path -Parent $LogPath
    $agentId     = Split-Path -Leaf $logDir
    $agentIdSafe = ($agentId -replace '[^a-zA-Z0-9\-]+','-').Trim('-')
    if (-not $agentIdSafe) { $agentIdSafe = 'Agent' }

    $nowForName = Get-Date
    $runDate = $nowForName.ToString('yyyyMMdd')
    $runTime = $nowForName.ToString('HHmmss')

    if (-not $OutputHtml) {
        $baseName = "Job-Analysis-{0}-{1}-{2}.html" -f $agentIdSafe, $runDate, $runTime
        $OutputHtml = Join-Path $ExportPath $baseName
    }

    $fileInfo = Get-Item -LiteralPath $LogPath -ErrorAction Stop
    if ($null -eq $fileInfo -or -not ($fileInfo -is [IO.FileInfo])) {
        throw "Resolved log path is not a file: $LogPath"
    }

    $fileSizeMB = [math]::Round($fileInfo.Length / 1MB, 2)

    # ---------- Quick-mode selection ----------
    $allLines = @(Get-Content -LiteralPath $LogPath)
    $totalLines = Get-CountSafe $allLines

    $usingQuick = $false
    $percentOfLines = 100.0
    $rawLines = $allLines

    if (-not $FullDataset -and $fileSizeMB -gt 3.0 -and $totalLines -gt 0) {
        $fraction = 3.0 / $fileSizeMB
        if ($fraction -gt 1.0) { $fraction = 1.0 }
        $linesUsed = [int]([math]::Ceiling($totalLines * $fraction))
        if ($linesUsed -lt 1) { $linesUsed = 1 }

        if ($linesUsed -lt $totalLines) {
            $usingQuick = $true
            $startIndex = $totalLines - $linesUsed
            $percentOfLines = [math]::Round(100.0 * $linesUsed / $totalLines, 1)
            $rawLines = $allLines[$startIndex..($totalLines - 1)]
        }
    }

    $allLines = $null
    $selectedTotal = Get-CountSafe $rawLines

    # ---------- Build runs ----------
    $openJobs = @{}    # jobName -> current run
    $jobRuns  = @{}    # jobName -> List[run]

    for ($i = 0; $i -lt $selectedTotal; $i++) {
        if ($selectedTotal -gt 0 -and ($i % 2000 -eq 0)) {
            $pct = [int](($i * 100.0) / $selectedTotal)
            Write-ProgressSafe -Activity "Phase 1: Parsing & building runs" -Status ("{0}% ({1} of {2} lines)" -f $pct, $i, $selectedTotal) -PercentComplete $pct
        }

        $entry = Parse-LogLine -Line $rawLines[$i] -Index $i
        $boundary = Get-JobBoundary -Entry $entry

        foreach ($run in $openJobs.Values) { $run.Lines.Add($entry.RawLine) }

        if ($boundary.StartJobName) {
            $jobName = $boundary.StartJobName.Trim()

            if (-not $jobRuns.ContainsKey($jobName)) {
                $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]'
            }

            $run = [PSCustomObject]@{
                JobName   = $jobName
                StartTime = $entry.Time
                EndTime   = $null
                Lines     = New-Object 'System.Collections.Generic.List[string]'
                Status    = $null
                Duration  = $null
            }

            $run.Lines.Add($entry.RawLine)

            if ($openJobs.ContainsKey($jobName)) { $jobRuns[$jobName].Add($openJobs[$jobName]) }
            $openJobs[$jobName] = $run
        }

        if ($boundary.EndJobName) {
            $jobName = $boundary.EndJobName.Trim()

            if ($openJobs.ContainsKey($jobName)) {
                $run = $openJobs[$jobName]
                $run.EndTime = $entry.Time
                $jobRuns[$jobName].Add($run)
                $null = $openJobs.Remove($jobName)
            }
            else {
                if (-not $jobRuns.ContainsKey($jobName)) {
                    $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]'
                }

                $run = [PSCustomObject]@{
                    JobName   = $jobName
                    StartTime = $entry.Time
                    EndTime   = $entry.Time
                    Lines     = New-Object 'System.Collections.Generic.List[string]'
                    Status    = $null
                    Duration  = $null
                }
                $run.Lines.Add($entry.RawLine)
                $jobRuns[$jobName].Add($run)
            }
        }
    }

    Write-ProgressSafe -Activity "Phase 1: Parsing & building runs" -Status "Done" -PercentComplete 100

    foreach ($kvp in $openJobs.GetEnumerator()) {
        $jobName = $kvp.Key
        $run = $kvp.Value
        if (-not $jobRuns.ContainsKey($jobName)) { $jobRuns[$jobName] = New-Object 'System.Collections.Generic.List[object]' }
        $jobRuns[$jobName].Add($run)
    }

    $rawLines = $null

    # ---------- Summaries ----------
    $jobSummaries = @()

    foreach ($jobName in ($jobRuns.Keys | Sort-Object)) {
        $runs = @($jobRuns[$jobName] | Sort-Object StartTime)

        foreach ($run in $runs) {
            $text = [string]::Join([Environment]::NewLine, @($run.Lines))
            $run.Status = Classify-RunStatus -Text $text
            if ($run.StartTime -and $run.EndTime) { $run.Duration = $run.EndTime - $run.StartTime }
        }

        $totalRuns   = Get-CountSafe $runs
        $successRuns = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Success' }))
        $warningRuns = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Warning' }))
        $failedRuns  = Get-CountSafe (@($runs | Where-Object { $_.Status -eq 'Failure' }))

        $runsWithTime = @($runs | Where-Object { $_.StartTime } | Sort-Object StartTime)
        $intervalsMinutes = @()
        for ($j = 1; $j -lt (Get-CountSafe $runsWithTime); $j++) {
            $delta = $runsWithTime[$j].StartTime - $runsWithTime[$j - 1].StartTime
            if ($delta.TotalMinutes -gt 0) { $intervalsMinutes += $delta.TotalMinutes }
        }

        $avgInterval     = $null
        $predictedNext   = $null
        $avgIntervalText = 'N/A'
        $nextRunText     = 'N/A'

        if ((Get-CountSafe $intervalsMinutes) -gt 0) {
            $avgMinutes = ($intervalsMinutes | Measure-Object -Average).Average
            $avgInterval = [TimeSpan]::FromMinutes($avgMinutes)
            $avgIntervalText = Format-TimeSpanShort -Span $avgInterval

            if ((Get-CountSafe $runsWithTime) -gt 0) {
                $lastStart = $runsWithTime[(Get-CountSafe $runsWithTime) - 1].StartTime
                $predictedNext = $lastStart + $avgInterval
                $nextRunText = $predictedNext.ToString('yyyy-MM-dd HH:mm:ss')
            }
        }

        $lastRun = $runs | Sort-Object StartTime -Descending | Select-Object -First 1

        $jobSummaries += [PSCustomObject]@{
            JobName           = $jobName
            TotalRuns         = $totalRuns
            SuccessCount      = $successRuns
            WarningCount      = $warningRuns
            FailureCount      = $failedRuns
            AvgInterval       = $avgInterval
            AvgIntervalText   = $avgIntervalText
            PredictedNextRun  = $predictedNext
            PredictedNextText = $nextRunText
            LastRun           = $lastRun
            Runs              = $runs
            IsGrouped         = $false
        }
    }

    # ---------- Mark grouped jobs ----------
    $ppJobs = @($jobSummaries | Where-Object { $_.JobName -like 'ProcessPendingRecords with assetid:*' })
    foreach ($job in $ppJobs) {
        $parsed = Parse-PPJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['AssetId']) { $job | Add-Member -NotePropertyName AssetId -NotePropertyValue $parsed.AssetId -Force } else { $job.AssetId = $parsed.AssetId }
        if (-not $job.PSObject.Properties['PPTypeSuffix']) { $job | Add-Member -NotePropertyName PPTypeSuffix -NotePropertyValue $parsed.Suffix -Force } else { $job.PPTypeSuffix = $parsed.Suffix }
        $job.IsGrouped = $true
    }

    $fsJobs = @($jobSummaries | Where-Object { $_.JobName -like 'task FULLSCAN with jobId*' })
    foreach ($job in $fsJobs) {
        $parsed = Parse-FullScanJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['FullScanJobId']) { $job | Add-Member -NotePropertyName FullScanJobId -NotePropertyValue $parsed.JobId -Force } else { $job.FullScanJobId = $parsed.JobId }
        $job.IsGrouped = $true
    }

    $adsJobs = @($jobSummaries | Where-Object { $_.JobName -like 'adscan for :*inputParams.VerifyCreds*' })
    foreach ($job in $adsJobs) {
        $parsed = Parse-AdScanJobName -JobName $job.JobName
        if (-not $job.PSObject.Properties['AdIp']) { $job | Add-Member -NotePropertyName AdIp -NotePropertyValue $parsed.Ip -Force } else { $job.AdIp = $parsed.Ip }
        if (-not $job.PSObject.Properties['AdVerifyCreds']) { $job | Add-Member -NotePropertyName AdVerifyCreds -NotePropertyValue $parsed.VerifyCreds -Force } else { $job.AdVerifyCreds = $parsed.VerifyCreds }
        $job.IsGrouped = $true
    }

    # ---------- Select runs to include & anchors ----------
    foreach ($job in $jobSummaries) {
        $allRuns = @($job.Runs | Sort-Object StartTime)

        $successDesc = @($allRuns | Where-Object { $_.Status -eq 'Success' } | Sort-Object StartTime -Descending)
        $successIncluded = @($successDesc | Select-Object -First 1)
        $wfRuns = @($allRuns | Where-Object { $_.Status -ne 'Success' })

        $includedRuns = @($successIncluded + $wfRuns | Sort-Object StartTime)
        $hiddenCount = (Get-CountSafe $successDesc) - (Get-CountSafe $successIncluded)
        if ($hiddenCount -lt 0) { $hiddenCount = 0 }

        $jobAnchorBase = New-JobAnchorId -JobName $job.JobName

        $idx = 0
        foreach ($run in $includedRuns) {
            $anchorId = "{0}-run-{1}" -f $jobAnchorBase, $idx
            if ($run.PSObject.Properties['AnchorId']) { $run.AnchorId = $anchorId }
            else { $run | Add-Member -NotePropertyName AnchorId -NotePropertyValue $anchorId -Force }
            $idx++
        }

        $failureCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Failure' } | Sort-Object StartTime -Descending)
        $warningCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Warning' } | Sort-Object StartTime -Descending)
        $successCandidates = @($includedRuns | Where-Object { $_.Status -eq 'Success' } | Sort-Object StartTime -Descending)

        $failureHref = if ((Get-CountSafe $failureCandidates) -gt 0) { "#$($failureCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }
        $warningHref = if ((Get-CountSafe $warningCandidates) -gt 0) { "#$($warningCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }
        $successHref = if ((Get-CountSafe $successCandidates) -gt 0) { "#$($successCandidates[0].AnchorId)" } else { "#$jobAnchorBase" }

        $lastRun = $job.LastRun
        $lastHref = "#$jobAnchorBase"
        if ($null -ne $lastRun -and ($includedRuns -contains $lastRun)) {
            if (-not $lastRun.PSObject.Properties['AnchorId']) {
                $lastRun | Add-Member -NotePropertyName AnchorId -NotePropertyValue ("{0}-run-last" -f $jobAnchorBase) -Force
            }
            $lastHref = "#$($lastRun.AnchorId)"
        }

        $issueRuns = @($includedRuns | Where-Object { $_.Status -ne 'Success' -and $_.StartTime })
        $lastIssueTime = $null
        $lastIssueText = 'N/A'
        $issueHref = "#$jobAnchorBase"

        if ((Get-CountSafe $issueRuns) -gt 0) {
            $latestIssue = $issueRuns | Sort-Object StartTime -Descending | Select-Object -First 1
            $lastIssueTime = $latestIssue.StartTime
            $lastIssueText = $lastIssueTime.ToString('yyyy-MM-dd HH:mm:ss')
            $issueHref = "#$($latestIssue.AnchorId)"
        }

        $job | Add-Member -NotePropertyName IncludedRuns -NotePropertyValue $includedRuns -Force
        $job | Add-Member -NotePropertyName HiddenSuccessCount -NotePropertyValue $hiddenCount -Force
        $job | Add-Member -NotePropertyName JobAnchorHref -NotePropertyValue ("#$jobAnchorBase") -Force
        $job | Add-Member -NotePropertyName FailureAnchorHref -NotePropertyValue $failureHref -Force
        $job | Add-Member -NotePropertyName WarningAnchorHref -NotePropertyValue $warningHref -Force
        $job | Add-Member -NotePropertyName SuccessAnchorHref -NotePropertyValue $successHref -Force
        $job | Add-Member -NotePropertyName LastRunAnchorHref -NotePropertyValue $lastHref -Force
        $job | Add-Member -NotePropertyName LastIssueTime -NotePropertyValue $lastIssueTime -Force
        $job | Add-Member -NotePropertyName LastIssueText -NotePropertyValue $lastIssueText -Force
        $job | Add-Member -NotePropertyName IssueAnchorHref -NotePropertyValue $issueHref -Force
    }

    # ---------------- Build HTML ----------------
    $now = Get-Date
    $logoUrl = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'

    $css = @'
body { font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 20px; background-color: #0f172a; color: #e5e7eb; }
h1, h2, h3 { color: #38bdf8; }
.logo-wrap { margin-bottom: 10px; text-align: center; }
.logo { max-height: 60px; display: inline-block; }
table { border-collapse: collapse; width: 100%; margin-bottom: 1.5rem; }
th, td { border: 1px solid #334155; padding: 6px 10px; text-align: left; font-size: 13px; }
th { background-color: #1e293b; }
tr:nth-child(even) td { background-color: #020617; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }
.badge-success { background-color: #022c22; color: #4ade80; }
.badge-warning { background-color: #451a03; color: #fbbf24; }
.badge-failure { background-color: #450a0a; color: #f87171; }
pre { background-color: #020617; padding: 10px; border-radius: 6px; overflow-x: auto; font-size: 12px; }
details { margin-bottom: 8px; }
details > summary { cursor: pointer; padding: 4px 8px; background-color: #020617; border-radius: 4px; font-size: 13px; }
summary::-webkit-details-marker { display: none; }
.summary-row { display: flex; flex-wrap: wrap; gap: 12px; font-size: 13px; }
.summary-row span { white-space: nowrap; }
.small { font-size: 11px; color: #9ca3af; }
code { background-color: #020617; padding: 2px 4px; border-radius: 4px; }
a { color: #38bdf8; text-decoration: none; }
a:hover { text-decoration: underline; }
.quick-banner { margin: 8px 0 16px 0; padding: 8px 12px; border-radius: 6px; background-color: #451a03; color: #fde68a; font-size: 12px; }
.hl-failure { background-color: #7f1d1d; color: #fee2e2; font-weight: 600; }
.hl-warning { background-color: #854d0e; color: #fef3c7; font-weight: 600; }
@media (prefers-color-scheme: light) {
  body { background-color: #ffffff; color: #111827; }
  th { background-color: #f9fafb; }
  tr:nth-child(even) td { background-color: #f9fafb; }
  pre { background-color: #111827; color: #e5e7eb; }
  details > summary { background-color: #f3f4f6; }
  code { background-color: #f3f4f6; }
  .quick-banner { background-color: #f97316; color: #111827; }
  .hl-failure { background-color: #fecaca; color: #7f1d1d; }
  .hl-warning { background-color: #fef3c7; color: #854d0e; }
}
'@

    $html = New-Object System.Text.StringBuilder
    $null = $html.AppendLine('<!DOCTYPE html>')
    $null = $html.AppendLine('<html><head><meta charset="utf-8" />')
    $null = $html.AppendLine('<title>Agent Job Analysis Report</title>')
    $null = $html.AppendLine('<style>')
    $null = $html.AppendLine($css)
    $null = $html.AppendLine('</style>')
    $null = $html.AppendLine('<script>')
    $null = $html.AppendLine('function collapseAllDetails(){var ds=document.querySelectorAll("details[open]");for(var i=0;i<ds.length;i++){ds[i].removeAttribute("open");}}')
    $null = $html.AppendLine('</script>')
    $null = $html.AppendLine('</head><body>')

    if ($logoUrl) {
        $null = $html.AppendLine('<div class="logo-wrap"><img src="' + $logoUrl + '" alt="ConnectSecure Logo" class="logo" /></div>')
    }

    $null = $html.AppendLine('<h1>Agent Job Analysis Report</h1>')
    $null = $html.AppendLine('<button onclick="collapseAllDetails()" style="margin-bottom:10px;">Collapse All</button>')
    $null = $html.AppendLine('<p class="small">Generated: ' + $now.ToString('yyyy-MM-dd HH:mm:ss') +
        '<br />Log file: <code>' + (Html-Encode $LogPath) + '</code>' +
        '<br />File size: ' + $fileSizeMB + ' MB' +
        '<br />AgentId: <code>' + (Html-Encode $agentIdSafe) + '</code></p>')

    if ($usingQuick) {
        $null = $html.AppendLine('<div class="quick-banner"><strong>Quick mode:</strong> This report analyzed only the most recent ~3 MB of the log (about ' + $percentOfLines + '% of lines).</div>')
    }

    $null = $html.AppendLine('<p class="small">Known benign messages (service already running, RPC eventlog unavailable) do not count as failures.</p>')

    $individualJobs = @($jobSummaries | Where-Object { -not $_.IsGrouped }) |
        Sort-Object @{ Expression = { $_.LastIssueTime }; Descending = $true }, @{ Expression = { $_.JobName }; Descending = $false }

    $null = $html.AppendLine('<h2>Job Summary - Individual Jobs</h2>')
    $null = $html.AppendLine('<table>')
    $null = $html.AppendLine('<tr><th>Job</th><th>Total Runs</th><th>Success</th><th>Warnings</th><th>Failures</th><th>Last Issue (Warn/Fail)</th><th>Avg Interval</th><th>Predicted Next Run</th><th>Last Run Start</th><th>Last Status</th></tr>')

    foreach ($job in $individualJobs) {
        $last = $job.LastRun

        $statusBadgeClass = 'badge'
        switch ($last.Status) {
            'Success' { $statusBadgeClass += ' badge-success' }
            'Warning' { $statusBadgeClass += ' badge-warning' }
            'Failure' { $statusBadgeClass += ' badge-failure' }
        }

        $lastStartText = if ($last.StartTime) { $last.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }
        $lastStatusHtml = '<a href="' + $job.LastRunAnchorHref + '"><span class="' + $statusBadgeClass + '">' + $last.Status + '</span></a>'

        $issueText = $job.LastIssueText
        $issueCell = if ($job.LastIssueTime) {
            '<a href="' + $job.IssueAnchorHref + '">' + (Html-Encode $issueText) + '</a>'
        } else {
            (Html-Encode $issueText)
        }

        $row = '<tr>' +
            '<td><a href="' + $job.JobAnchorHref + '">' + (Html-Encode $job.JobName) + '</a></td>' +
            '<td><a href="' + $job.JobAnchorHref + '">' + $job.TotalRuns + '</a></td>' +
            '<td><a href="' + $job.SuccessAnchorHref + '">' + $job.SuccessCount + '</a></td>' +
            '<td><a href="' + $job.WarningAnchorHref + '">' + $job.WarningCount + '</a></td>' +
            '<td><a href="' + $job.FailureAnchorHref + '">' + $job.FailureCount + '</a></td>' +
            '<td>' + $issueCell + '</td>' +
            '<td><a href="' + $job.JobAnchorHref + '">' + (Html-Encode $job.AvgIntervalText) + '</a></td>' +
            '<td><a href="' + $job.JobAnchorHref + '">' + (Html-Encode $job.PredictedNextText) + '</a></td>' +
            '<td><a href="' + $job.LastRunAnchorHref + '">' + (Html-Encode $lastStartText) + '</a></td>' +
            '<td>' + $lastStatusHtml + '</td>' +
            '</tr>'

        $null = $html.AppendLine($row)
    }
    $null = $html.AppendLine('</table>')

    # Details per job (kept as in your version)
    $maxSuccessLinesPerRun = 300
    $maxWarningLinesPerRun = 800
    $maxFailureLinesPerRun = 1000

    foreach ($job in ($jobSummaries | Sort-Object JobName)) {
        $includedRuns = @($job.IncludedRuns)
        $anchorId = New-JobAnchorId -JobName $job.JobName

        $null = $html.AppendLine('<h2 id="' + $anchorId + '">Job: ' + (Html-Encode $job.JobName) + '</h2>')
        $null = $html.AppendLine('<div class="summary-row">')
        $null = $html.AppendLine('<span><strong>Total Runs:</strong> ' + $job.TotalRuns + '</span>')
        $null = $html.AppendLine('<span><strong>Success:</strong> ' + $job.SuccessCount + '</span>')
        $null = $html.AppendLine('<span><strong>Warnings:</strong> ' + $job.WarningCount + '</span>')
        $null = $html.AppendLine('<span><strong>Failures:</strong> ' + $job.FailureCount + '</span>')
        $null = $html.AppendLine('<span><strong>Avg Interval:</strong> ' + (Html-Encode $job.AvgIntervalText) + '</span>')
        $null = $html.AppendLine('<span><strong>Predicted Next Run:</strong> ' + (Html-Encode $job.PredictedNextText) + '</span>')
        $null = $html.AppendLine('</div>')

        if ((Get-CountSafe $includedRuns) -eq 0) {
            $null = $html.AppendLine('<p>No runs included for this job.</p>')
            continue
        }

        $hiddenSuccessCount = $job.HiddenSuccessCount
        if ($hiddenSuccessCount -gt 0) {
            $null = $html.AppendLine('<p class="small">' + $hiddenSuccessCount + ' older successful run(s) omitted from details.</p>')
        }

        $failureRuns = @($includedRuns | Where-Object { $_.Status -eq 'Failure' } | Sort-Object StartTime -Descending)
        $extraFailureRuns = @()
        if ((Get-CountSafe $failureRuns) -gt 1) { $extraFailureRuns = $failureRuns[1..($failureRuns.Count - 1)] }

        $null = $html.AppendLine('<h3>Included Runs (most recent first)</h3>')

        foreach ($run in ($includedRuns | Sort-Object StartTime -Descending)) {
            $startText = if ($run.StartTime) { $run.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Unknown' }
            $endText   = if ($run.EndTime) { $run.EndTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Open-ended' }
            $durText   = if ($run.Duration) { Format-TimeSpanShort -Span $run.Duration } else { 'N/A' }

            $badgeClass = 'badge'
            switch ($run.Status) {
                'Success' { $badgeClass += ' badge-success' }
                'Warning' { $badgeClass += ' badge-warning' }
                'Failure' { $badgeClass += ' badge-failure' }
            }

            $summaryHtml = Html-Encode ("Run starting {0} (Status: {1}, Duration: {2})" -f $startText, $run.Status, $durText)
            $anchorAttr = if ($run.PSObject.Properties['AnchorId']) { ' id="' + $run.AnchorId + '"' } else { '' }

            $null = $html.AppendLine('<details' + $anchorAttr + '>')
            $null = $html.AppendLine('<summary>' + $summaryHtml + ' &nbsp; <span class="' + $badgeClass + '">' + $run.Status + '</span></summary>')
            $null = $html.AppendLine('<p class="small"><strong>Start:</strong> ' + $startText + ' &nbsp; | &nbsp; <strong>End:</strong> ' + $endText + ' &nbsp; | &nbsp; <strong>Duration:</strong> ' + $durText + '</p>')

            $linesToUse = $run.Lines
            $lineCount = Get-CountSafe $linesToUse

            if ($lineCount -gt 0) {
                $normalizedLines = @($linesToUse | ForEach-Object { if ($_ -ne $null) { [string]$_ } } | Where-Object { $_ -ne '' })
                $linesToUse = $normalizedLines
                $lineCount = $normalizedLines.Count

                if ($lineCount -gt 0) {
                    $maxLines = switch ($run.Status) {
                        'Success' { $maxSuccessLinesPerRun }
                        'Warning' { $maxWarningLinesPerRun }
                        'Failure' { $maxFailureLinesPerRun }
                        default   { $maxSuccessLinesPerRun }
                    }
                    $linesToUse = Get-TrimmedLinesForRun -Lines $linesToUse -MaxLines $maxLines
                    $lineCount = Get-CountSafe $linesToUse
                }
            }

            $linesArray = @($linesToUse)
            $primaryIssue = if ($lineCount -gt 0) { Find-PrimaryIssueLine -Lines $linesArray } else { $null }

            if ($primaryIssue) {
                $issueLineNumber = $primaryIssue.Index + 1
                $issueSnippet = $primaryIssue.Line
                if ($issueSnippet.Length -gt 120) { $issueSnippet = $issueSnippet.Substring(0,117) + '...' }
                $issueAnchorId = if ($run.PSObject.Properties['AnchorId']) { $run.AnchorId + '-issue' } else { 'run-issue-' + $issueLineNumber }

                $null = $html.AppendLine('<p class="small">Primary issue line: <a href="#' + $issueAnchorId + '">line ' + $issueLineNumber + '</a> &mdash; <code>' + (Html-Encode $issueSnippet) + '</code></p>')
            }

            if ($run.Status -eq 'Failure' -and ($extraFailureRuns -contains $run)) {
                $null = $html.AppendLine('<p class="small">Additional failure run; log details omitted to keep this report compact.</p>')
                $null = $html.AppendLine('</details>')
                continue
            }

            if ($lineCount -gt 0) {
                $sb = New-Object System.Text.StringBuilder
                for ($x = 0; $x -lt $lineCount; $x++) {
                    $encoded = Highlight-StatusText (Html-Encode $linesArray[$x])
                    if ($primaryIssue -and $x -eq $primaryIssue.Index) {
                        $issueAnchorId = if ($run.PSObject.Properties['AnchorId']) { $run.AnchorId + '-issue' } else { 'run-issue-' + ($x + 1) }
                        $null = $sb.Append('<a id="' + $issueAnchorId + '"></a>')
                    }
                    $null = $sb.Append($encoded)
                    if ($x -lt $lineCount - 1) { $null = $sb.Append([Environment]::NewLine) }
                }
                $null = $html.AppendLine('<pre>' + $sb.ToString() + '</pre>')
            }
            else {
                $null = $html.AppendLine('<p class="small">No log output captured for this run.</p>')
            }

            $null = $html.AppendLine('</details>')
        }
    }

    $null = $html.AppendLine('</body></html>')

    $dir = Split-Path -Parent $OutputHtml
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [IO.File]::WriteAllText($OutputHtml, $html.ToString(), [Text.Encoding]::UTF8)

    if (-not $NoOpen) { Start-Process $OutputHtml | Out-Null }

    [PSCustomObject]@{
        OutputHtml     = $OutputHtml
        QuickModeUsed  = $usingQuick
        FileSizeMB     = $fileSizeMB
        PercentOfLines = $percentOfLines
    }
}

# ---------------- Entry point / switch handling ----------------
$effectiveNoOpen = $NoOpen -or $Silent

if ($AllLogs) {
    $folder = $null

    if ($LogPath) {
        if (Test-Path -LiteralPath $LogPath -PathType Container) { $folder = $LogPath }
        elseif (Test-Path -LiteralPath $LogPath -PathType Leaf) { $folder = Split-Path -Parent $LogPath }
        else { $folder = $DefaultLogFolder }
    }
    else {
        $folder = $DefaultLogFolder
    }

    if (-not (Test-Path -LiteralPath $folder -PathType Container)) { throw "Log folder not found: $folder" }

    $logs = @(Get-ChildItem -LiteralPath $folder -Filter '*.log' -File -ErrorAction SilentlyContinue | Sort-Object Name)
    if (-not $logs -or (Get-CountSafe $logs) -eq 0) { throw "No .log files found in: $folder" }

    foreach ($lf in $logs) {
        $baseName = [IO.Path]::GetFileNameWithoutExtension($lf.Name)
        $safeBase = ($baseName -replace '[^a-zA-Z0-9\-]+','-').Trim('-')
        if (-not $safeBase) { $safeBase = 'log' }
        $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
        $outName = "Job-Analysis-{0}-{1}.html" -f $safeBase, $stamp
        $outPath = Join-Path $ExportPath $outName

        # -AllLogs forces full dataset
        Analyze-LogFile -LogPath $lf.FullName -OutputHtml $outPath -NoOpen:$true -FullDataset | Out-Null
    }

    exit 0
}

# Single-log modes (menu or direct)
if (-not $LogPath) {
    if ($effectiveNoOpen -and (Test-Path -LiteralPath $DefaultLogFile -PathType Leaf)) {
        $LogPath = $DefaultLogFile
    }
    else {
        $LogPath = Select-LogFile
        if (-not $LogPath) { exit 0 }
    }
}
else {
    # FIX: if user passed a folder here, auto-pick cybercns.log or first *.log
    if (Test-Path -LiteralPath $LogPath -PathType Container) {
        $LogPath = Resolve-LogPathToFile -Path $LogPath
    }
}

$result = Analyze-LogFile -LogPath $LogPath -OutputHtml $OutputHtml -NoOpen:$effectiveNoOpen

if ($result -and $result.QuickModeUsed -and -not $effectiveNoOpen -and -not $AllLogs -and -not $Silent) {
    Write-Host ""
    Write-Host ("[SUMMARY] Quick mode analyzed ~3 MB (~{0}% of lines) of a {1} MB log." -f $result.PercentOfLines, $result.FileSizeMB)
    $choice = Read-Host "Run full-dataset analysis now? (Y/N)"
    if ($choice.ToUpper() -eq 'Y') {
        Analyze-LogFile -LogPath $LogPath -NoOpen:$effectiveNoOpen -FullDataset | Out-Null
    }
}

exit 0
