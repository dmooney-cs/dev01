<# ==================================================================================================
  Windows-Update-Details.ps1
  ConnectSecure Technicians Toolbox

  VERSION: v3.1 – TableView + KB Column + ExportOnly Mode (Silent-fixed)

  CHANGE (per request):
    - All interactive prompts now remind techs: "(press Enter after selection/entry)"
    - -ExportOnly remains COMPLETELY silent (no header, no output, no prompts)

  DESCRIPTION:
     Collects Windows Update history via osquery and:

       • Default: Block view (per-update blocks with details)
       • -TableView  : Compact table with KB, InstallDate, Name, ResultCode, ErrorCode, Operation, UpdateID
       • -ExportOnly : Run osquery, save JSON/CSV only, NO screen output, NO prompts/pauses

  SWITCHES:
     -TableView     Show a compact table (KB + metadata), most recent first
     -ExportOnly    Export JSON/CSV only, silent (no header, no output, no prompts)

==================================================================================================#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$TableView,
    [switch]$ExportOnly
)

# -------------------------------------------------------------------------------------------------
# Core Settings
# -------------------------------------------------------------------------------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# Silent mode flag (must be completely quiet)
$script:Silent = [bool]$ExportOnly

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot        = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot        = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch       = Join-Path $ExportRoot 'OSQuery-WindowsUpdates'
$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = $ExportPatch

# -------------------------------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------------------------------
function Write-UI {
    param(
        [string]$Message = "",
        [ConsoleColor]$ForegroundColor = [ConsoleColor]::Gray
    )
    if ($script:Silent) { return }
    if ($Message -eq "") { Write-Host "" }
    else { Write-Host $Message -ForegroundColor $ForegroundColor }
}

function Clear-UI {
    if ($script:Silent) { return }
    try { Clear-Host } catch {}
}

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolders {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
}

function Get-IsAdmin {
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    param([string]$Message="Press any key to continue... (press Enter after selection)")
    if ($script:Silent) { return }
    try {
        Write-Host ""
        Write-Host $Message -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue (press Enter after selection)"
    }
}

function Show-Header {
    param([string]$Title="OSQuery - Windows Update Details")
    if ($script:Silent) { return }

    Clear-UI
    $isAdmin  = Get-IsAdmin
    $HostName = $env:COMPUTERNAME
    $UserName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $HostName,$UserName,($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

function Get-WindowWidth {
    try {
        $raw = $Host.UI.RawUI
        if ($raw -and $raw.BufferSize.Width -gt 0) { return $raw.BufferSize.Width }
        if ($raw -and $raw.WindowSize.Width -gt 0) { return $raw.WindowSize.Width }
        return 120
    } catch { return 120 }
}

function Write-LabelLine {
    param(
        [string]$Label,
        [string]$Value,
        [int]$LabelWidth=14
    )
    if ($script:Silent) { return }
    $lbl = ($Label + ":").PadRight($LabelWidth)
    Write-Host ("{0} {1}" -f $lbl,$Value) -ForegroundColor Gray
}

# Convert osquery epoch seconds -> DateTime
function Convert-OsqEpochToDateTime {
    param($Value)
    if ($null -eq $Value -or $Value -eq "") { return $null }
    try {
        $epoch = [int64]$Value
        return [DateTimeOffset]::FromUnixTimeSeconds($epoch).LocalDateTime
    } catch { return $null }
}

# -------------------------------------------------------------------------------------------------
# OSQuery
# -------------------------------------------------------------------------------------------------
function Initialize-OsqOutput {
    Ensure-ExportFolders
    Ensure-Directory -Path $Global:OsqOutRoot
}

function Test-OsqueryPresent {
    if (-not (Test-Path -LiteralPath $Global:OsqBinPath)) {
        # ExportOnly must be completely silent
        if (-not $script:Silent) {
            Write-Host ""
            Write-Host ("osqueryi.exe not found at: {0}" -f $Global:OsqBinPath) -ForegroundColor Red
            Pause-Script "Press any key to return... (press Enter after selection)"
        }
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory)][string]$Sql,
        [Parameter(Mandatory)][string]$BaseName
    )

    Initialize-OsqOutput

    $ts       = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName+"_"+$ts+".json")
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName+"_"+$ts+".csv")

    if (-not $script:Silent) {
        Write-Host ""
        Write-Host "Running osquery query:" -ForegroundColor Cyan
        Write-Host ("  {0}" -f $Sql) -ForegroundColor DarkGray
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $Global:OsqBinPath
    $psi.Arguments              = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    # In silent mode: never print stderr
    if (-not $script:Silent) {
        if ($stderr -and $stderr.Trim().Length -gt 0) {
            Write-Host "osquery stderr:" -ForegroundColor Yellow
            Write-Host ("  {0}" -f $stderr) -ForegroundColor DarkYellow
        }
    }

    if (-not $stdout) {
        if (-not $script:Silent) {
            Write-Host "No output received from osquery." -ForegroundColor Red
        }
        return @()
    }

    # Always save JSON
    try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    # Export CSV if rows exist
    try {
        if (@($objs).Count -gt 0) {
            $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
            if (-not $script:Silent) {
                Write-Host ""
                Write-Host "Saved:" -ForegroundColor Green
                Write-Host ("  JSON: {0}" -f $jsonPath) -ForegroundColor Green
                Write-Host ("  CSV : {0}" -f $csvPath)  -ForegroundColor Green
            }
        } else {
            if (-not $script:Silent) {
                Write-Host ("No rows returned. JSON saved: {0}" -f $jsonPath) -ForegroundColor DarkCyan
            }
        }
    } catch {}

    return $objs
}

# -------------------------------------------------------------------------------------------------
# Renderer (block view, tolerant schema)
# -------------------------------------------------------------------------------------------------
function Render-UpdateBlocks {
    param(
        [Parameter(Mandatory)][object[]]$Items,
        [int]$PageSize=10
    )

    if ($script:Silent) { return }

    if (-not $Items -or @($Items).Count -eq 0) {
        Write-Host "No update history to display." -ForegroundColor Yellow
        return
    }

    $i          = 0
    $total      = [int]@($Items).Count
    $labelWidth = 14

    while ($i -lt $total) {
        $batchEnd = [Math]::Min($i + $PageSize, $total)

        for ($j = $i; $j -lt $batchEnd; $j++) {
            $row   = $Items[$j]
            $date  = if ($row.PSObject.Properties.Name -contains 'date')  { $row.date }  else { $null }
            $title = if ($row.PSObject.Properties.Name -contains 'title') { $row.title } else { $null }

            $op     = if ($row.PSObject.Properties.Name -contains 'operation')      { $row.operation }      else { "" }
            $result = if ($row.PSObject.Properties.Name -contains 'result_code')    { $row.result_code }    else { "" }
            $err    = if ($row.PSObject.Properties.Name -contains 'error_code')     { $row.error_code }     else { "" }
            $url    = if ($row.PSObject.Properties.Name -contains 'support_url')    { $row.support_url }    else { "" }
            $srvsel = if ($row.PSObject.Properties.Name -contains 'server_selection'){ $row.server_selection } else { "" }
            $updId  = if ($row.PSObject.Properties.Name -contains 'update_id')      { $row.update_id }      else { "" }
            $hres   = if ($row.PSObject.Properties.Name -contains 'hresult')        { $row.hresult }        else { "" }
            $svcId  = if ($row.PSObject.Properties.Name -contains 'service_id')     { $row.service_id }     else { "" }
            $appId  = if ($row.PSObject.Properties.Name -contains 'client_app_id')  { $row.client_app_id }  else { "" }
            $desc   = if ($row.PSObject.Properties.Name -contains 'description')    { $row.description }    else { "" }

            $dateText  = if ($date)  { [string]$date }  else { "(no date)" }
            $titleText = if ($title) { [string]$title } else { "(no title)" }

            $win = Get-WindowWidth
            $h   = "-- $dateText | $titleText "
            if ($h.Length -gt $win) {
                $h = $h.Substring(0,[Math]::Max(0,$win-2))+" "
            }
            $divider = $h + ("-" * [Math]::Max(0,$win - $h.Length))
            Write-Host $divider -ForegroundColor Cyan

            if ($op)     { Write-LabelLine -Label "Operation"   -Value ([string]$op)     -LabelWidth $labelWidth }
            if ($result) { Write-LabelLine -Label "ResultCode"  -Value ([string]$result) -LabelWidth $labelWidth }
            if ($err)    { Write-LabelLine -Label "ErrorCode"   -Value ([string]$err)    -LabelWidth $labelWidth }
            if ($url)    { Write-LabelLine -Label "SupportURL"  -Value ([string]$url)    -LabelWidth $labelWidth }
            if ($srvsel) { Write-LabelLine -Label "ServerSel"   -Value ([string]$srvsel) -LabelWidth $labelWidth }
            if ($updId)  { Write-LabelLine -Label "UpdateID"    -Value ([string]$updId)  -LabelWidth $labelWidth }
            if ($hres)   { Write-LabelLine -Label "HResult"     -Value ([string]$hres)   -LabelWidth $labelWidth }
            if ($svcId)  { Write-LabelLine -Label "ServiceID"   -Value ([string]$svcId)  -LabelWidth $labelWidth }
            if ($appId)  { Write-LabelLine -Label "ClientApp"   -Value ([string]$appId)  -LabelWidth $labelWidth }
            if ($desc)   { Write-LabelLine -Label "Description" -Value ([string]$desc)   -LabelWidth $labelWidth }
            Write-Host ""
        }

        $i = $batchEnd
        if ($i -lt $total) {
            $ans = (Read-Host "[ENTER] next 10  |   [A] show ALL   |   [Q] back (press Enter after selection)").Trim()
            switch -regex ($ans) {
                '^(?i)q$' { break }
                '^(?i)a$' { $PageSize = [int]($total - $i) }
                default   { }
            }
        }
    }
}

# -------------------------------------------------------------------------------------------------
# Table view renderer (with real DateTime + KB column)
# -------------------------------------------------------------------------------------------------
function Show-TableView {
    param(
        [Parameter(Mandatory)][object[]]$Items
    )

    if ($script:Silent) { return }

    if (-not $Items -or @($Items).Count -eq 0) {
        Write-Host "No update history to display." -ForegroundColor Yellow
        return
    }

    $width = Get-WindowWidth
    Write-Host ""
    Write-Host "Windows Update History (Most Recent First) - Table View" -ForegroundColor Cyan
    Write-Host ("-" * [Math]::Min($width,120)) -ForegroundColor Cyan

    $sorted = $Items | Sort-Object -Property @{
        Expression = {
            if ($_.PSObject.Properties.Name -contains 'date') {
                Convert-OsqEpochToDateTime $_.date
            } else {
                Get-Date 0
            }
        }
        Descending = $true
    }

    $sorted |
        Select-Object `
            @{Name='KB';Expression={
                $title = if ($_.PSObject.Properties.Name -contains 'title') { [string]$_.title } else { '' }
                if (-not $title) { return '' }
                $m = [regex]::Match($title,'KB\d+')
                if ($m.Success) { $m.Value } else { '' }
            }},
            @{Name='InstallDate';Expression={
                if ($_.PSObject.Properties.Name -contains 'date') {
                    $dt = Convert-OsqEpochToDateTime $_.date
                    if ($dt) { $dt.ToString('yyyy-MM-dd HH:mm') } else { '' }
                } else { '' }
            }},
            @{Name='Name';Expression={
                if ($_.PSObject.Properties.Name -contains 'title') { $_.title } else { '' }
            }},
            @{Name='ResultCode';Expression={ if ($_.PSObject.Properties.Name -contains 'result_code') { $_.result_code } else { '' } }},
            @{Name='ErrorCode';Expression={ if ($_.PSObject.Properties.Name -contains 'error_code') { $_.error_code } else { '' } }},
            @{Name='Operation';Expression={ if ($_.PSObject.Properties.Name -contains 'operation') { $_.operation } else { '' } }},
            @{Name='UpdateID';Expression={ if ($_.PSObject.Properties.Name -contains 'update_id') { $_.update_id } else { '' } }} |
        Format-Table -AutoSize | Out-Host
}

# -------------------------------------------------------------------------------------------------
# Main
# -------------------------------------------------------------------------------------------------
if (-not $script:Silent) {
    Show-Header "OSQuery - Windows Update Details"
}

if (-not (Test-OsqueryPresent)) {
    return
}

$sql = @'
SELECT * FROM windows_update_history
ORDER BY date DESC;
'@

# Always run osquery / export
$objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Windows_Update_History'

# EXPORT ONLY: absolutely no output, no pause
if ($ExportOnly) {
    return
}

# Nothing to show
if (@($objs).Count -eq 0) {
    Write-Host "No update history returned by osquery." -ForegroundColor Yellow
    Pause-Script "Press any key to return... (press Enter after selection)"
    return
}

# Normalize schema (carry all properties, but keep stable ordering for blocks)
$preferredOrder = @(
    'date','title','operation','result_code','error_code',
    'support_url','server_selection','update_id',
    'hresult','service_id','client_app_id','description'
)

$norm = foreach ($o in $objs) {
    $props = @{}
    foreach ($k in $preferredOrder) {
        if ($o.PSObject.Properties.Name -contains $k) { $props[$k] = $o.$k }
    }
    foreach ($k in $o.PSObject.Properties.Name) {
        if (-not $props.ContainsKey($k)) { $props[$k] = $o.$k }
    }
    [PSCustomObject]$props
}

if ($TableView) {
    Show-TableView -Items $norm
    Pause-Script "Press any key to continue... (press Enter after selection)"
} else {
    Render-UpdateBlocks -Items $norm -PageSize 10
    Pause-Script "Press any key to continue... (press Enter after selection)"
}