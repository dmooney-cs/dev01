# Machine-Utilities.ps1 (standalone; fixes Pause-Script error and aligns export paths)

<# =====================================================================
  Machine-Utilities.ps1
  Collects system utilities info: Services and Disk Space
  - Self-contained: includes Show-Header, Ensure-ExportFolder, Pause-Script
  - Exports to C:\\CS-Toolbox-TEMP\\Collected-Info\\Utilities
  - Writes three services CSVs (All / Running / Stopped) + one disk CSV
===================================================================== #>

# --- Utility Functions ---
function Show-Header {
    param([string]$Title)
    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host " $Title" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Info { param([string]$Message) Write-Host "[INFO]  $Message" -ForegroundColor Cyan }
function Write-Ok   { param([string]$Message) Write-Host "[OK]    $Message" -ForegroundColor Green }
function Write-Err  { param([string]$Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

function Ensure-ExportFolder { param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Pause-Script {
    param([string]$Prompt = "Press Enter to return to the menu...")
    try { [void](Read-Host $Prompt) } catch { Start-Sleep -Seconds 1 }
}

function Get-Timestamp { (Get-Date).ToString('yyyyMMdd_HHmmss') }

# --- Output Roots ---
$OutRoot = "C:\\CS-Toolbox-TEMP"
$OutDir  = Join-Path $OutRoot "Collected-Info\\Utilities"
Ensure-ExportFolder -Path $OutDir

# --- Data Collectors ---
function Export-ServicesCsvs {
    try {
        $ts = Get-Timestamp
        $allPath     = Join-Path $OutDir ("Services_All_$ts.csv")
        $runningPath = Join-Path $OutDir ("Services_Running_$ts.csv")
        $stoppedPath = Join-Path $OutDir ("Services_Stopped_$ts.csv")

        $cols = 'Name','DisplayName','Status','StartType','ServiceType','CanPauseAndContinue','CanStop'
        $services = Get-Service | Select-Object $cols
        $services | Export-Csv -Path $allPath -NoTypeInformation -Encoding UTF8
        $services | Where-Object {$_.Status -eq 'Running'} | Export-Csv -Path $runningPath -NoTypeInformation -Encoding UTF8
        $services | Where-Object {$_.Status -eq 'Stopped'} | Export-Csv -Path $stoppedPath -NoTypeInformation -Encoding UTF8

        Write-Ok "Saved:"; Write-Host "  $allPath"; Write-Host "  $runningPath"; Write-Host "  $stoppedPath"
    } catch { Write-Err "Failed to export services: $($_.Exception.Message)" }
    Pause-Script
}

function Export-DiskCsv {
    try {
        $ts = Get-Timestamp
        $diskPath = Join-Path $OutDir ("DiskSpace_$ts.csv")
        $drives = Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }
        $rows = $drives | ForEach-Object {
            $size = [double]$_.Size
            $free = [double]$_.FreeSpace
            [pscustomobject]@{
                Drive       = $_.DeviceID
                Label       = $_.VolumeName
                FileSystem  = $_.FileSystem
                SizeGB      = if ($size) { [math]::Round($size/1GB,2) } else { 0 }
                UsedGB      = if ($size -and $free -ne $null) { [math]::Round(($size-$free)/1GB,2) } else { 0 }
                FreeGB      = if ($free -ne $null) { [math]::Round($free/1GB,2) } else { 0 }
                FreePercent = if ($size) { [math]::Round(($free/$size)*100,2) } else { 0 }
            }
        }
        $rows | Export-Csv -Path $diskPath -NoTypeInformation -Encoding UTF8
        Write-Ok "Saved:  $diskPath"
    } catch { Write-Err "Failed to export disk space: $($_.Exception.Message)" }
    Pause-Script
}

# --- Menu ---
while ($true) {
    Show-Header "Machine Utilities"
    Write-Host " [1] Services Report            - All / Running / Stopped"
    Write-Host " [2] Disk Space Report          - Size/Used/Free per drive"
    Write-Host " [Q] Back to CS Toolbox Main Menu"
    ""
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Export-ServicesCsvs }
        '2' { Export-DiskCsv }
        'Q' { & "C:\\CS-Toolbox-TEMP\\prod-01-01\\CS-Toolbox-Launcher.ps1"; break }
        'q' { & "C:\\CS-Toolbox-TEMP\\prod-01-01\\CS-Toolbox-Launcher.ps1"; break }
        default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
    }
}
