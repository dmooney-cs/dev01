<# =====================================================================================
 ValidationTool-AD.ps1
 ConnectSecure Technicians Toolbox - Active Directory Validation Tools

 Menu:
  [1] Users               - rich export (admins, pwd expiry, timestamps) -> CSV + JSON
  [2] Groups & OUs        - Groups (scope/category/managedBy) + OUs (empty, linked GPOs) -> CSV + JSON
  [3] Group Policy Objects- DC discovery, robust fallback -> CSV + JSON
  [4] Computers           - OS/version, last logon, password flags -> CSV + JSON
  [6] Run All (no prompts)- Runs 1-4 sequentially and writes a summary CSV

 Conventions:
  - Outputs: C:\CS-Toolbox-TEMP\Collected-Info\ActiveDirectory\*
  - PowerShell 5.1 compatible (no ?. or ??)
  - Silent progress inside collectors; on-screen table previews maintained
 ===================================================================================== #>

[CmdletBinding()]
param()

# -------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'
$OutRoot     = 'C:\CS-Toolbox-TEMP\Collected-Info\ActiveDirectory'

# -------------------------------------------------------------------------------------
# Load shared functions if present; provide local fallbacks if missing
# -------------------------------------------------------------------------------------
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try { . $commonPath } catch {
        Write-Host "ERROR: Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if (-not (Get-Command Ensure-Directory -ErrorAction SilentlyContinue)) {
    function Ensure-Directory {
        param([Parameter(Mandatory)][string]$Path)
        if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
    }
}
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
        Ensure-Directory -Path $ExportRoot
        Ensure-Directory -Path $ExportPatch
        Ensure-Directory -Path $ExportTLS
        Ensure-Directory -Path $ExportReg
        Ensure-Directory -Path $OutRoot
    }
}
if (-not (Get-Command Get-IsAdmin -ErrorAction SilentlyContinue)) {
    function Get-IsAdmin {
        try {
            $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
            $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
            return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
        } catch { return $false }
    }
}

# Non-interactive flag used by Run-All to suppress pauses
$script:NonInteractive = $false

# If a Pause-Script already exists, wrap it; else define ours
if (Get-Command Pause-Script -ErrorAction SilentlyContinue) {
    Set-Alias -Name Pause-Script-Original -Value Pause-Script -Force
    function Pause-Script {
        param([string]$Message = "Press any key to continue...")
        if ($script:NonInteractive) { return }
        Pause-Script-Original $Message
    }
} else {
    function Pause-Script {
        param([string]$Message = "Press any key to continue...")
        if ($script:NonInteractive) { return }
        try {
            Write-Host ""
            Write-Host $Message -ForegroundColor DarkGray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        } catch {
            $null = Read-Host ($Message -replace 'any key','ENTER')
        }
    }
}

if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = "Secondary Validation Tools")
        Clear-Host
        $isAdmin  = Get-IsAdmin
        $hostName = $env:COMPUTERNAME
        $userName = "$env:USERDOMAIN\$env:USERNAME"
        Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
        Write-Host ("========================================================") -ForegroundColor Cyan
        Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
        Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
        Write-Host ""
    }
}

# Ensure output roots exist
Ensure-ExportFolder
if (-not (Test-Path -LiteralPath $OutRoot)) { New-Item -ItemType Directory -Path $OutRoot -Force | Out-Null }

# -------------------------------------------------------------------------------------
# Module helpers
# -------------------------------------------------------------------------------------
function Ensure-AdModule {
    try {
        Import-Module ActiveDirectory -ErrorAction Stop | Out-Null
        return $true
    } catch {
        Write-Host "ActiveDirectory module not available. Install RSAT: Active Directory tools and retry." -ForegroundColor Yellow
        return $false
    }
}

# -------------------------------------------------------------------------------------
# [1] USERS - rich export (CSV + JSON)
# -------------------------------------------------------------------------------------
function Run-AdUsers {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Users"

    $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv  = Join-Path $OutRoot "AD_Users_$ts.csv"
    $json = Join-Path $OutRoot "AD_Users_$ts.json"

    $oldProgress = $global:ProgressPreference
    $global:ProgressPreference = 'SilentlyContinue'

    function Get-PasswordExpireDate([Microsoft.ActiveDirectory.Management.ADUser]$user){
        try {
            if ($null -eq $user) { return $null }
            if ($user.Enabled -and -not $user.PasswordNeverExpires -and $user.'msDS-UserPasswordExpiryTimeComputed' -gt 0) {
                try { return [datetime]::FromFileTime([int64]$user.'msDS-UserPasswordExpiryTimeComputed') } catch { return $null }
            }
            return $null
        } catch { return $null }
    }

    try {
        # Admin groups cache
        $domainAdmins = @()
        try {
            $domainAdmins = Get-ADGroupMember -Identity "Domain Admins" -Recursive |
                            Select-Object -ExpandProperty SamAccountName -ErrorAction Stop
        } catch {
            try {
                $daSid = (Get-ADDomain).DomainSID.Value + "-512"
                $domainAdmins = Get-ADGroupMember -Identity $daSid -Recursive |
                                Select-Object -ExpandProperty SamAccountName
            } catch { $domainAdmins = @() }
        }

        $enterpriseAdmins = @()
        try {
            $enterpriseAdmins = Get-ADGroupMember -Identity "Enterprise Admins" -Recursive |
                                Select-Object -ExpandProperty SamAccountName
        } catch { $enterpriseAdmins = @() }

        # Forest/dom context
        $forest = ""
        try { $forest = (Get-ADDomainController -ErrorAction Stop).Forest } catch {
            try { $forest = (Get-ADDomain -ErrorAction Stop).DNSRoot } catch { $forest = "" }
        }

        $props = @(
            'LockedOut','EmailAddress','Department','BadLogonCount','PasswordNeverExpires','PasswordExpired',
            'isCriticalSystemObject','PasswordNotRequired','CannotChangePassword','PasswordLastSet',
            'msDS-UserPasswordExpiryTimeComputed','Created','Modified','LogonCount','Enabled',
            'AccountExpirationDate','accountExpires','LastLogonTimestamp','LastLogonDate','MemberOf',
            'Office','DisplayName','SID','AccountLockoutTime','LastBadPasswordAttempt','DistinguishedName',
            'HomeDrive','Description','HomeDirectory','City','Country','ObjectGUID','UserPrincipalName','Name','SamAccountName'
        )

        $rows = foreach ($u in (Get-ADUser -Filter * -Properties $props)) {
            if ($null -eq $u) { continue }

            $llt = $null
            if ($u.LastLogonTimestamp -and $u.LastLogonTimestamp -ne 0) {
                $llt = [datetime]::FromFileTime([int64]$u.LastLogonTimestamp)
            }
            $acctExpire = $null
            if ($u.accountExpires -and $u.accountExpires -gt 0 -and $u.accountExpires -ne 9223372036854775807) {
                $acctExpire = [datetime]::FromFileTime([int64]$u.accountExpires)
            }
            $pwdExp = Get-PasswordExpireDate $u

            [pscustomobject]@{
                Name                     = $u.Name
                SamAccountName           = $u.SamAccountName
                UserPrincipalName        = $u.UserPrincipalName
                Domain                   = $forest
                Office                   = $u.Office
                LockedOut                = [bool]$u.LockedOut
                AccountLockoutTime       = $u.AccountLockoutTime
                ObjectSid                = $u.SID
                Mail                     = $u.EmailAddress
                Department               = $u.Department
                BadLogonCount            = $u.BadLogonCount
                ObjectGuid               = $u.ObjectGUID
                LastLogonTimestampDT     = $llt
                LastLogonDateDT          = $u.LastLogonDate
                LastBadPasswordAttemptDT = $u.LastBadPasswordAttempt
                PasswordNeverExpires     = [bool]$u.PasswordNeverExpires
                CriticalSystemObject     = [bool]$u.isCriticalSystemObject
                PasswordExpired          = [bool]$u.PasswordExpired
                PasswordNotRequired      = [bool]$u.PasswordNotRequired
                CannotChangePassword     = [bool]$u.CannotChangePassword
                PasswordLastSetDT        = $u.PasswordLastSet
                PasswordExpiryDT         = $pwdExp
                LogonCount               = $u.LogonCount
                CreatedDT                = $u.Created
                ModifiedDT               = $u.Modified
                AccountExpiresDT         = $acctExpire
                AccountDisabled          = -not [bool]$u.Enabled
                MemberOf                 = @($u.MemberOf)
                DisplayName              = $u.DisplayName
                DistinguishedName        = $u.DistinguishedName
                DomainAdmin              = $domainAdmins -contains $u.SamAccountName
                EnterpriseAdmin          = $enterpriseAdmins -contains $u.SamAccountName
                BuiltInAdmin             = ($u.Name -eq 'Administrator')
                HomeDrive                = $u.HomeDrive
                HomeDirectory            = $u.HomeDirectory
                Description              = $u.Description
                City                     = $u.City
                Country                  = $u.Country

                LastLogonTimestampText   = $((if ($llt) { $llt.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                LastLogonDateText        = $((if ($u.LastLogonDate) { $u.LastLogonDate.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                LastBadPasswordText      = $((if ($u.LastBadPasswordAttempt) { $u.LastBadPasswordAttempt.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                PasswordLastSetText      = $((if ($u.PasswordLastSet) { $u.PasswordLastSet.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                PasswordExpiryText       = $((if ($pwdExp) { $pwdExp.ToString('yyyy-MM-dd HH:mm:ss') } else { '-' }))
                CreatedText              = $((if ($u.Created) { $u.Created.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                ModifiedText             = $((if ($u.Modified) { $u.Modified.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                AccountExpiresText       = $((if ($acctExpire) { $acctExpire.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Never Expires' }))

                LastLogonTimestampISO    = $((if ($llt) { $llt.ToString('o') } else { $null }))
                LastLogonDateISO         = $((if ($u.LastLogonDate) { $u.LastLogonDate.ToString('o') } else { $null }))
                LastBadPasswordISO       = $((if ($u.LastBadPasswordAttempt) { $u.LastBadPasswordAttempt.ToString('o') } else { $null }))
                PasswordLastSetISO       = $((if ($u.PasswordLastSet) { $u.PasswordLastSet.ToString('o') } else { $null }))
                PasswordExpiryISO        = $((if ($pwdExp) { $pwdExp.ToString('o') } else { $null }))
                CreatedISO               = $((if ($u.Created) { $u.Created.ToString('o') } else { $null }))
                ModifiedISO              = $((if ($u.Modified) { $u.Modified.ToString('o') } else { $null }))
                AccountExpiresISO        = $((if ($acctExpire) { $acctExpire.ToString('o') } else { $null }))
            }
        }

        # CSV (readable)
        $rows |
            Select-Object Name, SamAccountName, UserPrincipalName, Domain, DisplayName,
                          AccountDisabled, LockedOut, PasswordExpired, PasswordNeverExpires, PasswordNotRequired, CannotChangePassword,
                          DomainAdmin, EnterpriseAdmin, BuiltInAdmin,
                          LastLogonDateText, LastLogonTimestampText, LastBadPasswordText,
                          PasswordLastSetText, PasswordExpiryText, AccountExpiresText,
                          CreatedText, ModifiedText,
                          Department, Mail, Office, City, Country, DistinguishedName |
            Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8

        # JSON (ISO)
        $dataJson = @()
        foreach ($r in $rows) {
            $dataJson += @{
                name                      = $r.Name
                samaccountname            = $r.SamAccountName
                userprincipalname         = $r.UserPrincipalName
                domain                    = $r.Domain
                office                    = $r.Office
                lockout                   = $r.LockedOut
                accountLockoutTime        = $((if ($r.AccountLockoutTime) { $r.AccountLockoutTime.ToString('o') } else { $null }))
                objectsid                 = "$($r.ObjectSid)"
                mail                      = $r.Mail
                department                = $r.Department
                bad_logon_count           = $r.BadLogonCount
                objectguid                = "$($r.ObjectGuid)"
                lastlogontimestamppshell  = $r.LastLogonTimestampISO
                lastLogonDate             = $r.LastLogonDateISO
                lastBadPasswordAttempt    = $r.LastBadPasswordISO
                password_never_expires    = $r.PasswordNeverExpires
                is_critical_system_object = $r.CriticalSystemObject
                password_expired          = $r.PasswordExpired
                password_not_required     = $r.PasswordNotRequired
                cannot_change_password    = $r.CannotChangePassword
                pwdlastsettime            = $r.PasswordLastSetISO
                password_expiry_date      = $r.PasswordExpiryISO
                logonCount                = $r.LogonCount
                createdwhen               = $r.CreatedISO
                modifiedwhen              = $r.ModifiedISO
                account_expire_date       = $((if ($r.AccountExpiresISO) { $r.AccountExpiresISO } else { "Never Expires" }))
                account_disabled          = $r.AccountDisabled
                memberOf                  = $r.MemberOf
                displayName               = $r.DisplayName
                distinguishedname         = $r.DistinguishedName
                domainAdmin               = $r.DomainAdmin
                enterpriseAdmin           = $r.EnterpriseAdmin
                buildInAdmin              = $r.BuiltInAdmin
                homeDrive                 = $r.HomeDrive
                homeDirectory             = $r.HomeDirectory
                description               = $r.Description
                city                      = $r.City
                country                   = $r.Country
            }
        }
        @{ status = $true; data = $dataJson } |
            ConvertTo-Json -Depth 10 -Compress | Out-File -LiteralPath $json -Encoding UTF8

        # Screen
        $count = ($rows | Measure-Object).Count
        if ($count -gt 0) {
            Write-Host ("Users exported: {0}" -f $count) -ForegroundColor Green
            $rows | Select-Object Name, SamAccountName, AccountDisabled, DomainAdmin, LastLogonDateText |
                   Sort-Object Name | Format-Table -AutoSize
        } else {
            Write-Host "No users returned." -ForegroundColor Yellow
        }
        Write-Host "Saved:`n CSV : $csv`n JSON: $json" -ForegroundColor Green

    } catch {
        "" | Out-File -LiteralPath $csv -Encoding UTF8
        ConvertTo-Json -Depth 5 -Compress @{
            status     = $false
            msg        = $_.Exception.Message
            stackTrace = ($_ | Out-String)
        } | Out-File -LiteralPath $json -Encoding UTF8
        Write-Host "ERROR collecting users: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Wrote placeholder CSV and error JSON to:`n CSV : $csv`n JSON: $json" -ForegroundColor Yellow
    } finally {
        $global:ProgressPreference = $oldProgress
    }

    Pause-Script "Press any key to return to the menu..."
}

# -------------------------------------------------------------------------------------
# [2] GROUPS & OUs - merged export (Groups CSV; OUs CSV + JSON with linked GPOs)
# -------------------------------------------------------------------------------------
function Run-AdGroupsAndOUs {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Groups & OUs"

    $ts     = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csvGrp = Join-Path $OutRoot "AD_Groups_$ts.csv"
    $csvOU  = Join-Path $OutRoot "AD_OUs_$ts.csv"
    $jsonOU = Join-Path $OutRoot "AD_OUs_$ts.json"

    $oldProgress = $global:ProgressPreference
    $global:ProgressPreference = 'SilentlyContinue'

    # Try GroupPolicy for linked GPOs
    $hasGp = $false
    try { Import-Module GroupPolicy -ErrorAction Stop | Out-Null; $hasGp = $true } catch {
        Write-Host "GroupPolicy module not available; OU linked GPOs will be omitted." -ForegroundColor Yellow
    }

    try {
        # -------- Groups --------
        $propsG = 'Name','GroupCategory','GroupScope','Description','WhenCreated','ManagedBy'
        $groups = Get-ADGroup -Filter * -Properties $propsG
        if ($groups) {
            $groups | Select-Object $propsG | Export-Csv -LiteralPath $csvGrp -NoTypeInformation -Encoding UTF8
            Write-Host ("Groups exported: {0}" -f ($groups.Count)) -ForegroundColor Green
            $groups | Select-Object Name, GroupScope, GroupCategory | Sort-Object Name | Format-Table -AutoSize
            Write-Host "Saved (Groups CSV): $csvGrp" -ForegroundColor Green
        } else {
            Write-Host "No groups returned." -ForegroundColor Yellow
            "" | Out-File -LiteralPath $csvGrp -Encoding UTF8
        }

        # -------- OUs --------
        $forest = ""
        try { $forest = (Get-ADDomainController -ErrorAction Stop).Forest } catch {
            try { $forest = (Get-ADDomain -ErrorAction Stop).DNSRoot } catch { $forest = "" }
        }

        $propsOU = @('Name','ManagedBy','Created','Modified','DistinguishedName','ObjectGUID')
        $ous     = Get-ADOrganizationalUnit -Filter * -Properties $propsOU

        # Precompute linked GPOs per OU DN
        $linkedByDn = @{}
        if ($hasGp) {
            foreach ($ou in $ous) {
                if ($null -eq $ou) { continue }
                $dn = $ou.DistinguishedName
                try {
                    $inh = Get-GPInheritance -Target $dn -ErrorAction Stop
                    $gpolinks = @()
                    foreach ($l in ($inh.GpoLinks | Where-Object { $_ -ne $null })) {
                        $gpolinks += [pscustomobject]@{
                            Name     = $l.DisplayName
                            Enabled  = [bool]$l.Enabled
                            Enforced = [bool]$l.Enforced
                        }
                    }
                    $linkedByDn[$dn] = $gpolinks
                } catch { $linkedByDn[$dn] = @() }
            }
        }

        $ouRows = foreach ($o in $ous) {
            if ($null -eq $o) { continue }
            if ($o.DistinguishedName -notlike '*OU=*') { continue }

            $isEmpty = $false
            try {
                $child = Get-ADObject -SearchBase $o.DistinguishedName -SearchScope OneLevel -Filter * -ErrorAction Stop
                if (-not $child) { $isEmpty = $true }
            } catch { $isEmpty = $true }

            $linked = @()
            if ($hasGp -and $linkedByDn.ContainsKey($o.DistinguishedName)) { $linked = $linkedByDn[$o.DistinguishedName] }

            [pscustomobject]@{
                Domain               = $forest
                OUName               = $o.Name
                ManagedBy            = $o.ManagedBy
                CreatedDT            = $o.Created
                ModifiedDT           = $o.Modified
                DistinguishedName    = $o.DistinguishedName
                Guid                 = $o.ObjectGUID
                Empty                = [bool]$isEmpty
                LinkedGPOs           = $linked
                CreatedText          = $((if ($o.Created) { $o.Created.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                ModifiedText         = $((if ($o.Modified) { $o.Modified.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
            }
        }

        # OUs CSV
        $ouRows |
            Select-Object OUName, Domain, ManagedBy, Empty, CreatedText, ModifiedText, DistinguishedName, Guid |
            Export-Csv -LiteralPath $csvOU -NoTypeInformation -Encoding UTF8

        # OUs JSON (ISO + linked GPOs)
        $ouJson = @()
        foreach ($r in $ouRows) {
            $linkedGpoArr = @()
            foreach ($g in $r.LinkedGPOs) {
                $linkedGpoArr += @{ name = $g.Name; enabled = $g.Enabled; enforced = $g.Enforced }
            }
            $ouJson += @{
                domain            = $r.Domain
                ouName            = $r.OUName
                managedBy         = $((if ($r.ManagedBy) { $r.ManagedBy } else { "" }))
                ouCreated         = $((if ($r.CreatedDT) { $r.CreatedDT.ToString('o') } else { $null }))
                ouModified        = $((if ($r.ModifiedDT) { $r.ModifiedDT.ToString('o') } else { $null }))
                distinguishedName = $r.DistinguishedName
                guid              = "$($r.Guid)"
                empty             = $r.Empty
                linkedGPO         = $linkedGpoArr
            }
        }
        @{ status = $true; count = ($ouRows | Measure-Object).Count; data = $ouJson } |
            ConvertTo-Json -Depth 8 -Compress | Out-File -LiteralPath $jsonOU -Encoding UTF8

        # Screen summary for OUs
        $ouCnt = ($ouRows | Measure-Object).Count
        if ($ouCnt -gt 0) {
            Write-Host ("OUs exported: {0}" -f $ouCnt) -ForegroundColor Green
            $ouRows | Select-Object OUName, Empty, ManagedBy, ModifiedText |
                    Sort-Object OUName | Format-Table -AutoSize
        } else {
            Write-Host "No OUs returned." -ForegroundColor Yellow
        }
        Write-Host "Saved:`n Groups CSV : $csvGrp`n OUs CSV   : $csvOU`n OUs JSON  : $jsonOU" -ForegroundColor Green

    } catch {
        "" | Out-File -LiteralPath $csvGrp -Encoding UTF8
        "" | Out-File -LiteralPath $csvOU  -Encoding UTF8
        ConvertTo-Json -Depth 5 -Compress @{
            status     = $false
            msg        = $_.Exception.Message
            stackTrace = ($_ | Out-String)
        } | Out-File -LiteralPath $jsonOU -Encoding UTF8
        Write-Host "ERROR collecting Groups/OUs: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Wrote placeholder outputs to:`n $csvGrp`n $csvOU`n $jsonOU" -ForegroundColor Yellow
    } finally {
        $global:ProgressPreference = $oldProgress
    }

    Pause-Script "Press any key to return to the menu..."
}

# -------------------------------------------------------------------------------------
# [3] GPOs - DC discovery + CSV/JSON
# -------------------------------------------------------------------------------------
function Run-AdGpos {
    Show-Header "AD - Group Policy Objects"

    $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv  = Join-Path $OutRoot "AD_GPOs_$ts.csv"
    $json = Join-Path $OutRoot "AD_GPOs_$ts.json"

    $hasGp = $false
    try { Import-Module GroupPolicy -ErrorAction Stop | Out-Null; $hasGp = $true } catch {
        Write-Host "GroupPolicy module not available (RSAT: Group Policy Management). Export will be limited (no Get-GPO)." -ForegroundColor Yellow
    }
    if (-not $hasGp) {
        "" | Out-File -LiteralPath $csv -Encoding UTF8
        @{ status = $false; msg = "GroupPolicy module not available on this system."; data = @() } |
            ConvertTo-Json -Depth 5 -Compress | Out-File -LiteralPath $json -Encoding UTF8
        Write-Host "Saved empty GPO export (module missing):`n CSV : $csv`n JSON: $json" -ForegroundColor Yellow
        Pause-Script "Press any key to return to the menu..."
        return
    }

    $oldProgress = $global:ProgressPreference
    $global:ProgressPreference = 'SilentlyContinue'

    try {
        $gpoData = $null
        try {
            foreach ($ip in (Get-NetIPConfiguration)) {
                if ($null -eq $ip -or $null -eq $ip.IPv4Address) { continue }
                try {
                    $server = $ip.IPv4Address.IPAddress
                    if ([string]::IsNullOrWhiteSpace($server)) { continue }
                    $gpoData = Get-GPO -All -Server $server
                    if ($gpoData) { break }
                } catch { }
            }
        } catch { }

        if (-not $gpoData) {
            try { $gpoData = Get-GPO -All } catch { throw }
        }

        $gpos = @()
        foreach ($g in $gpoData) {
            if ($null -eq $g) { continue }
            $gpos += [pscustomobject]@{
                DisplayName       = $g.DisplayName
                Id                = $g.Id
                Path              = $g.Path
                DomainName        = $g.DomainName
                GpoStatus         = [string]$g.GpoStatus
                CreationTime      = $g.CreationTime
                ModificationTime  = $g.ModificationTime
                CreationTimeText  = $g.CreationTime.ToString('yyyy-MM-dd HH:mm:ss')
                ModificationText  = $g.ModificationTime.ToString('yyyy-MM-dd HH:mm:ss')
            }
        }

        # CSV
        $gpos |
            Select-Object DisplayName, Id, DomainName, GpoStatus, CreationTimeText, ModificationText, Path |
            Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8

        # JSON
        $dataJson = @()
        foreach ($x in $gpos) {
            $dataJson += @{
                guid            = $x.Id
                path            = $x.Path
                displayName     = $x.DisplayName
                domain          = $x.DomainName
                gpoStatus       = $x.GpoStatus
                gpoCreatedTime  = $x.CreationTime.ToString("o")
                gpoModifiedTime = $x.ModificationTime.ToString("o")
            }
        }
        @{ status = $true; data = $dataJson } |
            ConvertTo-Json -Depth 5 -Compress | Out-File -LiteralPath $json -Encoding UTF8

        if ($gpos.Count -gt 0) {
            Write-Host ("GPOs exported: {0}" -f $gpos.Count) -ForegroundColor Green
            $gpos | Select-Object DisplayName, GpoStatus, ModificationText |
                   Sort-Object DisplayName | Format-Table -AutoSize
        } else {
            Write-Host "No GPOs returned." -ForegroundColor Yellow
        }
        Write-Host "Saved:`n CSV : $csv`n JSON: $json" -ForegroundColor Green

    } catch {
        "" | Out-File -LiteralPath $csv -Encoding UTF8
        ConvertTo-Json -Depth 5 -Compress @{
            status     = $false
            msg        = $_.Exception.Message
            stackTrace = ($_ | Out-String)
        } | Out-File -LiteralPath $json -Encoding UTF8
        Write-Host "ERROR collecting GPOs: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Wrote placeholder CSV and error JSON to:`n CSV : $csv`n JSON: $json" -ForegroundColor Yellow
    } finally {
        $global:ProgressPreference = $oldProgress
    }

    Pause-Script "Press any key to return to the menu..."
}

# -------------------------------------------------------------------------------------
# [4] COMPUTERS - CSV + JSON
# -------------------------------------------------------------------------------------
function Run-AdComputers {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Computers"

    $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv  = Join-Path $OutRoot "AD_Computers_$ts.csv"
    $json = Join-Path $OutRoot "AD_Computers_$ts.json"

    $oldProgress = $global:ProgressPreference
    $global:ProgressPreference = 'SilentlyContinue'

    try {
        $forest = ""
        try { $forest = (Get-ADDomainController -ErrorAction Stop).Forest } catch {
            try { $forest = (Get-ADDomain -ErrorAction Stop).DNSRoot } catch { $forest = "" }
        }

        $props = @(
            'Name','DNSHostName','OperatingSystem','OperatingSystemVersion',
            'DistinguishedName','SamAccountName','Enabled','LastLogonTimestamp','LastLogonDate',
            'Created','Modified','LockedOut','PasswordExpired','PasswordLastSet',
            'PasswordNeverExpires','PasswordNotRequired'
        )

        $rows = foreach ($c in (Get-ADComputer -Filter * -Properties $props)) {
            if ($null -eq $c) { continue }

            $lltIso = $null
            if ($c.LastLogonTimestamp -and $c.LastLogonTimestamp -ne 0) {
                $lltIso = [datetime]::FromFileTime([int64]$c.LastLogonTimestamp)
            }

            [pscustomobject]@{
                Name                     = $c.Name
                Domain                   = $forest
                DNSHostName              = $c.DNSHostName
                OperatingSystem          = $c.OperatingSystem
                OperatingSystemVersion   = $c.OperatingSystemVersion
                DistinguishedName        = $c.DistinguishedName
                SamAccountName           = $c.SamAccountName
                Enabled                  = $c.Enabled
                LockedOut                = $c.LockedOut
                PasswordExpired          = $c.PasswordExpired
                PasswordNeverExpires     = $c.PasswordNeverExpires
                PasswordNotRequired      = $c.PasswordNotRequired
                LastLogonDateDT          = $c.LastLogonDate
                LastLogonTimestampDT     = $lltIso
                PasswordLastSetDT        = $c.PasswordLastSet
                CreatedDT                = $c.Created
                ModifiedDT               = $c.Modified

                LastLogonDateText        = $((if ($c.LastLogonDate) { $c.LastLogonDate.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                LastLogonTimestampText   = $((if ($lltIso) { $lltIso.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                PasswordLastSetText      = $((if ($c.PasswordLastSet) { $c.PasswordLastSet.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                CreatedText              = $((if ($c.Created) { $c.Created.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))
                ModifiedText             = $((if ($c.Modified) { $c.Modified.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }))

                LastLogonDateISO         = $((if ($c.LastLogonDate) { $c.LastLogonDate.ToString('o') } else { $null }))
                LastLogonTimestampISO    = $((if ($lltIso) { $lltIso.ToString('o') } else { $null }))
                PasswordLastSetISO       = $((if ($c.PasswordLastSet) { $c.PasswordLastSet.ToString('o') } else { $null }))
                CreatedISO               = $((if ($c.Created) { $c.Created.ToString('o') } else { $null }))
                ModifiedISO              = $((if ($c.Modified) { $c.Modified.ToString('o') } else { $null }))
            }
        }

        # CSV
        $rows |
            Select-Object Name, Domain, DNSHostName, OperatingSystem, OperatingSystemVersion,
                          Enabled, LockedOut, PasswordExpired, PasswordNeverExpires, PasswordNotRequired,
                          LastLogonDateText, LastLogonTimestampText, PasswordLastSetText,
                          CreatedText, ModifiedText, DistinguishedName, SamAccountName |
            Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8

        # JSON
        $dataJson = @()
        foreach ($r in $rows) {
            $dataJson += @{
                name                   = $r.Name
                domain                 = $r.Domain
                dnsHostName            = $r.DNSHostName
                osname                 = $r.OperatingSystem
                OperatingSystemVersion = $r.OperatingSystemVersion
                lastLogonTimestamp     = $r.LastLogonTimestampISO
                lastLogonDate          = $r.LastLogonDateISO
                distinguishedName      = $r.DistinguishedName
                samAccountName         = $r.SamAccountName
                enabled                = $r.Enabled
                whenCreated            = $r.CreatedISO
                whenModified           = $r.ModifiedISO
                lockedOut              = $r.LockedOut
                passwordExpired        = $r.PasswordExpired
                passwordLastSet        = $r.PasswordLastSetISO
                passwordNeverExpires   = $r.PasswordNeverExpires
                passwordNotRequired    = $r.PasswordNotRequired
            }
        }
        @{ status = $true; data = $dataJson } |
            ConvertTo-Json -Depth 5 -Compress | Out-File -LiteralPath $json -Encoding UTF8

        $count = ($rows | Measure-Object).Count
        if ($count -gt 0) {
            Write-Host ("Computers exported: {0}" -f $count) -ForegroundColor Green
            $rows | Select-Object Name, OperatingSystem, Enabled, LastLogonDateText |
                   Sort-Object Name | Format-Table -AutoSize
        } else {
            Write-Host "No computers returned." -ForegroundColor Yellow
        }
        Write-Host "Saved:`n CSV : $csv`n JSON: $json" -ForegroundColor Green

    } catch {
        "" | Out-File -LiteralPath $csv -Encoding UTF8
        ConvertTo-Json -Depth 5 -Compress @{
            status     = $false
            msg        = $_.Exception.Message
            stackTrace = ($_ | Out-String)
        } | Out-File -LiteralPath $json -Encoding UTF8
        Write-Host "ERROR collecting computers: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Wrote placeholder CSV and error JSON to:`n CSV : $csv`n JSON: $json" -ForegroundColor Yellow
    } finally {
        $global:ProgressPreference = $oldProgress
    }

    Pause-Script "Press any key to return to the menu..."
}

# -------------------------------------------------------------------------------------
# [6] RUN ALL - no prompts, writes a summary CSV
# -------------------------------------------------------------------------------------
function Run-AdAll {
    Show-Header "AD - Run All (no prompts)"
    $started = Get-Date
    $log = @()

    $script:NonInteractive = $true
    try {
        $steps = @(
            @{ Name = 'Users';        Fn = { Run-AdUsers } },
            @{ Name = 'Groups & OUs'; Fn = { Run-AdGroupsAndOUs } },
            @{ Name = 'GPOs';         Fn = { Run-AdGpos } },
            @{ Name = 'Computers';    Fn = { Run-AdComputers } }
        )

        foreach ($s in $steps) {
            Write-Host ("[STEP] {0}..." -f $s.Name) -ForegroundColor Cyan
            $t0 = Get-Date
            try {
                & $s.Fn
                $log += [pscustomobject]@{ Step = $s.Name; Status = 'OK';     Start = $t0; End = Get-Date }
            } catch {
                $log += [pscustomobject]@{ Step = $s.Name; Status = ('ERR: ' + $_.Exception.Message); Start = $t0; End = Get-Date }
            }
        }
    } finally {
        $script:NonInteractive = $false
    }

    $ended = Get-Date
    Write-Host ""
    Write-Host ("Completed all steps in {0:g}" -f ($ended - $started)) -ForegroundColor Green
    $log | Format-Table -AutoSize

    try {
        $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
        $summaryPath = Join-Path $OutRoot "AD_RunAll_Summary_$ts.csv"
        $log | Export-Csv -LiteralPath $summaryPath -NoTypeInformation -Encoding UTF8
        Write-Host "Summary saved: $summaryPath" -ForegroundColor Green
    } catch { }
}

# -------------------------------------------------------------------------------------
# Menu
# -------------------------------------------------------------------------------------
function Show-Menu {
    Show-Header "Active Directory Tools"
    Write-Host ""
    Write-Host " [1] Users               - Core attributes, last logon, password state" -ForegroundColor White
    Write-Host " [2] Groups & OUs        - Groups (scope/category) + OUs (empty, linked GPOs)" -ForegroundColor White
    Write-Host " [3] Group Policy Objects- Status, timestamps, domain" -ForegroundColor White
    Write-Host " [4] Computers           - OS/version, last logon, password flags" -ForegroundColor White
    Write-Host " [6] Run All (no prompts)- Runs 1-4 sequentially" -ForegroundColor Yellow
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# -------------------------------------------------------------------------------------
# Main loop
# -------------------------------------------------------------------------------------
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-AdUsers }
        '2' { Run-AdGroupsAndOUs }
        '3' { Run-AdGpos }
        '4' { Run-AdComputers }
        '6' { Run-AdAll }
        'Q' {
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path -LiteralPath $launcher) { & $launcher }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}