# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ============================
#  Active Directory Tool Menu
# ============================

$OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\ActiveDirectory'
if (-not (Test-Path $OutRoot)) {
    New-Item -Path $OutRoot -ItemType Directory | Out-Null
}

function Ensure-AdModule {
    # Try to load AD cmdlets; show a helpful note if missing (RSAT/AD module not installed)
    try {
        Import-Module ActiveDirectory -ErrorAction Stop | Out-Null
        return $true
    } catch {
        Write-Host "ActiveDirectory module not available. Install RSAT: Active Directory tools and retry." -ForegroundColor Yellow
        return $false
    }
}

function Run-AdUsers {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Users"
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv = Join-Path $OutRoot "AD_Users_$ts.csv"

    try {
        $props = 'SamAccountName','Name','Enabled','UserPrincipalName','WhenCreated','LastLogonDate','PasswordNeverExpires','PasswordLastSet','Description','MemberOf'
        $users = Get-ADUser -Filter * -Properties $props
        if ($users) {
            $users | Select-Object $props | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            Write-Host ("Users exported: {0}" -f ($users.Count)) -ForegroundColor Green
            $users | Select-Object SamAccountName, Enabled, LastLogonDate | Sort-Object SamAccountName | Format-Table -AutoSize
            Write-Host "Saved: $csv" -ForegroundColor Green
        } else {
            Write-Host "No users returned." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting users: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Run-AdGroups {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Groups"
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv = Join-Path $OutRoot "AD_Groups_$ts.csv"

    try {
        $props = 'Name','GroupCategory','GroupScope','Description','WhenCreated','ManagedBy'
        $groups = Get-ADGroup -Filter * -Properties $props
        if ($groups) {
            $groups | Select-Object $props | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            Write-Host ("Groups exported: {0}" -f ($groups.Count)) -ForegroundColor Green
            $groups | Select-Object Name, GroupScope, GroupCategory | Sort-Object Name | Format-Table -AutoSize
            Write-Host "Saved: $csv" -ForegroundColor Green
        } else {
            Write-Host "No groups returned." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting groups: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Run-AdOUs {
    if (-not (Ensure-AdModule)) { Pause-Script "Press any key to return to the menu..."; return }
    Show-Header "AD - Organizational Units"
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv = Join-Path $OutRoot "AD_OUs_$ts.csv"

    try {
        $props = 'Name','DistinguishedName','ProtectedFromAccidentalDeletion','ManagedBy','WhenCreated'
        $ous = Get-ADOrganizationalUnit -Filter * -Properties $props
        if ($ous) {
            $ous | Select-Object $props | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            Write-Host ("OUs exported: {0}" -f ($ous.Count)) -ForegroundColor Green
            $ous | Select-Object Name, ProtectedFromAccidentalDeletion | Sort-Object Name | Format-Table -AutoSize
            Write-Host "Saved: $csv" -ForegroundColor Green
        } else {
            Write-Host "No OUs returned." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting OUs: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Run-AdGpos {
    Show-Header "AD - Group Policy Objects"
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csv = Join-Path $OutRoot "AD_GPOs_$ts.csv"

    # GPO cmdlets are in the GroupPolicy module (part of RSAT)
    $hasGp = $false
    try {
        Import-Module GroupPolicy -ErrorAction Stop | Out-Null
        $hasGp = $true
    } catch {
        Write-Host "GroupPolicy module not available (RSAT: Group Policy Management). Export will be limited (no Get-GPO)." -ForegroundColor Yellow
    }

    try {
        if ($hasGp) {
            $gpos = Get-GPO -All
            if ($gpos) {
                $gpos | Select-Object DisplayName, Id, Owner, CreationTime, ModificationTime, DomainName, GpoStatus |
                    Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
                Write-Host ("GPOs exported: {0}" -f ($gpos.Count)) -ForegroundColor Green
                $gpos | Select-Object DisplayName, GpoStatus, ModificationTime | Sort-Object DisplayName | Format-Table -AutoSize
                Write-Host "Saved: $csv" -ForegroundColor Green
            } else {
                Write-Host "No GPOs returned." -ForegroundColor Yellow
            }
        } else {
            # Fallback: try to read basic GPO listing via registry or WMI? Keep a placeholder CSV for consistency.
            "" | Out-File -LiteralPath $csv -Encoding utf8
            Write-Host "Saved empty GPO export (module missing): $csv" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting GPOs: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Show-Menu {
    Clear-Host
    Show-Header "Active Directory Tools"

    Write-Host ""
    Write-Host " [1] Users                      - Core attributes, last logon, password state" -ForegroundColor White
    Write-Host " [2] Groups                     - Scope/category, managed by" -ForegroundColor White
    Write-Host " [3] Organizational Units (OUs) - OU list and protection flag" -ForegroundColor White
    Write-Host " [4] Group Policy Objects (GPOs)- Basic details and status" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-AdUsers }
        '2' { Run-AdGroups }
        '3' { Run-AdOUs }
        '4' { Run-AdGpos }
        'Q' {
            # Relaunch main CS Toolbox Launcher in the SAME window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
