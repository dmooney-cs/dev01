<#
.SYNOPSIS
  ConnectSecure (CyberCNS) Agent Install / Reinstall Helper

REQUIREMENTS IMPLEMENTED
  - Accepts: -c (Company), -e (Tenant), -j (Secret), -y (UninstallSecret)
  - Interactive: if agent detected, ALWAYS ASK if reinstall is needed (Y/N)
  - If reinstall chosen:
      * MUST read Company/Tenant from cybercns.log BEFORE uninstall (if possible)
      * Proceeds uninstall -> install (no additional prompts)
  - Silent/ExportOnly: do NOT prompt; force reinstall flow.
  - Uninstall Secret:
      * OPTIONAL until 2026-04-01, REQUIRED after
      * ONLY used if provided via -y (never prompted, never read from file)
  - Install syntax MUST be:
      cybercnsagent.exe -c <CompanyID> -e <TenantID> -j <User_Secret> -i

CHANGE
  - After a SUCCESSFUL install in interactive mode, show agent service status,
    wait 5 seconds, then continue automatically.
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Reinstall,

    [Alias('c')]
    [string]$Company,

    [Alias('e')]
    [string]$Tenant,

    [Alias('j')]
    [string]$Secret,

    [Alias('us','y')]
    [string]$UninstallSecret,

    [switch]$Quiet,
    [switch]$Silent,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

# ---------------------------
# Mode normalization
# ---------------------------
if ($Silent) {
    $Quiet     = $true
    $Reinstall = $true
}
if ($ExportOnly) {
    $Quiet     = $true
    $Reinstall = $true
}
$Interactive = (-not $Silent) -and (-not $ExportOnly)

# ---------------------------
# Paths / constants
# ---------------------------
$CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$DownloadRoot      = 'C:\CS-Toolbox-TEMP\Downloads'
$InstallerPath     = Join-Path $DownloadRoot 'cybercnsagent.exe'

$AgentDir          = 'C:\Program Files (x86)\CyberCNSAgent'
$AgentExePath      = Join-Path $AgentDir 'cybercnsagent.exe'
$UninstallBatPath  = Join-Path $AgentDir 'uninstall.bat'
$AgentLogPath      = Join-Path $AgentDir 'logs\cybercns.log'

$InstallerCodeFile = Join-Path $CollectedInfoRoot 'installer-code.txt'
$AgentIdsCacheFile = Join-Path $CollectedInfoRoot 'AgentIds-FromLog.txt'

$AgentApiUrl       = 'https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows'

# ---------------------------
# Logging
# ---------------------------
if (-not (Test-Path -LiteralPath $CollectedInfoRoot)) {
    New-Item -ItemType Directory -Path $CollectedInfoRoot -Force | Out-Null
}
$stamp   = Get-Date -Format 'yyyy-MM-dd-HHmm'
$hostn   = $env:COMPUTERNAME
$logFile = Join-Path $CollectedInfoRoot "$hostn-AgentInstall-$stamp.txt"
try { Start-Transcript -Path $logFile -Append | Out-Null } catch {}

# ---------------------------
# Helpers
# ---------------------------
function Enable-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

function Write-HostIf {
    param([string]$Msg,[string]$Color='Gray')
    if ($Quiet -or $Silent) { return }
    if ([string]::IsNullOrEmpty($Msg)) { Write-Host '' }
    else { Write-Host $Msg -ForegroundColor $Color }
}

function Show-Step {
    param([int]$i,[int]$n,[string]$msg)
    if ($Silent) { return }
    Write-Host ("[Step {0}/{1}] {2}" -f $i,$n,$msg) -ForegroundColor Cyan
}

function Get-ServiceRow {
    param([Parameter(Mandatory)][string]$Name)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) {
        return [PSCustomObject]@{ Service=$Name; Installed='No'; Status='Not Installed'; StartType='N/A' }
    }

    $startMode='Unknown'
    try {
        $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction SilentlyContinue
        if ($wmi -and $wmi.StartMode) { $startMode = $wmi.StartMode }
    } catch {}

    [PSCustomObject]@{ Service=$Name; Installed='Yes'; Status=$svc.Status.ToString(); StartType=$startMode }
}

function Show-ServicesTable {
    $rows = @(
        Get-ServiceRow -Name 'CyberCNSAgent'
        Get-ServiceRow -Name 'ConnectSecureAgentMonitor'
    )

    if (-not $Quiet -and -not $Silent) {
        Write-Host ""
        Write-Host "=== ConnectSecure Services ===" -ForegroundColor Cyan
        $rows | Format-Table Service, Installed, Status, StartType -AutoSize | Out-Host
        Write-Host ""
        Write-Host "Note: It is normal for only 'CyberCNSAgent' to be present immediately after the first install." -ForegroundColor Yellow
    }
    return ,$rows
}

function Any-AgentDetected {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    if ($svc1 -or $svc2) { return $true }
    if (Test-Path -LiteralPath $AgentExePath) { return $true }
    return $false
}

function Get-UninstallSecretPolicy {
    $cutover = Get-Date '2026-04-01T00:00:00'
    $now = Get-Date
    return [PSCustomObject]@{
        Required = ($now -ge $cutover)
        Message  = if ($now -ge $cutover) {
            "Uninstall Secret is REQUIRED as of April 1, 2026."
        } else {
            "Uninstall Secret is OPTIONAL until April 1, 2026 (required after)."
        }
    }
}

function Get-InstallerCodesFromFile {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }

    try {
        $raw = Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue
        if (-not $raw) { return $null }

        $lines = @()
        foreach ($l in $raw) {
            if ($null -eq $l) { continue }
            $t = $l.ToString().Trim()
            if ([string]::IsNullOrWhiteSpace($t)) { continue }
            if ($t.StartsWith('#') -or $t.StartsWith(';')) { continue }
            $lines += $t
        }
        if ($lines.Count -lt 3) { return $null }

        return [PSCustomObject]@{
            Company = $lines[0]
            Tenant  = $lines[1]
            Secret  = $lines[2]
        }
    } catch {
        return $null
    }
}

function Get-AgentIdsFromLog {
    if (-not (Test-Path -LiteralPath $AgentLogPath)) { return $null }

    try {
        $tenantLine  = Select-String -Path $AgentLogPath -Pattern 'Tenant\s*ID'  -ErrorAction SilentlyContinue | Select-Object -Last 1
        $companyLine = Select-String -Path $AgentLogPath -Pattern 'Company\s*ID' -ErrorAction SilentlyContinue | Select-Object -Last 1

        $tenantId  = $null
        $companyId = $null

        if ($tenantLine) {
            $m = [regex]::Match($tenantLine.Line, 'Tenant\s*ID\s*[:\-]*\s*([0-9]+)')
            if ($m.Success) { $tenantId = $m.Groups[1].Value.Trim() }
        }
        if ($companyLine) {
            $m = [regex]::Match($companyLine.Line, 'Company\s*ID\s*[:\-]*\s*([0-9]+)')
            if ($m.Success) { $companyId = $m.Groups[1].Value.Trim() }
        }

        if ([string]::IsNullOrWhiteSpace($tenantId) -and [string]::IsNullOrWhiteSpace($companyId)) { return $null }
        return [PSCustomObject]@{ CompanyId=$companyId; TenantId=$tenantId }
    } catch {
        return $null
    }
}

function Cache-AgentIds {
    param([string]$CompanyId,[string]$TenantId)
    if ([string]::IsNullOrWhiteSpace($CompanyId) -or [string]::IsNullOrWhiteSpace($TenantId)) { return }
    try { @($CompanyId,$TenantId) | Set-Content -LiteralPath $AgentIdsCacheFile -Encoding ASCII -Force } catch {}
}

function Invoke-RestWithRetry {
    param([string]$Uri,[int]$MaxAttempts=3,[int]$DelaySeconds=2)

    Enable-Tls12
    for ($i=1; $i -le $MaxAttempts; $i++) {
        Write-HostIf ("Fetching agent download URL... Attempt $i/$MaxAttempts") 'Cyan'
        try {
            $resp = Invoke-RestMethod -Method Get -Uri $Uri -ErrorAction Stop
            Write-HostIf "Request successful." 'Green'
            return $resp
        } catch {
            if ($i -eq $MaxAttempts) { return $null }
            Write-HostIf ("Attempt failed: {0}" -f $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $null
}

function Get-DownloadUrl {
    param([Parameter(Mandatory)][object]$Resp)

    if ($Resp -is [string] -and $Resp -match '^https?://') { return $Resp }

    try { if ($Resp.link -and $Resp.link -match '^https?://') { return [string]$Resp.link } } catch {}
    try { if ($Resp.url  -and $Resp.url  -match '^https?://') { return [string]$Resp.url  } } catch {}
    try { if ($Resp.downloadUrl -and $Resp.downloadUrl -match '^https?://') { return [string]$Resp.downloadUrl } } catch {}
    try { if ($Resp.data -and $Resp.data.link -and $Resp.data.link -match '^https?://') { return [string]$Resp.data.link } } catch {}
    try { if ($Resp.data -and $Resp.data.url  -and $Resp.data.url  -match '^https?://') { return [string]$Resp.data.url  } } catch {}

    try {
        $json = $Resp | ConvertTo-Json -Depth 10 -Compress
        $m = [regex]::Match($json, 'https?://[^"\\s]+?\.exe')
        if ($m.Success) { return $m.Value }
    } catch {}

    return $null
}

function Download-File {
    param([Parameter(Mandatory)][string]$Uri,[Parameter(Mandatory)][string]$OutFile)

    Enable-Tls12

    $outDir = Split-Path -Parent $OutFile
    if (-not (Test-Path -LiteralPath $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($i=1; $i -le 3; $i++) {
        Write-HostIf ("Downloading agent installer... Attempt $i/3") 'Cyan'
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-HostIf "Download successful." 'Green'
                return $true
            }
            throw "Downloaded file missing/empty."
        } catch {
            if ($i -eq 3) { return $false }
            Write-HostIf ("Download failed: {0}" -f $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds 2
        }
    }
    return $false
}

function Run-Uninstall {
    Write-HostIf ""
    Write-HostIf "Starting uninstall process..." 'Yellow'

    $policy = Get-UninstallSecretPolicy
    if ($Interactive) {
        Write-HostIf $policy.Message 'Cyan'
        if ([string]::IsNullOrWhiteSpace($UninstallSecret)) {
            Write-HostIf "No uninstall secret provided. Uninstall will still be attempted without it (best-effort)." 'Yellow'
        } else {
            Write-HostIf "Uninstall secret provided. It will be used and not shown." 'Green'
        }
    }

    $hasY = -not [string]::IsNullOrWhiteSpace($UninstallSecret)

    if ($policy.Required -and -not $hasY) {
        Write-HostIf "WARN: Cutover date has passed, but no uninstall secret was provided. Continuing without it (best-effort)." 'Yellow'
    }
    if (Test-Path -LiteralPath $AgentExePath) {
        try {
            if ($hasY) {
                Write-HostIf "Running: cybercnsagent.exe -r -y <secret> (secret not shown)" 'Cyan'
                if ($Quiet -or $Silent) { & $AgentExePath -r -y $UninstallSecret *> $null } else { & $AgentExePath -r -y $UninstallSecret }
            } else {
                Write-HostIf "Running: cybercnsagent.exe -r (no -y provided)" 'Cyan'
                if ($Quiet -or $Silent) { & $AgentExePath -r *> $null } else { & $AgentExePath -r }
            }
        } catch {}
    }

    if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-HostIf "Found vendor uninstall.bat, executing it (best-effort)." 'Green'
        try {
            Push-Location $AgentDir
            if ($hasY) {
                Write-HostIf "Running: .\uninstall.bat <secret> (secret not shown)" 'Cyan'
                if ($Quiet -or $Silent) { & $UninstallBatPath $UninstallSecret *> $null } else { & $UninstallBatPath $UninstallSecret }
            } else {
                Write-HostIf "Running: .\uninstall.bat (no -y provided)" 'Cyan'
                if ($Quiet -or $Silent) { & $UninstallBatPath *> $null } else { & $UninstallBatPath }
            }
        } catch {
        } finally {
            Pop-Location
        }
    }

    Write-HostIf "Uninstall process completed (errors ignored if any)." 'Green'
    Show-Step -i 1 -n 3 -msg "Uninstall phase completed (best-effort)."
}

function Start-AgentServices {
    foreach ($n in @('CyberCNSAgent','ConnectSecureAgentMonitor')) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            try { Start-Service -Name $n -ErrorAction SilentlyContinue } catch {}
        }
    }
}

function Verify-AgentInstalled {
    $svc = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    if (-not $svc) { return $false }
    if (-not (Test-Path -LiteralPath $AgentExePath)) { return $false }
    return $true
}

# ---------------------------
# MAIN
# ---------------------------
$script:FinalExitCode = 0

try {
    $agentDetected = Any-AgentDetected
    $null = Show-ServicesTable

    if ($Interactive -and $agentDetected -and (-not $Reinstall)) {
        Write-HostIf ""
        Write-HostIf "Agent appears to be installed." 'Yellow'

        if ([string]::IsNullOrWhiteSpace($UninstallSecret)) {
            $policy = Get-UninstallSecretPolicy
            Write-HostIf $policy.Message 'Cyan'
            Write-HostIf "Enter uninstall secret now if available. Leave blank to attempt uninstall without it." 'DarkGray'
            $enteredUninstallSecret = Read-Host "Uninstall secret optional"
            if (-not [string]::IsNullOrWhiteSpace($enteredUninstallSecret)) {
                $UninstallSecret = $enteredUninstallSecret.Trim()
                Write-HostIf "Uninstall secret captured for this run (value not shown)." 'Green'
            } else {
                Write-HostIf "No uninstall secret entered. If reinstall is selected, uninstall will continue without it (best-effort)." 'Yellow'
            }
            Write-HostIf ""
        }

        Write-HostIf "Reinstall needed? (Y/N)  Press Enter after entry." 'DarkGray'
        $ans = Read-Host "Reinstall needed"
        if ($ans -and $ans.Trim().ToUpperInvariant() -eq 'Y') {
            $Reinstall = $true
        } else {
            Write-HostIf "Reinstall not selected. Proceeding with INSTALL attempt only." 'Yellow'
        }
    }

    if ($Reinstall -and $agentDetected) {
        $ids = Get-AgentIdsFromLog
        if ($ids -and -not [string]::IsNullOrWhiteSpace($ids.CompanyId) -and -not [string]::IsNullOrWhiteSpace($ids.TenantId)) {
            $Company = $ids.CompanyId
            $Tenant  = $ids.TenantId
            Cache-AgentIds -CompanyId $Company -TenantId $Tenant
            Write-HostIf "Captured Company/Tenant from cybercns.log for reinstall (values not shown)." 'Green'
        } else {
            Write-HostIf "WARN: Could not read Company/Tenant from cybercns.log before uninstall." 'Yellow'
        }

        Write-HostIf ""
        Write-HostIf "Reinstall path: starting uninstall immediately (best-effort)." 'Yellow'
        Run-Uninstall
        $null = Show-ServicesTable
    }

    if ([string]::IsNullOrWhiteSpace($Company) -or [string]::IsNullOrWhiteSpace($Tenant) -or [string]::IsNullOrWhiteSpace($Secret)) {
        $codes = Get-InstallerCodesFromFile -Path $InstallerCodeFile
        if ($codes) {
            if ([string]::IsNullOrWhiteSpace($Company)) { $Company = $codes.Company }
            if ([string]::IsNullOrWhiteSpace($Tenant))  { $Tenant  = $codes.Tenant }
            if ([string]::IsNullOrWhiteSpace($Secret))  { $Secret  = $codes.Secret }
            if ($Interactive) { Write-HostIf "Using installer-code.txt for missing values." 'Green' }
        }
    }

    if ($Interactive) {
        if ([string]::IsNullOrWhiteSpace($Company)) { $Company = Read-Host "Enter Company ID (press Enter after entry)" }
        if ([string]::IsNullOrWhiteSpace($Tenant))  { $Tenant  = Read-Host "Enter Tenant ID (press Enter after entry)" }
        if ([string]::IsNullOrWhiteSpace($Secret))  { $Secret  = Read-Host "Enter User Secret (press Enter after entry)" }
    }

    if ([string]::IsNullOrWhiteSpace($Company) -or [string]::IsNullOrWhiteSpace($Tenant) -or [string]::IsNullOrWhiteSpace($Secret)) {
        throw "Missing required install values (Company/Tenant/Secret). Provide via -c/-e/-j or installer-code.txt (interactive will prompt)."
    }

    Write-HostIf ""
    Write-HostIf "Using TLS 1.2 for secure agent link download..." 'Cyan'
    $resp = Invoke-RestWithRetry -Uri $AgentApiUrl -MaxAttempts 3 -DelaySeconds 2
    if (-not $resp) { throw "Unable to retrieve agent link from API after 3 attempts." }

    $url = Get-DownloadUrl -Resp $resp
    if (-not $url) { throw "API response did not include a usable download URL." }

    $ok = Download-File -Uri $url -OutFile $InstallerPath
    if (-not $ok) { throw "Failed to download agent installer after retries." }

    Show-Step -i 2 -n 3 -msg "Download phase completed."

    if ($Interactive) {
        Write-HostIf ""
        Write-HostIf "Executing install (secret not shown):" 'Yellow'
        Write-HostIf ("  {0} -c {1} -e {2} -j **** -i" -f $InstallerPath, $Company, $Tenant) 'White'
    }

    if ($Quiet -or $Silent) {
        & $InstallerPath -c $Company -e $Tenant -j $Secret -i *> $null
    } else {
        & $InstallerPath -c $Company -e $Tenant -j $Secret -i
    }
    $exitCode = $LASTEXITCODE

    if ($exitCode -eq 0) { Write-HostIf "[OK] Agent installer returned success." 'Green' }
    else { Write-HostIf ("[WARN] Agent installer returned exit code: {0}" -f $exitCode) 'Yellow' }

    Start-AgentServices
    $null = Show-ServicesTable

    if (-not (Verify-AgentInstalled)) {
        throw "Install finished but agent was not found installed (CyberCNSAgent service or exe missing)."
    }

    Show-Step -i 3 -n 3 -msg "Install phase completed (verified CyberCNSAgent service + exe present)."

    if ($exitCode -ne 0) {
        $script:FinalExitCode = [int]$exitCode
    } else {
        $script:FinalExitCode = 0
    }

    if ($Interactive -and $script:FinalExitCode -eq 0) {
        Write-HostIf ""
        Write-HostIf "Install completed successfully. Service status shown above." 'Green'
        Write-HostIf "Continuing automatically in 5 seconds..." 'Yellow'
        Start-Sleep -Seconds 5
    }
}
catch {
    $script:FinalExitCode = 9
    if (-not $Silent) { Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red }
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
    if (-not $Silent) { Write-HostIf ("Log file saved to: {0}" -f $logFile) 'DarkGray' }
}

exit $script:FinalExitCode
