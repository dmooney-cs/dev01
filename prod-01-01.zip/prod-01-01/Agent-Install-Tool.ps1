<#
.SYNOPSIS
    ConnectSecure (CyberCNS) Agent Install / Reinstall Helper

.NOTES
    Patched:
      - Quiet/Silent continue on uninstall errors (missing processes/files/keys)
      - Uninstall batch ignores taskkill/sc/reg/rmdir failures
      - Adds -ExportOnly for cookbook usage (no prompts/pauses)
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Reinstall,

    [Alias('c')]
    [string]$Company,

    [Alias('e')]
    [string]$Tenant,

    [Alias('j')]
    [string]$Secret,

    [switch]$Quiet,
    [switch]$Silent,

    # COOKBOOK CONTROL
    [switch]$ExportOnly
)

# ====================== Global behavior ======================
# We do not want random missing items to stop the workflow.
$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

# Silent mode forces Quiet and Reinstall semantics.
if ($Silent) {
    $Quiet     = $true
    $Reinstall = $true
}

# ExportOnly implies non-interactive behavior
if ($ExportOnly) {
    $Quiet     = $true
    $Reinstall = $true
}

# ====================== Setup / Logging ======================
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$shortDate = Get-Date -Format "yyyy-MM-dd"
$shortTime = Get-Date -Format "HHmm"
$hostname  = $env:COMPUTERNAME

$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}
$logFile = Join-Path $exportDir "$hostname-AgentInstall-$shortDate-$shortTime.txt"
try { Start-Transcript -Path $logFile -Append | Out-Null } catch {}

# ====================== Constants ============================
$AgentApiUrl      = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
$DownloadRoot     = "C:\CS-Toolbox-TEMP\Downloads"
$InstallerPath    = Join-Path $DownloadRoot "cybercnsagent.exe"

$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"
$AgentLogPath     = Join-Path $AgentDir "logs\cybercns.log"

# Raw uninstall fallback (batch) - patched to IGNORE errors
$RawUninstall = @"
@echo off
setlocal ENABLEEXTENSIONS

REM Give services a moment if we're racing a prior install/uninstall
ping 127.0.0.1 -n 3 > nul 2>&1

cd /d "C:\PROGRA~2" 2>nul

REM Stop/delete services (ignore failures)
sc stop ConnectSecureAgentMonitor >nul 2>&1
timeout /T 2 >nul 2>&1
sc delete ConnectSecureAgentMonitor >nul 2>&1
timeout /T 2 >nul 2>&1
sc stop CyberCNSAgent >nul 2>&1
timeout /T 2 >nul 2>&1
sc delete CyberCNSAgent >nul 2>&1

REM Kill helper processes (ignore failures)
taskkill /IM osqueryi.exe /F >nul 2>&1
taskkill /IM nmap.exe /F >nul 2>&1
taskkill /IM cyberutilities.exe /F >nul 2>&1

REM Vendor internal uninstall if present (ignore failures)
if exist "CyberCNSAgent\cybercnsagent.exe" (
  "CyberCNSAgent\cybercnsagent.exe" --internalAssetArgument uninstallservice >nul 2>&1
)

REM Remove uninstall registry keys (ignore failures)
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1

REM Remove folder (ignore failures)
rmdir "CyberCNSAgent" /s /q >nul 2>&1

exit /b 0
"@

# ====================== Helpers ==============================
function Enable-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

function Write-HostIfNotQuiet {
    param(
        [string]$Message,
        [string]$Color = 'Gray'
    )
    if ($Quiet -or $Silent) { return }

    if ([string]::IsNullOrEmpty($Message)) {
        Write-Host ""
    } else {
        Write-Host $Message -ForegroundColor $Color
    }
}

function Show-StepSummary {
    param(
        [int]$Index,
        [int]$Total,
        [string]$Message
    )
    if ($Silent) { return }
    if ([string]::IsNullOrEmpty($Message)) {
        $Message = "Phase $Index of $Total completed."
    }
    Write-Host ("[Step {0}/{1}] {2}" -f $Index, $Total, $Message) -ForegroundColor Cyan
}

# --- Resolve Company/Tenant from cybercns.log ---
function Get-AgentIdsFromLog {
    if (-not (Test-Path -LiteralPath $AgentLogPath)) { return $null }

    try {
        $tenantLine  = Select-String -Path $AgentLogPath -Pattern 'Tenant ID\s*:-'  -ErrorAction SilentlyContinue | Select-Object -Last 1
        $companyLine = Select-String -Path $AgentLogPath -Pattern 'Company ID\s*:-' -ErrorAction SilentlyContinue | Select-Object -Last 1

        $tenantId  = $null
        $companyId = $null

        if ($tenantLine) {
            $m = [regex]::Match($tenantLine.Line, 'Tenant ID\s*:-\s*([0-9]+)')
            if ($m.Success) { $tenantId = $m.Groups[1].Value }
        }
        if ($companyLine) {
            $m = [regex]::Match($companyLine.Line, 'Company ID\s*:-\s*([0-9]+)')
            if ($m.Success) { $companyId = $m.Groups[1].Value }
        }

        if ($tenantId -or $companyId) {
            return [PSCustomObject]@{ TenantId = $tenantId; CompanyId = $companyId }
        }
    } catch {}

    return $null
}

function Invoke-RestWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "agent link"
    )
    Enable-Tls12
    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-HostIfNotQuiet ("Fetching {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) 'Cyan'
        try {
            $resp = Invoke-RestMethod -Method Get -Uri $Uri -ErrorAction Stop
            Write-HostIfNotQuiet "Request successful." 'Green'
            return $resp
        } catch {
            if ($attempt -eq $MaxAttempts) {
                if (-not $Silent) {
                    Write-Host ("ERROR: Failed to fetch {0} on attempt {1}/{2}: {3}" -f $What, $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                }
                return $null
            }
            Write-HostIfNotQuiet ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $null
}

function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "installer"
    )
    Enable-Tls12
    $outDir = Split-Path -Parent $OutFile
    if (-not (Test-Path -LiteralPath $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-HostIfNotQuiet ("Downloading {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) 'Cyan'
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-HostIfNotQuiet "Download successful." 'Green'
                return $true
            } else {
                throw "Downloaded file is missing or empty."
            }
        } catch {
            Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
            if ($attempt -eq $MaxAttempts) {
                if (-not $Silent) {
                    Write-Host ("ERROR: Download failed on attempt {0}/{1}: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                }
                return $false
            }
            Write-HostIfNotQuiet ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $false
}

function Get-DownloadUrl {
    param([Parameter(Mandatory=$true)][object]$Resp)

    if ($Resp -is [string] -and $Resp -match '^https?://') { return $Resp }

    try { if ($Resp.link        -and $Resp.link        -match '^https?://') { return [string]$Resp.link } } catch {}
    try { if ($Resp.url         -and $Resp.url         -match '^https?://') { return [string]$Resp.url } } catch {}
    try { if ($Resp.downloadUrl -and $Resp.downloadUrl -match '^https?://') { return [string]$Resp.downloadUrl } } catch {}
    try { if ($Resp.data -and $Resp.data.link -and $Resp.data.link -match '^https?://') { return [string]$Resp.data.link } } catch {}

    try {
        $json = $Resp | ConvertTo-Json -Depth 6 -Compress
        $m = [Regex]::Match($json, 'https?://[^"\\s]+?\.exe')
        if ($m.Success) { return $m.Value }
    } catch {}

    return $null
}

function Get-ServiceRow {
    param([Parameter(Mandatory=$true)][string]$Name)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        return [PSCustomObject]@{ Service=$Name; Installed='No'; Status='Not Installed'; StartType='N/A' }
    }

    $startMode = 'Unknown'
    try {
        $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction SilentlyContinue
        if ($wmi -and $wmi.StartMode) { $startMode = $wmi.StartMode }
    } catch {}

    return [PSCustomObject]@{ Service=$Name; Installed='Yes'; Status=$svc.Status.ToString(); StartType=$startMode }
}

function Show-ServicesTable {
    param([string]$Phase = 'Current')

    $rows = @(
        Get-ServiceRow -Name 'CyberCNSAgent'
        Get-ServiceRow -Name 'ConnectSecureAgentMonitor'
    )

    if ($Quiet -and -not $Silent) {
        $tag = switch ($Phase) {
            'Initial'       { '[Initial Service Status]' }
            'PostUninstall' { '[Post-Uninstall Service Status]' }
            'Final'         { '[Final Service Status]' }
            default         { '[Service Status]' }
        }

        foreach ($row in $rows) {
            Write-Host ("{0} {1}: Installed={2}, Status={3}, StartType={4}" -f $tag, $row.Service, $row.Installed, $row.Status, $row.StartType) -ForegroundColor Cyan
        }
    }
    elseif (-not $Quiet -and -not $Silent) {
        Write-Host ""
        Write-Host "=== ConnectSecure Services ===" -ForegroundColor Cyan
        $rows | Format-Table Service, Installed, Status, StartType -AutoSize | Out-Host
        Write-Host ""
        Write-Host "Note: It is normal for only 'CyberCNSAgent' to be present immediately after the first install." -ForegroundColor Yellow
    }

    return ,$rows
}

function Any-ServiceRunning {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    return (($svc1 -and $svc1.Status -eq 'Running') -or ($svc2 -and $svc2.Status -eq 'Running'))
}

function Run-Uninstall {
    Write-HostIfNotQuiet ""
    Write-HostIfNotQuiet "Starting uninstall process..." 'Yellow'

    # Attempt agent-driven removal first (ignore any failures)
    $agentExe = Join-Path $AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        try {
            if ($Quiet -or $Silent) { & $agentExe -r *> $null } else { & $agentExe -r }
        } catch {}
    }

    # Use vendor uninstall if present, else fallback; ALWAYS continue
    $uninstallScript = if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-HostIfNotQuiet "Found vendor uninstall.bat, using it." 'Green'
        try { Get-Content $UninstallBatPath -Raw -ErrorAction SilentlyContinue } catch { $null }
    } else {
        Write-HostIfNotQuiet "Vendor uninstall.bat not found. Using built-in fallback." 'Yellow'
        $null
    }

    if ([string]::IsNullOrWhiteSpace($uninstallScript)) {
        $uninstallScript = $RawUninstall
    } else {
        # Wrap vendor script to suppress errors and return 0
        $uninstallScript = "@echo off`r`nsetlocal`r`n" + $uninstallScript + "`r`nexit /b 0`r`n"
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        $uninstallScript | Out-File -FilePath $tempBat -Encoding ASCII -Force
        Write-HostIfNotQuiet "Executing uninstall script..." 'Cyan'

        if ($Quiet -or $Silent) {
            cmd /c "`"$tempBat`"" > $null 2>&1
        } else {
            cmd /c "`"$tempBat`""
        }
        # Ignore exit codes from uninstall on purpose
        $null = $LASTEXITCODE
    } catch {
        # swallow
    } finally {
        Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue
    }

    Write-HostIfNotQuiet "Uninstall process completed (errors ignored if any)." 'Green'
    Show-StepSummary -Index 1 -Total 3 -Message "Uninstall phase completed (best-effort; missing items are expected and ignored)."
}

function Start-AgentServices {
    foreach ($n in @('CyberCNSAgent','ConnectSecureAgentMonitor')) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            Write-HostIfNotQuiet ("Starting {0} ..." -f $n) 'Cyan'
            try {
                Start-Service -Name $n -ErrorAction SilentlyContinue
                try { $svc.WaitForStatus('Running','00:00:25') } catch {}
                $svc2 = Get-Service -Name $n -ErrorAction SilentlyContinue
                if ($svc2 -and $svc2.Status -eq 'Running') {
                    Write-HostIfNotQuiet ("[OK] {0} is Running" -f $n) 'Green'
                } else {
                    Write-HostIfNotQuiet ("[WARN] {0} did not report Running" -f $n) 'Yellow'
                }
            } catch {}
        } elseif ($svc) {
            Write-HostIfNotQuiet ("[OK] {0} already Running" -f $n) 'Green'
        }
    }
}

# ====================== Flow ================================
try {
    # Auto-resolve Company/Tenant from log if Secret is provided but IDs missing
    if (-not [string]::IsNullOrWhiteSpace($Secret) -and
        ([string]::IsNullOrWhiteSpace($Company) -or [string]::IsNullOrWhiteSpace($Tenant))) {

        $ids = Get-AgentIdsFromLog
        if ($ids) {
            if ([string]::IsNullOrWhiteSpace($Company) -and $ids.CompanyId) { $Company = $ids.CompanyId }
            if ([string]::IsNullOrWhiteSpace($Tenant)  -and $ids.TenantId)  { $Tenant  = $ids.TenantId }
        }
    }

    # Validate forced reinstall parameters (after log-based auto-fill)
    if ($Reinstall) {
        if ([string]::IsNullOrWhiteSpace($Company) -or
            [string]::IsNullOrWhiteSpace($Tenant)  -or
            [string]::IsNullOrWhiteSpace($Secret)) {

            if (-not $Silent) {
                Write-Host "[ERROR] -Reinstall (or -Silent/-ExportOnly) requires -c (Company), -e (Tenant), and -j (Secret) to be specified or resolvable from cybercns.log." -ForegroundColor Red
            }
            exit 1
        }
    }

    # 0) Show current services up-front
    $null = Show-ServicesTable -Phase 'Initial'
    if ($Quiet -and -not $Silent) {
        Write-Host "[Info] Starting agent reinstall workflow (this may take a few minutes before Step 1/3 appears)..." -ForegroundColor Yellow
    }

    # 1) Handle uninstall
    if ($Reinstall) {
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "Reinstall mode: forcing full uninstall before install (best-effort)." 'Yellow'
        Run-Uninstall
        $null = Show-ServicesTable -Phase 'PostUninstall'
    }
    else {
        if (Any-ServiceRunning) {
            if (-not $Silent) {
                Write-HostIfNotQuiet ""
                $ans = Read-Host "Uninstall ConnectSecure before reinstall?  (Press Enter to start uninstall, or type N to skip)"
                if ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y') {
                    Run-Uninstall
                    $null = Show-ServicesTable -Phase 'PostUninstall'
                } else {
                    Write-HostIfNotQuiet "Skipping uninstall." 'Yellow'
                    exit 0
                }
            } else {
                # Silent should never prompt; just proceed
                Run-Uninstall
                $null = Show-ServicesTable -Phase 'PostUninstall'
            }
        }
    }

    # 2) Collect install parameters
    $companyId = $Company
    $tenantId  = $Tenant
    $secretKey = $Secret

    if (-not $Reinstall) {
        # Only in interactive mode do we prompt
        if (-not $Silent -and -not $ExportOnly) {
            if ([string]::IsNullOrWhiteSpace($companyId)) { $companyId = Read-Host "Enter Company ID" }
            if ([string]::IsNullOrWhiteSpace($tenantId))  { $tenantId  = Read-Host "Enter Tenant ID" }
            if ([string]::IsNullOrWhiteSpace($secretKey)) { $secretKey = Read-Host "Enter Secret Key" }
        }
    }

    # 3) Get latest agent URL (TLS 1.2) with retries
    Write-HostIfNotQuiet ""
    Write-HostIfNotQuiet "Using TLS 1.2 for secure agent link download..." 'Cyan'
    $resp = Invoke-RestWithRetry -Uri $AgentApiUrl -MaxAttempts 3 -DelaySeconds 2 -What "agent download URL"
    if (-not $resp) {
        if (-not $Silent) { Write-Host "[ERROR] Unable to retrieve agent link from API after 3 attempts." -ForegroundColor Red }
        exit 2
    }

    $source = Get-DownloadUrl -Resp $resp
    if (-not $source) {
        if (-not $Silent) { Write-Host "[ERROR] API response did not include a usable download URL." -ForegroundColor Red }
        exit 3
    }

    # 4) Download installer with retries
    $ok = Invoke-DownloadWithRetry -Uri $source -OutFile $InstallerPath -MaxAttempts 3 -DelaySeconds 2 -What "agent installer"
    if (-not $ok) { exit 4 }

    Show-StepSummary -Index 2 -Total 3 -Message "Download phase completed (agent URL retrieved from API and installer binary downloaded)."

    # 5) Build and run install command (NO quotes around values)
    if (-not $Silent) {
        $masked = if ($secretKey.Length -gt 6) { ('*' * ($secretKey.Length - 4)) + $secretKey.Substring($secretKey.Length - 4) } else { '****' }
        $preview = "$InstallerPath -c $companyId -e $tenantId -j $masked -i"
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "Executing:" 'Yellow'
        Write-HostIfNotQuiet "  $preview" 'White'
        if (-not $Quiet) { Start-Sleep -Seconds 2 }
    }

    if ($Quiet -or $Silent) {
        cmd /c "`"$InstallerPath`" -c $companyId -e $tenantId -j $secretKey -i" > $null 2>&1
    } else {
        cmd /c "`"$InstallerPath`" -c $companyId -e $tenantId -j $secretKey -i"
    }
    $exitCode = $LASTEXITCODE

    if ($exitCode -eq 0) {
        Write-HostIfNotQuiet "[OK] Agent installation completed successfully." 'Green'
    } else {
        if (-not $Silent) {
            Write-HostIfNotQuiet ("[ERROR] Agent installation failed (Exit Code: {0})." -f $exitCode) 'Red'
        }
        # Keep going to attempt service start/status; still return nonzero at end
    }

    # 6) Post-install: attempt to start services and show final table
    Start-AgentServices
    $finalRows = Show-ServicesTable -Phase 'Final'
    $agentRow   = $finalRows | Where-Object { $_ -is [psobject] -and $_.Service -eq 'CyberCNSAgent' }
    $statusText = if ($agentRow) { $agentRow.Status } else { 'Unknown' }

    Show-StepSummary -Index 3 -Total 3 -Message ("Install phase completed (services started where possible; CyberCNSAgent status: {0})." -f $statusText)

    if ($agentRow -and $agentRow.Status -eq 'Running') {
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "ConnectSecure has been successfully installed." 'Green'
    }

    # In interactive only (not quiet/silent/exportonly) we pause
    if (-not $Reinstall -and -not $Quiet -and -not $Silent -and -not $ExportOnly) {
        Read-Host -Prompt "Press Enter to exit"
    }

    if ($exitCode -ne 0) { exit $exitCode }
}
catch {
    # Never stop silently; just return a code
    if (-not $Silent) {
        Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
    }
    exit 9
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
    if (-not $Silent) {
        Write-HostIfNotQuiet ("Log file saved to: {0}" -f $logFile) 'DarkGray'
    }
}
