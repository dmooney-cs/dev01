﻿<#
.SYNOPSIS
  Ultra-aggressive cleanup & self-destruct tool for ConnectSecure Toolbox folders (targeted subfolder).

.DESCRIPTION
  Performs a forced, multi-stage deletion process against ONLY the specified TargetPath:
    • Kill processes running from the target tree
    • Reset ownership and ACLs (takeown/icacls)
    • Clear hidden/system/readonly attributes
    • Attempt deep removal via long-path Remove-Item
    • Robocopy mirror-purge fallback
    • Delete-on-reboot marking
    • RunOnce and ScheduledTask startup sweep

.PARAMETER TargetPath
  The primary folder to remove.
  Default: C:\CS-Toolbox-TEMP\prod-01-01

.PARAMETER PlusCol
  Also cleans:
      C:\CS-Toolbox-TEMP\Collected-Info
  using the same aggressive deletion pipeline.
  NOTE: This is one level up from the default target; do not use if you must retain it.

.PARAMETER ExportOnly
  Audit-only mode:
    - Does NOT delete anything
    - Enumerates what WOULD be deleted under TargetPath (and Collected-Info if -PlusCol)
    - Writes an audit report under: C:\CS-Toolbox-TEMP\Collected-Info\cleanup-audit.log (best effort)

#>

#requires -version 5.1
[CmdletBinding()]
param(
  [string]$TargetPath = "C:\CS-Toolbox-TEMP\prod-01-01",
  [switch]$Diag,        # Diagnostic logging + transcript
  [switch]$Quiet,       # Non-interactive output mode
  [switch]$Silent,      # No output, non-interactive
  [switch]$PlusCol,     # Also delete C:\CS-Toolbox-TEMP\Collected-Info
  [switch]$ExportOnly   # Audit-only (no deletion)
)

# =================== Exit Helper (clear window + hard-exit) ===================
$script:CS_DiagEnabled = $Diag.IsPresent

function Exit-CleanupSession {
  param([int]$Code = 0)
  try { if ($script:CS_DiagEnabled) { Stop-Transcript | Out-Null } } catch {}
  try { Clear-Host } catch {}
  [Environment]::Exit($Code)
}

# =================== Diagnostics & Globals ===================
$global:CS_LogPath = Join-Path $env:TEMP ("CS_Cleanup_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")
$global:CS_Silent  = $Silent.IsPresent
$global:CS_ColPath = "C:\CS-Toolbox-TEMP\Collected-Info"

function Log([string]$Level, [string]$Message) {
  $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
  $line = ("[{0}] {1}  {2}" -f ($Level.ToUpper()), $ts, $Message)
  $lc   = ''
  if ($null -ne $Level) { $lc = $Level.ToString().ToLower() }

  $color = 'White'
  if     ($lc -eq 'ok')    { $color = 'Green' }
  elseif ($lc -eq 'info')  { $color = 'Cyan' }
  elseif ($lc -eq 'warn')  { $color = 'Yellow' }
  elseif ($lc -eq 'fatal' -or $lc -eq 'error') { $color = 'Red' }

  if (-not $global:CS_Silent) {
    Write-Host $line -ForegroundColor $color
  }
}

function Log-Exception([string]$Context, [System.Exception]$ex) {
  $w32 = $null
  try { $w32 = (New-Object System.ComponentModel.Win32Exception([Runtime.InteropServices.Marshal]::GetLastWin32Error())).Message } catch {}
  Log 'error' ("{0} failed:" -f $Context)
  Log 'error' ("  Type: {0}" -f $ex.GetType().FullName)
  Log 'error' ("  Message: {0}" -f $ex.Message)
  Log 'error' ("  HResult: 0x{0:X8}" -f $ex.HResult)
  if ($w32) { Log 'error' ("  Win32: {0}" -f $w32) }
  if ($ex.InnerException) { Log 'error' ("  Inner: {0}" -f $ex.InnerException.Message) }
  if ($ex.ScriptStackTrace) {
    Log 'error' "  Stack:"
    $ex.ScriptStackTrace -split "`n" | ForEach-Object { Log 'error' ("    {0}" -f $_) }
  } elseif ($ex.StackTrace) {
    Log 'error' "  Stack:"
    $ex.StackTrace -split "`n" | ForEach-Object { Log 'error' ("    {0}" -f $_) }
  }
}

if ($Diag) {
  try {
    $VerbosePreference     = 'Continue'
    $InformationPreference = 'Continue'
    Start-Transcript -Path $global:CS_LogPath -Append -ErrorAction Stop | Out-Null
    Log 'info' ("Transcript started: {0}" -f $global:CS_LogPath)
  } catch {
    Log-Exception "Start-Transcript" $_.Exception
  }
}

# -Silent implies -Quiet
if ($Silent) { $Quiet = $true }

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# =================== Elevation ===================
function Assert-Elevated {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p  = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
    Log 'info' "Re-launching elevated..."
    $args = @(
      "-NoProfile","-ExecutionPolicy","Bypass","-File",
      "`"$PSCommandPath`"",
      "-TargetPath","`"$TargetPath`""
    )
    if ($Diag)       { $args += "-Diag" }
    if ($Quiet)      { $args += "-Quiet" }
    if ($Silent)     { $args += "-Silent" }
    if ($PlusCol)    { $args += "-PlusCol" }
    if ($ExportOnly) { $args += "-ExportOnly" }
    Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs | Out-Null
    Exit-CleanupSession 0
  }
}

# =================== Long-path helpers & P/Invoke ===================
function As-Long([string]$p) {
  if ($p -like "\\?\*") { return $p }
  if ($p -match '^[\\]{2}') { return "\\?\UNC\" + $p.Substring(2) }
  return "\\?\" + $p
}

Add-Type -Namespace Win32 -Name Native -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true, CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
public static extern bool MoveFileEx(string lpExistingFileName, string lpNewFileName, int dwFlags);
"@

$MOVEFILE_DELAY_UNTIL_REBOOT = 0x4

function Mark-For-DeleteOnReboot([string]$path) {
  $p = $path
  if ($p -like "\\?\UNC\*") { $p = "\\" + $p.Substring(7) }
  elseif ($p -like "\\?\*") { $p = $p.Substring(4) }
  $ok = [Win32.Native]::MoveFileEx($p, $null, $MOVEFILE_DELAY_UNTIL_REBOOT)
  if (-not $ok) {
    $err = (New-Object System.ComponentModel.Win32Exception([Runtime.InteropServices.Marshal]::GetLastWin32Error())).Message
    throw ("MoveFileEx failed: {0} (path={1})" -f $err, $p)
  }
}

# =================== Core operations ===================
function Kill-ProcsInPath([string]$path) {
  try {
    Log 'info' ("Killing processes running from under: {0}" -f $path)
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
      try {
        if ($_.Path -and ($_.Path -like "$path*")) {
          Stop-Process -Id $_.Id -Force -ErrorAction Stop
          Log 'ok' ("Killed {0} ({1})" -f $_.ProcessName, $_.Id)
        }
      } catch {
        Log-Exception ("Stop-Process " + $_.ProcessName) $_.Exception
      }
    }
    try {
      $shell = New-Object -ComObject Shell.Application -ErrorAction Stop
      foreach ($w in @($shell.Windows())) {
        try {
          $loc = $w.Document.Folder.Self.Path
          if ($loc -and ($loc -like "$path*")) { $w.Quit() }
        } catch {}
      }
    } catch { Log-Exception "Close Explorer windows" $_.Exception }
  } catch { Log-Exception "Kill-ProcsInPath" $_.Exception }
}

function Reset-OwnershipAndAcl([string]$path) {
  Log 'info' "Taking ownership + granting Administrators:(OI)(CI)F ..."
  try { & takeown.exe /F "$path" /R /D Y | Write-Verbose } catch { Log-Exception "takeown.exe" $_.Exception }
  try { & icacls.exe "$path" /grant "*S-1-5-32-544:(OI)(CI)F" /T /C | Write-Verbose } catch { Log-Exception "icacls.exe grant" $_.Exception }
}

function Clear-Attributes([string]$path) {
  Log 'info' "Clearing ReadOnly/Hidden/System attributes recursively..."
  try {
    Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
      try { [System.IO.File]::SetAttributes($_.FullName, [System.IO.FileAttributes]::Normal) } catch {}
    }
    try { [System.IO.File]::SetAttributes($path, [System.IO.FileAttributes]::Directory) } catch {}
  } catch { Log-Exception "Clear-Attributes" $_.Exception }
}

function Try-Remove([string]$path) {
  $lp = As-Long $path
  for ($i=1; $i -le 6; $i++) {
    try {
      Log 'info' ("Remove-Item attempt {0} ..." -f $i)
      Remove-Item -LiteralPath $lp -Recurse -Force -ErrorAction Stop -Verbose:$Diag
      Log 'ok' ("Removed {0}" -f $path)
      return $true
    } catch {
      Log-Exception ("Remove-Item attempt " + $i) $_.Exception
      Start-Sleep -Milliseconds 700
      Kill-ProcsInPath $path
    }
  }
  return $false
}

function Robocopy-Purge([string]$path) {
  Log 'warn' "Falling back to robocopy purge..."
  try {
    $empty = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    New-Item -ItemType Directory -Path $empty -Force | Out-Null
    & robocopy "$empty" "$path" /MIR /NFL /NDL /NJH /NJS /NC /NS /NP | Out-Null
    Remove-Item -LiteralPath (As-Long $path) -Recurse -Force -ErrorAction SilentlyContinue -Verbose:$Diag
    Remove-Item -LiteralPath (As-Long $empty) -Recurse -Force -ErrorAction SilentlyContinue
    return -not (Test-Path -LiteralPath $path)
  } catch {
    Log-Exception "Robocopy purge" $_.Exception
    return $false
  }
}

function Schedule-StartupSweep([string]$path) {
  Log 'warn' "Scheduling delete-on-boot and startup sweeps..."
  try {
    if (Test-Path -LiteralPath $path) {
      $all = Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue
      $files = $all | Where-Object { -not $_.PSIsContainer }
      $dirs  = $all | Where-Object { $_.PSIsContainer } | Sort-Object FullName -Descending
      foreach ($f in $files) { try { Mark-For-DeleteOnReboot $f.FullName } catch { Log-Exception "Mark-For-DeleteOnReboot file" $_.Exception } }
      foreach ($d in $dirs)  { try { Mark-For-DeleteOnReboot $d.FullName } catch { Log-Exception "Mark-For-DeleteOnReboot dir" $_.Exception } }
      try { Mark-For-DeleteOnReboot $path } catch { Log-Exception "Mark-For-DeleteOnReboot root" $_.Exception }
      Log 'ok' "Marked tree for delete-on-reboot."
    }
  } catch { Log-Exception "Delete-on-reboot marking" $_.Exception }

  try {
    $runOnce = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
    $cmd = "cmd.exe /c rmdir /s /q `"`\\?\$path`""
    New-ItemProperty -Path $runOnce -Name ("CS_Cleanup_" + ([Guid]::NewGuid().ToString("N"))) -Value $cmd -PropertyType String -Force | Out-Null
    Log 'ok' "RunOnce registered."
  } catch { Log-Exception "Register RunOnce" $_.Exception }

  try {
    $action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c rmdir /s /q `"`\\?\$path`""
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $taskName = "CS_Toolbox_StartupCleanup_" + ([Guid]::NewGuid().ToString("N"))
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Log 'ok' ("Startup cleanup task created: {0}" -f $taskName)
  } catch { Log-Exception "Register-ScheduledTask" $_.Exception }
}

function Dump-WhatRemains([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return }
  Log 'warn' ("Remaining content under: {0}" -f $path)
  try {
    $items = Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue |
      Select-Object FullName, @{n='LengthKB';e={[int]($_.Length/1KB)}}, Attributes, LastWriteTime |
      Sort-Object FullName
    foreach ($it in $items) {
      $line = "{0}  {1} KB  {2}  {3}" -f $it.FullName, $it.LengthKB, $it.Attributes, $it.LastWriteTime
      Log 'warn' $line
    }
  } catch { Log-Exception "Listing remaining files" $_.Exception }

  try {
    Log 'info' "ACL (SDDL) for root:"
    $acl = Get-Acl -LiteralPath $path
    Log 'info' $acl.Sddl
  } catch { Log-Exception "Get-Acl SDDL" $_.Exception }

  try {
    Log 'info' "icacls /verify output:"
    & icacls.exe "$path" /verify | ForEach-Object { Log 'info' $_ }
  } catch { Log-Exception "icacls /verify" $_.Exception }
}

function Show-PendingDeletion([string]$path) {
  Log 'info' "Enumerating files/folders that will be deleted..."
  try {
    $items = Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName
    if (-not $items -or $items.Count -eq 0) {
      Log 'info' "(Empty directory)"
    } else {
      foreach ($i in $items) { Log 'warn' $i.FullName }
    }
  } catch {
    Log-Exception "Show-PendingDeletion" $_.Exception
  }
}

function Write-AuditReport([string]$Text) {
  # Best effort: write audit to Collected-Info even if target is elsewhere.
  try {
    if (-not (Test-Path -LiteralPath $global:CS_ColPath)) {
      New-Item -ItemType Directory -Path $global:CS_ColPath -Force | Out-Null
    }
    $p = Join-Path $global:CS_ColPath "cleanup-audit.log"
    Add-Content -LiteralPath $p -Value $Text -Encoding UTF8
  } catch {}
}

function Invoke-PlusColCleanup {
  if (-not $PlusCol) { return }

  $path = $global:CS_ColPath
  if (-not (Test-Path -LiteralPath $path)) {
    Log 'info' ("PlusCol: No Collected-Info folder found at {0}" -f $path)
    return
  }

  if ($Quiet) { Show-PendingDeletion $path }

  Log 'info' ("PlusCol: Starting cleanup for {0} ..." -f $path)
  Kill-ProcsInPath $path
  Reset-OwnershipAndAcl $path
  Clear-Attributes $path

  if (Try-Remove $path) {
    Log 'ok' "PlusCol: Cleanup complete for Collected-Info."
    return
  }

  if (Robocopy-Purge $path) {
    Log 'ok' "PlusCol: Cleanup complete for Collected-Info (robocopy purge)."
    return
  }

  Dump-WhatRemains $path
  Schedule-StartupSweep $path
  Log 'warn' "PlusCol: Cleanup of Collected-Info deferred to next boot."
}

# =================== Entry ===================
try {
  Assert-Elevated

  $resolved = Resolve-Path -LiteralPath $TargetPath -ErrorAction SilentlyContinue
  if ($resolved) { $TargetPath = $resolved.Path }
  Log 'info' ("TargetPath: {0}" -f $TargetPath)

  if ($PlusCol) {
    Log 'warn' ("PlusCol is enabled: will ALSO target {0} (one level up from default target)." -f $global:CS_ColPath)
  }

  # =================== EXPORT ONLY (AUDIT) ===================
  if ($ExportOnly) {
    $hdr = "=== CS Cleanup Audit (ExportOnly) ===`r`nTime: {0}`r`nUser: {1}`r`nElevated: {2}`r`nTargetPath: {3}`r`nPlusCol: {4}`r`n" -f `
      (Get-Date), $env:USERNAME, ([Security.Principal.WindowsPrincipal]([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator), `
      $TargetPath, $PlusCol.IsPresent

    Log 'info' "ExportOnly mode: no deletion will occur."
    Log 'info' "Enumerating TargetPath..."
    Write-AuditReport $hdr

    if (Test-Path -LiteralPath $TargetPath) {
      try {
        $items = Get-ChildItem -LiteralPath $TargetPath -Force -Recurse -ErrorAction SilentlyContinue |
          Select-Object FullName, @{n='Type';e={ if($_.PSIsContainer){'Dir'} else {'File'} }}, Length, Attributes, LastWriteTime |
          Sort-Object FullName

        Write-AuditReport ("Target listing count: {0}`r`n" -f ($items.Count))
        foreach ($i in $items) {
          $line = "{0} | {1} | {2} | {3} | {4}" -f $i.Type, $i.FullName, $i.Length, $i.Attributes, $i.LastWriteTime
          Write-AuditReport ($line + "`r`n")
        }
      } catch {
        Write-AuditReport ("Target enumeration error: {0}`r`n" -f $_.Exception.Message)
      }
    } else {
      Write-AuditReport "TargetPath not found.`r`n"
    }

    if ($PlusCol -and (Test-Path -LiteralPath $global:CS_ColPath)) {
      Log 'info' "Enumerating Collected-Info (PlusCol)..."
      try {
        $ci = Get-ChildItem -LiteralPath $global:CS_ColPath -Force -Recurse -ErrorAction SilentlyContinue |
          Select-Object FullName, @{n='Type';e={ if($_.PSIsContainer){'Dir'} else {'File'} }}, Length, Attributes, LastWriteTime |
          Sort-Object FullName

        Write-AuditReport "`r`n--- PlusCol listing ---`r`n"
        Write-AuditReport ("Collected-Info listing count: {0}`r`n" -f ($ci.Count))
        foreach ($i in $ci) {
          $line = "{0} | {1} | {2} | {3} | {4}" -f $i.Type, $i.FullName, $i.Length, $i.Attributes, $i.LastWriteTime
          Write-AuditReport ($line + "`r`n")
        }
      } catch {
        Write-AuditReport ("Collected-Info enumeration error: {0}`r`n" -f $_.Exception.Message)
      }
    }

    Log 'ok' "ExportOnly complete. (Best-effort) audit written to Collected-Info\cleanup-audit.log"
    Exit-CleanupSession 0
  }

  # =================== Normal flow ===================
  if (-not (Test-Path -LiteralPath $TargetPath)) {
    Log 'info' "Nothing to delete; path not found."
    Invoke-PlusColCleanup
    Exit-CleanupSession 0
  }

  if ( (Get-Location).Path -like "$TargetPath*" ) {
    if ($Quiet) { Show-PendingDeletion $TargetPath }
    Invoke-PlusColCleanup

    Log 'warn' "Current directory is inside target. Launching detached helper..."

    $helper = @'
$ErrorActionPreference = "Stop"
function AsLong([string]$p){ if($p -like "\\?\*"){ return $p } if($p -match "^[\\]{2}"){ return "\\?\UNC\" + $p.Substring(2) } return "\\?\" + $p }
$t = "@TARGET_PATH@"
for($i=1; $i -le 60; $i++){
  Start-Sleep -Milliseconds 500
  try{
    if(Test-Path $t){
      Get-ChildItem -LiteralPath $t -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        try { [System.IO.File]::SetAttributes($_.FullName, [System.IO.FileAttributes]::Normal) } catch {}
      }
    }
    Remove-Item -LiteralPath (AsLong $t) -Recurse -Force -ErrorAction Stop
    exit 0
  } catch {}
}
try{
  if(Test-Path $t){
    $empty = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    New-Item -ItemType Directory -Path $empty | Out-Null
    & robocopy "$empty" "$t" /MIR /NFL /NDL /NJH /NJS /NC /NS /NP | Out-Null
    Remove-Item -LiteralPath (AsLong $t) -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (AsLong $empty) -Recurse -Force -ErrorAction SilentlyContinue
  }
}catch{}
exit 0
'@

    $helper = $helper.Replace('@TARGET_PATH@', $TargetPath)

    $tmp = Join-Path $env:TEMP ("cs_cleanup_" + [IO.Path]::GetRandomFileName() + ".ps1")
    Set-Content -LiteralPath $tmp -Value $helper -Encoding UTF8

    $argsArr = @(
      "-NoProfile",
      "-ExecutionPolicy","Bypass",
      "-WindowStyle","Hidden",
      "-File","`"$tmp`""
    )
    Start-Process -FilePath "powershell.exe" -ArgumentList $argsArr -WindowStyle Hidden | Out-Null
    Log 'ok' "Helper launched. Close the toolbox window; deletion will follow."
    Exit-CleanupSession 0
  }

  # QUIET / SILENT
  if ($Quiet) {
    Log 'info' "Quiet/Silent mode enabled — no prompts, just execute."
    Show-PendingDeletion $TargetPath
    Log 'info' "Beginning deletion..."

    Kill-ProcsInPath $TargetPath
    Reset-OwnershipAndAcl $TargetPath
    Clear-Attributes $TargetPath

    if (Try-Remove $TargetPath) {
      Invoke-PlusColCleanup
      Log 'ok' "Quiet/Silent cleanup complete."
      Exit-CleanupSession 0
    }

    if (Robocopy-Purge $TargetPath) {
      Invoke-PlusColCleanup
      Log 'ok' "Quiet/Silent cleanup complete (robocopy purge)."
      Exit-CleanupSession 0
    }

    Dump-WhatRemains $TargetPath
    Schedule-StartupSweep $TargetPath
    Log 'warn' "Quiet/Silent: Cleanup deferred to next boot."

    Invoke-PlusColCleanup
    Exit-CleanupSession 0
  }

  # Normal (non-quiet)
  Log 'info' "Starting cleanup sequence..."
  Kill-ProcsInPath $TargetPath
  Reset-OwnershipAndAcl $TargetPath
  Clear-Attributes $TargetPath

  if (Try-Remove $TargetPath) {
    Invoke-PlusColCleanup
    Log 'ok' "Cleanup complete."
    Exit-CleanupSession 0
  }

  if (Robocopy-Purge $TargetPath) {
    Invoke-PlusColCleanup
    Log 'ok' "Cleanup complete (robocopy purge)."
    Exit-CleanupSession 0
  }

  Dump-WhatRemains $TargetPath
  Schedule-StartupSweep $TargetPath
  Log 'warn' "Cleanup deferred to next boot. Everything is marked/scheduled for removal."

  Invoke-PlusColCleanup
  Exit-CleanupSession 0
}
catch {
  Log-Exception "Unhandled" $_.Exception
  Dump-WhatRemains $TargetPath
  Invoke-PlusColCleanup
  Exit-CleanupSession 1
}
```
