<# =================================================================================================
  CS-SNMP-Scan.ps1  (v1.01)
  Fix: Renamed -Host param to -Target to avoid collision with built-in $Host.

  ConnectSecure Technicians Toolbox - SNMP Validation Helper

  What it does:
    - Prompts for target host/IP
    - Prompts for SNMP version path:
        * v1 / v2c (community string)
        * v3 (security/auth/privacy)
    - Runs validation using validatesnmp.exe (downloads if missing)
    - Optionally (v1/v2c) can run snmpwalk if installed (-UseSnmpWalk)
    - Exports ALL run artifacts to Collected-Info per toolbox standard

  URLs (provided by CS):
    - validatesnmp.exe:
        https://toolsdev.myconnectsecure.com/agents/snmp/validatesnmp.exe
    - net-snmp installer (optional for snmpwalk usage):
        https://toolsdev.myconnectsecure.com/agents/net-snmp-5.5.0-2.x64.exe
================================================================================================= #>

[CmdletBinding()]
param(
  [Alias('IP','Host')]
  [string]$Target,

  [ValidateSet('1','2','3')]
  [string]$Version,

  [string]$CommunityString,

  [string]$SecurityName,

  [ValidateSet('MD5','SHA','md5','sha')]
  [string]$AuthProtocol,

  [string]$AuthPassword,

  [ValidateSet('AES','DES','aes','des')]
  [string]$PrivacyProtocol,

  [string]$PrivacyPassword,

  [switch]$UseSnmpWalk,
  [switch]$Silent,
  [switch]$ExportOnly,
  [switch]$NoLauncherReturn
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -------------------------------------------------------------------------------------------------
# Config
# -------------------------------------------------------------------------------------------------
$LauncherPath  = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
$CollectedRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\SNMP-Scan'
$StagingRoot   = Join-Path $CollectedRoot 'SNMP-Staging'

$ValidateSnmpUrl   = 'https://toolsdev.myconnectsecure.com/agents/snmp/validatesnmp.exe'
$ValidateSnmpPath  = Join-Path $StagingRoot 'validatesnmp.exe'

$NetSnmpInstallerUrl  = 'https://toolsdev.myconnectsecure.com/agents/net-snmp-5.5.0-2.x64.exe'
$NetSnmpInstallerPath = Join-Path $StagingRoot 'net-snmp-5.5.0-2.x64.exe'

# -------------------------------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------------------------------
function Test-IsAdmin {
  try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  } catch { return $false }
}

function Ensure-Folder([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) {
    $null = New-Item -ItemType Directory -Path $Path -Force
  }
}

function Write-Line([string]$Text = '') {
  if (-not $Silent) { Write-Host $Text }
}

function Write-Header([string]$Title) {
  if ($Silent) { return }
  Clear-Host
  Write-Host "====================================================================="
  Write-Host "  $Title"
  Write-Host "====================================================================="
}

function Pause-Enter([string]$Msg = 'Press ENTER to continue...') {
  if ($Silent -or $ExportOnly) { return }
  Write-Host ''
  Read-Host $Msg | Out-Null
}

function Download-File {
  param(
    [Parameter(Mandatory=$true)][string]$Url,
    [Parameter(Mandatory=$true)][string]$OutFile
  )

  Ensure-Folder (Split-Path -Parent $OutFile)

  # Force TLS 1.2
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

  $tmp = "$OutFile.download"
  if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }

  Invoke-WebRequest -Uri $Url -OutFile $tmp -UseBasicParsing -ErrorAction Stop
  Move-Item -LiteralPath $tmp -Destination $OutFile -Force
}

function Get-ValidateSnmpExe {
  if (Test-Path -LiteralPath $ValidateSnmpPath) { return $ValidateSnmpPath }

  Write-Line "[INFO] validatesnmp.exe not found. Downloading to staging..."
  Download-File -Url $ValidateSnmpUrl -OutFile $ValidateSnmpPath

  if (-not (Test-Path -LiteralPath $ValidateSnmpPath)) {
    throw "Download failed: validatesnmp.exe was not found after download."
  }
  return $ValidateSnmpPath
}

function Find-SnmpWalk {
  $candidates = @(
    'C:\usr\bin\snmpwalk.exe',
    'C:\Program Files\Net-SNMP\bin\snmpwalk.exe',
    'C:\Program Files (x86)\Net-SNMP\bin\snmpwalk.exe'
  )

  foreach ($p in $candidates) {
    if (Test-Path -LiteralPath $p) { return $p }
  }

  try {
    $cmd = Get-Command snmpwalk.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Path -and (Test-Path -LiteralPath $cmd.Path)) { return $cmd.Path }
  } catch {}

  return $null
}

function Redact([string]$s) {
  if ([string]::IsNullOrWhiteSpace($s)) { return '' }
  return ('*' * [Math]::Min(8, $s.Length))
}

function Export-RunArtifacts {
  param(
    [Parameter(Mandatory=$true)][string]$RunDir,
    [Parameter(Mandatory=$true)][string]$Title,
    [Parameter(Mandatory=$true)][string]$CommandLineRedacted,
    [Parameter(Mandatory=$true)][string]$StdOutPath,
    [Parameter(Mandatory=$true)][string]$StdErrPath
  )

  $meta = @()
  $meta += "Title: $Title"
  $meta += "RunTimeLocal:  $(Get-Date -Format o)"
  $meta += "IsAdmin:       $(Test-IsAdmin)"
  $meta += "Target:        $Target"
  $meta += "Version:       $Version"
  if ($Version -in @('1','2')) {
    $meta += "Community:     $CommunityString"
  } elseif ($Version -eq '3') {
    $meta += "SecurityName:  $SecurityName"
    $meta += "AuthProtocol:  $AuthProtocol"
    $meta += "AuthPassword:  $(Redact $AuthPassword)"
    $meta += "PrivProtocol:  $PrivacyProtocol"
    $meta += "PrivPassword:  $(Redact $PrivacyPassword)"
  }
  $meta += "UseSnmpWalk:   $UseSnmpWalk"
  $meta += ""
  $meta += "Command (redacted):"
  $meta += $CommandLineRedacted
  $meta += ""
  $meta += "StdOut: $StdOutPath"
  $meta += "StdErr: $StdErrPath"

  Set-Content -LiteralPath (Join-Path $RunDir 'RunInfo.txt') -Value ($meta -join "`r`n") -Encoding UTF8
}

function Invoke-ProcessCapture {
  param(
    [Parameter(Mandatory=$true)][string]$Exe,
    [Parameter(Mandatory=$true)][string[]]$Args,
    [Parameter(Mandatory=$true)][string]$StdOut,
    [Parameter(Mandatory=$true)][string]$StdErr
  )

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName               = $Exe
  $psi.Arguments              = ($Args -join ' ')
  $psi.UseShellExecute        = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError  = $true
  $psi.CreateNoWindow         = $true

  $p = New-Object System.Diagnostics.Process
  $p.StartInfo = $psi

  $null = $p.Start()
  $out = $p.StandardOutput.ReadToEnd()
  $err = $p.StandardError.ReadToEnd()
  $p.WaitForExit()

  Set-Content -LiteralPath $StdOut -Value $out -Encoding UTF8
  Set-Content -LiteralPath $StdErr -Value $err -Encoding UTF8

  return $p.ExitCode
}

# -------------------------------------------------------------------------------------------------
# Input collection (menu vs switches)
# -------------------------------------------------------------------------------------------------
function Prompt-ForInputs {
  if ($ExportOnly) { return }

  Write-Header "SNMP Scan - Validation Tool"

  if ([string]::IsNullOrWhiteSpace($Target)) {
    $Target = Read-Host "Enter target Host/IP"
  }

  if ([string]::IsNullOrWhiteSpace($Version)) {
    Write-Host ""
    Write-Host "Choose SNMP version:"
    Write-Host "  1) SNMP v1"
    Write-Host "  2) SNMP v2c"
    Write-Host "  3) SNMP v3"
    $sel = Read-Host "Selection (1/2/3)"
    if ($sel -notin @('1','2','3')) { throw "Invalid selection: $sel" }
    $Version = $sel
  }

  if ($Version -in @('1','2')) {
    if ([string]::IsNullOrWhiteSpace($CommunityString)) {
      $CommunityString = Read-Host "Enter SNMP community string"
    }

    Write-Host ""
    Write-Host "Optional: Use snmpwalk (Net-SNMP) instead of validatesnmp.exe?"
    Write-Host "  Y = Use snmpwalk (if installed)"
    Write-Host "  N = Use validatesnmp.exe (recommended)"
    $yn = Read-Host "Use snmpwalk? (Y/N)"
    if ($yn -match '^(y|yes)$') { $script:UseSnmpWalk = $true }
  }

  if ($Version -eq '3') {
    if ([string]::IsNullOrWhiteSpace($SecurityName)) {
      $SecurityName = Read-Host "Enter SNMPv3 security name (username)"
    }
    if ([string]::IsNullOrWhiteSpace($AuthProtocol)) {
      $AuthProtocol = Read-Host "Enter auth protocol (MD5 or SHA)"
    }
    if ([string]::IsNullOrWhiteSpace($AuthPassword)) {
      $AuthPassword = Read-Host "Enter auth password"
    }
    if ([string]::IsNullOrWhiteSpace($PrivacyProtocol)) {
      $PrivacyProtocol = Read-Host "Enter privacy protocol (AES or DES)"
    }
    if ([string]::IsNullOrWhiteSpace($PrivacyPassword)) {
      $PrivacyPassword = Read-Host "Enter privacy password"
    }
  }
}

function Validate-Inputs {
  if ([string]::IsNullOrWhiteSpace($Target))  { throw "Target is required. Use -Target (or -IP/-Host alias) or run interactively." }
  if ([string]::IsNullOrWhiteSpace($Version)) { throw "Version is required. Use -Version 1|2|3 or run interactively." }

  if ($Version -in @('1','2')) {
    if ([string]::IsNullOrWhiteSpace($CommunityString)) { throw "CommunityString is required for SNMP v$Version." }
  } elseif ($Version -eq '3') {
    if ([string]::IsNullOrWhiteSpace($SecurityName))    { throw "SecurityName is required for SNMP v3." }
    if ([string]::IsNullOrWhiteSpace($AuthProtocol))    { throw "AuthProtocol is required for SNMP v3." }
    if ([string]::IsNullOrWhiteSpace($AuthPassword))    { throw "AuthPassword is required for SNMP v3." }
    if ([string]::IsNullOrWhiteSpace($PrivacyProtocol)) { throw "PrivacyProtocol is required for SNMP v3." }
    if ([string]::IsNullOrWhiteSpace($PrivacyPassword)) { throw "PrivacyPassword is required for SNMP v3." }
  } else {
    throw "Unsupported Version: $Version"
  }
}

# -------------------------------------------------------------------------------------------------
# Execution
# -------------------------------------------------------------------------------------------------
function Run-ValidateSNMP {
  param(
    [Parameter(Mandatory=$true)][string]$RunDir
  )

  $exe = Get-ValidateSnmpExe

  $stdout = Join-Path $RunDir 'validatesnmp_stdout.txt'
  $stderr = Join-Path $RunDir 'validatesnmp_stderr.txt'

  $args = @()
  $args += "-version"
  $args += $Version
  if ($Version -in @('1','2')) {
    $args += "-community_string"
    $args += ('"{0}"' -f $CommunityString)
  } else {
    $args += "-security_name"
    $args += ('"{0}"' -f $SecurityName)
    $args += "-auth_protocol"
    $args += ('"{0}"' -f $AuthProtocol.ToUpper())
    $args += "-auth_password"
    $args += ('"{0}"' -f $AuthPassword)
    $args += "-privacy_protocol"
    $args += ('"{0}"' -f $PrivacyProtocol.ToUpper())
    $args += "-privacy_password"
    $args += ('"{0}"' -f $PrivacyPassword)
  }
  $args += "-ip"
  $args += ('"{0}"' -f $Target)

  $cmdRedacted = ($exe + ' ' + (($args -join ' ') `
    -replace [Regex]::Escape($AuthPassword), (Redact $AuthPassword) `
    -replace [Regex]::Escape($PrivacyPassword), (Redact $PrivacyPassword)))

  Write-Line ""
  Write-Line "[RUN] validatesnmp.exe (passwords redacted in logs)"
  if (-not $Silent) { Write-Host ("      {0}" -f $cmdRedacted) }

  $exit = Invoke-ProcessCapture -Exe $exe -Args $args -StdOut $stdout -StdErr $stderr

  Export-RunArtifacts -RunDir $RunDir -Title "SNMP Validate (validatesnmp.exe)" -CommandLineRedacted $cmdRedacted -StdOutPath $stdout -StdErrPath $stderr

  return @{
    ExitCode = $exit
    StdOut   = $stdout
    StdErr   = $stderr
    Cmd      = $cmdRedacted
  }
}

function Run-SnmpWalk {
  param(
    [Parameter(Mandatory=$true)][string]$RunDir
  )

  $snmpwalk = Find-SnmpWalk
  if (-not $snmpwalk) {
    Write-Line ""
    Write-Line "[WARN] snmpwalk.exe not found. Falling back to validatesnmp.exe."
    return $null
  }

  $stdout = Join-Path $RunDir 'snmpwalk_stdout.txt'
  $stderr = Join-Path $RunDir 'snmpwalk_stderr.txt'

  $verArg = if ($Version -eq '1') { '-v1' } else { '-v2c' }
  $args = @(
    $verArg,
    '-c', ('"{0}"' -f $CommunityString),
    ('"{0}"' -f $Target)
  )

  $cmd = $snmpwalk + ' ' + ($args -join ' ')
  Write-Line ""
  Write-Line "[RUN] snmpwalk.exe"
  if (-not $Silent) { Write-Host ("      {0}" -f $cmd) }

  $exit = Invoke-ProcessCapture -Exe $snmpwalk -Args $args -StdOut $stdout -StdErr $stderr

  Export-RunArtifacts -RunDir $RunDir -Title "SNMP Walk (snmpwalk.exe)" -CommandLineRedacted $cmd -StdOutPath $stdout -StdErrPath $stderr

  return @{
    ExitCode = $exit
    StdOut   = $stdout
    StdErr   = $stderr
    Cmd      = $cmd
  }
}

function Show-Results {
  param(
    [Parameter(Mandatory=$true)][string]$RunDir,
    [Parameter(Mandatory=$true)][hashtable]$Result
  )

  if ($Silent -or $ExportOnly) { return }

  Write-Host ""
  Write-Host "====================================================================="
  Write-Host "  Output (share these files with CS if requested)"
  Write-Host "====================================================================="
  Write-Host "Run folder: $RunDir"
  Write-Host ""

  if (Test-Path -LiteralPath $Result.StdOut) {
    Write-Host "----------------------------- STDOUT -----------------------------"
    Get-Content -LiteralPath $Result.StdOut -ErrorAction SilentlyContinue | ForEach-Object { Write-Host $_ }
  }
  if (Test-Path -LiteralPath $Result.StdErr) {
    $errText = Get-Content -LiteralPath $Result.StdErr -ErrorAction SilentlyContinue
    if ($errText -and $errText.Count -gt 0) {
      Write-Host ""
      Write-Host "----------------------------- STDERR -----------------------------"
      $errText | ForEach-Object { Write-Host $_ }
    }
  }

  Write-Host ""
  Write-Host ("ExitCode: {0}" -f $Result.ExitCode)
}

function Return-ToLauncher {
  if ($ExportOnly -or $NoLauncherReturn) { return }
  if (Test-Path -LiteralPath $LauncherPath) {
    Write-Line ""
    Pause-Enter "Press ENTER to return to Toolbox Launcher..."
    try {
      Clear-Host
      & $LauncherPath
    } catch {
      Write-Line "[WARN] Could not launch toolbox launcher: $($_.Exception.Message)"
    }
  } else {
    Pause-Enter "Launcher not found. Press ENTER to exit..."
  }
}

# -------------------------------------------------------------------------------------------------
# Main
# -------------------------------------------------------------------------------------------------
try {
  Ensure-Folder $CollectedRoot
  Ensure-Folder $StagingRoot

  if (-not (Test-IsAdmin)) {
    Write-Line "[WARN] Not running as Administrator. If the tool or network validation fails, re-run PowerShell as Administrator."
  }

  Prompt-ForInputs
  Validate-Inputs

  $stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
  $RunDir = Join-Path $CollectedRoot $stamp
  Ensure-Folder $RunDir

  Write-Header "SNMP Scan - Running"
  Write-Line "Target:  $Target"
  Write-Line "Version: $Version"

  $result = $null

  if ($UseSnmpWalk -and ($Version -in @('1','2'))) {
    $result = Run-SnmpWalk -RunDir $RunDir
    if (-not $result) {
      $result = Run-ValidateSNMP -RunDir $RunDir
    }
  } else {
    $result = Run-ValidateSNMP -RunDir $RunDir
  }

  Show-Results -RunDir $RunDir -Result $result

  if (-not $ExportOnly) {
    Write-Host ""
    Write-Host "Saved to: $RunDir"
    Write-Host "Files:"
    Write-Host "  - RunInfo.txt"
    Write-Host "  - validatesnmp_stdout/stderr.txt (or snmpwalk_stdout/stderr.txt)"
    Write-Host ""
    Write-Host "Optional (if you need snmpwalk):"
    Write-Host "  Net-SNMP installer URL:"
    Write-Host "    $NetSnmpInstallerUrl"
    Write-Host "  (Download + install, then rerun with -UseSnmpWalk)"
  }

  Return-ToLauncher
  exit 0
}
catch {
  if (-not $Silent) {
    Write-Host ""
    Write-Host "====================================================================="
    Write-Host "ERROR"
    Write-Host "====================================================================="
    Write-Host $_.Exception.Message
    Write-Host ""
  }

  try {
    Ensure-Folder $CollectedRoot
    $stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
    $RunDir = Join-Path $CollectedRoot ("ERROR_{0}" -f $stamp)
    Ensure-Folder $RunDir

    $errPath = Join-Path $RunDir 'Error.txt'
    Set-Content -LiteralPath $errPath -Value ($_.Exception.ToString()) -Encoding UTF8
  } catch {}

  if (-not $ExportOnly) { Pause-Enter "Press ENTER to return..." }
  Return-ToLauncher
  exit 1
}