# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ==============================
#   WMIC Patch Audit (QFE list)
# ==============================

Show-Header "Windows Patches (WMIC QFE)"

$patchOutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\Patches'
if (-not (Test-Path $patchOutRoot)) {
    $null = New-Item -Path $patchOutRoot -ItemType Directory
}

$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$csvPath = Join-Path $patchOutRoot ("WMIC_QFE_" + $ts + ".csv")
$txtPath = Join-Path $patchOutRoot ("WMIC_QFE_" + $ts + ".txt")

# Locate WMIC
$wmicPaths = @(
    (Join-Path $env:SystemRoot 'System32\wbem\WMIC.exe'),
    (Join-Path $env:SystemRoot 'SysWOW64\wbem\WMIC.exe'),
    (Join-Path $env:SystemRoot 'Sysnative\wbem\WMIC.exe')
)
$wmic = $wmicPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $wmic) {
    Write-Host "ERROR: WMIC.exe not found on this system." -ForegroundColor Red
    Pause-Script "Press any key to exit..."
    return
}

Write-Host "Gathering Quick Fix Engineering entries via WMIC..." -ForegroundColor Cyan

# Temporary files for raw output
$tempCsv = [System.IO.Path]::GetTempFileName()
$tempTxt = [System.IO.Path]::GetTempFileName()

# Run WMIC to CSV (full) and TXT (brief)
$proc1 = Start-Process -FilePath $wmic -ArgumentList 'qfe list full /format:csv' -NoNewWindow -RedirectStandardOutput $tempCsv -PassThru
$null = $proc1.WaitForExit()

$proc2 = Start-Process -FilePath $wmic -ArgumentList 'qfe list brief' -NoNewWindow -RedirectStandardOutput $tempTxt -PassThru
$null = $proc2.WaitForExit()

# Normalize encodings (WMIC often emits UTF-16 LE; fall back to Default if needed)
try {
    try {
        $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Unicode
    } catch {
        $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Default
    }

    try {
        $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Unicode
    } catch {
        $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Default
    }

    if (Get-Command -Name Write-Utf8NoBom -ErrorAction SilentlyContinue) {
        Write-Utf8NoBom -Path $csvPath -Content ($rawCsv -join [Environment]::NewLine)
        Write-Utf8NoBom -Path $txtPath -Content ($rawTxt -join [Environment]::NewLine)
    } else {
        ($rawCsv -join [Environment]::NewLine) | Set-Content -LiteralPath $csvPath -Encoding UTF8
        ($rawTxt -join [Environment]::NewLine) | Set-Content -LiteralPath $txtPath -Encoding UTF8
    }
} catch {
    Write-Host "WARN: Failed to re-encode outputs: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Display quick summary by parsing CSV (manual header scan; no LineNumber dependency)
try {
    $rows = @()
    $csvLines = Get-Content -LiteralPath $csvPath -Encoding UTF8

    # Some WMIC builds add blank lines or extra metadata at the top.
    # Find the FIRST line that looks like a CSV header containing both Node and HotFixID.
    $headerIndex = -1
    for ($i = 0; $i -lt $csvLines.Count; $i++) {
        $line = $csvLines[$i].Trim()
        if ($line -match '^(?i)Node,' -and $line -match '(?i)HotFixID') {
            $headerIndex = $i
            break
        }
    }

    if ($headerIndex -ge 0) {
        $data = $csvLines[$headerIndex..($csvLines.Count - 1)]
    } else {
        # Fallback: attempt to parse everything
        $data = $csvLines
    }

    # Try parsing; different WMIC builds vary in column casing.
    $rows = $data | ConvertFrom-Csv

    if ($rows -and $rows.Count -gt 0) {
        # Normalize possible column name variants
        $colHotFix   = @('HotFixID','HotfixID','HotFixId') | Where-Object { $rows[0].PSObject.Properties.Name -contains $_ } | Select-Object -First 1
        $colInstalled= @('InstalledOn','Installed_On')    | Where-Object { $rows[0].PSObject.Properties.Name -contains $_ } | Select-Object -First 1
        $colDesc     = @('Description')                   | Where-Object { $rows[0].PSObject.Properties.Name -contains $_ } | Select-Object -First 1
        $colBy       = @('InstalledBy','Installed_By')    | Where-Object { $rows[0].PSObject.Properties.Name -contains $_ } | Select-Object -First 1

        $sel = @()
        if ($colHotFix)    { $sel += @{n='HotFixID';e={$_.$colHotFix}} }
        if ($colInstalled) { $sel += @{n='InstalledOn';e={$_.$colInstalled}} }
        if ($colDesc)      { $sel += @{n='Description';e={$_.$colDesc}} }
        if ($colBy)        { $sel += @{n='InstalledBy';e={$_.$colBy}} }

        if ($sel.Count -eq 0) {
            # If columns are totally unexpected, just dump first few props for visibility
            $rows | Select-Object -First 20 | Format-List
        } else {
            $rows | Select-Object $sel | Sort-Object InstalledOn, HotFixID | Format-Table -AutoSize
        }

        Write-Host ""
        Write-Host "Saved:" -ForegroundColor Green
        Write-Host "  CSV: $csvPath" -ForegroundColor Green
        Write-Host "  TXT: $txtPath" -ForegroundColor Green
        Write-Host ""
        Write-Host "Tip: CSV includes FixComments when present." -ForegroundColor DarkGray
    } else {
        Write-Host "Info: No WMIC QFE entries found." -ForegroundColor DarkCyan
        Write-Host "Files saved (may be empty):" -ForegroundColor DarkCyan
        Write-Host "  $csvPath" -ForegroundColor DarkCyan
        Write-Host "  $txtPath" -ForegroundColor DarkCyan
    }
} catch {
    Write-Host "WARN: Could not parse WMIC CSV for on-screen table: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "Outputs still saved to:" -ForegroundColor Yellow
    Write-Host "  $csvPath" -ForegroundColor Yellow
    Write-Host "  $txtPath" -ForegroundColor Yellow
}

Pause-Script "Press any key to return..."
return
