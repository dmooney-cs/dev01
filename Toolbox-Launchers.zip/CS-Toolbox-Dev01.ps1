# CS-Toolbox-Launcher-FromZip-dev01.ps1
# Zero-touch Bootstrapper for ConnectSecure Technician Toolbox (dev01)
# - NO user prompts
# - Downloads prod-01-01.zip (with retry logic)
# - Extracts to C:\CS-Toolbox-TEMP\prod-01-01
# - Launches CS-Toolbox-Launcher.ps1 in the SAME PowerShell window (dot-sourced)

# --------------------------
# Config
# --------------------------
$ZipUrl      = 'https://github.com/dmooney-cs/dev01/raw/refs/heads/main/prod-01-01.zip'
$ZipPath     = Join-Path $env:TEMP 'prod-01-01.zip'
$ExtractPath = 'C:\CS-Toolbox-TEMP'
$DestRoot    = Join-Path $ExtractPath 'prod-01-01'
$Launcher    = Join-Path $DestRoot 'CS-Toolbox-Launcher.ps1'

# --------------------------
# Prep environment
# --------------------------
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

if (-not (Test-Path -LiteralPath $ExtractPath)) {
    New-Item -Path $ExtractPath -ItemType Directory -Force | Out-Null
}

# Clean existing destination
if (Test-Path -LiteralPath $DestRoot) {
    try {
        Remove-Item -LiteralPath $DestRoot -Recurse -Force -ErrorAction Stop
    } catch {
        Write-Host ("⚠️ WARN: Failed to remove existing folder {0}: {1}" -f $DestRoot, $_.Exception.Message) -ForegroundColor Yellow
    }
}

# --------------------------
# Helper: Download with retries
# --------------------------
function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        Write-Host ("Downloading toolbox... Attempt {0}/{1}" -f $attempt, $MaxAttempts) -ForegroundColor Cyan
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Get-Item -LiteralPath $OutFile).Length -gt 0) {
                Write-Host "✅ Download successful." -ForegroundColor Green
                return $true
            }
            throw "Downloaded file is empty."
        } catch {
            if ($attempt -eq $MaxAttempts) {
                Write-Host ("❌ ERROR: Download failed: {0}" -f $_.Exception.Message) -ForegroundColor Red
                return $false
            }
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $false
}

# --------------------------
# Download ZIP
# --------------------------
if (-not (Invoke-DownloadWithRetry -Uri $ZipUrl -OutFile $ZipPath)) {
    throw "Toolbox download failed."
}

# --------------------------
# Extract ZIP
# --------------------------
Write-Host 'Extracting toolbox...' -ForegroundColor Cyan
Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force

if (-not (Test-Path -LiteralPath $DestRoot)) {
    New-Item -Path $DestRoot -ItemType Directory -Force | Out-Null
}

# --------------------------
# Normalize folder structure
# --------------------------
function Move-Contents([string]$Source, [string]$Target) {
    if (-not (Test-Path -LiteralPath $Source)) { return }
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Move-Item -LiteralPath $_.FullName -Destination $Target -Force -ErrorAction SilentlyContinue
    }
}

if (-not (Test-Path -LiteralPath (Join-Path $DestRoot 'CS-Toolbox-Launcher.ps1'))) {
    $dirs  = Get-ChildItem -LiteralPath $ExtractPath -Directory | Where-Object { $_.FullName -ne $DestRoot }
    $files = Get-ChildItem -LiteralPath $ExtractPath -File | Where-Object { $_.FullName -ne $ZipPath }

    if ($dirs.Count -eq 1 -and $files.Count -eq 0) {
        Move-Contents $dirs[0].FullName $DestRoot
        Remove-Item $dirs[0].FullName -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        foreach ($d in $dirs) { Move-Contents $d.FullName $DestRoot }
        foreach ($f in $files) { Move-Item $f.FullName $DestRoot -Force -ErrorAction SilentlyContinue }
        foreach ($d in $dirs) { Remove-Item $d.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# --------------------------
# Unblock files
# --------------------------
Get-ChildItem -LiteralPath $DestRoot -Recurse -File -Force |
    ForEach-Object { Unblock-File $_.FullName -ErrorAction SilentlyContinue }

# --------------------------
# Verify + Launch
# --------------------------
if (-not (Test-Path -LiteralPath $Launcher)) {
    throw "Launcher not found: $Launcher"
}

Write-Host '✅ Toolbox ready. Launching...' -ForegroundColor Green

. $Launcher
