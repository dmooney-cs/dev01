<# =================================================================================================
 CS-Toolbox-Decryptor.ps1  (v1.8 - PS5.1-safe RSA unwrap fix + ExportOnly)

 Fixes:
  - Correct RSA unwrap for OAEP-SHA1 / OAEP-SHA256 across RSACng/RSAOpenSsl/RSA + RSACryptoServiceProvider.
  - Avoids invalid padding usage that leads to: "The property 'Oaep' cannot be found on this object."
  - Keeps PBES2/PBKDF2/AES-CBC decrypt of encrypted PKCS#8 private key (as in your old decryptor).

 Behavior:
  - Prompts for passphrase (SecureString) to decrypt embedded encrypted private key.
  - Lets user pick a .csb file (or pass -InFile).
  - Outputs ZIP + extracted folder under OutDir (default C:\CS-Toolbox-TEMP\Decrypt).
  - Opens File Explorer to extracted directory.

 Switches:
  -InFile <path>   : Decrypt a specific CSB without OpenFileDialog
  -OutDir <path>   : Output folder (default C:\CS-Toolbox-TEMP\Decrypt)
  -ExportOnly      : Export JSON summary to C:\CS-Toolbox-TEMP\Collected-Info and exit

================================================================================================= #>

#requires -version 5.1
[CmdletBinding()]
param(
  [string]$InFile,
  [string]$OutDir = 'C:\CS-Toolbox-TEMP\Decrypt',
  [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =================== Logging ===================
function Write-Info ($m){ Write-Host "[INFO]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Cyan }
function Write-Ok   ($m){ Write-Host "[OK]    $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Green }
function Write-Warn ($m){ Write-Host "[WARN]  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Yellow }
function Write-Err  ($m){ Write-Host "[ERROR] $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" -ForegroundColor Red }

function Ensure-Folder {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

Ensure-Folder -Path $OutDir

# Ensure Zip APIs (PS 5.1-safe)
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+ or ensure System.IO.Compression assemblies are present." }
  }
}

# ---- Embedded encrypted PKCS#8 PRIVATE KEY (PEM) ----
$EncryptedPrivateKeyPem = @'
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQVqpfmIOsXqQKzn+1
cECzMQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEJrXQAs92MM6jTy6
tRw43LIEggTQ9zl6K9oEJHLdrTWmhxS22okeXW9NGU7jorabqXsPDU52aGao43xS
1Q+tsPpkqR3Fi/ujL7x9NxbUUWhYlmz89UTfrpnn1l4h4+Fy+W+k2Wz8CTbjnN5S
oaPfzH40km+zDXib7HAvyNix5dUkQ05GVR6SBu3ljNrlLY1UKgP9NNVyOjyaCE37
jViKUuYEjXnoconYgjWiqY8zvl3K3SKK7Qf5S3y7fM2KLI2uZLM5JbwixDNLAmEx
il0cMyiu06nhltRPGriMWblsNnTQJrF+Lbuh/qHzNOu23XTqDSxHqSHubiibkLzl
nmFP7VG+iKpE8NCkF1Sp/y3rmJPjzzBYfrQqcnAqsUoikr8YqZL0+geNJ4YR43vi
Ks/xlFkj6exQSAVGWivO2miUwReq1RWcpUDQdYWrsI6A0ZaqONvRN5fHyP+RkxRO
aIugnGmmoPGS2G3aA/WfjsVudkwCAng8SLyCNnM4D/ry2AUetfhYagHSAqbih6Mg
LB3NhbvE4BJ/ixTTnM7HIdbiFY/rP43JpWS7z5PfWoAcvc7fPbtyjKrmsMTvKaut
klLgVFTBjiLcM3jgMW4RUE22RR8lHxp+4WOfMhoVrGUPVP5ptWUxompKE2fc2p1b
L5lpK/oYm/TqL4cdDP+FQzDIFwLb2AUaaRxzcmDLK3aSqMwjTHvT3Qp4LzD+r/w4
I7dCix3TBuQu8L/NzMXRlJ9OjyxDoyuE+6nRcfQGaXIcIgcv05y3RbWlCh4MD3Np
rzjxYwKYrR3dOKLbH1cfOZDrVKPKGr/b1sXukEcX+aiGb3uBkuAC02XAKBXG9VN5
TzT2F4JEZ2ecflRDcB8YEzCc1yoej9xaR821fqtfjE99Bp2yA60wP79Jdv/uWJau
T2PyrlFQB9m5gfBUqhqbIhvmpBX4EtwKXOs3IDc8xKhy4YuhBhwKpySJ3BDzZ1D0
5vmilv19R2EEsvwlOxQPpp+73u5hcTDluxj5ddNww+xe9MQp4RGHMqnTjFKPHPAA
GeG6AhQW4PfREUZvV6WV/mrIbVTkEhINzETPP8aJRuPjwqRvmvEUb0gE97iG8hqo
5pcp1fHyc7LshQoZ81PwgMYM80i5V53dCfC/6UGflKWj34dwfRh+KvLWCztOew10
+ypcxT/lditoomPkrFP0cC9r0C3UyPNU6R+Sb2gp4WKWmI/N8z0Vr2JjwjuoiHw1
nLF1zz7VZhSpGeMOxe07gdNBhiXY0c9uUSuTE0TmeSqP+1t3+i2f+vA+V8qmuMI/
1qObRazOcoGx3O4iw5p3q+fMrYoMGcXWzYiMWi6jtCZ5LlEsopuSmQPISUMJshMO
TJxHpoKVg13U9vVHmasPpBXAXXJrNO9SGAPDYPOBZbHNaw9+SzTDrgT2XMpc0/fY
0FLwKP1iBjboUwR46FnR2Pnx6HmVADnNt0cFzezQVUhn4IGlvWRoLkpsL3Ynm11P
ohaL+j126Nht01Jm1HrM4fUPIslw52WyMqBR/PM3QhG/uyHa1Ld6K53gIsid30uq
b8KYM3aBKxnUhGQ21YuVjg0v8noWnkaYY4iQj5VURRD9+cBrp0N7mCClY3R3T/cN
7D/ShzXBnVCX2J1eXT8p6v6He3ue9EIWtRwvyd6b8BswoMPOlRCbWaQ=
-----END ENCRYPTED PRIVATE KEY-----
'@

# =================== Small byte helpers ===================
function Join-Bytes([byte[]]$a,[byte[]]$b){
  $out = New-Object byte[] ($a.Length + $b.Length)
  [Array]::Copy($a,0,$out,0,$a.Length)
  [Array]::Copy($b,0,$out,$a.Length,$b.Length)
  return $out
}
function BytesEqual([byte[]]$a,[byte[]]$b){
  if ($a.Length -ne $b.Length) { return $false }
  $diff = 0
  for($i=0;$i -lt $a.Length;$i++){ $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

# =================== UI: pick .csb bundle ===================
function Pick-CsbFile {
  Add-Type -AssemblyName System.Windows.Forms | Out-Null
  $ofd = New-Object Windows.Forms.OpenFileDialog
  $ofd.Filter = "ConnectSecure bundle (*.csb)|*.csb|All files (*.*)|*.*"
  $ofd.Title  = "Pick the encrypted bundle (*.csb)..."
  $null = $ofd.ShowDialog()
  if ([string]::IsNullOrWhiteSpace($ofd.FileName)) { throw "No file selected." }
  return $ofd.FileName
}

# Secure passphrase
function Read-Secret([string]$prompt){
  Write-Host -NoNewline $prompt
  $sec = Read-Host -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

# =================== ASN.1 helpers ===================
function ASN-ExpectTag([byte[]]$buf, [int]$idx, [byte]$tag) {
  if ($idx -ge $buf.Length) { throw "ASN.1 read past end at $idx" }
  if ($buf[$idx] -ne $tag) { throw "ASN.1 tag mismatch. Expected 0x$("{0:X2}" -f $tag), got 0x$("{0:X2}" -f $buf[$idx]) at $idx" }
  return ($idx + 1)
}
function ASN-ReadLen([byte[]]$buf, [int]$idx) {
  if ($idx -ge $buf.Length) { throw "ASN.1 length read past end" }
  $b = [int]$buf[$idx]; $idx++
  if ($b -lt 0x80) { return @{ Len = $b; Idx = $idx } }
  $n = $b - 0x80; if ($n -lt 1 -or $n -gt 4) { throw "Unsupported length octets ($n)" }
  if ($idx + $n -gt $buf.Length) { throw "ASN.1 length overrun" }
  $val = 0
  for($k=0;$k -lt $n;$k++){ $val = (($val -shl 8) -bor [int]$buf[$idx]); $idx++ }
  return @{ Len = $val; Idx = $idx }
}
function ASN-ReadInt([byte[]]$buf, [int]$idx) {
  $idx = ASN-ExpectTag $buf $idx 0x02
  $lr  = ASN-ReadLen  $buf $idx; $len = $lr.Len; $idx = $lr.Idx
  if ($idx + $len -gt $buf.Length) { throw "ASN.1 INTEGER overrun" }
  $val = $buf[$idx..($idx+$len-1)]; $idx += $len
  if ($val.Length -gt 1 -and $val[0] -eq 0x00) { $val = $val[1..($val.Length-1)] }
  return @{ Val = ([byte[]]$val); Idx = $idx }
}
function ASN-ReadOctets([byte[]]$buf, [int]$idx) {
  $idx = ASN-ExpectTag $buf $idx 0x04
  $lr  = ASN-ReadLen  $buf $idx; $len = $lr.Len; $idx = $lr.Idx
  if ($idx + $len -gt $buf.Length) { throw "ASN.1 OCTET STRING overrun" }
  return @{ Val = ([byte[]]$buf[$idx..($idx+$len-1)]); Idx = ($idx + $len) }
}
function ASN-ReadOid([byte[]]$buf, [int]$idx) {
  $idx = ASN-ExpectTag $buf $idx 0x06
  $lr  = ASN-ReadLen  $buf $idx; $len = $lr.Len; $idx = $lr.Idx
  if ($idx + $len -gt $buf.Length) { throw "ASN.1 OID overrun" }
  $data = $buf[$idx..($idx+$len-1)]; $idx += $len
  $first = [int]$data[0]; $a = [int]([math]::Floor($first/40)); $b = $first % 40
  $oidParts = @($a,$b)
  $val=0
  for($i=1;$i -lt $data.Length;$i++){
    $val = ($val -shl 7) -bor ($data[$i] -band 0x7F)
    if(($data[$i] -band 0x80) -eq 0){ $oidParts += $val; $val=0 }
  }
  @{ Oid = ($oidParts -join '.'); Idx = $idx }
}
function ASN-ReadSeq([byte[]]$buf, [int]$idx) {
  $idx = ASN-ExpectTag $buf $idx 0x30
  $lr  = ASN-ReadLen  $buf $idx; $len = $lr.Len; $idx = $lr.Idx
  if ($idx + $len -gt $buf.Length) { throw "ASN.1 SEQUENCE overrun" }
  @{ Start=$idx; End=($idx+$len); Idx=$idx }
}
function IntFromBytes([byte[]]$b){ $v=0; foreach($x in $b){ $v = (($v -shl 8) -bor $x) }; return $v }

# =================== PBES2/PBKDF2/AES-CBC decrypt of PKCS#8 ===================
function PemToBytes([string]$pem, [string]$header, [string]$footer){
  $clean = ($pem -replace "`r","" -replace "`n","`n")
  $i1 = $clean.IndexOf($header); $i2 = $clean.IndexOf($footer)
  if ($i1 -lt 0 -or $i2 -lt 0) { throw "PEM missing header/footer" }
  $b64 = $clean.Substring($i1 + $header.Length, $i2 - ($i1 + $header.Length)) -replace '\s',''
  [Convert]::FromBase64String($b64)
}

function PBKDF2-Derive([string]$password, [byte[]]$salt, [int]$iters, [int]$keyLen, [string]$prf){
  if ($prf -eq 'SHA1') {
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters)
    try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
  } elseif ($prf -eq 'SHA256') {
    try {
      $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
      try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
    } catch {
      # Manual PBKDF2-HMAC-SHA256
      $pwd = [Text.Encoding]::UTF8.GetBytes($password)
      $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$pwd)
      try {
        $hLen = 32
        $blocks = [int][math]::Ceiling($keyLen / $hLen)
        $dk = New-Object byte[] ($blocks * $hLen)
        for ($i=1; $i -le $blocks; $i++){
          $intBlock = [byte[]]@(
            ($i -shr 24) -band 0xFF,
            ($i -shr 16) -band 0xFF,
            ($i -shr 8)  -band 0xFF,
            $i -band 0xFF
          )
          $u = $hmac.ComputeHash( (Join-Bytes $salt $intBlock) )
          $t = [byte[]]$u.Clone()
          for ($j=2; $j -le $iters; $j++){
            $u = $hmac.ComputeHash($u)
            for ($kidx=0; $kidx -lt $hLen; $kidx++){ $t[$kidx] = $t[$kidx] -bxor $u[$kidx] }
          }
          [Array]::Copy($t, 0, $dk, ($i-1)*$hLen, $hLen)
        }
        $out = New-Object byte[] $keyLen
        [Array]::Copy($dk, 0, $out, 0, $keyLen)
        return $out
      } finally {
        $hmac.Dispose()
      }
    }
  } else {
    throw "Unsupported PBKDF2 PRF: $prf"
  }
}

function Decrypt-Pkcs8EncryptedPrivateKey([string]$pem, [string]$password){
  Write-Info "Loading private key..."
  $der = PemToBytes $pem '-----BEGIN ENCRYPTED PRIVATE KEY-----' '-----END ENCRYPTED PRIVATE KEY-----'

  # EncryptedPrivateKeyInfo ::= SEQUENCE { encryptionAlgorithm AlgorithmIdentifier, encryptedData OCTET STRING }
  $top = ASN-ReadSeq $der 0
  $idx = $top.Idx

  # encryptionAlgorithm (PBES2)
  $alg = ASN-ReadSeq $der $idx
  $idx = $alg.End
  $algOid = ASN-ReadOid $der $alg.Idx
  if ($algOid.Oid -ne '1.2.840.113549.1.5.13') { throw "Unsupported encryption algorithm OID: $($algOid.Oid) (expected PBES2)" }
  $pbes2 = ASN-ReadSeq $der $algOid.Idx

  # PBES2 params: kdf + enc
  $kdfAlg = ASN-ReadSeq $der $pbes2.Idx
  $encAlgPos = $kdfAlg.End
  $kdfOid = ASN-ReadOid $der $kdfAlg.Idx
  if ($kdfOid.Oid -ne '1.2.840.113549.1.5.12') { throw "Unsupported KDF OID: $($kdfOid.Oid) (expected PBKDF2)" }
  $pbkdf2Seq = ASN-ReadSeq $der $kdfOid.Idx

  $saltOct   = ASN-ReadOctets $der $pbkdf2Seq.Idx
  $iterInt   = ASN-ReadInt    $der $saltOct.Idx
  $scanIdx   = $iterInt.Idx
  $klenMaybe = $null
  $prfOid    = '1.2.840.113549.2.7' # default HMAC-SHA1
  if ($scanIdx -lt $pbkdf2Seq.End) {
    if ($der[$scanIdx] -eq 0x02) { $klenMaybe = ASN-ReadInt $der $scanIdx; $scanIdx = $klenMaybe.Idx }
    if ($scanIdx -lt $pbkdf2Seq.End -and $der[$scanIdx] -eq 0x30) {
      $prfSeq = ASN-ReadSeq $der $scanIdx
      $prfRead = ASN-ReadOid $der $prfSeq.Idx
      $prfOid = $prfRead.Oid
    }
  }

  # encryptionScheme (AES-CBC + IV)
  $encAlg = ASN-ReadSeq $der $encAlgPos
  $encOid = ASN-ReadOid $der $encAlg.Idx
  $ivOct  = ASN-ReadOctets $der $encOid.Idx

  # encryptedData OCTET STRING after encryptionAlgorithm
  $encOctet = ASN-ReadOctets $der $idx
  $cipherPrivKey = $encOctet.Val

  # KDF derive
  $prf = if ($prfOid -eq '1.2.840.113549.2.7') { 'SHA1' } elseif ($prfOid -eq '1.2.840.113549.2.9') { 'SHA256' } else { throw "Unsupported PRF OID: $prfOid" }
  $aesBits = switch ($encOid.Oid) {
    '2.16.840.1.101.3.4.1.42' { 256 } # aes256-CBC
    '2.16.840.1.101.3.4.1.22' { 192 }
    '2.16.840.1.101.3.4.1.2'  { 128 }
    default { throw "Unsupported encryption OID: $($encOid.Oid) (expected AES-CBC)" }
  }
  $keyLen = if ($klenMaybe) { IntFromBytes $klenMaybe.Val } else { $aesBits / 8 }
  $iters  = [int](IntFromBytes $iterInt.Val)
  if ($iters -le 0) { throw "Bad PBKDF2 iteration count" }

  $key = PBKDF2-Derive $password $saltOct.Val $iters $keyLen $prf

  # AES-CBC decrypt -> PrivateKeyInfo (DER)
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = $aesBits
    $aes.BlockSize = 128
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $key
    $aes.IV  = $ivOct.Val

    $ms = New-Object IO.MemoryStream
    try {
      $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try {
        $cs.Write($cipherPrivKey,0,$cipherPrivKey.Length)
        $cs.FlushFinalBlock()
      } finally {
        $cs.Dispose()
      }
      $pkcs8 = $ms.ToArray()
    } finally {
      $ms.Dispose()
    }
  } finally {
    $aes.Dispose()
  }

  # PrivateKeyInfo -> RSAPrivateKey
  $pki = ASN-ReadSeq $pkcs8 0
  $i2 = $pki.Idx
  $ver  = ASN-ReadInt $pkcs8 $i2; $i2 = $ver.Idx
  $alg2 = ASN-ReadSeq $pkcs8 $i2
  $oid2 = ASN-ReadOid $pkcs8 $alg2.Idx
  if ($oid2.Oid -ne '1.2.840.113549.1.1.1') { throw "PrivateKey algorithm not RSA (OID $($oid2.Oid))" }
  $i2 = $alg2.End
  $ok = ASN-ReadOctets $pkcs8 $i2
  $rk = $ok.Val

  # RSAPrivateKey decode
  $rseq = ASN-ReadSeq $rk 0; $ri = $rseq.Idx
  $v    = ASN-ReadInt $rk $ri; $ri = $v.Idx
  $n    = ASN-ReadInt $rk $ri; $ri = $n.Idx
  $e    = ASN-ReadInt $rk $ri; $ri = $e.Idx
  $d    = ASN-ReadInt $rk $ri; $ri = $d.Idx
  $p    = ASN-ReadInt $rk $ri; $ri = $p.Idx
  $q    = ASN-ReadInt $rk $ri; $ri = $q.Idx
  $dp   = ASN-ReadInt $rk $ri; $ri = $dp.Idx
  $dq   = ASN-ReadInt $rk $ri; $ri = $dq.Idx
  $iq   = ASN-ReadInt $rk $ri; $ri = $iq.Idx

  $rp = New-Object System.Security.Cryptography.RSAParameters
  $rp.Modulus  = [byte[]]$n.Val
  $rp.Exponent = [byte[]]$e.Val
  $rp.D        = [byte[]]$d.Val
  $rp.P        = [byte[]]$p.Val
  $rp.Q        = [byte[]]$q.Val
  $rp.DP       = [byte[]]$dp.Val
  $rp.DQ       = [byte[]]$dq.Val
  $rp.InverseQ = [byte[]]$iq.Val

  # Prefer CNG when available; fallback to CSP when needed
  try {
    $rsa = New-Object System.Security.Cryptography.RSACng
    $rsa.ImportParameters($rp)
    return $rsa
  } catch {
    try {
      $cspParams = New-Object System.Security.Cryptography.CspParameters
      $cspParams.ProviderType = 24 # PROV_RSA_AES
      $cspParams.KeyNumber = [System.Security.Cryptography.KeyNumber]::Exchange
      $cspParams.Flags = [System.Security.Cryptography.CspProviderFlags]::NoFlags
      $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($rp.Modulus.Length*8, $cspParams)
      $csp.PersistKeyInCsp = $false
      $csp.ImportParameters($rp)
      return $csp
    } catch {
      $fallback = [System.Security.Cryptography.RSA]::Create()
      $fallback.ImportParameters($rp)
      return $fallback
    }
  }
}

# =================== CSB parser ===================
function Read-CSB([string]$path){
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -lt 4+1+1+2+32) { throw "File too small to be a CSB bundle." }
  $magic = [Text.Encoding]::ASCII.GetString($bytes,0,4)
  if ($magic -ne 'CSB1') { throw "Bad magic '$magic' (expected 'CSB1')" }
  $ver   = $bytes[4]
  if ($ver -ne 1) { throw "Unsupported CSB version $ver" }
  $flags = $bytes[5]
  $wlen  = (([int]$bytes[6] -shl 8) -bor ([int]$bytes[7]))

  $hdrLenNoTag = 8 + $wlen
  if ($bytes.Length -lt $hdrLenNoTag + 32) { throw "Truncated CSB header." }

  $wrapped = New-Object byte[] $wlen
  [Array]::Copy($bytes,8,$wrapped,0,$wlen)

  $tag = New-Object byte[] 32
  [Array]::Copy($bytes, $bytes.Length-32, $tag, 0, 32)

  $cipherLen = $bytes.Length - $hdrLenNoTag - 32
  if ($cipherLen -le 0) { throw "No ciphertext present in CSB." }
  $cipher = New-Object byte[] $cipherLen
  [Array]::Copy($bytes, $hdrLenNoTag, $cipher, 0, $cipherLen)

  $headerNoTag = New-Object byte[] $hdrLenNoTag
  [Array]::Copy($bytes, 0, $headerNoTag, 0, $hdrLenNoTag)

  return [pscustomobject]@{
    Version      = $ver
    Flags        = $flags
    Wrapped      = $wrapped
    Ciphertext   = $cipher
    Tag          = $tag
    HeaderNoTag  = $headerNoTag
  }
}

# =================== RSA unwrap (FIXED) ===================
function Unwrap-Secret {
  param(
    [Parameter(Mandatory)][byte[]]$Wrapped,
    [Parameter(Mandatory)][int]$Flags,
    [Parameter(Mandatory)][System.Security.Cryptography.RSA]$Rsa
  )

  $isCsp = ($Rsa -is [System.Security.Cryptography.RSACryptoServiceProvider])

  # Build attempt order from flags: 0x02=OAEP-SHA256, 0x04=OAEP-SHA1, 0x08=CSP OAEP-SHA1 fallback (encryptor), but we also allow PKCS1 as last resort.
  $order = @()
  if (($Flags -band 0x02) -ne 0) { $order += 'OaepSHA256' }
  if (($Flags -band 0x04) -ne 0) { $order += 'OaepSHA1' }
  if ($order.Count -eq 0) { $order = @('OaepSHA256','OaepSHA1') }

  # Always add PKCS1 as a final hail-mary (some legacy bundles)
  $order += 'Pkcs1'

  foreach($pad in $order){
    try {
      switch ($pad) {
        'OaepSHA256' {
          if ($isCsp) { throw "RSACryptoServiceProvider does not support OAEP-SHA256 in .NET Framework; skipping." }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        }
        'OaepSHA1' {
          if ($isCsp) {
            # OAEP-SHA1 for CSP uses bool overload
            return ([System.Security.Cryptography.RSACryptoServiceProvider]$Rsa).Decrypt($Wrapped, $true)
          } else {
            return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
          }
        }
        'Pkcs1' {
          # PKCS#1 v1.5: easiest via CSP bool overload ($false)
          Write-Warn "Trying PKCS#1 v1.5 unwrap with explicit RSACryptoServiceProvider..."
          $priv = $Rsa.ExportParameters($true)
          $keySizeBits = $priv.Modulus.Length * 8
          $cspParams = New-Object System.Security.Cryptography.CspParameters
          $cspParams.ProviderType = 24  # PROV_RSA_AES
          $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
          try {
            $csp.PersistKeyInCsp = $false
            $csp.ImportParameters($priv)
            return $csp.Decrypt($Wrapped, $false) # PKCS#1 v1.5
          } finally {
            try { $csp.Clear() } catch {}
            try { $csp.Dispose() } catch {}
          }
        }
      }
    } catch {
      Write-Warn ("RSA unwrap failed with {0}: {1}" -f $pad, $_.Exception.Message)
    }
  }

  throw "Unable to unwrap AES/HMAC/IV secret with available paddings."
}

# =================== MAIN ===================
try {
  Write-Host "ConnectSecure CSB Decryptor" -ForegroundColor Cyan

  $csbPath = $InFile
  if ([string]::IsNullOrWhiteSpace($csbPath)) {
    $csbPath = Pick-CsbFile
  }
  if (-not (Test-Path -LiteralPath $csbPath)) { throw "Input file not found: $csbPath" }

  $pass = Read-Secret "Enter passphrase for the encrypted private key: "

  # Parse CSB
  $csb = Read-CSB -path $csbPath
  Write-Info ("CSB version={0}, flags=0x{1:X2}, wrappedLen={2}, cipherLen={3}" -f $csb.Version,$csb.Flags,$csb.Wrapped.Length,$csb.Ciphertext.Length)

  # Load RSA private key
  $rsaPriv = Decrypt-Pkcs8EncryptedPrivateKey -pem $EncryptedPrivateKeyPem -password $pass
  Write-Info ("RSA provider type: {0}" -f $rsaPriv.GetType().FullName)

  # Unwrap secret
  Write-Info "Unwrapping AES/HMAC/IV with RSA..."
  $secret = Unwrap-Secret -Wrapped $csb.Wrapped -Flags $csb.Flags -Rsa $rsaPriv
  if ($secret.Length -lt 80) { throw "Unwrapped secret too short ($($secret.Length)); expected 80 bytes." }

  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0,  $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret,32,  $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret,64,  $iv,     0, 16)

  # Verify HMAC tag over (headerNoTag || ciphertext)
  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  try {
    $combined = New-Object byte[] ($csb.HeaderNoTag.Length + $csb.Ciphertext.Length)
    [Array]::Copy($csb.HeaderNoTag,0,$combined,0,$csb.HeaderNoTag.Length)
    [Array]::Copy($csb.Ciphertext,0,$combined,$csb.HeaderNoTag.Length,$csb.Ciphertext.Length)
    $calcTag = $hmac.ComputeHash($combined)
  } finally {
    $hmac.Dispose()
  }
  if (-not (BytesEqual $calcTag $csb.Tag)) {
    throw "HMAC authentication failed. The CSB may be corrupted or the wrong private key/password was used."
  }
  Write-Ok "HMAC verified."

  # AES decrypt -> ZIP bytes
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = 256
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $aesKey
    $aes.IV  = $iv

    $msOut = New-Object IO.MemoryStream
    try {
      $cs2 = New-Object System.Security.Cryptography.CryptoStream($msOut, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try {
        $cs2.Write($csb.Ciphertext,0,$csb.Ciphertext.Length)
        $cs2.FlushFinalBlock()
      } finally {
        $cs2.Dispose()
      }
      $zipBytes = $msOut.ToArray()
    } finally {
      $msOut.Dispose()
    }
  } finally {
    $aes.Dispose()
  }

  # Write ZIP and extract
  Ensure-ZipAssemblies
  $zipName = ([IO.Path]::GetFileNameWithoutExtension($csbPath)) + ".zip"
  $outZip = Join-Path $OutDir $zipName
  [IO.File]::WriteAllBytes($outZip, $zipBytes)
  Write-Ok "Decrypted ZIP -> $outZip"

  $extractDir = Join-Path $OutDir ([IO.Path]::GetFileNameWithoutExtension($zipName))
  if (Test-Path -LiteralPath $extractDir) {
    try { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction Stop }
    catch { $extractDir = "$extractDir`_" + (Get-Date -Format 'yyyyMMdd_HHmmss') }
  }
  [System.IO.Compression.ZipFile]::ExtractToDirectory($outZip, $extractDir)
  Write-Ok "Extracted -> $extractDir"
  try { Start-Process $extractDir | Out-Null } catch {}

  if ($ExportOnly) {
    $exportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
    Ensure-Folder -Path $exportRoot
    $stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
    $outObj = [pscustomobject]@{
      stamp       = $stamp
      csb         = $csbPath
      outDir      = $OutDir
      zip         = $outZip
      extractedTo = $extractDir
      flags       = ('0x{0:X2}' -f $csb.Flags)
      rsaType     = $rsaPriv.GetType().FullName
    }
    $jsonPath = Join-Path $exportRoot ("decrypt_export_{0}.json" -f $stamp)
    $outObj | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $jsonPath -Encoding UTF8 -Force
    Write-Ok "ExportOnly -> $jsonPath"
    exit 0
  }

  Write-Host "Done." -ForegroundColor Green
}
catch {
  Write-Err $_.Exception.Message
  throw
}
