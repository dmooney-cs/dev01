<# =====================================================================
  CS-secure-log-browser.ps1  (v2.3)
  ConnectSecure – Secure Bundle Browser / Downloader
  Local MinIO (SigV4) -> Azure SAS -> HTML helper fallback
  + CSB decrypt prompt after download
  + Passphrase cache (DPAPI) with configurable timeout

  PASS CACHE:
    - Cached on disk (DPAPI, per-user) for $Global:CS_PassphraseCacheMinutes minutes
    - If cache valid, no prompt; otherwise prompts again
    - Cache file: secure-passphrase-cache.json in Collected-Info

  COOKBOOK:
    - Supports -ExportOnly (exports list JSON to C:\CS-Toolbox-TEMP\Collected-Info then exits)

  EXIT CODES:
    0 = success / normal exit
    2 = error
===================================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [int]$MaxResults = 50,
    [string]$DownloadRoot = "C:\CS-Toolbox-TEMP\Downloads",

    # Azure fallback: container-level SAS with Read+List
    [string]$SasUrl,

    # Relaunch as admin if requested
    [switch]$Elevate,

    # Export-only standard (cookbook)
    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# ---------------- Paths ----------------
$Global:CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$Global:AuditLogPath      = Join-Path $Global:CollectedInfoRoot 'CS-secure-log-browser-audit.log'
$Global:MinioCredPath     = Join-Path $Global:CollectedInfoRoot 'secure-upload-creds.json'
$Global:HtmlHelperPath    = Join-Path $Global:CollectedInfoRoot 'secure-access-helper.html'

# ---------------- Passphrase cache config (CHANGE THIS LATER IF YOU WANT) ----------------
$Global:CS_PassphraseCacheMinutes = 15

# ---------------- Decrypt key (embedded) ----------------
$Global:CS_EncryptedPrivateKeyPem = @'
-----BEGIN ENCRYPTED PRIVATE KEY-----
-----END ENCRYPTED PRIVATE KEY-----
'@

# ===================== Output helpers =====================
function Ensure-Folder([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-Audit([string]$Message, [string]$Level = 'INFO') {
    try {
        Ensure-Folder $Global:CollectedInfoRoot
        $line = "{0} [{1}] [{2}\{3}] {4}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $env:COMPUTERNAME, [Environment]::UserName, $Message
        Add-Content -Path $Global:AuditLogPath -Value $line -Encoding UTF8
    } catch { }
}

function Write-InfoColor([string]$Message, [ConsoleColor]$Color) {
    Write-Host $Message -ForegroundColor $Color
}

# ===================== Admin / elevation =====================
function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Relaunch-AsAdmin([string[]]$OriginalArgs) {
    $ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $scriptPath = $MyInvocation.MyCommand.Path
    $argLine = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$scriptPath`"") + $OriginalArgs
    Start-Process -FilePath $ps -ArgumentList $argLine -Verb RunAs | Out-Null
}

if ($Elevate -and -not (Test-IsAdmin)) {
    Write-InfoColor "Elevation requested. Relaunching as Administrator..." Yellow
    $orig = @()
    foreach ($k in $PSBoundParameters.Keys) {
        if ($k -eq 'Elevate') { continue }
        $v = $PSBoundParameters[$k]
        if ($v -is [switch] -and $v) { $orig += "-$k"; continue }
        if ($v -isnot [switch]) { $orig += "-$k"; $orig += "`"$v`"" }
    }
    Relaunch-AsAdmin -OriginalArgs $orig
    exit 0
}

# ===================== Safe array helpers =====================
function Force-Array($x) {
    $list = New-Object System.Collections.ArrayList
    if ($null -eq $x) { return $list.ToArray() }
    if ($x -is [string]) { [void]$list.Add($x); return $list.ToArray() }
    if ($x -is [System.Collections.IEnumerable]) { foreach ($i in $x) { [void]$list.Add($i) }; return $list.ToArray() }
    [void]$list.Add($x)
    return $list.ToArray()
}
function Count-Items($x) {
    if ($null -eq $x) { return 0 }
    if ($x -is [string]) { return 1 }
    if ($x -is [System.Collections.IEnumerable]) { $c = 0; foreach ($i in $x) { $c++ }; return $c }
    return 1
}

# ===================== Interactive user profile (works when elevated) =====================
function Get-InteractiveUserProfilePath {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $u = [string]$cs.UserName
        if ([string]::IsNullOrWhiteSpace($u)) { return $null }
        $name = ($u -split '\\')[-1]
        $candidate = Join-Path "C:\Users" $name
        if (Test-Path -LiteralPath $candidate -PathType Container) { return $candidate }
    } catch { }
    return $null
}
function Get-UserCollectedInfoRoot {
    $prof = Get-InteractiveUserProfilePath
    if (-not $prof) { return $null }
    return Join-Path $prof 'CS-Toolbox-TEMP\Collected-Info'
}
function Get-UserMinioCredPath {
    $root = Get-UserCollectedInfoRoot
    if (-not $root) { return $null }
    return Join-Path $root 'secure-upload-creds.json'
}
function Get-PreferredCollectedInfoRoot {
    $uRoot = Get-UserCollectedInfoRoot
    if ($uRoot -and (Test-Path -LiteralPath $uRoot -PathType Container)) { return $uRoot }
    return $Global:CollectedInfoRoot
}

# =====================================================================
# PASSHRASE CACHE (DPAPI, per-user)
# =====================================================================
$Global:CS_EncryptPassphrase = $null

function Get-PassphraseCachePath {
    $root = Get-PreferredCollectedInfoRoot
    return Join-Path $root 'secure-passphrase-cache.json'
}

function Try-LoadCachedPassphrase {
    $cachePath = Get-PassphraseCachePath
    if (-not (Test-Path -LiteralPath $cachePath -PathType Leaf)) { return $null }

    try {
        $raw = Get-Content -LiteralPath $cachePath -Raw -Encoding UTF8
        $obj = $raw | ConvertFrom-Json
        if ($null -eq $obj) { return $null }

        $savedAt = [datetime]::Parse([string]$obj.SavedAtUtc).ToUniversalTime()
        $ageMin  = ([datetime]::UtcNow - $savedAt).TotalMinutes
        if ($ageMin -gt [double]$Global:CS_PassphraseCacheMinutes) { return $null }

        $enc = [string]$obj.DpapiProtected
        if ([string]::IsNullOrWhiteSpace($enc)) { return $null }

        $sec = ConvertTo-SecureString $enc
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } catch {
        return $null
    }
}

function Save-CachedPassphrase([string]$Pass) {
    if ([string]::IsNullOrWhiteSpace($Pass)) { return }

    try {
        $cachePath = Get-PassphraseCachePath
        $cacheRoot = Split-Path -Path $cachePath -Parent
        Ensure-Folder $cacheRoot

        $sec = ConvertTo-SecureString $Pass -AsPlainText -Force
        $dp  = $sec | ConvertFrom-SecureString  # DPAPI (current user)

        $obj = [pscustomobject]@{
            SavedAtUtc      = ([datetime]::UtcNow.ToString("o"))
            CacheMinutes    = [int]$Global:CS_PassphraseCacheMinutes
            DpapiProtected  = $dp
        }

        ($obj | ConvertTo-Json -Depth 4) | Out-File -FilePath $cachePath -Encoding UTF8 -Force
        Write-Audit ("Passphrase cached at {0} (minutes={1})" -f $cachePath, $Global:CS_PassphraseCacheMinutes)
    } catch {
        Write-Audit ("Passphrase cache write failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

function Prompt-Passphrase {
    $cached = Try-LoadCachedPassphrase
    if (-not [string]::IsNullOrWhiteSpace($cached)) {
        $Global:CS_EncryptPassphrase = $cached
        Write-InfoColor ("Passphrase cache: OK (valid for {0} minutes)" -f $Global:CS_PassphraseCacheMinutes) Green
        Write-Audit "Passphrase cache hit."
        return
    }

    Write-InfoColor "ConnectSecure Secure Bundle Browser" Yellow
    Write-Host ""
    $securePass = Read-Host "Enter ConnectSecure passphrase (input hidden)" -AsSecureString

    if ($securePass) {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
        try { $Global:CS_EncryptPassphrase = [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } else {
        $Global:CS_EncryptPassphrase = ""
    }

    Save-CachedPassphrase -Pass $Global:CS_EncryptPassphrase
}

# =====================================================================
# HTML Email Helper fallback (unchanged)
# =====================================================================
function Open-HtmlEmailHelper {
    param(
        [string]$Reason,
        [string]$MinioPathTried,
        [string]$UserMinioPathTried,
        [string]$SasUrlTried
    )

    Ensure-Folder $Global:CollectedInfoRoot

    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $who = "{0}\{1}" -f $env:COMPUTERNAME, [Environment]::UserName

    $html = @"
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>ConnectSecure Secure Access Helper</title>
  <style>
    body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#111;}
    .box{border:1px solid #ddd;border-radius:10px;padding:16px;margin:12px 0;}
    .h{font-size:18px;font-weight:700;margin:0 0 8px 0;}
    .k{font-family:Consolas,monospace;background:#f6f6f6;padding:2px 6px;border-radius:6px;}
    textarea{width:100%;height:140px;font-family:Consolas,monospace;}
    input{width:100%;padding:8px;font-family:Consolas,monospace;}
    .muted{color:#666;font-size:12px;}
    .btn{display:inline-block;background:#0b5fff;color:#fff;text-decoration:none;padding:10px 14px;border-radius:8px;margin-top:10px;}
  </style>
</head>
<body>
  <div class="box">
    <div class="h">Secure Bundle Browser - Access Helper</div>
    <div class="muted">Generated: $ts &nbsp;&nbsp; User: $who</div>
    <p><b>Why you are seeing this:</b> $Reason</p>
  </div>

  <div class="box">
    <div class="h">What to send to Support</div>
    <textarea readonly>
ConnectSecure Secure Bundle Browser access request

Issue:
- Browser could not use Local MinIO creds AND could not use Azure SAS fallback.

Details:
- MinIO creds path tried (machine): $MinioPathTried
- MinIO creds path tried (interactive user): $UserMinioPathTried
- Azure SAS provided/entered: $SasUrlTried

Need:
- Provide either:
  (A) MinIO endpoint + bucket + access key + secret key + region (read/list)
  OR
  (B) Azure container SAS URL with Read (r) + List (l)
    </textarea>

    <p class="muted">
      Tip: Put MinIO creds JSON here:
      <span class="k">$Global:MinioCredPath</span>
    </p>
  </div>
</body>
</html>
"@

    $html | Out-File -FilePath $Global:HtmlHelperPath -Encoding UTF8 -Force
    Write-InfoColor "Opened HTML helper: $Global:HtmlHelperPath" Yellow
    Write-Audit ("HTML helper opened: {0}" -f $Global:HtmlHelperPath) 'WARN'
    try { Start-Process $Global:HtmlHelperPath | Out-Null } catch { }
}

# =====================================================================
# MinIO creds (load / prompt / save)  (unchanged)
# =====================================================================
function Validate-MinioCfg($cfg) {
    if ($null -eq $cfg) { return $false }
    if ([string]::IsNullOrWhiteSpace($cfg.EndpointUrl)) { return $false }
    if ([string]::IsNullOrWhiteSpace($cfg.Bucket))      { return $false }
    if ([string]::IsNullOrWhiteSpace($cfg.AccessKey))   { return $false }
    if ([string]::IsNullOrWhiteSpace($cfg.SecretKey))   { return $false }
    if ([string]::IsNullOrWhiteSpace($cfg.Region))      { $cfg.Region = "us-east-1" }
    if ($null -eq $cfg.Prefix)                          { $cfg.Prefix = "" }
    return $true
}

function Try-LoadMinioCredsFromPath([string]$path) {
    try {
        if ([string]::IsNullOrWhiteSpace($path)) { return $null }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
        $raw = Get-Content -Path $path -Raw -Encoding UTF8
        $cfg = $raw | ConvertFrom-Json
        if (Validate-MinioCfg $cfg) { return $cfg }
    } catch { }
    return $null
}

function Save-MinioCreds($cfg) {
    $json = $cfg | ConvertTo-Json -Depth 6
    Ensure-Folder $Global:CollectedInfoRoot
    $json | Out-File -FilePath $Global:MinioCredPath -Encoding UTF8 -Force

    $uRoot = Get-UserCollectedInfoRoot
    if ($uRoot) {
        try {
            Ensure-Folder $uRoot
            $uPath = Join-Path $uRoot 'secure-upload-creds.json'
            $json | Out-File -FilePath $uPath -Encoding UTF8 -Force
        } catch { }
    }
}

function Prompt-MinioCreds {
    Write-Host ""
    Write-InfoColor "MinIO credentials not found. Enter them to continue (Local mode)." Yellow
    Write-Host ""

    $endpoint = Read-Host "MinIO Endpoint URL (example: http://10.0.0.238:9000)"
    $bucket   = Read-Host "Bucket name"
    $region   = Read-Host "Region (default us-east-1)"
    $prefix   = Read-Host "Prefix (optional, blank allowed)"
    $ak       = Read-Host "AccessKey"
    $skSec    = Read-Host "SecretKey (input hidden)" -AsSecureString

    $sk = ""
    if ($skSec) {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($skSec)
        try { $sk = [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    }

    if ([string]::IsNullOrWhiteSpace($region)) { $region = "us-east-1" }
    if ($null -eq $prefix) { $prefix = "" }

    $cfg = [pscustomobject]@{
        EndpointUrl = $endpoint
        Bucket      = $bucket
        Region      = $region
        Prefix      = $prefix
        AccessKey   = $ak
        SecretKey   = $sk
    }

    if (-not (Validate-MinioCfg $cfg)) {
        throw "MinIO creds are incomplete. EndpointUrl/Bucket/AccessKey/SecretKey are required."
    }

    Save-MinioCreds $cfg
    Write-InfoColor "Saved MinIO creds to Collected-Info for future runs." Green
    Write-Audit "MinIO creds saved."
    return $cfg
}

# =====================================================================
# Azure SAS list + download (unchanged)
# =====================================================================
function Try-ListAzure([uri]$SasContainerUri, [int]$MaxResults) {
    $left  = $SasContainerUri.GetLeftPart([UriPartial]::Path)
    $query = $SasContainerUri.Query.TrimStart('?')
    $listUri = "$left?restype=container&comp=list&$query"
    $resp = Invoke-RestMethod -Uri $listUri -Method Get -TimeoutSec 20

    $blobNodes = Force-Array $resp.EnumerationResults.Blobs.Blob
    $results = @()

    foreach ($b in $blobNodes) {
        if (-not $b) { continue }
        $name = [string]$b.Name
        $prop = $b.Properties
        $lm   = Get-Date $prop.'Last-Modified'
        $len  = [int64]$prop.'Content-Length'
        $folder = if ($name -like "*/*") { $name.Split('/')[0] } else { $name }

        $results += [pscustomobject]@{
            Provider     = 'Azure'
            Name         = $name
            Folder       = $folder
            File         = (Split-Path $name -Leaf)
            SizeBytes    = $len
            SizeMB       = [math]::Round($len / 1MB, 2)
            LastModified = $lm
        }
    }

    Force-Array ($results | Sort-Object LastModified -Descending | Select-Object -First $MaxResults)
}

function Download-AzureBlobFromSas([uri]$SasContainerUri, [string]$BlobName, [string]$DownloadRoot) {
    Ensure-Folder $DownloadRoot
    $left  = $SasContainerUri.GetLeftPart([UriPartial]::Path).TrimEnd('/')
    $query = $SasContainerUri.Query.TrimStart('?')
    $encoded = [Uri]::EscapeDataString($BlobName)
    $downloadUri = "{0}/{1}?{2}" -f $left, $encoded, $query

    $safeName = (Split-Path $BlobName -Leaf) -replace '[^\w\.\-]','_'
    $localPath = Join-Path $DownloadRoot $safeName

    Write-InfoColor ("Downloading to: {0}" -f $localPath) Cyan
    Invoke-RestMethod -Uri $downloadUri -Method Get -OutFile $localPath -TimeoutSec 60
    Write-InfoColor "Download complete." Green
    return $localPath
}

# =====================================================================
# MinIO SigV4 list + download (unchanged)
# =====================================================================
function Escape-Rfc3986([string]$s) { ([Uri]::EscapeDataString($s) -replace '\+','%20' -replace '\*','%2A' -replace '%7E','~') }
function HashSHA256Hex([byte[]]$bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') }) -join '' }
    finally { $sha.Dispose() }
}
function HmacSHA256([byte[]]$key, [string]$data) {
    $h = New-Object Security.Cryptography.HMACSHA256
    $h.Key = $key
    try { $h.ComputeHash([Text.Encoding]::UTF8.GetBytes($data)) }
    finally { $h.Dispose() }
}
function Get-SigningKey([string]$secret,[string]$dateStamp,[string]$region,[string]$service) {
    $kSecret = [Text.Encoding]::UTF8.GetBytes("AWS4$secret")
    $kDate   = HmacSHA256 $kSecret $dateStamp
    $kRegion = HmacSHA256 $kDate $region
    $kSvc    = HmacSHA256 $kRegion $service
    HmacSHA256 $kSvc "aws4_request"
}
function Encode-S3KeyPath([string]$key) {
    (($key -split '/') | ForEach-Object { Escape-Rfc3986 $_ }) -join '/'
}

function Sign-MinIORequest {
    param(
        [ValidateSet('GET','HEAD')][string]$Method,
        [string]$EndpointUrl,
        [string]$Region,
        [string]$AccessKey,
        [string]$SecretKey,
        [string]$CanonicalUri,
        [hashtable]$QueryParams
    )

    $service = "s3"
    $u = [Uri]$EndpointUrl
    $hostHeader = if ($u.IsDefaultPort) { $u.Host } else { "$($u.Host):$($u.Port)" }

    $t = [DateTime]::UtcNow
    $amzDate   = $t.ToString("yyyyMMddTHHmmssZ")
    $dateStamp = $t.ToString("yyyyMMdd")
    $payloadHash = HashSHA256Hex ([byte[]]@())

    $qp = @{}
    foreach ($k in $QueryParams.Keys) { $qp[$k] = [string]$QueryParams[$k] }
    $canonicalQuery = ($qp.Keys | Sort-Object | ForEach-Object { "$(Escape-Rfc3986 $_)=$(Escape-Rfc3986 $qp[$_])" }) -join "&"

    $headers = @{}
    $headers["host"] = $hostHeader
    $headers["x-amz-date"] = $amzDate
    $headers["x-amz-content-sha256"] = $payloadHash

    $signedHeaders = ($headers.Keys | Sort-Object) -join ";"
    $canonicalHeaders = ($headers.Keys | Sort-Object | ForEach-Object { "{0}:{1}`n" -f $_, ($headers[$_] -replace '\s+',' ').Trim() }) -join ""

    $canonicalRequest = @(
        $Method
        $CanonicalUri
        $canonicalQuery
        $canonicalHeaders
        $signedHeaders
        $payloadHash
    ) -join "`n"

    $scope = "$dateStamp/$Region/$service/aws4_request"
    $hashCanon = HashSHA256Hex ([Text.Encoding]::UTF8.GetBytes($canonicalRequest))
    $stringToSign = @("AWS4-HMAC-SHA256",$amzDate,$scope,$hashCanon) -join "`n"

    $signingKey = Get-SigningKey -secret $SecretKey -dateStamp $dateStamp -region $Region -service $service
    $sigBytes = HmacSHA256 $signingKey $stringToSign
    $signature = ($sigBytes | ForEach-Object { $_.ToString('x2') }) -join ""

    $auth = "AWS4-HMAC-SHA256 Credential=$AccessKey/$scope, SignedHeaders=$signedHeaders, Signature=$signature"

    $outHeaders = @{}
    $outHeaders["x-amz-date"] = $amzDate
    $outHeaders["x-amz-content-sha256"] = $payloadHash
    $outHeaders["Authorization"] = $auth

    $base = "$($u.Scheme)://$hostHeader"
    $fullUrl = if ([string]::IsNullOrWhiteSpace($canonicalQuery)) { "$base${CanonicalUri}" } else { "$base${CanonicalUri}?$canonicalQuery" }

    return [pscustomobject]@{ Url = $fullUrl; Headers = $outHeaders }
}

function Get-MinIOObjectList($Cfg, [int]$MaxResults) {
    $canonUri = "/$([string]$Cfg.Bucket)"
    $qp = @{ "list-type" = "2"; "max-keys" = [string]([Math]::Min([Math]::Max($MaxResults,1),1000)) }
    if (-not [string]::IsNullOrWhiteSpace([string]$Cfg.Prefix)) { $qp["prefix"] = [string]$Cfg.Prefix }

    $sig = Sign-MinIORequest -Method GET -EndpointUrl $Cfg.EndpointUrl -Region $Cfg.Region -AccessKey $Cfg.AccessKey -SecretKey $Cfg.SecretKey -CanonicalUri $canonUri -QueryParams $qp
    $xml = Invoke-RestMethod -Uri $sig.Url -Method Get -Headers $sig.Headers -TimeoutSec 20

    $contents = $null
    if ($xml -and $xml.ListBucketResult) { $contents = $xml.ListBucketResult.Contents }
    $contents = Force-Array $contents

    $results = @()
    foreach ($c in $contents) {
        $key = [string]$c.Key
        if ([string]::IsNullOrWhiteSpace($key)) { continue }
        $lm  = Get-Date ([string]$c.LastModified)
        $len = [int64]([string]$c.Size)
        $folder = if ($key -like "*/*") { $key.Split('/')[0] } else { $key }

        $results += [pscustomobject]@{
            Provider     = 'MinIO'
            Name         = $key
            Folder       = $folder
            File         = (Split-Path $key -Leaf)
            SizeBytes    = $len
            SizeMB       = [math]::Round($len / 1MB, 2)
            LastModified = $lm
        }
    }

    Force-Array ($results | Sort-Object LastModified -Descending | Select-Object -First $MaxResults)
}

function Download-MinIOObject($Cfg, [string]$Key, [string]$DownloadRoot) {
    Ensure-Folder $DownloadRoot
    $safeName  = (Split-Path $Key -Leaf) -replace '[^\w\.\-]','_'
    $localPath = Join-Path $DownloadRoot $safeName

    $canonUri = "/$([string]$Cfg.Bucket)/$(Encode-S3KeyPath $Key)"
    $sig = Sign-MinIORequest -Method GET -EndpointUrl $Cfg.EndpointUrl -Region $Cfg.Region -AccessKey $Cfg.AccessKey -SecretKey $Cfg.SecretKey -CanonicalUri $canonUri -QueryParams @{}

    Write-InfoColor ("Downloading to: {0}" -f $localPath) Cyan
    Invoke-WebRequest -Uri $sig.Url -Method Get -Headers $sig.Headers -OutFile $localPath -UseBasicParsing -TimeoutSec 60
    Write-InfoColor "Download complete." Green
    return $localPath
}

# =====================================================================
# CSB DECRYPT (UPDATED RSA UNWRAP FIX)
# =====================================================================
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+." }
  }
}
function Join-Bytes([byte[]]$a,[byte[]]$b){
  $out = New-Object byte[] ($a.Length + $b.Length)
  [Array]::Copy($a,0,$out,0,$a.Length)
  [Array]::Copy($b,0,$out,$a.Length,$b.Length)
  return $out
}
function BytesEqual([byte[]]$a,[byte[]]$b){
  if ($a.Length -ne $b.Length) { return $false }
  $diff = 0
  for($i=0;$i -lt $a.Length;$i++){ $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

function ASN-ExpectTag([byte[]]$buf, [int]$idx, [byte]$tag) { if ($idx -ge $buf.Length) { throw "ASN.1 read past end" }; if ($buf[$idx] -ne $tag) { throw "ASN.1 tag mismatch" }; return ($idx+1) }
function ASN-ReadLen([byte[]]$buf, [int]$idx) { if ($idx -ge $buf.Length) { throw "ASN.1 length read past end" }; $b=[int]$buf[$idx]; $idx++; if($b -lt 0x80){ return @{Len=$b;Idx=$idx} }; $n=$b-0x80; if($n -lt 1 -or $n -gt 4){ throw "Unsupported ASN.1 length" }; $val=0; for($k=0;$k -lt $n;$k++){ $val=(($val -shl 8) -bor [int]$buf[$idx]); $idx++ }; return @{Len=$val;Idx=$idx} }
function ASN-ReadSeq([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x30; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 SEQUENCE overrun" }; @{Start=$idx;End=($idx+$len);Idx=$idx} }
function ASN-ReadInt([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x02; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 INTEGER overrun" }; $val=$buf[$idx..($idx+$len-1)]; $idx+=$len; if($val.Length -gt 1 -and $val[0]-eq 0x00){ $val=$val[1..($val.Length-1)] }; @{Val=([byte[]]$val);Idx=$idx} }
function ASN-ReadOctets([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x04; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OCTET STRING overrun" }; @{Val=([byte[]]$buf[$idx..($idx+$len-1)]);Idx=($idx+$len)} }
function ASN-ReadOid([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x06; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OID overrun" }; $data=$buf[$idx..($idx+$len-1)]; $idx+=$len; $first=[int]$data[0]; $a=[int]([math]::Floor($first/40)); $b=$first%40; $oidParts=@($a,$b); $val=0; for($i=1;$i -lt $data.Length;$i++){ $val=($val -shl 7) -bor ($data[$i] -band 0x7F); if(($data[$i] -band 0x80)-eq 0){ $oidParts+=$val; $val=0 } }; @{Oid=($oidParts -join '.');Idx=$idx} }
function IntFromBytes([byte[]]$b){ $v=0; foreach($x in $b){ $v=(($v -shl 8) -bor $x) }; $v }
function PemToBytes([string]$pem, [string]$header, [string]$footer){ $i1=$pem.IndexOf($header); $i2=$pem.IndexOf($footer); if($i1 -lt 0 -or $i2 -lt 0){ throw "PEM missing header/footer" }; $b64=$pem.Substring($i1+$header.Length,$i2-($i1+$header.Length)) -replace '\s',''; [Convert]::FromBase64String($b64) }

function PBKDF2-Derive([string]$password, [byte[]]$salt, [int]$iters, [int]$keyLen, [string]$prf){
  if ($prf -eq 'SHA1') {
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters)
    try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
  }
  if ($prf -eq 'SHA256') {
    try {
      $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
      try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
    } catch {
      # Manual PBKDF2-HMAC-SHA256 (for older frameworks)
      $pwd = [Text.Encoding]::UTF8.GetBytes($password)
      $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$pwd)
      try {
        $hLen = 32
        $blocks = [int][math]::Ceiling($keyLen / $hLen)
        $dk = New-Object byte[] ($blocks * $hLen)
        for ($i=1; $i -le $blocks; $i++){
          $intBlock = [byte[]]@(
            ($i -shr 24) -band 0xFF,
            ($i -shr 16) -band 0xFF,
            ($i -shr 8)  -band 0xFF,
            $i -band 0xFF
          )
          $u = $hmac.ComputeHash( (Join-Bytes $salt $intBlock) )
          $t = [byte[]]$u.Clone()
          for ($j=2; $j -le $iters; $j++){
            $u = $hmac.ComputeHash($u)
            for ($kidx=0; $kidx -lt $hLen; $kidx++){ $t[$kidx] = $t[$kidx] -bxor $u[$kidx] }
          }
          [Array]::Copy($t, 0, $dk, ($i-1)*$hLen, $hLen)
        }
        $out = New-Object byte[] $keyLen
        [Array]::Copy($dk, 0, $out, 0, $keyLen)
        return $out
      } finally {
        $hmac.Dispose()
      }
    }
  }
  throw "Unsupported PBKDF2 PRF: $prf"
}

function Decrypt-Pkcs8EncryptedPrivateKey([string]$pem, [string]$password){
  $der = PemToBytes $pem '-----BEGIN ENCRYPTED PRIVATE KEY-----' '-----END ENCRYPTED PRIVATE KEY-----'
  $top = ASN-ReadSeq $der 0
  $idx = $top.Idx

  $alg = ASN-ReadSeq $der $idx
  $idx = $alg.End
  $algOid = ASN-ReadOid $der $alg.Idx
  if ($algOid.Oid -ne '1.2.840.113549.1.5.13') { throw "Unsupported encryption algorithm OID (expected PBES2)" }
  $pbes2 = ASN-ReadSeq $der $algOid.Idx

  $kdfAlg = ASN-ReadSeq $der $pbes2.Idx
  $encAlgPos = $kdfAlg.End
  $kdfOid = ASN-ReadOid $der $kdfAlg.Idx
  if ($kdfOid.Oid -ne '1.2.840.113549.1.5.12') { throw "Unsupported KDF OID (expected PBKDF2)" }
  $pbkdf2Seq = ASN-ReadSeq $der $kdfOid.Idx

  $saltOct   = ASN-ReadOctets $der $pbkdf2Seq.Idx
  $iterInt   = ASN-ReadInt    $der $saltOct.Idx
  $scanIdx   = $iterInt.Idx
  $klenMaybe = $null
  $prfOid    = '1.2.840.113549.2.7'
  if ($scanIdx -lt $pbkdf2Seq.End) {
    if ($der[$scanIdx] -eq 0x02) { $klenMaybe = ASN-ReadInt $der $scanIdx; $scanIdx = $klenMaybe.Idx }
    if ($scanIdx -lt $pbkdf2Seq.End -and $der[$scanIdx] -eq 0x30) {
      $prfSeq = ASN-ReadSeq $der $scanIdx
      $prfRead = ASN-ReadOid $der $prfSeq.Idx
      $prfOid = $prfRead.Oid
    }
  }

  $encAlg = ASN-ReadSeq $der $encAlgPos
  $encOid = ASN-ReadOid $der $encAlg.Idx
  $ivOct  = ASN-ReadOctets $der $encOid.Idx

  $encOctet = ASN-ReadOctets $der $idx
  $cipherPrivKey = $encOctet.Val

  $prf = if ($prfOid -eq '1.2.840.113549.2.7') { 'SHA1' } elseif ($prfOid -eq '1.2.840.113549.2.9') { 'SHA256' } else { throw "Unsupported PRF OID: $prfOid" }
  $aesBits = switch ($encOid.Oid) {
    '2.16.840.1.101.3.4.1.42' { 256 }
    '2.16.840.1.101.3.4.1.22' { 192 }
    '2.16.840.1.101.3.4.1.2'  { 128 }
    default { throw "Unsupported encryption OID (expected AES-CBC)" }
  }
  $keyLen = if ($klenMaybe) { IntFromBytes $klenMaybe.Val } else { $aesBits / 8 }
  $iters  = [int](IntFromBytes $iterInt.Val)
  if ($iters -le 0) { throw "Bad PBKDF2 iteration count" }

  $key = PBKDF2-Derive $password $saltOct.Val $iters $keyLen $prf

  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = $aesBits
    $aes.BlockSize = 128
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $key
    $aes.IV  = $ivOct.Val

    $ms = New-Object IO.MemoryStream
    try {
      $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try {
        $cs.Write($cipherPrivKey,0,$cipherPrivKey.Length)
        $cs.FlushFinalBlock()
      } finally { $cs.Dispose() }
      $pkcs8 = $ms.ToArray()
    } finally { $ms.Dispose() }
  } finally { $aes.Dispose() }

  $pki = ASN-ReadSeq $pkcs8 0
  $i2 = $pki.Idx
  $ver  = ASN-ReadInt $pkcs8 $i2; $i2 = $ver.Idx
  $alg2 = ASN-ReadSeq $pkcs8 $i2
  $oid2 = ASN-ReadOid $pkcs8 $alg2.Idx
  if ($oid2.Oid -ne '1.2.840.113549.1.1.1') { throw "PrivateKey algorithm not RSA" }
  $i2 = $alg2.End
  $ok = ASN-ReadOctets $pkcs8 $i2
  $rk = $ok.Val

  $rseq = ASN-ReadSeq $rk 0; $ri = $rseq.Idx
  $v    = ASN-ReadInt $rk $ri; $ri = $v.Idx
  $n    = ASN-ReadInt $rk $ri; $ri = $n.Idx
  $e    = ASN-ReadInt $rk $ri; $ri = $e.Idx
  $d    = ASN-ReadInt $rk $ri; $ri = $d.Idx
  $p    = ASN-ReadInt $rk $ri; $ri = $p.Idx
  $q    = ASN-ReadInt $rk $ri; $ri = $q.Idx
  $dp   = ASN-ReadInt $rk $ri; $ri = $dp.Idx
  $dq   = ASN-ReadInt $rk $ri; $ri = $dq.Idx
  $iq   = ASN-ReadInt $rk $ri; $ri = $iq.Idx

  $rp = New-Object System.Security.Cryptography.RSAParameters
  $rp.Modulus  = [byte[]]$n.Val
  $rp.Exponent = [byte[]]$e.Val
  $rp.D        = [byte[]]$d.Val
  $rp.P        = [byte[]]$p.Val
  $rp.Q        = [byte[]]$q.Val
  $rp.DP       = [byte[]]$dp.Val
  $rp.DQ       = [byte[]]$dq.Val
  $rp.InverseQ = [byte[]]$iq.Val

  try {
    $rsa = New-Object System.Security.Cryptography.RSACng
    $rsa.ImportParameters($rp)
    return $rsa
  } catch {
    try {
      $cspParams = New-Object System.Security.Cryptography.CspParameters
      $cspParams.ProviderType = 24
      $cspParams.KeyNumber = [System.Security.Cryptography.KeyNumber]::Exchange
      $cspParams.Flags = [System.Security.Cryptography.CspProviderFlags]::NoFlags
      $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($rp.Modulus.Length*8, $cspParams)
      $csp.PersistKeyInCsp = $false
      $csp.ImportParameters($rp)
      return $csp
    } catch {
      $fallback = [System.Security.Cryptography.RSA]::Create()
      $fallback.ImportParameters($rp)
      return $fallback
    }
  }
}

function Read-CSB([string]$path){
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -lt 4+1+1+2+32) { throw "File too small to be a CSB bundle." }
  $magic = [Text.Encoding]::ASCII.GetString($bytes,0,4)
  if ($magic -ne 'CSB1') { throw "Bad magic '$magic' (expected CSB1)" }
  $ver   = $bytes[4]
  if ($ver -ne 1) { throw "Unsupported CSB version $ver" }
  $flags = $bytes[5]
  $wlen  = (([int]$bytes[6] -shl 8) -bor ([int]$bytes[7]))
  $hdrLenNoTag = 8 + $wlen
  if ($bytes.Length -lt $hdrLenNoTag + 32) { throw "Truncated CSB header." }

  $wrapped = New-Object byte[] $wlen
  [Array]::Copy($bytes,8,$wrapped,0,$wlen)

  $tag = New-Object byte[] 32
  [Array]::Copy($bytes, $bytes.Length-32, $tag, 0, 32)

  $cipherLen = $bytes.Length - $hdrLenNoTag - 32
  if ($cipherLen -le 0) { throw "No ciphertext present in CSB." }
  $cipher = New-Object byte[] $cipherLen
  [Array]::Copy($bytes, $hdrLenNoTag, $cipher, 0, $cipherLen)

  $headerNoTag = New-Object byte[] $hdrLenNoTag
  [Array]::Copy($bytes, 0, $headerNoTag, 0, $hdrLenNoTag)

  return [pscustomobject]@{
    Version      = $ver
    Flags        = $flags
    Wrapped      = $wrapped
    Ciphertext   = $cipher
    Tag          = $tag
    HeaderNoTag  = $headerNoTag
  }
}

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# FIXED RSA UNWRAP (lifted from your CS-Toolbox-Decryptor v1.8)
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
function Unwrap-Secret {
  param(
    [Parameter(Mandatory)][byte[]]$Wrapped,
    [Parameter(Mandatory)][int]$Flags,
    [Parameter(Mandatory)][System.Security.Cryptography.RSA]$Rsa
  )

  $isCsp = ($Rsa -is [System.Security.Cryptography.RSACryptoServiceProvider])

  $order = @()
  if (($Flags -band 0x02) -ne 0) { $order += 'OaepSHA256' }
  if (($Flags -band 0x04) -ne 0) { $order += 'OaepSHA1' }
  if ($order.Count -eq 0) { $order = @('OaepSHA256','OaepSHA1') }

  $order += 'Pkcs1'

  foreach($pad in $order){
    try {
      switch ($pad) {
        'OaepSHA256' {
          if ($isCsp) { throw "RSACryptoServiceProvider does not support OAEP-SHA256 in .NET Framework; skipping." }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        }
        'OaepSHA1' {
          if ($isCsp) {
            return ([System.Security.Cryptography.RSACryptoServiceProvider]$Rsa).Decrypt($Wrapped, $true)
          } else {
            return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
          }
        }
        'Pkcs1' {
          $priv = $Rsa.ExportParameters($true)
          $keySizeBits = $priv.Modulus.Length * 8
          $cspParams = New-Object System.Security.Cryptography.CspParameters
          $cspParams.ProviderType = 24
          $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
          try {
            $csp.PersistKeyInCsp = $false
            $csp.ImportParameters($priv)
            return $csp.Decrypt($Wrapped, $false)
          } finally {
            try { $csp.Clear() } catch {}
            try { $csp.Dispose() } catch {}
          }
        }
      }
    } catch {
      Write-Audit ("RSA unwrap failed with {0}: {1}" -f $pad, $_.Exception.Message) 'WARN'
    }
  }

  throw "Unable to unwrap AES/HMAC/IV secret with available paddings."
}

function Decrypt-CSB-InPlace {
  param([string]$CsbPath,[string]$Passphrase)

  if (-not (Test-Path -LiteralPath $CsbPath -PathType Leaf)) { throw "CSB not found: $CsbPath" }
  if ([string]::IsNullOrWhiteSpace($Passphrase)) { throw "Passphrase is blank; cannot decrypt." }
  if ([string]::IsNullOrWhiteSpace($Global:CS_EncryptedPrivateKeyPem)) { throw "Encrypted private key PEM not set in script." }

  $outDir = Split-Path -Path $CsbPath -Parent
  Ensure-ZipAssemblies

  $csb = Read-CSB -path $CsbPath
  $rsaPriv = Decrypt-Pkcs8EncryptedPrivateKey -pem $Global:CS_EncryptedPrivateKeyPem -password $Passphrase

  $secret = Unwrap-Secret -Wrapped $csb.Wrapped -Flags $csb.Flags -Rsa $rsaPriv
  if ($secret.Length -lt 80) { throw "Unwrapped secret too short ($($secret.Length)); expected 80." }

  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0,  $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret, 32, $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret, 64, $iv, 0, 16)

  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  try {
    $combined = New-Object byte[] ($csb.HeaderNoTag.Length + $csb.Ciphertext.Length)
    [Array]::Copy($csb.HeaderNoTag,0,$combined,0,$csb.HeaderNoTag.Length)
    [Array]::Copy($csb.Ciphertext,0,$combined,$csb.HeaderNoTag.Length,$csb.Ciphertext.Length)
    $calcTag = $hmac.ComputeHash($combined)
  } finally {
    $hmac.Dispose()
  }

  if (-not (BytesEqual $calcTag $csb.Tag)) { throw "HMAC authentication failed." }

  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = 256
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $aesKey
    $aes.IV  = $iv

    $msOut = New-Object IO.MemoryStream
    try {
      $cs2 = New-Object System.Security.Cryptography.CryptoStream($msOut, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try {
        $cs2.Write($csb.Ciphertext,0,$csb.Ciphertext.Length)
        $cs2.FlushFinalBlock()
      } finally {
        $cs2.Dispose()
      }
      $zipBytes = $msOut.ToArray()
    } finally {
      $msOut.Dispose()
    }
  } finally {
    $aes.Dispose()
  }

  $baseName = [IO.Path]::GetFileNameWithoutExtension($CsbPath)
  $outZip = Join-Path $outDir ($baseName + ".zip")
  [IO.File]::WriteAllBytes($outZip, $zipBytes)

  $extractDir = Join-Path $outDir $baseName
  if (Test-Path -LiteralPath $extractDir) {
    try { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction Stop }
    catch { $extractDir = $extractDir + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') }
  }

  [System.IO.Compression.ZipFile]::ExtractToDirectory($outZip, $extractDir)
  [pscustomobject]@{ ZipPath = $outZip; ExtractPath = $extractDir }
}

function Open-Folder([string]$Path) {
    try { if (Test-Path -LiteralPath $Path) { Start-Process explorer.exe -ArgumentList "`"$Path`"" | Out-Null } } catch { }
}

# =====================================================================
# Mode resolution: MinIO -> Azure -> HTML helper
# =====================================================================
function Resolve-StorageModeOrFallbackHtml {
    $minioPathTried = $Global:MinioCredPath
    $userMinioPathTried = Get-UserMinioCredPath
    if ([string]::IsNullOrWhiteSpace($userMinioPathTried)) { $userMinioPathTried = "(none)" }

    $cfg = Try-LoadMinioCredsFromPath $Global:MinioCredPath
    if ($cfg) {
        try { [void](Get-MinIOObjectList -Cfg $cfg -MaxResults 1); return [pscustomobject]@{ Mode='MinIO'; Ctx=$cfg; MinioPath=$minioPathTried; UserMinioPath=$userMinioPathTried; Sas=$SasUrl } }
        catch { Write-Audit ("MinIO validation failed (machine creds): {0}" -f $_.Exception.Message) 'WARN' }
    }

    $cfg2 = Try-LoadMinioCredsFromPath $userMinioPathTried
    if ($cfg2) {
        try { [void](Get-MinIOObjectList -Cfg $cfg2 -MaxResults 1); return [pscustomobject]@{ Mode='MinIO'; Ctx=$cfg2; MinioPath=$minioPathTried; UserMinioPath=$userMinioPathTried; Sas=$SasUrl } }
        catch { Write-Audit ("MinIO validation failed (user creds): {0}" -f $_.Exception.Message) 'WARN' }
    }

    Write-Host ""
    $yn = Read-Host "Local MinIO creds not found/valid. Enter MinIO creds now? (Y/N)"
    if ($yn -match '^[Yy]$') {
        try {
            $cfg3 = Prompt-MinioCreds
            [void](Get-MinIOObjectList -Cfg $cfg3 -MaxResults 1)
            return [pscustomobject]@{ Mode='MinIO'; Ctx=$cfg3; MinioPath=$minioPathTried; UserMinioPath=$userMinioPathTried; Sas=$SasUrl }
        } catch {
            Write-Audit ("MinIO prompt/validation failed: {0}" -f $_.Exception.Message) 'WARN'
        }
    }

    $sasTried = $SasUrl
    if ([string]::IsNullOrWhiteSpace($SasUrl)) {
        Write-Host ""
        $SasUrl = Read-Host "Enter Azure Container SAS URL (Read+List) to browse (or press Enter to skip)"
        $sasTried = $SasUrl
    }

    if (-not [string]::IsNullOrWhiteSpace($SasUrl)) {
        try {
            $uri = [uri]$SasUrl
            [void](Try-ListAzure -SasContainerUri $uri -MaxResults 1)
            return [pscustomobject]@{ Mode='Azure'; Ctx=$uri; MinioPath=$minioPathTried; UserMinioPath=$userMinioPathTried; Sas=$sasTried }
        } catch {
            Write-Audit ("Azure SAS validation failed: {0}" -f $_.Exception.Message) 'WARN'
        }
    }

    Open-HtmlEmailHelper -Reason "Neither Local MinIO nor Azure SAS access could be validated." `
        -MinioPathTried $minioPathTried `
        -UserMinioPathTried $userMinioPathTried `
        -SasUrlTried ("" + $sasTried)

    return $null
}

# =====================================================================
# Table UI loop
# =====================================================================
function Show-EnhancedTableWithSearch {
    param(
        $AllItems,
        [string]$Mode,
        $ModeContext,
        [string]$DownloadRoot
    )

    $currentFilter = ""

    while ($true) {
        Clear-Host
        Write-InfoColor "============================================================" Yellow
        Write-InfoColor ("  Secure Bundles - Enhanced Table View  ({0})" -f $Mode) Yellow
        Write-InfoColor "============================================================" Yellow
        Write-Host ""

        if (-not [string]::IsNullOrWhiteSpace($currentFilter)) { Write-InfoColor ("Active Filter: '{0}'" -f $currentFilter) Cyan }
        else { Write-InfoColor "Active Filter: (none)" DarkGray }

        Write-Host ""

        $all = Force-Array $AllItems
        $displayItems = if (-not [string]::IsNullOrWhiteSpace($currentFilter)) {
            Force-Array ($all | Where-Object { $_.Name -like "*$currentFilter*" -or $_.Folder -like "*$currentFilter*" })
        } else { $all }

        $displayCount = Count-Items $displayItems

        if ($displayCount -eq 0) {
            Write-InfoColor "No items match the current filter." Red
        } else {
            "{0,4}  {1,-29}  {2,-28}  {3,8}  {4}" -f "Idx","Folder","File","Size(MB)","Uploaded"
            "{0,4}  {1,-29}  {2,-28}  {3,8}  {4}" -f "---","-----------------------------","----------------------------","--------","---------------------"

            $idx = 1
            foreach ($item in $displayItems) {
                $line = "{0,4}  {1,-29}  {2,-28}  {3,8:N1}  {4:yyyy-MM-dd HH:mm}" -f $idx, $item.Folder, $item.File, $item.SizeMB, $item.LastModified
                Write-Host $line
                $idx++
            }
        }

        Write-Host ""
        Write-Host "Commands:"
        Write-Host "  [Idx] Download    [S] Search    [C] Clear Filter    [R] Refresh    [Q] Quit"
        $input = Read-Host "Selection"

        if ($input -match '^[Qq]$') { return "QUIT" }
        if ($input -match '^[Rr]$') { return "REFRESH" }
        if ($input -match '^[Ss]$') { $currentFilter = Read-Host "Enter search text (ticket, id, hostname, file). Blank = none"; continue }
        if ($input -match '^[Cc]$') { $currentFilter = ""; continue }

        if ($input -match '^\d+$') {
            $num = [int]$input
            if ($num -lt 1 -or $num -gt $displayCount) {
                Write-InfoColor "Selection out of range." Red
                Start-Sleep -Seconds 1
                continue
            }

            $arr = Force-Array $displayItems
            $chosen = $arr[$num - 1]

            $downloaded = $null
            if ($Mode -eq 'Azure') {
                $downloaded = Download-AzureBlobFromSas -SasContainerUri $ModeContext -BlobName $chosen.Name -DownloadRoot $DownloadRoot
            } else {
                $downloaded = Download-MinIOObject -Cfg $ModeContext -Key $chosen.Name -DownloadRoot $DownloadRoot
            }

            Write-Audit ("Downloaded: {0}" -f $downloaded)

            if ($downloaded -and $downloaded.ToLower().EndsWith(".csb")) {
                Write-Host ""
                $yn = Read-Host "Decrypt this downloaded bundle now? (Y/N)"
                if ($yn -match '^[Yy]$') {
                    try {
                        Write-InfoColor "Decrypting .csb into the same download folder..." Yellow
                        $res = Decrypt-CSB-InPlace -CsbPath $downloaded -Passphrase $Global:CS_EncryptPassphrase
                        Write-InfoColor ("Decrypted ZIP : {0}" -f $res.ZipPath) Green
                        Write-InfoColor ("Extracted to  : {0}" -f $res.ExtractPath) Green
                        Write-Audit ("Decrypted: {0} -> {1}" -f $downloaded, $res.ExtractPath)
                        Open-Folder -Path $res.ExtractPath
                    } catch {
                        Write-InfoColor ("Decryption failed: {0}" -f $_.Exception.Message) Red
                        Write-Audit ("Decryption failed: {0}" -f $_.Exception.Message) 'ERROR'
                    }
                }
            }

            Write-Host ""
            Read-Host "Press Enter to return to the list" | Out-Null
            continue
        }

        Write-InfoColor "Unrecognized input." Red
        Start-Sleep -Seconds 1
    }
}

# =====================================================================
# MAIN
# =====================================================================
try {
    Ensure-Folder $Global:CollectedInfoRoot
    Write-Audit "RUN START CS-secure-log-browser v2.3"

    Prompt-Passphrase

    while ($true) {
        $resolved = Resolve-StorageModeOrFallbackHtml
        if ($null -eq $resolved) {
            Write-Audit "Exited after HTML helper fallback." 'WARN'
            exit 0
        }

        $mode = $resolved.Mode
        $ctx  = $resolved.Ctx

        $items = @()
        if ($mode -eq 'MinIO') {
            Write-InfoColor "Loading recent secure bundles from MinIO (Local mode)..." Cyan
            $items = Force-Array (Get-MinIOObjectList -Cfg $ctx -MaxResults $MaxResults)
        } else {
            Write-InfoColor "Loading recent secure bundles from Azure (SAS fallback)..." Cyan
            $items = Force-Array (Try-ListAzure -SasContainerUri $ctx -MaxResults $MaxResults)
        }

        if ($ExportOnly) {
            $outFile = Join-Path $Global:CollectedInfoRoot ("secure-log-browser-list_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            $items | ConvertTo-Json -Depth 8 | Out-File -FilePath $outFile -Encoding UTF8
            Write-InfoColor "ExportOnly: wrote list to:" Green
            Write-Host $outFile
            Write-Audit ("ExportOnly wrote {0}" -f $outFile)
            exit 0
        }

        if ((Count-Items $items) -eq 0) {
            Write-InfoColor "No items found." Yellow
            Write-Audit "No items found."
            exit 0
        }

        $result = Show-EnhancedTableWithSearch -AllItems $items -Mode $mode -ModeContext $ctx -DownloadRoot $DownloadRoot
        if ($result -eq "REFRESH") { continue }
        break
    }

    Write-Audit "RUN SUCCESS"
    exit 0
}
catch {
    Write-Audit $_.Exception.Message 'ERROR'
    Write-Error ("ERROR: {0}" -f $_.Exception.Message)
    exit 2
}
