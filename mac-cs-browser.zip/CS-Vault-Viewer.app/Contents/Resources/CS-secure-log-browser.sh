#!/bin/bash

set -u
set -o pipefail

SCRIPT_NAME="CS-secure-log-browser-mac-fixed-v07.sh"
VERSION="v0.7-mac-fix-hmac-and-open-folder"

AZURE_STORAGE_ACCOUNT="cssupport1"
AZURE_CONTAINER="uploadlogs"
AZURE_TENANT_ID="8ecbd342-5d6f-4e6c-9ade-efa82f2b0029"

MAX_RESULTS=2000
PAGE_SIZE=20
SEARCH_TEXT=""
BLOB_NAME=""
BLOB_ARG_PROVIDED=0
AUTO_DECRYPT=0
EXPORT_ONLY=0
DECRYPT_PASSWORD=""
KEEP_OPEN=1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PASSWORD_CACHE_FILE="$SCRIPT_DIR/.cs_secure_log_browser_password.cache"
PASSWORD_CACHE_DAYS=30
PASSWORD_CACHE_SECONDS=$((30 * 24 * 60 * 60))

DOWNLOAD_ROOT="$HOME/CS-Toolbox-TEMP/Downloads"
COLLECTED_INFO_ROOT="$HOME/CS-Toolbox-TEMP/Collected-Info"
WORK_ROOT="$HOME/CS-Toolbox-TEMP/Decrypt/_work"
AUDIT_LOG="$COLLECTED_INFO_ROOT/CS-secure-log-browser-mac.log"
RUN_EXPORT_FILE="$COLLECTED_INFO_ROOT/CS-secure-log-browser-mac-last.txt"

BREW_UPDATED_THIS_RUN=0
AZ_BIN=""
PYTHON_BIN=""
UNZIP_BIN=""
OPENSSL_BIN=""
STTY_WAS_CHANGED=0

cleanup() {
  if [ "$STTY_WAS_CHANGED" -eq 1 ]; then
    stty echo >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

read -r -d '' CS_ENCRYPTED_PRIVATE_KEY_PEM <<'PEM' || true
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQVqpfmIOsXqQKzn+1
cECzMQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEJrXQAs92MM6jTy6
tRw43LIEggTQ9zl6K9oEJHLdrTWmhxS22okeXW9NGU7jorabqXsPDU52aGao43xS
1Q+tsPpkqR3Fi/ujL7x9NxbUUWhYlmz89UTfrpnn1l4h4+Fy+W+k2Wz8CTbjnN5S
oaPfzH40km+zDXib7HAvyNix5dUkQ05GVR6SBu3ljNrlLY1UKgP9NNVyOjyaCE37
jViKUuYEjXnoconYgjWiqY8zvl3K3SKK7Qf5S3y7fM2KLI2uZLM5JbwixDNLAmEx
il0cMyiu06nhltRPGriMWblsNnTQJrF+Lbuh/qHzNOu23XTqDSxHqSHubiibkLzl
nmFP7VG+iKpE8NCkF1Sp/y3rmJPjzzBYfrQqcnAqsUoikr8YqZL0+geNJ4YR43vi
Ks/xlFkj6exQSAVGWivO2miUwReq1RWcpUDQdYWrsI6A0ZaqONvRN5fHyP+RkxRO
aIugnGmmoPGS2G3aA/WfjsVudkwCAng8SLyCNnM4D/ry2AUetfhYagHSAqbih6Mg
LB3NhbvE4BJ/ixTTnM7HIdbiFY/rP43JpWS7z5PfWoAcvc7fPbtyjKrmsMTvKaut
klLgVFTBjiLcM3jgMW4RUE22RR8lHxp+4WOfMhoVrGUPVP5ptWUxompKE2fc2p1b
L5lpK/oYm/TqL4cdDP+FQzDIFwLb2AUaaRxzcmDLK3aSqMwjTHvT3Qp4LzD+r/w4
I7dCix3TBuQu8L/NzMXRlJ9OjyxDoyuE+6nRcfQGaXIcIgcv05y3RbWlCh4MD3Np
rzjxYwKYrR3dOKLbH1cfOZDrVKPKGr/b1sXukEcX+aiGb3uBkuAC02XAKBXG9VN5
TzT2F4JEZ2ecflRDcB8YEzCc1yoej9xaR821fqtfjE99Bp2yA60wP79Jdv/uWJau
T2PyrlFQB9m5gfBUqhqbIhvmpBX4EtwKXOs3IDc8xKhy4YuhBhwKpySJ3BDzZ1D0
5vmilv19R2EEsvwlOxQPpp+73u5hcTDluxj5ddNww+xe9MQp4RGHMqnTjFKPHPAA
GeG6AhQW4PfREUZvV6WV/mrIbVTkEhINzETPP8aJRuPjwqRvmvEUb0gE97iG8hqo
5pcp1fHyc7LshQoZ81PwgMYM80i5V53dCfC/6UGflKWj34dwfRh+KvLWCztOew10
+ypcxT/lditoomPkrFP0cC9r0C3UyPNU6R+Sb2gp4WKWmI/N8z0Vr2JjwjuoiHw1
nLF1zz7VZhSpGeMOxe07gdNBhiXY0c9uUSuTE0TmeSqP+1t3+i2f+vA+V8qmuMI/
1qObRazOcoGx3O4iw5p3q+fMrYoMGcXWzYiMWi6jtCZ5LlEsopuSmQPISUMJshMO
TJxHpoKVg13U9vVHmasPpBXAXXJrNO9SGAPDYPOBZbHNaw9+SzTDrgT2XMpc0/fY
0FLwKP1iBjboUwR46FnR2Pnx6HmVADnNt0cFzezQVUhn4IGlvWRoLkpsL3Ynm11P
ohaL+j126Nht01Jm1HrM4fUPIslw52WyMqBR/PM3QhG/uyHa1Ld6K53gIsid30uq
b8KYM3aBKxnUhGQ21YuVjg0v8noWnkaYY4iQj5VURRD9+cBrp0N7mCClY3R3T/cN
7D/ShzXBnVCX2J1eXT8p6v6He3ue9EIWtRwvyd6b8BswoMPOlRCbWaQ=
-----END ENCRYPTED PRIVATE KEY-----
PEM

usage() {
  cat <<USAGE
$SCRIPT_NAME $VERSION

Mac-native Secure Bundle Browser / Downloader using Azure CLI.
Auto-installs / updates required components on macOS.

Usage:
  ./$SCRIPT_NAME [options]

Options:
  -blobname <name>           Download a specific blob directly.
  -search <text>             Filter blob names by text.
  -maxresults <n>            Max items to show when listing blobs. Default: $MAX_RESULTS
  -downloadroot <path>       Download folder. Default: $DOWNLOAD_ROOT
  -decryptpassword <pass>    Supply decrypt password at launch.
  -autodecrypt               Automatically decrypt downloaded .csb bundles.
  -exportonly                Minimal output and export run summary to Collected-Info.
  -noclosepause              Do not pause before exit.
  -help                      Show this help.

Password cache:
  - On launch, the script prompts for a decryption password in GUI.
  - The password cache is saved next to the script for 30 days:
      $PASSWORD_CACHE_FILE
USAGE
}

ensure_dirs() {
  mkdir -p "$DOWNLOAD_ROOT" "$COLLECTED_INFO_ROOT" "$WORK_ROOT" || fail "Unable to create working directories."
}

log() {
  mkdir -p "$COLLECTED_INFO_ROOT" >/dev/null 2>&1 || true
  printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" "$2" >> "$AUDIT_LOG"
}

write_export_summary() {
  local content="$1"
  mkdir -p "$COLLECTED_INFO_ROOT" >/dev/null 2>&1 || true
  printf '%s\n' "$content" > "$RUN_EXPORT_FILE"
}

info() {
  if [ "$EXPORT_ONLY" -eq 0 ]; then
    printf '%s\n' "$1" >&2
  fi
}

warn() {
  printf '%s\n' "$1" >&2
  log "WARN" "$1"
}

pause_before_exit() {
  if [ "$EXPORT_ONLY" -eq 1 ]; then
    return 0
  fi
  if [ "$KEEP_OPEN" -eq 0 ]; then
    return 0
  fi
  if [ ! -t 0 ]; then
    return 0
  fi
  printf '\nPress Enter to return to main menu...'
  read -r _dummy || true
  return 0 2>/dev/null || exit 0
}

fail() {
  printf '%s\n' "$1" >&2
  write_export_summary "status=error
message=$1
audit_log=$AUDIT_LOG"
  log "ERROR" "$1"
  pause_before_exit
  exit 1
}

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

popup() {
  local msg="$1"
  if have_cmd osascript; then
    osascript -e "display dialog \"${msg//\"/\\\"}\" buttons {\"OK\"} default button \"OK\"" >/dev/null 2>&1 || true
  fi
}

notify() {
  local title="$1"
  local msg="$2"
  if have_cmd osascript; then
    osascript -e "display notification \"${msg//\"/\\\"}\" with title \"${title//\"/\\\"}\"" >/dev/null 2>&1 || true
  fi
}

gui_prompt_password() {
  local prompt_msg="$1"
  if have_cmd osascript; then
    osascript <<OSA
tell application "System Events"
  activate
  set d to display dialog "$prompt_msg" default answer "" with hidden answer buttons {"Save Password", "Skip"} default button "Save Password"
  if button returned of d is "Skip" then
    return "__SKIP__"
  else
    return text returned of d
  end if
end tell
OSA
  else
    printf 'Enter ConnectSecure decrypt password: '
    stty -echo
    STTY_WAS_CHANGED=1
    read -r DECRYPT_PASSWORD
    stty echo
    STTY_WAS_CHANGED=0
    printf '\n'
    printf '%s\n' "$DECRYPT_PASSWORD"
  fi
}

save_password_cache() {
  local pw="$1"
  [ -n "$pw" ] || return 0
  local epoch_now
  epoch_now="$(date +%s)"
  umask 077
  {
    printf 'saved_epoch=%s\n' "$epoch_now"
    printf 'password_b64=%s\n' "$(printf '%s' "$pw" | base64)"
  } > "$PASSWORD_CACHE_FILE" || fail "Unable to write password cache file."
  chmod 600 "$PASSWORD_CACHE_FILE" >/dev/null 2>&1 || true
  log "INFO" "Updated cached decryption password at $PASSWORD_CACHE_FILE"
}

clear_password_cache() {
  if [ -f "$PASSWORD_CACHE_FILE" ]; then
    rm -f "$PASSWORD_CACHE_FILE" || fail "Unable to clear cached decryption password."
    log "INFO" "Cleared cached decryption password."
  fi
}

load_password_cache_if_valid() {
  [ -f "$PASSWORD_CACHE_FILE" ] || return 1

  local saved_epoch=""
  local password_b64=""
  saved_epoch="$(grep '^saved_epoch=' "$PASSWORD_CACHE_FILE" 2>/dev/null | head -n 1 | cut -d= -f2-)"
  password_b64="$(grep '^password_b64=' "$PASSWORD_CACHE_FILE" 2>/dev/null | head -n 1 | cut -d= -f2-)"

  [ -n "$saved_epoch" ] || return 1
  [ -n "$password_b64" ] || return 1

  local epoch_now age
  epoch_now="$(date +%s)"
  age=$((epoch_now - saved_epoch))
  if [ "$age" -gt "$PASSWORD_CACHE_SECONDS" ]; then
    clear_password_cache
    return 1
  fi

  DECRYPT_PASSWORD="$(printf '%s' "$password_b64" | base64 --decode 2>/dev/null || true)"
  [ -n "$DECRYPT_PASSWORD" ] || return 1
  return 0
}

password_cache_expiry_text() {
  if [ ! -f "$PASSWORD_CACHE_FILE" ]; then
    return 1
  fi
  local saved_epoch expire_epoch
  saved_epoch="$(grep '^saved_epoch=' "$PASSWORD_CACHE_FILE" 2>/dev/null | head -n 1 | cut -d= -f2-)"
  [ -n "$saved_epoch" ] || return 1
  expire_epoch=$((saved_epoch + PASSWORD_CACHE_SECONDS))
  date -r "$expire_epoch" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || printf '30 days from save'
}

setup_decrypt_password_on_launch() {
  if [ -n "$DECRYPT_PASSWORD" ]; then
    save_password_cache "$DECRYPT_PASSWORD"
    return 0
  fi

  local cached_valid=0
  local cache_expiry=""
  if load_password_cache_if_valid; then
    cached_valid=1
    cache_expiry="$(password_cache_expiry_text || true)"
  fi

  if [ "$cached_valid" -eq 1 ]; then
    local cache_choice=""
    if have_cmd osascript; then
      cache_choice="$(osascript <<OSA
tell application "System Events"
  activate
  set d to display dialog "A cached decryption password is available for Secure Bundle Browser.\n\nCache file:\n$PASSWORD_CACHE_FILE\n\nValid until: $cache_expiry" buttons {"Use Cached Password", "Enter New Password", "Clear Cached Password"} default button "Use Cached Password"
  return button returned of d
end tell
OSA
)"
    else
      info "A cached decryption password is available and valid until: $cache_expiry"
      printf 'Choose: [1] Use Cached Password  [2] Enter New Password  [3] Clear Cached Password : '
      read -r cache_choice
      case "$cache_choice" in
        1) cache_choice="Use Cached Password" ;;
        2) cache_choice="Enter New Password" ;;
        3) cache_choice="Clear Cached Password" ;;
        *) cache_choice="Use Cached Password" ;;
      esac
    fi

    case "$cache_choice" in
      "Use Cached Password")
        log "INFO" "Using cached decryption password."
        return 0
        ;;
      "Enter New Password")
        DECRYPT_PASSWORD=""
        ;;
      "Clear Cached Password")
        clear_password_cache
        DECRYPT_PASSWORD=""
        ;;
      *)
        return 0
        ;;
    esac
  fi

  local entered_pw=""
  entered_pw="$(gui_prompt_password "Enter the ConnectSecure decryption password now.\n\nIt will be cached in a file next to this script for 30 days.")"
  if [ "$entered_pw" = "__SKIP__" ]; then
    DECRYPT_PASSWORD=""
    log "INFO" "User skipped password entry at launch."
    return 0
  fi

  if [ -z "$entered_pw" ]; then
    DECRYPT_PASSWORD=""
    warn "No decryption password was entered at launch."
    return 0
  fi

  DECRYPT_PASSWORD="$entered_pw"
  save_password_cache "$DECRYPT_PASSWORD"
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      -blobname)
        [ $# -ge 2 ] || fail "Missing value for -blobname"
        BLOB_NAME="$2"
        BLOB_ARG_PROVIDED=1
        shift 2
        ;;
      -search)
        [ $# -ge 2 ] || fail "Missing value for -search"
        SEARCH_TEXT="$2"
        shift 2
        ;;
      -maxresults)
        [ $# -ge 2 ] || fail "Missing value for -maxresults"
        MAX_RESULTS="$2"
        shift 2
        ;;
      -downloadroot)
        [ $# -ge 2 ] || fail "Missing value for -downloadroot"
        DOWNLOAD_ROOT="$2"
        shift 2
        ;;
      -decryptpassword)
        [ $# -ge 2 ] || fail "Missing value for -decryptpassword"
        DECRYPT_PASSWORD="$2"
        shift 2
        ;;
      -autodecrypt)
        AUTO_DECRYPT=1
        shift
        ;;
      -exportonly)
        EXPORT_ONLY=1
        KEEP_OPEN=0
        shift
        ;;
      -noclosepause)
        KEEP_OPEN=0
        shift
        ;;
      -help|-h|--help)
        usage
        exit 0
        ;;
      *)
        fail "Unknown argument: $1"
        ;;
    esac
  done
}

ensure_brew_path() {
  if have_cmd brew; then
    return 0
  fi
  if [ -x "/opt/homebrew/bin/brew" ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [ -x "/usr/local/bin/brew" ]; then
    eval "$(/usr/local/bin/brew shellenv)"
  fi
}

ensure_homebrew() {
  ensure_brew_path
  if have_cmd brew; then
    return 0
  fi

  info "Homebrew not found. Installing Homebrew..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || fail "Homebrew install failed."
  ensure_brew_path
  have_cmd brew || fail "Homebrew installed, but brew still is not on PATH. Restart Terminal and rerun."
}

maybe_update_homebrew_once() {
  ensure_brew_path
  if [ "$BREW_UPDATED_THIS_RUN" -eq 0 ]; then
    info "Refreshing Homebrew metadata..."
    brew update >/dev/null 2>&1 || warn "brew update failed; continuing with existing metadata."
    BREW_UPDATED_THIS_RUN=1
  fi
}

brew_formula_installed() {
  brew list --formula "$1" >/dev/null 2>&1
}

ensure_brew_formula() {
  local formula="$1"
  ensure_homebrew
  maybe_update_homebrew_once

  if ! brew_formula_installed "$formula"; then
    info "Installing $formula ..."
    brew install "$formula" || fail "Failed to install $formula"
    return 0
  fi

  if brew outdated --formula "$formula" >/dev/null 2>&1; then
    info "Upgrading $formula ..."
    brew upgrade "$formula" >/dev/null 2>&1 || warn "Upgrade failed for $formula; continuing with installed version."
  fi
}

ensure_prereqs() {
  ensure_brew_formula azure-cli
  ensure_brew_formula openssl@3
  ensure_brew_formula python

  if ! have_cmd unzip; then
    info "Installing unzip ..."
    ensure_brew_formula unzip
  fi

  if ! have_cmd az; then
    if [ -x "$(brew --prefix)/bin/az" ]; then
      export PATH="$(brew --prefix)/bin:$PATH"
    fi
  fi

  if ! have_cmd python3; then
    if [ -x "$(brew --prefix python)/bin/python3" ]; then
      export PATH="$(brew --prefix python)/bin:$PATH"
    fi
  fi

  if [ -x "$(brew --prefix openssl@3)/bin/openssl" ]; then
    OPENSSL_BIN="$(brew --prefix openssl@3)/bin/openssl"
  elif have_cmd openssl; then
    OPENSSL_BIN="$(command -v openssl)"
  else
    fail "openssl is not available after install."
  fi

  AZ_BIN="$(command -v az || true)"
  PYTHON_BIN="$(command -v python3 || true)"
  UNZIP_BIN="$(command -v unzip || true)"

  [ -n "$AZ_BIN" ] || fail "Azure CLI is still not available after install."
  [ -n "$PYTHON_BIN" ] || fail "python3 is still not available after install."
  [ -n "$UNZIP_BIN" ] || fail "unzip is still not available after install."
}

ensure_azure_login() {
  if ! "$AZ_BIN" account show >/dev/null 2>&1; then
    info "Signing in to Azure with device code..."
    info "If a browser does not open automatically, follow the code shown below."
    "$AZ_BIN" login --tenant "$AZURE_TENANT_ID" --use-device-code || fail "Azure login failed."
  fi
}

list_blobs_raw() {
  "$AZ_BIN" storage blob list     --account-name "$AZURE_STORAGE_ACCOUNT"     --container-name "$AZURE_CONTAINER"     --auth-mode login     --num-results "$MAX_RESULTS"     --query "sort_by([].{name:name,lastModified:properties.lastModified,size:properties.contentLength}, &lastModified)[::-1]"     -o tsv
}

set_terminal_window() {
  if [ "$EXPORT_ONLY" -eq 0 ] && [ -t 1 ]; then
    printf ']0;CS Secure Bundle - Azure Vault Browser' >/dev/tty 2>/dev/null || true
    printf '[8;35;115t' >/dev/tty 2>/dev/null || true
  fi
}

clear_screen_if_interactive() {
  if [ "$EXPORT_ONLY" -eq 0 ] && [ -t 1 ]; then
    set_terminal_window
    clear
  fi
}

human_size() {
  local bytes="$1"
  awk -v bytes="$bytes" 'BEGIN {
    split("B KB MB GB TB", u, " ")
    size = bytes + 0
    i = 1
    while (size >= 1024 && i < 5) {
      size /= 1024
      i++
    }
    if (i == 1) {
      printf "%d %s", size, u[i]
    } else {
      printf "%.2f %s", size, u[i]
    }
  }'
}

size_mb_1dp() {
  local bytes="$1"
  awk -v bytes="$bytes" 'BEGIN { printf "%.1f", (bytes + 0) / 1048576 }'
}

trim_field() {
  local s="$1"
  s="${s#${s%%[![:space:]]*}}"
  s="${s%${s##*[![:space:]]}}"
  printf '%s' "$s"
}

parse_name_parts() {
  local blob_name="$1"
  local file base tail ticket company sender company_path ticket_path
  local part2

  file="${blob_name##*/}"
  base="${file%.csb}"
  base="${base%.zip}"

  company_path=""
  ticket_path=""
  case "$blob_name" in
    */*/*)
      company_path="$(printf '%s' "$blob_name" | cut -d '/' -f 1)"
      ticket_path="$(printf '%s' "$blob_name" | cut -d '/' -f 2)"
      ;;
  esac

  ticket=""
  if printf '%s' "$base" | grep -qi 't-'; then
    ticket="$(printf '%s' "$base" | sed -n 's/.*[Tt]-\([^.]*\).*/\1/p' | head -n 1)"
  fi

  tail="$base"
  if [[ "$base" == *_* ]]; then
    tail="${base##*_}"
  fi

  company="$(printf '%s' "$tail" | cut -d '-' -f 1)"
  if [ -z "$ticket" ]; then
    part2="$(printf '%s' "$tail" | cut -d '-' -f 2)"
    ticket="$part2"
  fi
  sender="$(printf '%s' "$tail" | cut -d '-' -f 3-)"

  if [ -n "$company_path" ] && [ "$company_path" != "$file" ]; then
    company="$company_path"
  fi
  if [ -n "$ticket_path" ] && [ "$ticket_path" != "$file" ]; then
    ticket="$ticket_path"
  fi

  company="$(trim_field "$company")"
  ticket="$(trim_field "$ticket")"
  sender="$(trim_field "$sender")"

  [ -n "$company" ] || company='-'
  [ -n "$ticket" ] || ticket='-'
  [ -n "$sender" ] || sender='-'

  printf '%s\t%s\t%s\n' "$company" "$ticket" "$sender"
}

format_timestamp_for_zone() {
  local iso_ts="$1"
  local zone_name="$2"
  "$PYTHON_BIN" - "$iso_ts" "$zone_name" <<'PYINNER'
import sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
iso_ts = sys.argv[1].strip()
zone_name = sys.argv[2].strip()
try:
    dt = datetime.fromisoformat(iso_ts.replace('Z', '+00:00'))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    out = dt.astimezone(ZoneInfo(zone_name))
    print(out.strftime('%Y-%m-%d %H:%M'))
except Exception:
    print(iso_ts[:16].replace('T', ' '))
PYINNER
}

menu_divider() {
  printf '%s
' '================================================================================================================'
}

render_blob_page() {
  local filtered_file="$1"
  local page="$2"
  local total_count="$3"
  local page_size="$4"
  local total_pages="$5"
  local start end count display_no name lastmod size size_mb est_ts ist_ts
  local company ticket sender parsed

  start=$(( (page - 1) * page_size + 1 ))
  end=$(( page * page_size ))
  if [ "$end" -gt "$total_count" ]; then
    end="$total_count"
  fi

  clear_screen_if_interactive
  menu_divider
  printf ' %-108s
' 'CS Secure Bundle - Azure Vault Browser'
  printf ' %-108s
' "$VERSION"
  menu_divider
  printf ' Storage Account: %-31s Container: %-24s
' "$AZURE_STORAGE_ACCOUNT" "$AZURE_CONTAINER"
  printf ' Tenant ID      : %-31s Window: %-24s
' "$AZURE_TENANT_ID" '115 x 35'
  if [ -n "$SEARCH_TEXT" ]; then
    printf ' Filter   : %s
' "$SEARCH_TEXT"
  else
    printf ' Filter   : Recent uploads
'
  fi
  printf ' Showing  : %s-%s of %s    Page: %s/%s
' "$start" "$end" "$total_count" "$page" "$total_pages"
  menu_divider
  printf '%-4s %-24s %-10s %-18s %6s %-16s %-16s
' 'No.' 'Company' 'Ticket' 'Sender' 'MB' 'Upload (EST)' 'Upload (IST)'
  menu_divider

  count=0
  while IFS=$'	' read -r name lastmod size; do
    count=$((count + 1))
    if [ "$count" -lt "$start" ] || [ "$count" -gt "$end" ]; then
      continue
    fi
    display_no="$count"
    parsed="$(parse_name_parts "$name")"
    company="$(printf '%s' "$parsed" | cut -f 1)"
    ticket="$(printf '%s' "$parsed" | cut -f 2)"
    sender="$(printf '%s' "$parsed" | cut -f 3)"
    size_mb="$(size_mb_1dp "$size")"
    est_ts="$(format_timestamp_for_zone "$lastmod" 'America/New_York')"
    ist_ts="$(format_timestamp_for_zone "$lastmod" 'Asia/Kolkata')"
    printf '%-4s %-24.24s %-10.10s %-18.18s %6s %-16s %-16s
' "$display_no" "$company" "$ticket" "$sender" "$size_mb" "$est_ts" "$ist_ts"
  done < "$filtered_file"

  menu_divider
  printf ' Commands: [number] Select   [N] Next page   [P] Previous page   [Q] Quit
'
}

set_terminal_window

choose_blob() {
  local tmpfile filtered_file error_file
  local choice page total_count total_pages
  local name lastmod size search_lc name_lc selected_line

  tmpfile="$(mktemp "$WORK_ROOT/bloblist_XXXXXX.txt")" || fail "Unable to create temporary blob list file."
  filtered_file="${tmpfile}.filtered"
  error_file="$WORK_ROOT/bloblist_error.txt"

  list_blobs_raw > "$tmpfile" 2>"$error_file" || {
    local azerr
    azerr="$(cat "$error_file" 2>/dev/null || true)"
    rm -f "$tmpfile" "$filtered_file" "$error_file" >/dev/null 2>&1 || true
    fail "Azure blob list failed. ${azerr}"
  }

  if [ ! -s "$tmpfile" ]; then
    rm -f "$tmpfile" "$filtered_file" "$error_file" >/dev/null 2>&1 || true
    fail "No blobs returned from Azure. Check RBAC access to $AZURE_STORAGE_ACCOUNT/$AZURE_CONTAINER."
  fi

  search_lc="$(printf '%s' "$SEARCH_TEXT" | tr '[:upper:]' '[:lower:]')"
  : > "$filtered_file"

  while IFS=$'	' read -r name lastmod size; do
    [ -n "$name" ] || continue
    name_lc="$(printf '%s' "$name" | tr '[:upper:]' '[:lower:]')"
    if [ -z "$search_lc" ] || [[ "$name_lc" == *"$search_lc"* ]]; then
      printf '%s	%s	%s
' "$name" "$lastmod" "$size" >> "$filtered_file"
    fi
  done < "$tmpfile"

  rm -f "$tmpfile" "$error_file" >/dev/null 2>&1 || true

  [ -s "$filtered_file" ] || {
    rm -f "$filtered_file" >/dev/null 2>&1 || true
    fail "No blobs matched search text: $SEARCH_TEXT"
  }

  total_count="$(wc -l < "$filtered_file" | tr -d '[:space:]')"
  [ "$total_count" -gt 0 ] || {
    rm -f "$filtered_file" >/dev/null 2>&1 || true
    fail "No blobs matched search text: $SEARCH_TEXT"
  }

  total_pages=$(( (total_count + PAGE_SIZE - 1) / PAGE_SIZE ))
  page=1

  while true; do
    render_blob_page "$filtered_file" "$page" "$total_count" "$PAGE_SIZE" "$total_pages"
    printf 'Selection: '
    read -r choice

    case "$choice" in
      q|Q)
        rm -f "$filtered_file" >/dev/null 2>&1 || true
        fail "User cancelled selection."
        ;;
      n|N)
        if [ "$page" -lt "$total_pages" ]; then
          page=$((page + 1))
        fi
        ;;
      p|P)
        if [ "$page" -gt 1 ]; then
          page=$((page - 1))
        fi
        ;;
      *)
        if [[ "$choice" =~ ^[0-9]+$ ]]; then
          if [ "$choice" -ge 1 ] && [ "$choice" -le "$total_count" ]; then
            selected_line="$(sed -n "${choice}p" "$filtered_file")"
            rm -f "$filtered_file" >/dev/null 2>&1 || true
            BLOB_NAME="${selected_line%%$'	'*}"
            [ -n "$BLOB_NAME" ] || fail "Unable to determine selected blob name."
            return 0
          fi
        fi
        ;;
    esac
  done
}

download_blob() {
  local out_file="$DOWNLOAD_ROOT/$(basename "$BLOB_NAME")"
  info "Downloading: $BLOB_NAME"
  "$AZ_BIN" storage blob download \
    --account-name "$AZURE_STORAGE_ACCOUNT" \
    --container-name "$AZURE_CONTAINER" \
    --name "$BLOB_NAME" \
    --file "$out_file" \
    --auth-mode login \
    --overwrite true >/dev/null || fail "Blob download failed."
  log "INFO" "Downloaded $BLOB_NAME to $out_file"
  printf '%s\n' "$out_file"
}

prompt_decrypt_password() {
  if [ -n "$DECRYPT_PASSWORD" ]; then
    return 0
  fi

  local entered_pw=""
  entered_pw="$(gui_prompt_password "Enter the ConnectSecure decryption password now.\n\nIt will be cached in a file next to this script for 30 days.")"
  if [ "$entered_pw" = "__SKIP__" ] || [ -z "$entered_pw" ]; then
    fail "Decrypt password cannot be blank."
  fi

  DECRYPT_PASSWORD="$entered_pw"
  save_password_cache "$DECRYPT_PASSWORD"
}

should_decrypt() {
  local path="$1"
  case "${path##*.}" in
    csb|CSB) ;;
    *) return 1 ;;
  esac

  if [ "$AUTO_DECRYPT" -eq 1 ]; then
    return 0
  fi

  if [ "$EXPORT_ONLY" -eq 1 ]; then
    return 1
  fi

  printf 'Decrypt this downloaded bundle now? (Y/N): '
  local answer
  read -r answer
  case "$answer" in
    y|Y|yes|YES) return 0 ;;
    *) return 1 ;;
  esac
}

decrypt_csb() {
  local csb_path="$1"
  prompt_decrypt_password

  local workdir
  workdir="$(mktemp -d "$WORK_ROOT/decrypt_XXXXXX")" || fail "Unable to create decrypt work folder."

  local enc_pem="$workdir/private.enc.pem"
  local plain_key="$workdir/private.key.pem"
  local meta_json="$workdir/meta.json"
  local hmac_input="$workdir/hmac_input.bin"
  local cipher_bin="$workdir/cipher.bin"
  local tag_hex_file="$workdir/tag.hex"
  local calc_tag_file="$workdir/calc_tag.txt"
  local wrapped_bin="$workdir/wrapped.bin"
  local secret_bin="$workdir/secret.bin"
  local zip_out="${csb_path%.*}.zip"
  local extract_dir="${csb_path%.*}"

  printf '%s\n' "$CS_ENCRYPTED_PRIVATE_KEY_PEM" > "$enc_pem" || fail "Unable to write private key PEM."
  printf '%s' "$DECRYPT_PASSWORD" | "$OPENSSL_BIN" pkcs8 -inform PEM -in "$enc_pem" -passin stdin -out "$plain_key" >/dev/null 2>&1 || fail "Decrypt password was rejected."

  "$PYTHON_BIN" - <<'PYA' "$csb_path" "$meta_json" "$hmac_input" "$cipher_bin" "$tag_hex_file"
import binascii, json, struct, sys
src, meta, hmac_in, cipher_out, tag_hex = sys.argv[1:6]
with open(src, 'rb') as f:
    data = f.read()
if len(data) < 4 + 1 + 1 + 2 + 32:
    raise SystemExit('File too small to be a CSB bundle.')
if data[:4] != b'CSB1':
    raise SystemExit('Bad CSB magic.')
ver = data[4]
flags = data[5]
wlen = struct.unpack('>H', data[6:8])[0]
hdr_len_no_tag = 8 + wlen
if len(data) < hdr_len_no_tag + 32:
    raise SystemExit('Truncated CSB header.')
wrapped = data[8:8+wlen]
tag = data[-32:]
cipher = data[hdr_len_no_tag:-32]
header = data[:hdr_len_no_tag]
with open(hmac_in, 'wb') as f:
    f.write(header)
    f.write(cipher)
with open(cipher_out, 'wb') as f:
    f.write(cipher)
with open(tag_hex, 'w') as f:
    f.write(binascii.hexlify(tag).decode())
with open(meta, 'w') as f:
    json.dump({'version': ver, 'flags': flags, 'wrapped_hex': binascii.hexlify(wrapped).decode()}, f)
PYA

  local wrapped_hex
  wrapped_hex="$("$PYTHON_BIN" - <<'PYB' "$meta_json"
import json, sys
with open(sys.argv[1], 'r') as f:
    print(json.load(f)['wrapped_hex'])
PYB
)"

  "$PYTHON_BIN" - <<'PYC' "$wrapped_hex" "$wrapped_bin"
import binascii, sys
hex_value, out_path = sys.argv[1:3]
with open(out_path, 'wb') as f:
    f.write(binascii.unhexlify(hex_value.encode()))
PYC

  "$OPENSSL_BIN" pkeyutl -decrypt -inkey "$plain_key" -in "$wrapped_bin" -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256 > "$secret_bin" 2>/dev/null || \
  "$OPENSSL_BIN" pkeyutl -decrypt -inkey "$plain_key" -in "$wrapped_bin" -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha1 > "$secret_bin" 2>/dev/null || \
  "$OPENSSL_BIN" pkeyutl -decrypt -inkey "$plain_key" -in "$wrapped_bin" -pkeyopt rsa_padding_mode:pkcs1 > "$secret_bin" 2>/dev/null || \
  fail "Unable to unwrap bundle secret."

  local secret_hex
  secret_hex="$("$PYTHON_BIN" - <<'PYD' "$secret_bin"
import binascii, sys
with open(sys.argv[1], 'rb') as f:
    print(binascii.hexlify(f.read()).decode(), end='')
PYD
)"
  [ ${#secret_hex} -ge 160 ] || fail "Unwrapped secret is too short."

  local aes_key_hex mac_key_hex iv_hex
  aes_key_hex="${secret_hex:0:64}"
  mac_key_hex="${secret_hex:64:64}"
  iv_hex="${secret_hex:128:32}"

  "$OPENSSL_BIN" dgst -sha256 -mac HMAC -macopt hexkey:"$mac_key_hex" -binary "$hmac_input" | "$PYTHON_BIN" -c 'import binascii,sys; sys.stdout.write(binascii.hexlify(sys.stdin.buffer.read()).decode())' > "$calc_tag_file"

  local expected_tag calc_tag
  expected_tag="$(cat "$tag_hex_file")"
  calc_tag="$(cat "$calc_tag_file")"
  [ "$expected_tag" = "$calc_tag" ] || fail "HMAC authentication failed."

  "$OPENSSL_BIN" enc -d -aes-256-cbc -K "$aes_key_hex" -iv "$iv_hex" -in "$cipher_bin" -out "$zip_out" >/dev/null 2>&1 || fail "AES decrypt failed."
  rm -rf "$extract_dir"
  mkdir -p "$extract_dir" || fail "Unable to create extract folder."
  "$UNZIP_BIN" -oq "$zip_out" -d "$extract_dir" >/dev/null || fail "ZIP extraction failed."

  rm -rf "$workdir" >/dev/null 2>&1 || true
  log "INFO" "Decrypted $csb_path to $zip_out and $extract_dir"
  printf '%s\n' "$extract_dir"
}

open_decrypted_info() {
  local extract_dir="$1"

  notify "Secure Bundle Browser" "Bundle decrypted successfully."
  open "$extract_dir" >/dev/null 2>&1 || true
  printf '%s\n' "$extract_dir"
}

write_success_export() {
  local downloaded="$1"
  local extracted="$2"
  local opened="$3"
  write_export_summary "status=ok
blob_name=$BLOB_NAME
downloaded_file=$downloaded
extracted_dir=$extracted
opened_target=$opened
password_cache_file=$PASSWORD_CACHE_FILE
audit_log=$AUDIT_LOG"
}

main() {
  parse_args "$@"
  ensure_dirs
  info "$SCRIPT_NAME $VERSION"
  info "Script folder: $SCRIPT_DIR"
  info "Working folder: $DOWNLOAD_ROOT"

  setup_decrypt_password_on_launch
  ensure_prereqs
  ensure_azure_login

  while true; do
    if [ -z "$BLOB_NAME" ]; then
      choose_blob
    fi

    local downloaded
    downloaded="$(download_blob)" || exit 1

    if should_decrypt "$downloaded"; then
      info "Decrypting bundle..."
      local extract_dir
      local opened_target
      extract_dir="$(decrypt_csb "$downloaded")" || exit 1
      info "Decrypted folder: $extract_dir"
      opened_target="$(open_decrypted_info "$extract_dir")"
      write_success_export "$downloaded" "$extract_dir" "$opened_target"
      if [ "$EXPORT_ONLY" -eq 1 ]; then
        printf '%s
' "$RUN_EXPORT_FILE"
      fi
    else
      info "Download complete: $downloaded"
      notify "Secure Bundle Browser" "Download complete."
      write_success_export "$downloaded" "" "$downloaded"
      if [ "$EXPORT_ONLY" -eq 1 ]; then
        printf '%s
' "$RUN_EXPORT_FILE"
      fi
    fi

    if [ "$EXPORT_ONLY" -eq 1 ] || [ "$KEEP_OPEN" -eq 0 ] || [ ! -t 0 ] || [ "$BLOB_ARG_PROVIDED" -eq 1 ]; then
      pause_before_exit
      break
    fi

    printf '
Press Enter to continue...'
    read -r _dummy || true
    BLOB_NAME=""
  done
}

main "$@"
