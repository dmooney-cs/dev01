#!/usr/bin/env bash
# ConnectSecure CSB Decryptor (macOS, OpenSSL)
# Flow:
#  1) Pick .csb (or pass as arg1)
#  2) Prompt for passphrase (encrypted PKCS#8 private key PEM is embedded)
#  3) Parse CSB1: header (magic/ver/flags/wrappedLen/wrapped) + ciphertext + tag(32)
#  4) RSA-decrypt wrapped secret trying OAEP-SHA256 -> OAEP-SHA1 -> PKCS#1 v1.5
#  5) Split secret: AES[32] || HMAC[32] || IV[16]
#  6) Verify HMAC-SHA256 over (headerNoTag || ciphertext)
#  7) AES-256-CBC decrypt ciphertext -> ZIP in same folder as CSB, extract, open Finder
#
# Optional:
#   --exportonly   : writes JSON to ~/CS-Toolbox-TEMP/Collected-Info and exits (no decrypt)

set -euo pipefail

# ---------- UI helpers ----------
ts() { date "+%Y-%m-%d %H:%M:%S"; }
info(){ printf "\033[36m[INFO]  %s  %s\033[0m\n"  "$(ts)" "$*"; }
ok()  { printf "\033[32m[OK]    %s  %s\033[0m\n"  "$(ts)" "$*"; }
warn(){ printf "\033[33m[WARN]  %s  %s\033[0m\n"  "$(ts)" "$*"; }
err() { printf "\033[31m[ERROR] %s  %s\033[0m\n"  "$(ts)" "$*"; }

# ---------- args ----------
EXPORTONLY=0
CSB_ARG=""

for a in "$@"; do
  case "$a" in
    --exportonly|-exportonly) EXPORTONLY=1 ;;
    *) CSB_ARG="$a" ;;
  esac
done

# ---------- config / dirs ----------
TEMP_ROOT="$HOME/CS-Toolbox-TEMP"
COLLECTED="$TEMP_ROOT/Collected-Info"
mkdir -p "$COLLECTED"

TMPROOT="$(mktemp -d /tmp/cs_csb_dec.XXXXXX)"
cleanup() { rm -rf "$TMPROOT"; }
trap cleanup EXIT

# ---------- dependencies ----------
if ! command -v openssl >/dev/null 2>&1; then
  err "openssl not found. Install Xcode Command Line Tools: xcode-select --install"
  exit 1
fi
if ! command -v xxd >/dev/null 2>&1; then
  err "xxd not found (usually included with macOS)."
  exit 1
fi

# ---------- file chooser (native) ----------
choose_file() {
  local prompt="$1"
  if command -v osascript >/dev/null 2>&1; then
    local r
    if r="$(/usr/bin/osascript <<EOF 2>/dev/null
set f to choose file with prompt "$prompt"
POSIX path of f
EOF
)"; then
      r="${r//$'\r'/}"
      if [[ -n "$r" && -e "$r" ]]; then printf "%s" "$r"; return 0; fi
    fi
  fi
  info "$prompt"
  read -r -p "Drag-and-drop the file here (or paste full path), then press Enter: " r
  r="${r%/}"; r="${r#\"}"; r="${r%\"}"
  [[ -e "$r" ]] || { err "File not found: $r"; exit 1; }
  printf "%s" "$r"
}

abspath() {
  local p="$1"
  if [[ "$p" = /* ]]; then printf "%s" "$p"; return; fi
  local d b
  d="$(cd "$(dirname "$p")" && pwd -P)"; b="$(basename "$p")"
  printf "%s/%s" "$d" "$b"
}

# ---------- ExportOnly ----------
if [[ "$EXPORTONLY" -eq 1 ]]; then
  stamp="$(date +%Y%m%d_%H%M%S)"
  out="$COLLECTED/csb_decryptor_export_${stamp}.json"
  cat >"$out" <<JSON
{
  "stamp": "$(date +%Y-%m-%dT%H:%M:%S%z)",
  "tool": "CSB-Decryptor-mac",
  "mode": "exportonly",
  "collectedInfo": "$(printf "%s" "$COLLECTED" | sed 's/"/\\"/g')"
}
JSON
  ok "ExportOnly wrote: $out"
  exit 0
fi

# ---------- inline encrypted PKCS#8 private key (PEM) ----------
KEY_ENC_PEM="$TMPROOT/priv_encrypted.pem"
cat >"$KEY_ENC_PEM" <<'PEM'
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQVqpfmIOsXqQKzn+1
cECzMQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEJrXQAs92MM6jTy6
tRw43LIEggTQ9zl6K9oEJHLdrTWmhxS22okeXW9NGU7jorabqXsPDU52aGao43xS
1Q+tsPpkqR3Fi/ujL7x9NxbUUWhYlmz89UTfrpnn1l4h4+Fy+W+k2Wz8CTbjnN5S
oaPfzH40km+zDXib7HAvyNix5dUkQ05GVR6SBu3ljNrlLY1UKgP9NNVyOjyaCE37
jViKUuYEjXnoconYgjWiqY8zvl3K3SKK7Qf5S3y7fM2KLI2uZLM5JbwixDNLAmEx
il0cMyiu06nhltRPGriMWblsNnTQJrF+Lbuh/qHzNOu23XTqDSxHqSHubiibkLzl
nmFP7VG+iKpE8NCkF1Sp/y3rmJPjzzBYfrQqcnAqsUoikr8YqZL0+geNJ4YR43vi
Ks/xlFkj6exQSAVGWivO2miUwReq1RWcpUDQdYWrsI6A0ZaqONvRN5fHyP+RkxRO
aIugnGmmoPGS2G3aA/WfjsVudkwCAng8SLyCNnM4D/ry2AUetfhYagHSAqbih6Mg
LB3NhbvE4BJ/ixTTnM7HIdbiFY/rP43JpWS7z5PfWoAcvc7fPbtyjKrmsMTvKaut
klLgVFTBjiLcM3jgMW4RUE22RR8lHxp+4WOfMhoVrGUPVP5ptWUxompKE2fc2p1b
L5lpK/oYm/TqL4cdDP+FQzDIFwLb2AUaaRxzcmDLK3aSqMwjTHvT3Qp4LzD+r/w4
I7dCix3TBuQu8L/NzMXRlJ9OjyxDoyuE+6nRcfQGaXIcIgcv05y3RbWlCh4MD3Np
rzjxYwKYrR3dOKLbH1cfOZDrVKPKGr/b1sXukEcX+aiGb3uBkuAC02XAKBXG9VN5
TzT2F4JEZ2ecflRDcB8YEzCc1yoej9xaR821fqtfjE99Bp2yA60wP79Jdv/uWJau
T2PyrlFQB9m5gfBUqhqbIhvmpBX4EtwKXOs3IDc8xKhy4YuhBhwKpySJ3BDzZ1D0
5vmilv19R2EEsvwlOxQPpp+73u5hcTDluxj5ddNww+xe9MQp4RGHMqnTjFKPHPAA
GeG6AhQW4PfREUZvV6WV/mrIbVTkEhINzETPP8aJRuPjwqRvmvEUb0gE97iG8hqo
5pcp1fHyc7LshQoZ81PwgMYM80i5V53dCfC/6UGflKWj34dwfRh+KvLWCztOew10
+ypcxT/lditoomPkrFP0cC9r0C3UyPNU6R+Sb2gp4WKWmI/N8z0Vr2JjwjuoiHw1
nLF1zz7VZhSpGeMOxe07gdNBhiXY0c9uUSuTE0TmeSqP+1t3+i2f+vA+V8qmuMI/
1qObRazOcoGx3O4iw5p3q+fMrYoMGcXWzYiMWi6jtCZ5LlEsopuSmQPISUMJshMO
TJxHpoKVg13U9vVHmasPpBXAXXJrNO9SGAPDYPOBZbHNaw9+SzTDrgT2XMpc0/fY
0FLwKP1iBjboUwR46FnR2Pnx6HmVADnNt0cFzezQVUhn4IGlvWRoLkpsL3Ynm11P
ohaL+j126Nht01Jm1HrM4fUPIslw52WyMqBR/PM3QhG/uyHa1Ld6K53gIsid30uq
b8KYM3aBKxnUhGQ21YuVjg0v8noWnkaYY4iQj5VURRD9+cBrp0N7mCClY3R3T/cN
7D/ShzXBnVCX2J1eXT8p6v6He3ue9EIWtRwvyd6b8BswoMPOlRCbWaQ=
-----END ENCRYPTED PRIVATE KEY-----
PEM

# Store passphrase in a temp file (avoid exposing it in process args)
PASS_FILE="$TMPROOT/pw.txt"
stty -echo
printf "Enter passphrase for the encrypted private key: "
IFS= read -r PASS
stty echo
printf "\n"
printf "%s" "$PASS" >"$PASS_FILE"
chmod 600 "$PASS_FILE"
unset PASS

# ---------- pick CSB ----------
CSB_PATH="$CSB_ARG"
if [[ -z "$CSB_PATH" ]]; then
  CSB_PATH="$(choose_file "Pick the encrypted bundle (*.csb)...")"
fi
CSB_PATH="$(abspath "$CSB_PATH")"
[[ -f "$CSB_PATH" ]] || { err "CSB not found: $CSB_PATH"; exit 1; }

CSB_DIR="$(dirname "$CSB_PATH")"
CSB_BASE="$(basename "$CSB_PATH")"
CSB_STEM="${CSB_BASE%.csb}"

ok "CSB bundle: $CSB_PATH"
info "Decrypt destination (same folder): $CSB_DIR"

# ---------- parse CSB ----------
FILE_SIZE="$(stat -f%z "$CSB_PATH")"

MAGIC="$(dd if="$CSB_PATH" bs=1 count=4 2>/dev/null)"
if [[ "$MAGIC" != "CSB1" ]]; then
  err "Bad magic '$MAGIC' (expected CSB1)"
  exit 1
fi

VER_HEX="$(dd if="$CSB_PATH" bs=1 skip=4 count=1 2>/dev/null | xxd -p)"
FLAGS_HEX="$(dd if="$CSB_PATH" bs=1 skip=5 count=1 2>/dev/null | xxd -p)"
WLEN_HEX="$(dd if="$CSB_PATH" bs=1 skip=6 count=2 2>/dev/null | xxd -p)"

VER=$((16#$VER_HEX))
FLAGS=$((16#$FLAGS_HEX))
WLEN=$((16#$WLEN_HEX))

if [[ "$VER" -ne 1 ]]; then
  err "Unsupported CSB version: $VER"
  exit 1
fi

HDR_LEN=$((8 + WLEN))
if (( FILE_SIZE < HDR_LEN + 32 )); then
  err "Truncated CSB (file too small)."
  exit 1
fi

CIPHER_LEN=$((FILE_SIZE - HDR_LEN - 32))
if (( CIPHER_LEN <= 0 )); then
  err "No ciphertext present in CSB."
  exit 1
fi

info "CSB version=$VER flags=0x$(printf "%02X" "$FLAGS") wrappedLen=$WLEN cipherLen=$CIPHER_LEN"

HEADER_BIN="$TMPROOT/header.bin"
WRAPPED_BIN="$TMPROOT/wrapped.bin"
CIPHER_BIN="$TMPROOT/cipher.bin"
TAG_BIN="$TMPROOT/tag.bin"

dd if="$CSB_PATH" bs=1 count="$HDR_LEN" 2>/dev/null >"$HEADER_BIN"
dd if="$CSB_PATH" bs=1 skip=8 count="$WLEN" 2>/dev/null >"$WRAPPED_BIN"
dd if="$CSB_PATH" bs=1 skip="$HDR_LEN" count="$CIPHER_LEN" 2>/dev/null >"$CIPHER_BIN"
dd if="$CSB_PATH" bs=1 skip=$((FILE_SIZE - 32)) count=32 2>/dev/null >"$TAG_BIN"

TAG_HEX="$(xxd -p "$TAG_BIN" | tr -d '\n' | tr 'A-F' 'a-f')"

# ---------- RSA unwrap helper (fixes padding issues) ----------
UNWRAPPED_BIN="$TMPROOT/unwrapped.bin"
try_rsa_unwrap() {
  local mode="$1" oaep_md="${2:-}"
  rm -f "$UNWRAPPED_BIN"

  if [[ "$mode" == "oaep" && -n "$oaep_md" ]]; then
    if openssl pkeyutl -decrypt \
        -inkey "$KEY_ENC_PEM" -passin "file:$PASS_FILE" \
        -in "$WRAPPED_BIN" -out "$UNWRAPPED_BIN" \
        -pkeyopt rsa_padding_mode:oaep -pkeyopt "rsa_oaep_md:$oaep_md" >/dev/null 2>&1; then
      return 0
    fi
  fi

  if [[ "$mode" == "oaep" && -z "$oaep_md" ]]; then
    if openssl pkeyutl -decrypt \
        -inkey "$KEY_ENC_PEM" -passin "file:$PASS_FILE" \
        -in "$WRAPPED_BIN" -out "$UNWRAPPED_BIN" \
        -pkeyopt rsa_padding_mode:oaep >/dev/null 2>&1; then
      return 0
    fi
    # legacy fallback (some builds)
    if openssl rsautl -decrypt -oaep \
        -inkey "$KEY_ENC_PEM" -passin "file:$PASS_FILE" \
        -in "$WRAPPED_BIN" -out "$UNWRAPPED_BIN" >/dev/null 2>&1; then
      return 0
    fi
  fi

  if [[ "$mode" == "pkcs1" ]]; then
    if openssl pkeyutl -decrypt \
        -inkey "$KEY_ENC_PEM" -passin "file:$PASS_FILE" \
        -in "$WRAPPED_BIN" -out "$UNWRAPPED_BIN" \
        -pkeyopt rsa_padding_mode:pkcs1 >/dev/null 2>&1; then
      return 0
    fi
    if openssl rsautl -decrypt -pkcs \
        -inkey "$KEY_ENC_PEM" -passin "file:$PASS_FILE" \
        -in "$WRAPPED_BIN" -out "$UNWRAPPED_BIN" >/dev/null 2>&1; then
      return 0
    fi
  fi

  return 1
}

info "Unwrapping AES/HMAC/IV secret with RSA..."
if try_rsa_unwrap "oaep" "sha256"; then
  ok "RSA unwrap succeeded (OAEP-SHA256)."
elif try_rsa_unwrap "oaep" ""; then
  ok "RSA unwrap succeeded (OAEP-SHA1/default)."
elif try_rsa_unwrap "pkcs1"; then
  ok "RSA unwrap succeeded (PKCS#1 v1.5)."
else
  err "Unable to unwrap secret with OAEP-SHA256, OAEP-SHA1, or PKCS#1."
  exit 1
fi

UNWRAP_SIZE="$(stat -f%z "$UNWRAPPED_BIN")"
if (( UNWRAP_SIZE < 80 )); then
  err "Unwrapped secret too short ($UNWRAP_SIZE). Expected 80 bytes."
  exit 1
fi

AES_KEY_BIN="$TMPROOT/aes.key"
MAC_KEY_BIN="$TMPROOT/mac.key"
AES_IV_BIN="$TMPROOT/aes.iv"

dd if="$UNWRAPPED_BIN" of="$AES_KEY_BIN" bs=1 count=32 status=none
dd if="$UNWRAPPED_BIN" of="$MAC_KEY_BIN" bs=1 skip=32 count=32 status=none
dd if="$UNWRAPPED_BIN" of="$AES_IV_BIN"  bs=1 skip=64 count=16 status=none

aeshex="$(xxd -p "$AES_KEY_BIN" | tr -d '\n')"
mackeyhex="$(xxd -p "$MAC_KEY_BIN" | tr -d '\n')"
ivhex="$(xxd -p "$AES_IV_BIN"  | tr -d '\n')"

# ---------- HMAC verify ----------
info "Verifying HMAC-SHA256..."
CALC_TAG_HEX="$(
  cat "$HEADER_BIN" "$CIPHER_BIN" \
    | openssl dgst -sha256 -mac HMAC -macopt "hexkey:$mackeyhex" -binary \
    | xxd -p | tr -d '\n' | tr 'A-F' 'a-f'
)"

if [[ "$CALC_TAG_HEX" != "$TAG_HEX" ]]; then
  err "HMAC authentication failed. Wrong passphrase/private key OR corrupted CSB."
  exit 1
fi
ok "HMAC verified."

# ---------- AES decrypt ciphertext -> ZIP in same folder ----------
OUT_ZIP="$CSB_DIR/${CSB_STEM}.zip"
info "Decrypting AES-256-CBC -> $OUT_ZIP"
if ! openssl enc -aes-256-cbc -d -K "$aeshex" -iv "$ivhex" -in "$CIPHER_BIN" -out "$OUT_ZIP" 2>/dev/null; then
  if ! openssl aes-256-cbc -d -K "$aeshex" -iv "$ivhex" -in "$CIPHER_BIN" -out "$OUT_ZIP" 2>/dev/null; then
    err "AES decrypt failed."
    exit 1
  fi
fi
ok "Decrypted ZIP -> $OUT_ZIP"

# ---------- extract ZIP next to it ----------
EXTRACT_DIR="$CSB_DIR/${CSB_STEM}"
if [[ -d "$EXTRACT_DIR" ]]; then
  EXTRACT_DIR="${EXTRACT_DIR}_$(date +%Y%m%d_%H%M%S)"
fi
mkdir -p "$EXTRACT_DIR"

if ditto -x -k "$OUT_ZIP" "$EXTRACT_DIR" 2>/dev/null; then
  :
elif command -v unzip >/dev/null 2>&1 && unzip -o -qq "$OUT_ZIP" -d "$EXTRACT_DIR"; then
  :
else
  err "Failed to extract ZIP (need 'ditto' or 'unzip')."
  exit 1
fi

ok "Extracted -> $EXTRACT_DIR"
open "$EXTRACT_DIR" >/dev/null 2>&1 || true
ok "Done."