<# =====================================================================
  CS-secure-log-browser.ps1  (v2.7)
  ConnectSecure – Secure Bundle Browser / Downloader (Azure RBAC ONLY)

  HARD-CODED DEFAULTS (per request):
    -AzureStorageAccount csvault01
    -AzureContainer      primary-vault
    -AzureTenantId       41d959ca-652d-4b57-a6b9-6fb6fb939467
    -ForceInstallModules (enabled by default)

  FEATURES
    - Azure Entra ID interactive login (RBAC) using Az.Accounts + Az.Storage
    - Lists blobs and shows a clean menu:
        Company | Ticket | Sender | MB | Upload Stamp (EST)
      (parsed from filename)
    - Accurate SizeMB + LastModified (fetches attributes when needed)
    - Upload Stamp is converted to Eastern Time and labeled "EST"
      (Azure timestamps are typically UTC; this fixes 00:22 -> 19:22, etc.)
    - Download selected blob to C:\CS-Toolbox-TEMP\Downloads
    - Optional CSB decrypt after download (same decrypt logic retained)
    - Passphrase cache (DPAPI) w/ timeout in minutes

  NOTE ABOUT LOGIN:
    Modern Azure auth is browser-based and may require MFA / device login depending
    on tenant conditional access. This script attempts normal interactive login first,
    then falls back to device authentication if required.

  EXIT CODES:
    0 = success / normal exit
    2 = error
===================================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [int]$MaxResults = 50,
    [string]$DownloadRoot = "C:\CS-Toolbox-TEMP\Downloads",

    # RBAC (DEFAULTS ARE HARD CODED)
    [string]$AzureStorageAccount = "csvault01",
    [string]$AzureContainer      = "primary-vault",
    [string]$AzureTenantId       = "41d959ca-652d-4b57-a6b9-6fb6fb939467",

    # Enabled by default (per request)
    [switch]$ForceInstallModules,

    # Relaunch as admin if requested
    [switch]$Elevate,

    # Export-only standard (cookbook)
    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# Switch defaults: make -ForceInstallModules ON unless explicitly passed (not possible to pass false for a switch)
if (-not $PSBoundParameters.ContainsKey('ForceInstallModules')) { $ForceInstallModules = $true }

# ---------------- Paths ----------------
$Global:CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$Global:AuditLogPath      = Join-Path $Global:CollectedInfoRoot 'CS-secure-log-browser-audit.log'

# ---------------- Passphrase cache config ----------------
$Global:CS_PassphraseCacheMinutes = 15

# ---------------- Eastern Time zone (Windows) ----------------
function Get-EasternTimeZoneInfo {
    try {
        return [System.TimeZoneInfo]::FindSystemTimeZoneById('Eastern Standard Time')
    } catch {
        # Fallback if somehow missing
        return [System.TimeZoneInfo]::Local
    }
}
$Global:CS_EasternTzi = Get-EasternTimeZoneInfo

function Convert-ToEastern {
    param([Parameter(Mandatory)][datetime]$UtcOrUnknown)

    $dt = $UtcOrUnknown
    if ($dt.Kind -eq [DateTimeKind]::Unspecified) {
        # Azure often yields "unspecified"; treat as UTC for correct conversion
        $dt = [DateTime]::SpecifyKind($dt, [DateTimeKind]::Utc)
    } elseif ($dt.Kind -eq [DateTimeKind]::Local) {
        # Convert Local -> UTC first, then to ET (avoids double-offset issues)
        $dt = $dt.ToUniversalTime()
    }

    try {
        return [System.TimeZoneInfo]::ConvertTimeFromUtc($dt.ToUniversalTime(), $Global:CS_EasternTzi)
    } catch {
        # Last resort: return as-is
        return $UtcOrUnknown
    }
}

# ---------------- Decrypt key (embedded) ----------------
$Global:CS_EncryptedPrivateKeyPem = @'
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQVqpfmIOsXqQKzn+1
cECzMQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEJrXQAs92MM6jTy6
tRw43LIEggTQ9zl6K9oEJHLdrTWmhxS22okeXW9NGU7jorabqXsPDU52aGao43xS
1Q+tsPpkqR3Fi/ujL7x9NxbUUWhYlmz89UTfrpnn1l4h4+Fy+W+k2Wz8CTbjnN5S
oaPfzH40km+zDXib7HAvyNix5dUkQ05GVR6SBu3ljNrlLY1UKgP9NNVyOjyaCE37
jViKUuYEjXnoconYgjWiqY8zvl3K3SKK7Qf5S3y7fM2KLI2uZLM5JbwixDNLAmEx
il0cMyiu06nhltRPGriMWblsNnTQJrF+Lbuh/qHzNOu23XTqDSxHqSHubiibkLzl
nmFP7VG+iKpE8NCkF1Sp/y3rmJPjzzBYfrQqcnAqsUoikr8YqZL0+geNJ4YR43vi
Ks/xlFkj6exQSAVGWivO2miUwReq1RWcpUDQdYWrsI6A0ZaqONvRN5fHyP+RkxRO
aIugnGmmoPGS2G3aA/WfjsVudkwCAng8SLyCNnM4D/ry2AUetfhYagHSAqbih6Mg
LB3NhbvE4BJ/ixTTnM7HIdbiFY/rP43JpWS7z5PfWoAcvc7fPbtyjKrmsMTvKaut
klLgVFTBjiLcM3jgMW4RUE22RR8lHxp+4WOfMhoVrGUPVP5ptWUxompKE2fc2p1b
L5lpK/oYm/TqL4cdDP+FQzDIFwLb2AUaaRxzcmDLK3aSqMwjTHvT3Qp4LzD+r/w4
I7dCix3TBuQu8L/NzMXRlJ9OjyxDoyuE+6nRcfQGaXIcIgcv05y3RbWlCh4MD3Np
rzjxYwKYrR3dOKLbH1cfOZDrVKPKGr/b1sXukEcX+aiGb3uBkuAC02XAKBXG9VN5
TzT2F4JEZ2ecflRDcB8YEzCc1yoej9xaR821fqtfjE99Bp2yA60wP79Jdv/uWJau
T2PyrlFQB9m5gfBUqhqbIhvmpBX4EtwKXOs3IDc8xKhy4YuhBhwKpySJ3BDzZ1D0
5vmilv19R2EEsvwlOxQPpp+73u5hcTDluxj5ddNww+xe9MQp4RGHMqnTjFKPHPAA
GeG6AhQW4PfREUZvV6WV/mrIbVTkEhINzETPP8aJRuPjwqRvmvEUb0gE97iG8hqo
5pcp1fHyc7LshQoZ81PwgMYM80i5V53dCfC/6UGflKWj34dwfRh+KvLWCztOew10
+ypcxT/lditoomPkrFP0cC9r0C3UyPNU6R+Sb2gp4WKWmI/N8z0Vr2JjwjuoiHw1
nLF1zz7VZhSpGeMOxe07gdNBhiXY0c9uUSuTE0TmeSqP+1t3+i2f+vA+V8qmuMI/
1qObRazOcoGx3O4iw5p3q+fMrYoMGcXWzYiMWi6jtCZ5LlEsopuSmQPISUMJshMO
TJxHpoKVg13U9vVHmasPpBXAXXJrNO9SGAPDYPOBZbHNaw9+SzTDrgT2XMpc0/fY
0FLwKP1iBjboUwR46FnR2Pnx6HmVADnNt0cFzezQVUhn4IGlvWRoLkpsL3Ynm11P
ohaL+j126Nht01Jm1HrM4fUPIslw52WyMqBR/PM3QhG/uyHa1Ld6K53gIsid30uq
b8KYM3aBKxnUhGQ21YuVjg0v8noWnkaYY4iQj5VURRD9+cBrp0N7mCClY3R3T/cN
7D/ShzXBnVCX2J1eXT8p6v6He3ue9EIWtRwvyd6b8BswoMPOlRCbWaQ=
-----END ENCRYPTED PRIVATE KEY-----
'@

# ===================== Output helpers =====================
function Ensure-Folder([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}
function Write-Audit([string]$Message, [string]$Level = 'INFO') {
    try {
        Ensure-Folder $Global:CollectedInfoRoot
        $line = "{0} [{1}] [{2}\{3}] {4}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $env:COMPUTERNAME, [Environment]::UserName, $Message
        Add-Content -Path $Global:AuditLogPath -Value $line -Encoding UTF8
    } catch { }
}
function Write-InfoColor([string]$Message, [ConsoleColor]$Color) { Write-Host $Message -ForegroundColor $Color }

# ===================== Admin / elevation =====================
function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}
function Relaunch-AsAdmin([string[]]$OriginalArgs) {
    $ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $scriptPath = $MyInvocation.MyCommand.Path
    $argLine = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$scriptPath`"") + $OriginalArgs
    Start-Process -FilePath $ps -ArgumentList $argLine -Verb RunAs | Out-Null
}
if ($Elevate -and -not (Test-IsAdmin)) {
    Write-InfoColor "Elevation requested. Relaunching as Administrator..." Yellow
    $orig = @()
    foreach ($k in $PSBoundParameters.Keys) {
        if ($k -eq 'Elevate') { continue }
        $v = $PSBoundParameters[$k]
        if ($v -is [switch] -and $v) { $orig += "-$k"; continue }
        if ($v -isnot [switch]) { $orig += "-$k"; $orig += "`"$v`"" }
    }
    Relaunch-AsAdmin -OriginalArgs $orig
    exit 0
}

# ===================== Safe array helpers =====================
function Force-Array($x) {
    $list = New-Object System.Collections.ArrayList
    if ($null -eq $x) { return $list.ToArray() }
    if ($x -is [string]) { [void]$list.Add($x); return $list.ToArray() }
    if ($x -is [System.Collections.IEnumerable]) { foreach ($i in $x) { [void]$list.Add($i) }; return $list.ToArray() }
    [void]$list.Add($x)
    return $list.ToArray()
}
function Count-Items($x) {
    if ($null -eq $x) { return 0 }
    if ($x -is [string]) { return 1 }
    if ($x -is [System.Collections.IEnumerable]) { $c = 0; foreach ($i in $x) { $c++ }; return $c }
    return 1
}

# ===================== Interactive user profile (works when elevated) =====================
function Get-InteractiveUserProfilePath {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $u = [string]$cs.UserName
        if ([string]::IsNullOrWhiteSpace($u)) { return $null }
        $name = ($u -split '\\')[-1]
        $candidate = Join-Path "C:\Users" $name
        if (Test-Path -LiteralPath $candidate -PathType Container) { return $candidate }
    } catch { }
    return $null
}
function Get-UserCollectedInfoRoot {
    $prof = Get-InteractiveUserProfilePath
    if (-not $prof) { return $null }
    return Join-Path $prof 'CS-Toolbox-TEMP\Collected-Info'
}
function Get-PreferredCollectedInfoRoot {
    $uRoot = Get-UserCollectedInfoRoot
    if ($uRoot -and (Test-Path -LiteralPath $uRoot -PathType Container)) { return $uRoot }
    return $Global:CollectedInfoRoot
}

# =====================================================================
# PASSHRASE CACHE (DPAPI, per-user)
# =====================================================================
$Global:CS_EncryptPassphrase = $null

function Get-PassphraseCachePath {
    $root = Get-PreferredCollectedInfoRoot
    return Join-Path $root 'secure-passphrase-cache.json'
}
function Try-LoadCachedPassphrase {
    $cachePath = Get-PassphraseCachePath
    if (-not (Test-Path -LiteralPath $cachePath -PathType Leaf)) { return $null }
    try {
        $raw = Get-Content -LiteralPath $cachePath -Raw -Encoding UTF8
        $obj = $raw | ConvertFrom-Json
        if ($null -eq $obj) { return $null }

        $savedAt = [datetime]::Parse([string]$obj.SavedAtUtc).ToUniversalTime()
        $ageMin  = ([datetime]::UtcNow - $savedAt).TotalMinutes
        if ($ageMin -gt [double]$Global:CS_PassphraseCacheMinutes) { return $null }

        $enc = [string]$obj.DpapiProtected
        if ([string]::IsNullOrWhiteSpace($enc)) { return $null }

        $sec = ConvertTo-SecureString $enc
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } catch { return $null }
}
function Save-CachedPassphrase([string]$Pass) {
    if ([string]::IsNullOrWhiteSpace($Pass)) { return }
    try {
        $cachePath = Get-PassphraseCachePath
        $cacheRoot = Split-Path -Path $cachePath -Parent
        Ensure-Folder $cacheRoot

        $sec = ConvertTo-SecureString $Pass -AsPlainText -Force
        $dp  = $sec | ConvertFrom-SecureString  # DPAPI (current user)

        $obj = [pscustomobject]@{
            SavedAtUtc     = ([datetime]::UtcNow.ToString("o"))
            CacheMinutes   = [int]$Global:CS_PassphraseCacheMinutes
            DpapiProtected = $dp
        }

        ($obj | ConvertTo-Json -Depth 4) | Out-File -FilePath $cachePath -Encoding UTF8 -Force
        Write-Audit ("Passphrase cached at {0} (minutes={1})" -f $cachePath, $Global:CS_PassphraseCacheMinutes)
    } catch {
        Write-Audit ("Passphrase cache write failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}
function Prompt-Passphrase {
    $cached = Try-LoadCachedPassphrase
    if (-not [string]::IsNullOrWhiteSpace($cached)) {
        $Global:CS_EncryptPassphrase = $cached
        Write-InfoColor ("Passphrase cache: OK (valid for {0} minutes)" -f $Global:CS_PassphraseCacheMinutes) Green
        Write-Audit "Passphrase cache hit."
        return
    }

    Write-InfoColor "ConnectSecure Secure Bundle Browser (Azure RBAC)" Yellow
    Write-Host ""
    $securePass = Read-Host "Enter ConnectSecure passphrase (input hidden)" -AsSecureString

    if ($securePass) {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
        try { $Global:CS_EncryptPassphrase = [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } else {
        $Global:CS_EncryptPassphrase = ""
    }

    Save-CachedPassphrase -Pass $Global:CS_EncryptPassphrase
}

# =====================================================================
# AZURE RBAC: module install + interactive login
# =====================================================================
function Ensure-Tls12 { try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { } }

function Ensure-NuGetProvider {
    if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
        Install-PackageProvider -Name NuGet -Force -Scope CurrentUser -ErrorAction Stop | Out-Null
    }
}

function Ensure-AzModules {
    param([switch]$ForceInstall)

    Ensure-Tls12

    try { Import-Module PowerShellGet -ErrorAction SilentlyContinue | Out-Null } catch { }

    if ($ForceInstall) {
        Ensure-NuGetProvider

        $psg = Get-PSRepository -Name 'PSGallery' -ErrorAction SilentlyContinue
        if ($psg -and $psg.InstallationPolicy -ne 'Trusted') {
            try { Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted -ErrorAction SilentlyContinue | Out-Null } catch { }
        }
    }

    $need = @('Az.Accounts','Az.Storage')
    foreach ($m in $need) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            if (-not $ForceInstall) { throw "Required module '$m' is missing. Re-run with -ForceInstallModules." }
            Write-InfoColor ("Installing module: {0} (CurrentUser)..." -f $m) Yellow
            Install-Module -Name $m -Scope CurrentUser -Force -AllowClobber -Repository PSGallery -ErrorAction Stop | Out-Null
        }
    }

    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.Storage  -ErrorAction Stop

    if ($ForceInstall) {
        foreach ($m in $need) {
            try {
                Write-InfoColor ("Updating module (if needed): {0} (CurrentUser)..." -f $m) Yellow
                Update-Module -Name $m -Scope CurrentUser -ErrorAction SilentlyContinue | Out-Null
            } catch { }
        }
    }
}

function Ensure-AzLogin {
    param([Parameter(Mandatory)][string]$TenantId)

    try {
        $ctx = Get-AzContext -ErrorAction SilentlyContinue
        if ($ctx -and $ctx.Tenant -and ([string]$ctx.Tenant.Id -eq $TenantId)) { return }
    } catch { }

    Write-InfoColor "Azure login required. A Microsoft sign-in window/browser should appear..." Yellow

    try {
        Connect-AzAccount -Tenant $TenantId -ErrorAction Stop | Out-Null
        return
    } catch {
        Write-Audit ("Connect-AzAccount normal failed: {0}" -f $_.Exception.Message) 'WARN'
    }

    Write-InfoColor "Falling back to DEVICE authentication (tenant policy/session may require this)..." Yellow
    Connect-AzAccount -Tenant $TenantId -UseDeviceAuthentication -ErrorAction Stop | Out-Null
}

function Get-AzureAdStorageContext {
    param([Parameter(Mandatory)][string]$StorageAccountName)

    try {
        return New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount -ErrorAction Stop
    } catch {
        throw ("Failed to create Azure Storage context via connected account (RBAC). " +
               "Ensure RBAC is assigned (e.g. Storage Blob Data Reader/Contributor) and Az modules are current. " +
               "Underlying: {0}" -f $_.Exception.Message)
    }
}

# =====================================================================
# Filename parsing: Company / Ticket / Sender
# =====================================================================
function Parse-NameParts {
    param([Parameter(Mandatory)][string]$BlobName)

    $file = Split-Path $BlobName -Leaf
    $base = [IO.Path]::GetFileNameWithoutExtension($file)

    # 1) Ticket marker form: "...t-<ticket>...."
    $ticket = ""
    $m = [regex]::Match($base, 't-([^\.]+)')  # user rule: text after "t-" and before the "."
    if ($m.Success) { $ticket = $m.Groups[1].Value }

    # 2) Common pattern: "..._<company>-<ticket>-<sender>"
    $company = ""
    $sender  = ""

    $tail = $base
    $u = $base.LastIndexOf('_')
    if ($u -ge 0 -and $u -lt ($base.Length-1)) { $tail = $base.Substring($u+1) }

    $parts = $tail -split '-'
    if ($parts.Count -ge 1) { $company = $parts[0] }
    if ($parts.Count -ge 2 -and [string]::IsNullOrWhiteSpace($ticket)) { $ticket = $parts[1] }
    if ($parts.Count -ge 3) { $sender = (($parts[2..($parts.Count-1)]) -join '-') }

    $company = ($company + "").Trim()
    $ticket  = ($ticket  + "").Trim()
    $sender  = ($sender  + "").Trim()

    return [pscustomobject]@{ Company=$company; Ticket=$ticket; Sender=$sender; File=$file }
}

# =====================================================================
# Azure list + download (RBAC)
# =====================================================================
function Get-BlobAccurateProps {
    param([Parameter(Mandatory)]$Blob)

    $lm = $null
    $len = 0

    try { if ($Blob.ICloudBlob -and $Blob.ICloudBlob.Properties) { $len = [int64]$Blob.ICloudBlob.Properties.Length } } catch { }
    try { if ($Blob.ICloudBlob -and $Blob.ICloudBlob.Properties -and $Blob.ICloudBlob.Properties.LastModified) { $lm = $Blob.ICloudBlob.Properties.LastModified.UtcDateTime } } catch { }

    if (($len -le 0) -or ($null -eq $lm) -or ($lm -is [datetime] -and $lm.Year -lt 2000)) {
        try {
            if ($Blob.ICloudBlob) {
                $Blob.ICloudBlob.FetchAttributes()
                try { $len = [int64]$Blob.ICloudBlob.Properties.Length } catch { }
                try { $lm = $Blob.ICloudBlob.Properties.LastModified.UtcDateTime } catch { }
            }
        } catch { }
    }

    if ($null -eq $lm) {
        try { $lm = [datetime]$Blob.LastModified } catch { $lm = Get-Date 0 }
    }
    if ($len -le 0) {
        try { $len = [int64]$Blob.Length } catch { $len = 0 }
    }

    return [pscustomobject]@{ Length=$len; LastModified=$lm }
}

function Try-ListAzureRBAC {
    param(
        [Parameter(Mandatory)][string]$StorageAccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [int]$MaxResults = 50
    )

    $ctx = Get-AzureAdStorageContext -StorageAccountName $StorageAccountName
    $blobs = @(Get-AzStorageBlob -Container $ContainerName -Context $ctx -ErrorAction Stop)

    $results = @()
    foreach ($b in $blobs) {
        $name = [string]$b.Name
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        $p = Get-BlobAccurateProps -Blob $b
        $len = [int64]$p.Length
        $lm  = [datetime]$p.LastModified

        $parsed = Parse-NameParts -BlobName $name

        # Convert Azure stamp (usually UTC) to Eastern and label as EST in UI
        $uploadEt = Convert-ToEastern -UtcOrUnknown $lm

        $results += [pscustomobject]@{
            Name          = $name
            Company       = $parsed.Company
            Ticket        = $parsed.Ticket
            Sender        = $parsed.Sender
            SizeBytes     = $len
            SizeMB        = [math]::Round($len / 1MB, 1)
            LastModified  = $lm
            UploadStampET = $uploadEt
        }
    }

    Force-Array ($results | Sort-Object UploadStampET -Descending | Select-Object -First $MaxResults)
}

function Download-AzureBlobRBAC {
    param(
        [Parameter(Mandatory)][string]$StorageAccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [Parameter(Mandatory)][string]$BlobName,
        [Parameter(Mandatory)][string]$DownloadRoot
    )

    Ensure-Folder $DownloadRoot
    $ctx = Get-AzureAdStorageContext -StorageAccountName $StorageAccountName

    $safeName  = (Split-Path $BlobName -Leaf) -replace '[^\w\.\-]','_'
    $localPath = Join-Path $DownloadRoot $safeName

    Write-InfoColor ("Downloading to: {0}" -f $localPath) Cyan
    Get-AzStorageBlobContent -Container $ContainerName -Blob $BlobName -Context $ctx -Destination $localPath -Force -ErrorAction Stop | Out-Null
    Write-InfoColor "Download complete." Green

    return $localPath
}

# =====================================================================
# CSB DECRYPT (retained)
# =====================================================================
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+." }
  }
}
function Join-Bytes([byte[]]$a,[byte[]]$b){
  $out = New-Object byte[] ($a.Length + $b.Length)
  [Array]::Copy($a,0,$out,0,$a.Length)
  [Array]::Copy($b,0,$out,$a.Length,$b.Length)
  return $out
}
function BytesEqual([byte[]]$a,[byte[]]$b){
  if ($a.Length -ne $b.Length) { return $false }
  $diff = 0
  for($i=0;$i -lt $a.Length;$i++){ $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

function ASN-ExpectTag([byte[]]$buf, [int]$idx, [byte]$tag) { if ($idx -ge $buf.Length) { throw "ASN.1 read past end" }; if ($buf[$idx] -ne $tag) { throw "ASN.1 tag mismatch" }; return ($idx+1) }
function ASN-ReadLen([byte[]]$buf, [int]$idx) { if ($idx -ge $buf.Length) { throw "ASN.1 length read past end" }; $b=[int]$buf[$idx]; $idx++; if($b -lt 0x80){ return @{Len=$b;Idx=$idx} }; $n=$b-0x80; if($n -lt 1 -or $n -gt 4){ throw "Unsupported ASN.1 length" }; $val=0; for($k=0;$k -lt $n;$k++){ $val=(($val -shl 8) -bor [int]$buf[$idx]); $idx++ }; return @{Len=$val;Idx=$idx} }
function ASN-ReadSeq([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x30; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 SEQUENCE overrun" }; @{Start=$idx;End=($idx+$len);Idx=$idx} }
function ASN-ReadInt([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x02; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 INTEGER overrun" }; $val=$buf[$idx..($idx+$len-1)]; $idx+=$len; if($val.Length -gt 1 -and $val[0]-eq 0x00){ $val=$val[1..($val.Length-1)] }; @{Val=([byte[]]$val);Idx=$idx} }
function ASN-ReadOctets([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x04; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OCTET STRING overrun" }; @{Val=([byte[]]$buf[$idx..($idx+$len-1)]);Idx=($idx+$len)} }
function ASN-ReadOid([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x06; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OID overrun" }; $data=$buf[$idx..($idx+$len-1)]; $idx+=$len; $first=[int]$data[0]; $a=[int]([math]::Floor($first/40)); $b=$first%40; $oidParts=@($a,$b); $val=0; for($i=1;$i -lt $data.Length;$i++){ $val=($val -shl 7) -bor ($data[$i] -band 0x7F); if(($data[$i] -band 0x80)-eq 0){ $oidParts+=$val; $val=0 } }; @{Oid=($oidParts -join '.');Idx=$idx} }
function IntFromBytes([byte[]]$b){ $v=0; foreach($x in $b){ $v=(($v -shl 8) -bor $x) }; $v }
function PemToBytes([string]$pem, [string]$header, [string]$footer){ $i1=$pem.IndexOf($header); $i2=$pem.IndexOf($footer); if($i1 -lt 0 -or $i2 -lt 0){ throw "PEM missing header/footer" }; $b64=$pem.Substring($i1+$header.Length,$i2-($i1+$header.Length)) -replace '\s',''; [Convert]::FromBase64String($b64) }

function PBKDF2-Derive([string]$password, [byte[]]$salt, [int]$iters, [int]$keyLen, [string]$prf){
  if ($prf -eq 'SHA1') {
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters)
    try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
  }
  if ($prf -eq 'SHA256') {
    try {
      $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
      try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
    } catch {
      $pwd = [Text.Encoding]::UTF8.GetBytes($password)
      $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$pwd)
      try {
        $hLen = 32
        $blocks = [int][math]::Ceiling($keyLen / $hLen)
        $dk = New-Object byte[] ($blocks * $hLen)
        for ($i=1; $i -le $blocks; $i++){
          $intBlock = [byte[]]@(
            ($i -shr 24) -band 0xFF,
            ($i -shr 16) -band 0xFF,
            ($i -shr 8)  -band 0xFF,
            $i -band 0xFF
          )
          $u = $hmac.ComputeHash( (Join-Bytes $salt $intBlock) )
          $t = [byte[]]$u.Clone()
          for ($j=2; $j -le $iters; $j++){
            $u = $hmac.ComputeHash($u)
            for ($kidx=0; $kidx -lt $hLen; $kidx++){ $t[$kidx] = $t[$kidx] -bxor $u[$kidx] }
          }
          [Array]::Copy($t, 0, $dk, ($i-1)*$hLen, $hLen)
        }
        $out = New-Object byte[] $keyLen
        [Array]::Copy($dk, 0, $out, 0, $keyLen)
        return $out
      } finally { $hmac.Dispose() }
    }
  }
  throw "Unsupported PBKDF2 PRF: $prf"
}

function Decrypt-Pkcs8EncryptedPrivateKey([string]$pem, [string]$password){
  $der = PemToBytes $pem '-----BEGIN ENCRYPTED PRIVATE KEY-----' '-----END ENCRYPTED PRIVATE KEY-----'
  $top = ASN-ReadSeq $der 0
  $idx = $top.Idx
  $alg = ASN-ReadSeq $der $idx
  $idx = $alg.End
  $algOid = ASN-ReadOid $der $alg.Idx
  if ($algOid.Oid -ne '1.2.840.113549.1.5.13') { throw "Unsupported encryption algorithm OID (expected PBES2)" }
  $pbes2 = ASN-ReadSeq $der $algOid.Idx
  $kdfAlg = ASN-ReadSeq $der $pbes2.Idx
  $encAlgPos = $kdfAlg.End
  $kdfOid = ASN-ReadOid $der $kdfAlg.Idx
  if ($kdfOid.Oid -ne '1.2.840.113549.1.5.12') { throw "Unsupported KDF OID (expected PBKDF2)" }
  $pbkdf2Seq = ASN-ReadSeq $der $kdfOid.Idx
  $saltOct   = ASN-ReadOctets $der $pbkdf2Seq.Idx
  $iterInt   = ASN-ReadInt    $der $saltOct.Idx
  $scanIdx   = $iterInt.Idx
  $klenMaybe = $null
  $prfOid    = '1.2.840.113549.2.7'
  if ($scanIdx -lt $pbkdf2Seq.End) {
    if ($der[$scanIdx] -eq 0x02) { $klenMaybe = ASN-ReadInt $der $scanIdx; $scanIdx = $klenMaybe.Idx }
    if ($scanIdx -lt $pbkdf2Seq.End -and $der[$scanIdx] -eq 0x30) {
      $prfSeq = ASN-ReadSeq $der $scanIdx
      $prfRead = ASN-ReadOid $der $prfSeq.Idx
      $prfOid = $prfRead.Oid
    }
  }
  $encAlg = ASN-ReadSeq $der $encAlgPos
  $encOid = ASN-ReadOid $der $encAlg.Idx
  $ivOct  = ASN-ReadOctets $der $encOid.Idx
  $encOctet = ASN-ReadOctets $der $idx
  $cipherPrivKey = $encOctet.Val
  $prf = if ($prfOid -eq '1.2.840.113549.2.7') { 'SHA1' } elseif ($prfOid -eq '1.2.840.113549.2.9') { 'SHA256' } else { throw "Unsupported PRF OID: $prfOid" }
  $aesBits = switch ($encOid.Oid) {
    '2.16.840.1.101.3.4.1.42' { 256 }
    '2.16.840.1.101.3.4.1.22' { 192 }
    '2.16.840.1.101.3.4.1.2'  { 128 }
    default { throw "Unsupported encryption OID (expected AES-CBC)" }
  }
  $keyLen = if ($klenMaybe) { IntFromBytes $klenMaybe.Val } else { $aesBits / 8 }
  $iters  = [int](IntFromBytes $iterInt.Val)
  if ($iters -le 0) { throw "Bad PBKDF2 iteration count" }
  $key = PBKDF2-Derive $password $saltOct.Val $iters $keyLen $prf
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = $aesBits
    $aes.BlockSize = 128
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $key
    $aes.IV  = $ivOct.Val
    $ms = New-Object IO.MemoryStream
    try {
      $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try { $cs.Write($cipherPrivKey,0,$cipherPrivKey.Length); $cs.FlushFinalBlock() } finally { $cs.Dispose() }
      $pkcs8 = $ms.ToArray()
    } finally { $ms.Dispose() }
  } finally { $aes.Dispose() }
  $pki = ASN-ReadSeq $pkcs8 0
  $i2 = $pki.Idx
  $ver  = ASN-ReadInt $pkcs8 $i2; $i2 = $ver.Idx
  $alg2 = ASN-ReadSeq $pkcs8 $i2
  $oid2 = ASN-ReadOid $pkcs8 $alg2.Idx
  if ($oid2.Oid -ne '1.2.840.113549.1.1.1') { throw "PrivateKey algorithm not RSA" }
  $i2 = $alg2.End
  $ok = ASN-ReadOctets $pkcs8 $i2
  $rk = $ok.Val
  $rseq = ASN-ReadSeq $rk 0; $ri = $rseq.Idx
  $v    = ASN-ReadInt $rk $ri; $ri = $v.Idx
  $n    = ASN-ReadInt $rk $ri; $ri = $n.Idx
  $e    = ASN-ReadInt $rk $ri; $ri = $e.Idx
  $d    = ASN-ReadInt $rk $ri; $ri = $d.Idx
  $p    = ASN-ReadInt $rk $ri; $ri = $p.Idx
  $q    = ASN-ReadInt $rk $ri; $ri = $q.Idx
  $dp   = ASN-ReadInt $rk $ri; $ri = $dp.Idx
  $dq   = ASN-ReadInt $rk $ri; $ri = $dq.Idx
  $iq   = ASN-ReadInt $rk $ri; $ri = $iq.Idx
  $rp = New-Object System.Security.Cryptography.RSAParameters
  $rp.Modulus  = [byte[]]$n.Val
  $rp.Exponent = [byte[]]$e.Val
  $rp.D        = [byte[]]$d.Val
  $rp.P        = [byte[]]$p.Val
  $rp.Q        = [byte[]]$q.Val
  $rp.DP       = [byte[]]$dp.Val
  $rp.DQ       = [byte[]]$dq.Val
  $rp.InverseQ = [byte[]]$iq.Val
  try {
    $rsa = New-Object System.Security.Cryptography.RSACng
    $rsa.ImportParameters($rp)
    return $rsa
  } catch {
    $fallback = [System.Security.Cryptography.RSA]::Create()
    $fallback.ImportParameters($rp)
    return $fallback
  }
}

function Read-CSB([string]$path){
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -lt 4+1+1+2+32) { throw "File too small to be a CSB bundle." }
  $magic = [Text.Encoding]::ASCII.GetString($bytes,0,4)
  if ($magic -ne 'CSB1') { throw "Bad magic '$magic' (expected CSB1)" }
  $ver   = $bytes[4]
  if ($ver -ne 1) { throw "Unsupported CSB version $ver" }
  $flags = $bytes[5]
  $wlen  = (([int]$bytes[6] -shl 8) -bor ([int]$bytes[7]))
  $hdrLenNoTag = 8 + $wlen
  if ($bytes.Length -lt $hdrLenNoTag + 32) { throw "Truncated CSB header." }
  $wrapped = New-Object byte[] $wlen
  [Array]::Copy($bytes,8,$wrapped,0,$wlen)
  $tag = New-Object byte[] 32
  [Array]::Copy($bytes, $bytes.Length-32, $tag, 0, 32)
  $cipherLen = $bytes.Length - $hdrLenNoTag - 32
  if ($cipherLen -le 0) { throw "No ciphertext present in CSB." }
  $cipher = New-Object byte[] $cipherLen
  [Array]::Copy($bytes, $hdrLenNoTag, $cipher, 0, $cipherLen)
  $headerNoTag = New-Object byte[] $hdrLenNoTag
  [Array]::Copy($bytes, 0, $headerNoTag, 0, $hdrLenNoTag)
  return [pscustomobject]@{
    Version      = $ver
    Flags        = $flags
    Wrapped      = $wrapped
    Ciphertext   = $cipher
    Tag          = $tag
    HeaderNoTag  = $headerNoTag
  }
}

function Unwrap-Secret {
  param(
    [Parameter(Mandatory)][byte[]]$Wrapped,
    [Parameter(Mandatory)][int]$Flags,
    [Parameter(Mandatory)][System.Security.Cryptography.RSA]$Rsa
  )
  $isCsp = ($Rsa -is [System.Security.Cryptography.RSACryptoServiceProvider])
  $order = @()
  if (($Flags -band 0x02) -ne 0) { $order += 'OaepSHA256' }
  if (($Flags -band 0x04) -ne 0) { $order += 'OaepSHA1' }
  if ($order.Count -eq 0) { $order = @('OaepSHA256','OaepSHA1') }
  $order += 'Pkcs1'
  foreach($pad in $order){
    try {
      switch ($pad) {
        'OaepSHA256' {
          if ($isCsp) { throw "RSACryptoServiceProvider does not support OAEP-SHA256 in .NET Framework; skipping." }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        }
        'OaepSHA1' {
          if ($isCsp) { return ([System.Security.Cryptography.RSACryptoServiceProvider]$Rsa).Decrypt($Wrapped, $true) }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
        }
        'Pkcs1' {
          $priv = $Rsa.ExportParameters($true)
          $keySizeBits = $priv.Modulus.Length * 8
          $cspParams = New-Object System.Security.Cryptography.CspParameters
          $cspParams.ProviderType = 24
          $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
          try {
            $csp.PersistKeyInCsp = $false
            $csp.ImportParameters($priv)
            return $csp.Decrypt($Wrapped, $false)
          } finally {
            try { $csp.Clear() } catch {}
            try { $csp.Dispose() } catch {}
          }
        }
      }
    } catch {
      Write-Audit ("RSA unwrap failed with {0}: {1}" -f $pad, $_.Exception.Message) 'WARN'
    }
  }
  throw "Unable to unwrap AES/HMAC/IV secret with available paddings."
}

function Decrypt-CSB-InPlace {
  param([string]$CsbPath,[string]$Passphrase)
  if (-not (Test-Path -LiteralPath $CsbPath -PathType Leaf)) { throw "CSB not found: $CsbPath" }
  if ([string]::IsNullOrWhiteSpace($Passphrase)) { throw "Passphrase is blank; cannot decrypt." }
  if ([string]::IsNullOrWhiteSpace($Global:CS_EncryptedPrivateKeyPem)) { throw "Encrypted private key PEM not set in script." }
  $outDir = Split-Path -Path $CsbPath -Parent
  Ensure-ZipAssemblies
  $csb = Read-CSB -path $CsbPath
  $rsaPriv = Decrypt-Pkcs8EncryptedPrivateKey -pem $Global:CS_EncryptedPrivateKeyPem -password $Passphrase
  $secret = Unwrap-Secret -Wrapped $csb.Wrapped -Flags $csb.Flags -Rsa $rsaPriv
  if ($secret.Length -lt 80) { throw "Unwrapped secret too short ($($secret.Length)); expected 80." }
  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0,  $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret, 32, $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret, 64, $iv, 0, 16)
  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  try {
    $combined = New-Object byte[] ($csb.HeaderNoTag.Length + $csb.Ciphertext.Length)
    [Array]::Copy($csb.HeaderNoTag,0,$combined,0,$csb.HeaderNoTag.Length)
    [Array]::Copy($csb.Ciphertext,0,$combined,$csb.HeaderNoTag.Length,$csb.Ciphertext.Length)
    $calcTag = $hmac.ComputeHash($combined)
  } finally { $hmac.Dispose() }
  if (-not (BytesEqual $calcTag $csb.Tag)) { throw "HMAC authentication failed." }
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = 256
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $aesKey
    $aes.IV  = $iv
    $msOut = New-Object IO.MemoryStream
    try {
      $cs2 = New-Object System.Security.Cryptography.CryptoStream($msOut, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try { $cs2.Write($csb.Ciphertext,0,$csb.Ciphertext.Length); $cs2.FlushFinalBlock() } finally { $cs2.Dispose() }
      $zipBytes = $msOut.ToArray()
    } finally { $msOut.Dispose() }
  } finally { $aes.Dispose() }
  $baseName = [IO.Path]::GetFileNameWithoutExtension($CsbPath)
  $outZip = Join-Path $outDir ($baseName + ".zip")
  [IO.File]::WriteAllBytes($outZip, $zipBytes)
  $extractDir = Join-Path $outDir $baseName
  if (Test-Path -LiteralPath $extractDir) {
    try { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction Stop }
    catch { $extractDir = $extractDir + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') }
  }
  [System.IO.Compression.ZipFile]::ExtractToDirectory($outZip, $extractDir)
  [pscustomobject]@{ ZipPath = $outZip; ExtractPath = $extractDir }
}

function Open-Folder([string]$Path) {
    try { if (Test-Path -LiteralPath $Path) { Start-Process explorer.exe -ArgumentList "`"$Path`"" | Out-Null } } catch { }
}

# =====================================================================
# Table UI loop (clean columns) - Upload Stamp adjusted to ET and labeled "EST"
# =====================================================================
function Show-MenuTable {
    param(
        $AllItems,
        [string]$StorageAccount,
        [string]$Container,
        [string]$TenantId,
        [string]$DownloadRoot
    )

    $currentFilter = ""

    while ($true) {
        Clear-Host
        Write-InfoColor ("Storage: {0}   Container: {1}   Tenant: {2}" -f $StorageAccount, $Container, $TenantId) Yellow

        if (-not [string]::IsNullOrWhiteSpace($currentFilter)) { Write-InfoColor ("Active Filter: '{0}'" -f $currentFilter) Cyan }
        else { Write-InfoColor "Active Filter: (none)" DarkGray }

        Write-Host ""
        Write-Host "      Company     Ticket      Sender     MB   Upload Stamp (EST)"

        $all = Force-Array $AllItems
        $displayItems = if (-not [string]::IsNullOrWhiteSpace($currentFilter)) {
            Force-Array ($all | Where-Object {
                ($_.Company -like "*$currentFilter*") -or
                ($_.Ticket  -like "*$currentFilter*") -or
                ($_.Sender  -like "*$currentFilter*") -or
                ($_.Name    -like "*$currentFilter*")
            })
        } else { $all }

        $displayCount = Count-Items $displayItems

        if ($displayCount -eq 0) {
            Write-InfoColor "No items match the current filter." Red
        } else {
            $idx = 1
            foreach ($item in $displayItems) {
                $stamp = $item.UploadStampET
                if ($null -eq $stamp) { $stamp = $item.LastModified }

                $line = "{0,4}  {1,-10}  {2,-10}  {3,-8}  {4,4:N1}  {5:yyyy-MM-dd HH:mm} EST" -f `
                        $idx, $item.Company, $item.Ticket, $item.Sender, $item.SizeMB, $stamp
                Write-Host $line
                $idx++
            }
        }

        Write-Host ""
        Write-Host "Commands:"
        Write-Host "  [Idx] Download    [S] Search    [C] Clear Filter    [R] Refresh    [Q] Quit"
        $input = Read-Host "Selection"

        if ($input -match '^[Qq]$') { return "QUIT" }
        if ($input -match '^[Rr]$') { return "REFRESH" }
        if ($input -match '^[Ss]$') { $currentFilter = Read-Host "Enter search text (company, ticket, sender). Blank = none"; continue }
        if ($input -match '^[Cc]$') { $currentFilter = ""; continue }

        if ($input -match '^\d+$') {
            $num = [int]$input
            if ($num -lt 1 -or $num -gt $displayCount) {
                Write-InfoColor "Selection out of range." Red
                Start-Sleep -Seconds 1
                continue
            }

            $arr = Force-Array $displayItems
            $chosen = $arr[$num - 1]

            $downloaded = Download-AzureBlobRBAC -StorageAccountName $StorageAccount -ContainerName $Container -BlobName $chosen.Name -DownloadRoot $DownloadRoot
            Write-Audit ("Downloaded: {0}" -f $downloaded)

            if ($downloaded -and $downloaded.ToLower().EndsWith(".csb")) {
                Write-Host ""
                $yn = Read-Host "Decrypt this downloaded bundle now? (Y/N)"
                if ($yn -match '^[Yy]$') {
                    try {
                        Write-InfoColor "Decrypting .csb into the same download folder..." Yellow
                        $res = Decrypt-CSB-InPlace -CsbPath $downloaded -Passphrase $Global:CS_EncryptPassphrase
                        Write-InfoColor ("Decrypted ZIP : {0}" -f $res.ZipPath) Green
                        Write-InfoColor ("Extracted to  : {0}" -f $res.ExtractPath) Green
                        Write-Audit ("Decrypted: {0} -> {1}" -f $downloaded, $res.ExtractPath)
                        Open-Folder -Path $res.ExtractPath
                    } catch {
                        Write-InfoColor ("Decryption failed: {0}" -f $_.Exception.Message) Red
                        Write-Audit ("Decryption failed: {0}" -f $_.Exception.Message) 'ERROR'
                    }
                }
            }

            Write-Host ""
            Read-Host "Press Enter to return to the list" | Out-Null
            continue
        }

        Write-InfoColor "Unrecognized input." Red
        Start-Sleep -Seconds 1
    }
}

# =====================================================================
# MAIN
# =====================================================================
try {
    Ensure-Folder $Global:CollectedInfoRoot
    Write-Audit "RUN START CS-secure-log-browser v2.7 (Azure RBAC ONLY, Upload Stamp -> EST)"

    Prompt-Passphrase

    Ensure-AzModules -ForceInstall:$ForceInstallModules
    Ensure-AzLogin -TenantId $AzureTenantId

    while ($true) {
        Write-InfoColor ("Loading recent secure bundles from Azure (RBAC): {0}/{1} ..." -f $AzureStorageAccount, $AzureContainer) Cyan
        $items = Force-Array (Try-ListAzureRBAC -StorageAccountName $AzureStorageAccount -ContainerName $AzureContainer -MaxResults $MaxResults)

        if ($ExportOnly) {
            $outFile = Join-Path $Global:CollectedInfoRoot ("secure-log-browser-list_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            $items | ConvertTo-Json -Depth 8 | Out-File -FilePath $outFile -Encoding UTF8
            Write-InfoColor "ExportOnly: wrote list to:" Green
            Write-Host $outFile
            Write-Audit ("ExportOnly wrote {0}" -f $outFile)
            exit 0
        }

        if ((Count-Items $items) -eq 0) {
            Write-InfoColor "No items found." Yellow
            Write-Audit "No items found."
            exit 0
        }

        $result = Show-MenuTable -AllItems $items -StorageAccount $AzureStorageAccount -Container $AzureContainer -TenantId $AzureTenantId -DownloadRoot $DownloadRoot
        if ($result -eq "REFRESH") { continue }
        break
    }

    Write-Audit "RUN SUCCESS"
    exit 0
}
catch {
    Write-Audit $_.Exception.Message 'ERROR'
    Write-Error ("ERROR: {0}" -f $_.Exception.Message)
    exit 2
}