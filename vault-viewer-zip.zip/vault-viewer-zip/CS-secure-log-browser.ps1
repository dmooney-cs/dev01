<# =====================================================================
  CS-secure-log-browser.ps1  (v3.5)
  ConnectSecure – Secure Bundle Browser / Downloader (Azure RBAC ONLY)

  HARD-CODED DEFAULTS:
    -AzureStorageAccount cssupport1
    -AzureContainer      uploadlogs
    -AzureTenantId       8ecbd342-5d6f-4e6c-9ade-efa82f2b0029
    -ForceInstallModules (enabled by default)

  v3.5 CHANGES
    1) Production defaults updated for cssupport1 / uploadlogs / new tenant
    2) Added [L] FULL local clear + reload
    3) Clears in-memory/session state before hard reload
    4) Cache files are target-specific per account/container
    5) Clears legacy cache files too
    6) Clears self-update state + managed copy folders
    7) Self-update is DISABLED by default for testing
    8) Shows actual running script path
    9) Shows list load source: CACHE or AZURE
   10) Azure storage context is keyed by account + tenant
===================================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [int]$MaxResults = 20,
    [string]$DownloadRoot = "C:\CS-Toolbox-TEMP\Downloads",

    [string]$AzureStorageAccount = "cssupport1",
    [string]$AzureContainer      = "uploadlogs",
    [string]$AzureTenantId       = "8ecbd342-5d6f-4e6c-9ade-efa82f2b0029",

    [switch]$ForceInstallModules,
    [switch]$Elevate,
    [switch]$ExportOnly,

    [switch]$EnableNotifications,
    [switch]$DisableNotifications,

    [switch]$EnableSelfUpdate
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

if ($EnableNotifications -and $DisableNotifications) {
    throw "Use only one of: -EnableNotifications or -DisableNotifications."
}

# =====================================================================
# SELF-UPDATE / MANAGED RELAUNCH
# =====================================================================
$script:VV_UpdateZipUrl        = 'https://github.com/dmooney-cs/dev01/raw/refs/heads/main/vault-viewer-zip.zip'
$script:VV_BaseRoot            = 'C:\CS-Toolbox-TEMP'
$script:VV_DecryptRoot         = Join-Path $script:VV_BaseRoot 'Decrypt'
$script:VV_WorkRoot            = Join-Path $script:VV_DecryptRoot '_work'
$script:VV_AppRoot             = Join-Path $script:VV_DecryptRoot 'VaultViewer-App'
$script:VV_CollectedInfoRoot   = Join-Path $script:VV_BaseRoot 'Collected-Info'
$script:VV_UpdateLog           = Join-Path $script:VV_CollectedInfoRoot 'CS-secure-log-browser-selfupdate.log'
$script:VV_UpdateState         = Join-Path $script:VV_CollectedInfoRoot 'CS-secure-log-browser-selfupdate.json'
$script:VV_CurrentScriptPath   = $PSCommandPath
$script:VV_CurrentScriptName   = if ($PSCommandPath) { Split-Path -Leaf $PSCommandPath } else { 'CS-secure-log-browser.ps1' }

function VV-EnsureDir {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function VV-WriteLog {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','OK')][string]$Level = 'INFO'
    )
    try {
        VV-EnsureDir $script:VV_CollectedInfoRoot
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Add-Content -LiteralPath $script:VV_UpdateLog -Value ("[{0}][{1}] {2}" -f $ts, $Level, $Message) -Encoding UTF8
    } catch { }
}

function VV-NormalizeExtract {
    param([Parameter(Mandatory)][string]$Root)

    $dirs  = @(Get-ChildItem -LiteralPath $Root -Directory -Force -ErrorAction SilentlyContinue)
    $files = @(Get-ChildItem -LiteralPath $Root -File      -Force -ErrorAction SilentlyContinue)

    if ($dirs.Count -eq 1 -and $files.Count -eq 0) {
        $top = $dirs[0].FullName
        Get-ChildItem -LiteralPath $top -Force | Move-Item -Destination $Root -Force
        Remove-Item -LiteralPath $top -Recurse -Force
    }
}

function VV-LoadState {
    if (-not (Test-Path -LiteralPath $script:VV_UpdateState -PathType Leaf)) { return $null }
    try {
        return (Get-Content -LiteralPath $script:VV_UpdateState -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
        VV-WriteLog ("State load failed: {0}" -f $_.Exception.Message) 'WARN'
        return $null
    }
}

function VV-SaveState {
    param([Parameter(Mandatory)]$State)
    try {
        VV-EnsureDir $script:VV_CollectedInfoRoot
        $State | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:VV_UpdateState -Encoding UTF8
    } catch {
        VV-WriteLog ("State save failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

function VV-GetRemoteSignature {
    param([Parameter(Mandatory)][string]$Uri)

    try {
        $r = Invoke-WebRequest -Uri $Uri -Method Head -UseBasicParsing -Headers @{ 'Cache-Control'='no-cache' } -ErrorAction Stop
        $etag = ''
        $lm   = ''
        $len  = ''

        try { $etag = [string]$r.Headers.ETag } catch { }
        try { $lm   = [string]$r.Headers.'Last-Modified' } catch { }
        try { $len  = [string]$r.Headers.'Content-Length' } catch { }

        return [pscustomobject]@{
            ETag          = ($etag + '').Trim()
            LastModified  = ($lm + '').Trim()
            ContentLength = ($len + '').Trim()
        }
    } catch {
        VV-WriteLog ("HEAD failed: {0}" -f $_.Exception.Message) 'WARN'
        return $null
    }
}

function VV-SignaturesMatch {
    param($A,$B)
    if ($null -eq $A -or $null -eq $B) { return $false }

    $aE = [string]$A.ETag
    $bE = [string]$B.ETag
    if (-not [string]::IsNullOrWhiteSpace($aE) -and -not [string]::IsNullOrWhiteSpace($bE)) {
        return ($aE -eq $bE)
    }

    $aLm = [string]$A.LastModified
    $bLm = [string]$B.LastModified
    $aLn = [string]$A.ContentLength
    $bLn = [string]$B.ContentLength

    if (-not [string]::IsNullOrWhiteSpace($aLm) -and -not [string]::IsNullOrWhiteSpace($bLm) -and
        -not [string]::IsNullOrWhiteSpace($aLn) -and -not [string]::IsNullOrWhiteSpace($bLn)) {
        return (($aLm -eq $bLm) -and ($aLn -eq $bLn))
    }

    return $false
}

function VV-DownloadFile {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile
    )

    Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue

    for ($i = 1; $i -le 3; $i++) {
        try {
            VV-WriteLog ("Downloading update zip ({0}/3): {1}" -f $i, $Uri)
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -Headers @{ 'Cache-Control'='no-cache' } -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile -PathType Leaf) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                return $true
            }
        } catch {
            VV-WriteLog ("Download attempt {0} failed: {1}" -f $i, $_.Exception.Message) 'WARN'
            Start-Sleep -Seconds 2
        }
    }

    return $false
}

function VV-GetFileHashSha256 {
    param([Parameter(Mandatory)][string]$Path)
    try {
        return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    } catch {
        VV-WriteLog ("Hash failed for {0}: {1}" -f $Path, $_.Exception.Message) 'WARN'
        return $null
    }
}

function VV-GetRelaunchArgs {
    $argsList = New-Object System.Collections.Generic.List[string]

    if ($PSBoundParameters.ContainsKey('MaxResults')) {
        $argsList.Add('-MaxResults')
        $argsList.Add([string]$MaxResults)
    }
    if ($PSBoundParameters.ContainsKey('DownloadRoot')) {
        $argsList.Add('-DownloadRoot')
        $argsList.Add($DownloadRoot)
    }
    if ($PSBoundParameters.ContainsKey('AzureStorageAccount')) {
        $argsList.Add('-AzureStorageAccount')
        $argsList.Add($AzureStorageAccount)
    }
    if ($PSBoundParameters.ContainsKey('AzureContainer')) {
        $argsList.Add('-AzureContainer')
        $argsList.Add($AzureContainer)
    }
    if ($PSBoundParameters.ContainsKey('AzureTenantId')) {
        $argsList.Add('-AzureTenantId')
        $argsList.Add($AzureTenantId)
    }
    if ($ForceInstallModules)  { $argsList.Add('-ForceInstallModules') }
    if ($Elevate)              { $argsList.Add('-Elevate') }
    if ($ExportOnly)           { $argsList.Add('-ExportOnly') }
    if ($EnableNotifications)  { $argsList.Add('-EnableNotifications') }
    if ($DisableNotifications) { $argsList.Add('-DisableNotifications') }
    if ($EnableSelfUpdate)     { $argsList.Add('-EnableSelfUpdate') }

    return ,@($argsList.ToArray())
}

function VV-StartManagedCopy {
    param([Parameter(Mandatory)][string]$TargetScript)

    $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $argList = New-Object System.Collections.Generic.List[string]
    $argList.Add('-ExecutionPolicy')
    $argList.Add('Bypass')
    $argList.Add('-File')
    $argList.Add($TargetScript)

    foreach ($a in (VV-GetRelaunchArgs)) {
        $argList.Add($a)
    }

    VV-WriteLog ("Relaunching managed copy: {0}" -f $TargetScript) 'OK'
    Start-Process -FilePath $psExe -ArgumentList @($argList.ToArray()) | Out-Null
}

function VV-ResolveManagedTargetFromState {
    param($State)

    if ($null -eq $State) { return $null }

    $target = [string]$State.ManagedScriptPath
    if (-not [string]::IsNullOrWhiteSpace($target) -and (Test-Path -LiteralPath $target -PathType Leaf)) {
        return $target
    }

    $hash = [string]$State.ZipHash
    if ([string]::IsNullOrWhiteSpace($hash)) { return $null }

    $candidateRoot = Join-Path $script:VV_AppRoot $hash
    if (-not (Test-Path -LiteralPath $candidateRoot -PathType Container)) { return $null }

    $candidate = Get-ChildItem -LiteralPath $candidateRoot -Recurse -File -Filter $script:VV_CurrentScriptName -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($candidate) { return $candidate.FullName }

    return $null
}

function VV-InstallZipVersionAndResolveScript {
    param(
        [Parameter(Mandatory)][string]$ZipPath,
        [Parameter(Mandatory)][string]$ZipHash
    )

    VV-EnsureDir $script:VV_AppRoot
    VV-EnsureDir $script:VV_WorkRoot

    $versionRoot = Join-Path $script:VV_AppRoot $ZipHash
    if (-not (Test-Path -LiteralPath $versionRoot -PathType Container)) {
        VV-WriteLog ("Installing new managed version: {0}" -f $ZipHash)
        VV-EnsureDir $versionRoot

        $extractTmp = Join-Path $script:VV_WorkRoot ("vaultviewer_extract_{0}" -f ([guid]::NewGuid().ToString()))
        VV-EnsureDir $extractTmp

        try {
            Expand-Archive -LiteralPath $ZipPath -DestinationPath $extractTmp -Force
            VV-NormalizeExtract -Root $extractTmp
            Copy-Item -LiteralPath (Join-Path $extractTmp '*') -Destination $versionRoot -Recurse -Force
        } finally {
            Remove-Item -LiteralPath $extractTmp -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    $target = Get-ChildItem -LiteralPath $versionRoot -Recurse -File -Filter $script:VV_CurrentScriptName -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $target) {
        throw ("Updated zip does not contain expected script '{0}'." -f $script:VV_CurrentScriptName)
    }

    return $target.FullName
}

function VV-InvokeSelfUpdateCheck {
    try {
        VV-EnsureDir $script:VV_DecryptRoot
        VV-EnsureDir $script:VV_WorkRoot
        VV-EnsureDir $script:VV_AppRoot
        VV-EnsureDir $script:VV_CollectedInfoRoot

        VV-WriteLog ("Self-update check start. Current script: {0}" -f $script:VV_CurrentScriptPath)

        $state = VV-LoadState
        $remoteSig = VV-GetRemoteSignature -Uri $script:VV_UpdateZipUrl

        if ($remoteSig -and $state -and (VV-SignaturesMatch -A $remoteSig -B $state.RemoteSignature)) {
            $managedTarget = VV-ResolveManagedTargetFromState -State $state
            if ($managedTarget -and ([IO.Path]::GetFullPath($managedTarget) -ne [IO.Path]::GetFullPath($script:VV_CurrentScriptPath))) {
                VV-WriteLog "Remote signature unchanged. Redirecting to current managed copy."
                VV-StartManagedCopy -TargetScript $managedTarget
                exit 0
            }

            VV-WriteLog "Remote signature unchanged. Continuing current copy."
            return
        }

        $zipPath = Join-Path $script:VV_WorkRoot ("vaultviewer_{0}.zip" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        if (-not (VV-DownloadFile -Uri $script:VV_UpdateZipUrl -OutFile $zipPath)) {
            VV-WriteLog "Update zip download failed; continuing current copy." 'WARN'

            $managedFallback = VV-ResolveManagedTargetFromState -State $state
            if ($managedFallback -and ([IO.Path]::GetFullPath($managedFallback) -ne [IO.Path]::GetFullPath($script:VV_CurrentScriptPath))) {
                VV-WriteLog "Falling back to previously managed copy."
                VV-StartManagedCopy -TargetScript $managedFallback
                exit 0
            }

            return
        }

        $zipHash = VV-GetFileHashSha256 -Path $zipPath
        if ([string]::IsNullOrWhiteSpace($zipHash)) {
            VV-WriteLog "Zip hash unavailable; continuing current copy." 'WARN'
            return
        }

        $targetScript = VV-InstallZipVersionAndResolveScript -ZipPath $zipPath -ZipHash $zipHash

        $newState = [ordered]@{
            CheckedAtUtc       = (Get-Date).ToUniversalTime().ToString('o')
            UpdateZipUrl       = $script:VV_UpdateZipUrl
            RemoteSignature    = $remoteSig
            ZipHash            = $zipHash
            ManagedScriptPath  = $targetScript
            CurrentScriptName  = $script:VV_CurrentScriptName
        }
        VV-SaveState -State $newState

        if ([IO.Path]::GetFullPath($targetScript) -ne [IO.Path]::GetFullPath($script:VV_CurrentScriptPath)) {
            VV-WriteLog ("Newer or managed copy resolved. Relaunching: {0}" -f $targetScript) 'OK'
            VV-StartManagedCopy -TargetScript $targetScript
            exit 0
        }

        VV-WriteLog "Already running latest managed copy."
    } catch {
        VV-WriteLog ("Self-update check failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

if ($EnableSelfUpdate) {
    VV-InvokeSelfUpdateCheck
}

# =====================================================================
# MAIN SCRIPT
# =====================================================================

if (-not $PSBoundParameters.ContainsKey('ForceInstallModules')) { $ForceInstallModules = $true }

$script:WindowSize = if ($MaxResults -and $MaxResults -gt 0) { $MaxResults } else { 20 }
if ($script:WindowSize -ne 20 -and $script:WindowSize -ne 100) { $script:WindowSize = 20 }

$Global:CollectedInfoRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'
$Global:AuditLogPath      = Join-Path $Global:CollectedInfoRoot 'CS-secure-log-browser-audit.log'
$Global:NotifyStatePath   = Join-Path $Global:CollectedInfoRoot 'CS-secure-log-browser-notify.json'

$Global:CS_PassphraseCacheMinutes = 15
$Global:CS_ListCacheTtlSeconds    = 300
$Global:CS_AutoRefreshMinutes     = 5
$Global:CS_ListCacheEntropy       = 'CS-secure-log-browser-list-cache-v1'

$script:AzureStorageContext           = $null
$script:AzureStorageContextAccount    = $null
$script:AzureStorageContextTenant     = $null
$script:CurrentFilterRaw              = ""
$script:CurrentFilterTerms            = @()
$script:LastRefreshLocal              = $null
$script:NextRefreshLocal              = $null
$script:NotificationsEnabled          = $false
$script:NotifyState                   = $null
$script:LastLoadUsedCache             = $false

function Get-TimeZoneSafe([string]$WindowsId) {
    try { return [System.TimeZoneInfo]::FindSystemTimeZoneById($WindowsId) }
    catch { return [System.TimeZoneInfo]::Local }
}

$Global:CS_EasternTzi = Get-TimeZoneSafe 'Eastern Standard Time'
$Global:CS_IndiaTzi   = Get-TimeZoneSafe 'India Standard Time'

function Convert-ToTimeZone {
    param(
        [Parameter(Mandatory)]$UtcOrUnknown,
        [Parameter(Mandatory)][System.TimeZoneInfo]$Tzi
    )

    if ($UtcOrUnknown -is [DateTimeOffset]) {
        try {
            $utc = $UtcOrUnknown.UtcDateTime
            return [System.TimeZoneInfo]::ConvertTimeFromUtc($utc, $Tzi)
        } catch {
            return $UtcOrUnknown.DateTime
        }
    }

    $dt = [datetime]$UtcOrUnknown

    if ($dt.Kind -eq [DateTimeKind]::Unspecified) {
        $dt = [DateTime]::SpecifyKind($dt, [DateTimeKind]::Utc)
    } elseif ($dt.Kind -eq [DateTimeKind]::Local) {
        $dt = $dt.ToUniversalTime()
    }

    try {
        return [System.TimeZoneInfo]::ConvertTimeFromUtc($dt.ToUniversalTime(), $Tzi)
    } catch {
        return $dt
    }
}

function Get-ETAbbrev {
    param([Parameter(Mandatory)][datetime]$EasternTime)
    try {
        if ($Global:CS_EasternTzi.IsDaylightSavingTime($EasternTime)) { return 'EDT' }
        return 'EST'
    } catch { return 'ET' }
}

function Format-Stamp {
    param(
        [Parameter(Mandatory)][datetime]$LocalTime,
        [Parameter(Mandatory)][string]$TzAbbrev
    )
    return ("{0:yyyy-MM-dd HH:mm} ({0:h:mm tt}) {1}" -f $LocalTime, $TzAbbrev)
}

function Format-UploadStampET {
    param([Parameter(Mandatory)]$UtcOrUnknown)
    $et = Convert-ToTimeZone -UtcOrUnknown $UtcOrUnknown -Tzi $Global:CS_EasternTzi
    $tz = Get-ETAbbrev -EasternTime $et
    return Format-Stamp -LocalTime $et -TzAbbrev $tz
}

function Format-UploadStampIST {
    param([Parameter(Mandatory)]$UtcOrUnknown)
    $ist = Convert-ToTimeZone -UtcOrUnknown $UtcOrUnknown -Tzi $Global:CS_IndiaTzi
    return Format-Stamp -LocalTime $ist -TzAbbrev 'IST'
}

function Format-LocalRefreshStamp {
    param([Parameter(Mandatory)][datetime]$Dt)
    return ("{0:yyyy-MM-dd HH:mm:ss}" -f $Dt)
}

$Global:CS_EncryptedPrivateKeyPem = @'
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQVqpfmIOsXqQKzn+1
cECzMQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEJrXQAs92MM6jTy6
tRw43LIEggTQ9zl6K9oEJHLdrTWmhxS22okeXW9NGU7jorabqXsPDU52aGao43xS
1Q+tsPpkqR3Fi/ujL7x9NxbUUWhYlmz89UTfrpnn1l4h4+Fy+W+k2Wz8CTbjnN5S
oaPfzH40km+zDXib7HAvyNix5dUkQ05GVR6SBu3ljNrlLY1UKgP9NNVyOjyaCE37
jViKUuYEjXnoconYgjWiqY8zvl3K3SKK7Qf5S3y7fM2KLI2uZLM5JbwixDNLAmEx
il0cMyiu06nhltRPGriMWblsNnTQJrF+Lbuh/qHzNOu23XTqDSxHqSHubiibkLzl
nmFP7VG+iKpE8NCkF1Sp/y3rmJPjzzBYfrQqcnAqsUoikr8YqZL0+geNJ4YR43vi
Ks/xlFkj6exQSAVGWivO2miUwReq1RWcpUDQdYWrsI6A0ZaqONvRN5fHyP+RkxRO
aIugnGmmoPGS2G3aA/WfjsVudkwCAng8SLyCNnM4D/ry2AUetfhYagHSAqbih6Mg
LB3NhbvE4BJ/ixTTnM7HIdbiFY/rP43JpWS7z5PfWoAcvc7fPbtyjKrmsMTvKaut
klLgVFTBjiLcM3jgMW4RUE22RR8lHxp+4WOfMhoVrGUPVP5ptWUxompKE2fc2p1b
L5lpK/oYm/TqL4cdDP+FQzDIFwLb2AUaaRxzcmDLK3aSqMwjTHvT3Qp4LzD+r/w4
I7dCix3TBuQu8L/NzMXRlJ9OjyxDoyuE+6nRcfQGaXIcIgcv05y3RbWlCh4MD3Np
rzjxYwKYrR3dOKLbH1cfOZDrVKPKGr/b1sXukEcX+aiGb3uBkuAC02XAKBXG9VN5
TzT2F4JEZ2ecflRDcB8YEzCc1yoej9xaR821fqtfjE99Bp2yA60wP79Jdv/uWJau
T2PyrlFQB9m5gfBUqhqbIhvmpBX4EtwKXOs3IDc8xKhy4YuhBhwKpySJ3BDzZ1D0
5vmilv19R2EEsvwlOxQPpp+73u5hcTDluxj5ddNww+xe9MQp4RGHMqnTjFKPHPAA
GeG6AhQW4PfREUZvV6WV/mrIbVTkEhINzETPP8aJRuPjwqRvmvEUb0gE97iG8hqo
5pcp1fHyc7LshQoZ81PwgMYM80i5V53dCfC/6UGflKWj34dwfRh+KvLWCztOew10
+ypcxT/lditoomPkrFP0cC9r0C3UyPNU6R+Sb2gp4WKWmI/N8z0Vr2JjwjuoiHw1
nLF1zz7VZhSpGeMOxe07gdNBhiXY0c9uUSuTE0TmeSqP+1t3+i2f+vA+V8qmuMI/
1qObRazOcoGx3O4iw5p3q+fMrYoMGcXWzYiMWi6jtCZ5LlEsopuSmQPISUMJshMO
TJxHpoKVg13U9vVHmasPpBXAXXJrNO9SGAPDYPOBZbHNaw9+SzTDrgT2XMpc0/fY
0FLwKP1iBjboUwR46FnR2Pnx6HmVADnNt0cFzezQVUhn4IGlvWRoLkpsL3Ynm11P
ohaL+j126Nht01Jm1HrM4fUPIslw52WyMqBR/PM3QhG/uyHa1Ld6K53gIsid30uq
b8KYM3aBKxnUhGQ21YuVjg0v8noWnkaYY4iQj5VURRD9+cBrp0N7mCClY3R3T/cN
7D/ShzXBnVCX2J1eXT8p6v6He3ue9EIWtRwvyd6b8BswoMPOlRCbWaQ=
-----END ENCRYPTED PRIVATE KEY-----
'@

function Ensure-Folder([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-Audit([string]$Message, [string]$Level = 'INFO') {
    try {
        Ensure-Folder $Global:CollectedInfoRoot
        $line = "{0} [{1}] [{2}\{3}] {4}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $env:COMPUTERNAME, [Environment]::UserName, $Message
        Add-Content -Path $Global:AuditLogPath -Value $line -Encoding UTF8
    } catch { }
}

function Write-InfoColor([string]$Message, [ConsoleColor]$Color) {
    Write-Host $Message -ForegroundColor $Color
}

function Force-Array($x) {
    $list = New-Object System.Collections.ArrayList
    if ($null -eq $x) { return $list.ToArray() }
    if ($x -is [string]) { [void]$list.Add($x); return $list.ToArray() }
    if ($x -is [System.Collections.IEnumerable]) { foreach ($i in $x) { [void]$list.Add($i) }; return $list.ToArray() }
    [void]$list.Add($x)
    return $list.ToArray()
}

function Count-Items($x) {
    if ($null -eq $x) { return 0 }
    if ($x -is [string]) { return 1 }
    if ($x -is [System.Collections.IEnumerable]) { $c = 0; foreach ($i in $x) { $c++ }; return $c }
    return 1
}

function Trunc([string]$s, [int]$max) {
    if ($null -eq $s) { return "" }
    $t = ($s + "")
    if ($max -le 0) { return "" }
    if ($t.Length -le $max) { return $t }
    if ($max -le 3) { return $t.Substring(0, $max) }
    return ($t.Substring(0, $max - 3) + "...")
}

function Set-ConsoleWidthToFitCommands {
    param(
        [Parameter(Mandatory)][string]$CommandsLine,
        [int]$ExtraChars = 5
    )
    try {
        if (-not $Host -or -not $Host.UI -or -not $Host.UI.RawUI) { return }
        $raw = $Host.UI.RawUI
        $desired = $CommandsLine.Length + $ExtraChars
        if ($desired -lt 120) { $desired = 120 }

        $win = $raw.WindowSize
        $buf = $raw.BufferSize

        if ($buf.Width -lt $desired) {
            $raw.BufferSize = New-Object System.Management.Automation.Host.Size($desired, $buf.Height)
        }
        if ($win.Width -lt $desired) {
            $raw.WindowSize = New-Object System.Management.Automation.Host.Size($desired, $win.Height)
        }
    } catch { }
}

# =====================================================================
# NOTIFICATION STATE
# =====================================================================
function Get-DefaultNotifyState {
    return [ordered]@{
        NotificationsEnabled    = $false
        LastSeenTopBlobName     = ''
        LastSeenTopLastModified = ''
        LastNotifiedBlobName    = ''
        LastNotifiedAtUtc       = ''
    }
}

function Load-NotifyState {
    if (-not (Test-Path -LiteralPath $Global:NotifyStatePath -PathType Leaf)) {
        return (Get-DefaultNotifyState)
    }

    try {
        $obj = Get-Content -LiteralPath $Global:NotifyStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -eq $obj) { return (Get-DefaultNotifyState) }

        return [ordered]@{
            NotificationsEnabled    = [bool]$obj.NotificationsEnabled
            LastSeenTopBlobName     = [string]$obj.LastSeenTopBlobName
            LastSeenTopLastModified = [string]$obj.LastSeenTopLastModified
            LastNotifiedBlobName    = [string]$obj.LastNotifiedBlobName
            LastNotifiedAtUtc       = [string]$obj.LastNotifiedAtUtc
        }
    } catch {
        Write-Audit ("Notification state load failed: {0}" -f $_.Exception.Message) 'WARN'
        return (Get-DefaultNotifyState)
    }
}

function Save-NotifyState {
    param([Parameter(Mandatory)]$State)

    try {
        Ensure-Folder $Global:CollectedInfoRoot
        $State | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Global:NotifyStatePath -Encoding UTF8
    } catch {
        Write-Audit ("Notification state save failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

function Initialize-NotificationPreference {
    $script:NotifyState = Load-NotifyState
    $script:NotificationsEnabled = [bool]$script:NotifyState.NotificationsEnabled

    if ($EnableNotifications) {
        $script:NotificationsEnabled = $true
    }
    if ($DisableNotifications) {
        $script:NotificationsEnabled = $false
    }

    $script:NotifyState.NotificationsEnabled = $script:NotificationsEnabled
    Save-NotifyState -State $script:NotifyState
}

function Set-NotificationsEnabled {
    param([Parameter(Mandatory)][bool]$Enabled)

    $script:NotificationsEnabled = $Enabled
    if ($null -eq $script:NotifyState) {
        $script:NotifyState = Get-DefaultNotifyState
    }
    $script:NotifyState.NotificationsEnabled = $Enabled
    Save-NotifyState -State $script:NotifyState
}

function Show-NewFileNotification {
    param([Parameter(Mandatory)]$Item)

    $title = 'New secure bundle posted'
    $body  = "Company: {0}`nTicket: {1}`nSender: {2}`nET: {3}" -f `
        ($Item.Company + '').Trim(),
        ($Item.Ticket + '').Trim(),
        ($Item.Sender + '').Trim(),
        (Format-UploadStampET -UtcOrUnknown $Item.LastModified)

    $shown = $false

    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop

        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ni.Icon = [System.Drawing.SystemIcons]::Information
        $ni.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
        $ni.BalloonTipTitle = $title
        $ni.BalloonTipText  = $body
        $ni.Visible = $true
        $ni.ShowBalloonTip(10000)
        Start-Sleep -Milliseconds 1500
        $ni.Dispose()
        $shown = $true
    } catch {
        Write-Audit ("Toast/balloon notification failed: {0}" -f $_.Exception.Message) 'WARN'
    }

    if (-not $shown) {
        try {
            [void][Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
            [System.Windows.Forms.MessageBox]::Show($body, $title, 'OK', 'Information') | Out-Null
            $shown = $true
        } catch {
            Write-Audit ("Fallback message notification failed: {0}" -f $_.Exception.Message) 'WARN'
        }
    }

    if ($shown) {
        Write-Audit ("New file notification shown for blob: {0}" -f $Item.Name)
    }
}

function Update-NotificationStateForTopItem {
    param([Parameter(Mandatory)]$TopItem)

    $script:NotifyState.LastSeenTopBlobName = [string]$TopItem.Name
    try {
        $utc = ([datetime]$TopItem.LastModified).ToUniversalTime().ToString('o')
        $script:NotifyState.LastSeenTopLastModified = $utc
    } catch {
        $script:NotifyState.LastSeenTopLastModified = ''
    }
    Save-NotifyState -State $script:NotifyState
}

function Process-NewItemNotification {
    param(
        [Parameter(Mandatory)]$Items,
        [switch]$SuppressPopup
    )

    $arr = Force-Array $Items
    if ((Count-Items $arr) -eq 0) { return }

    $top = $arr[0]
    $currentName = [string]$top.Name
    $currentUtc  = ''
    try { $currentUtc = ([datetime]$top.LastModified).ToUniversalTime().ToString('o') } catch { }

    $priorName = [string]$script:NotifyState.LastSeenTopBlobName
    $priorUtc  = [string]$script:NotifyState.LastSeenTopLastModified

    $isFirstBaseline = [string]::IsNullOrWhiteSpace($priorName)
    $isNewTop = (($currentName -ne $priorName) -or ($currentUtc -ne $priorUtc))

    if ($isFirstBaseline) {
        Update-NotificationStateForTopItem -TopItem $top
        Write-Audit ("Notification baseline initialized to blob: {0}" -f $currentName)
        return
    }

    if ($isNewTop) {
        if ($script:NotificationsEnabled -and (-not $SuppressPopup)) {
            $alreadyNotified = ([string]$script:NotifyState.LastNotifiedBlobName -eq $currentName)
            if (-not $alreadyNotified) {
                Show-NewFileNotification -Item $top
                $script:NotifyState.LastNotifiedBlobName = $currentName
                $script:NotifyState.LastNotifiedAtUtc = [datetime]::UtcNow.ToString('o')
            }
        }
        Update-NotificationStateForTopItem -TopItem $top
    }
}

# =====================================================================
# PASSHRASE CACHE
# =====================================================================
$Global:CS_EncryptPassphrase = $null

function Get-InteractiveUserProfilePath {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $u = [string]$cs.UserName
        if ([string]::IsNullOrWhiteSpace($u)) { return $null }
        $name = ($u -split '\\')[-1]
        $candidate = Join-Path "C:\Users" $name
        if (Test-Path -LiteralPath $candidate -PathType Container) { return $candidate }
    } catch { }
    return $null
}

function Get-UserCollectedInfoRoot {
    $prof = Get-InteractiveUserProfilePath
    if (-not $prof) { return $null }
    return Join-Path $prof 'CS-Toolbox-TEMP\Collected-Info'
}

function Get-PreferredCollectedInfoRoot {
    $uRoot = Get-UserCollectedInfoRoot
    if ($uRoot -and (Test-Path -LiteralPath $uRoot -PathType Container)) { return $uRoot }
    return $Global:CollectedInfoRoot
}

function Get-PassphraseCachePath {
    $root = Get-PreferredCollectedInfoRoot
    return Join-Path $root 'secure-passphrase-cache.json'
}

function Try-LoadCachedPassphrase {
    $cachePath = Get-PassphraseCachePath
    if (-not (Test-Path -LiteralPath $cachePath -PathType Leaf)) { return $null }
    try {
        $raw = Get-Content -LiteralPath $cachePath -Raw -Encoding UTF8
        $obj = $raw | ConvertFrom-Json
        if ($null -eq $obj) { return $null }

        $savedAt = [datetime]::Parse([string]$obj.SavedAtUtc).ToUniversalTime()
        $ageMin  = ([datetime]::UtcNow - $savedAt).TotalMinutes
        if ($ageMin -gt [double]$Global:CS_PassphraseCacheMinutes) { return $null }

        $enc = [string]$obj.DpapiProtected
        if ([string]::IsNullOrWhiteSpace($enc)) { return $null }

        $sec = ConvertTo-SecureString $enc
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } catch { return $null }
}

function Save-CachedPassphrase([string]$Pass) {
    if ([string]::IsNullOrWhiteSpace($Pass)) { return }
    try {
        $cachePath = Get-PassphraseCachePath
        $cacheRoot = Split-Path -Path $cachePath -Parent
        Ensure-Folder $cacheRoot

        $sec = ConvertTo-SecureString $Pass -AsPlainText -Force
        $dp  = $sec | ConvertFrom-SecureString

        $obj = [pscustomobject]@{
            SavedAtUtc     = ([datetime]::UtcNow.ToString("o"))
            CacheMinutes   = [int]$Global:CS_PassphraseCacheMinutes
            DpapiProtected = $dp
        }

        ($obj | ConvertTo-Json -Depth 4) | Out-File -FilePath $cachePath -Encoding UTF8 -Force
        Write-Audit ("Passphrase cached at {0} (minutes={1})" -f $cachePath, $Global:CS_PassphraseCacheMinutes)
    } catch {
        Write-Audit ("Passphrase cache write failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

function Prompt-Passphrase {
    $cached = Try-LoadCachedPassphrase
    if (-not [string]::IsNullOrWhiteSpace($cached)) {
        $Global:CS_EncryptPassphrase = $cached
        Write-InfoColor ("Passphrase cache: OK (valid for {0} minutes)" -f $Global:CS_PassphraseCacheMinutes) Green
        Write-Audit "Passphrase cache hit."
        return
    }

    Write-InfoColor "ConnectSecure Secure Bundle Browser (Azure RBAC)" Yellow
    Write-Host ""
    $securePass = Read-Host "Enter ConnectSecure passphrase (input hidden)" -AsSecureString

    if ($securePass) {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
        try { $Global:CS_EncryptPassphrase = [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } else {
        $Global:CS_EncryptPassphrase = ""
    }

    Save-CachedPassphrase -Pass $Global:CS_EncryptPassphrase
}

# =====================================================================
# AZURE
# =====================================================================
function Ensure-Tls12 { try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { } }

function Ensure-NuGetProvider {
    if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
        Install-PackageProvider -Name NuGet -Force -Scope CurrentUser -ErrorAction Stop | Out-Null
    }
}

function Ensure-AzModules {
    param([switch]$ForceInstall)

    Ensure-Tls12
    try { Import-Module PowerShellGet -ErrorAction SilentlyContinue | Out-Null } catch { }

    if ($ForceInstall) {
        Ensure-NuGetProvider
        $psg = Get-PSRepository -Name 'PSGallery' -ErrorAction SilentlyContinue
        if ($psg -and $psg.InstallationPolicy -ne 'Trusted') {
            try { Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted -ErrorAction SilentlyContinue | Out-Null } catch { }
        }
    }

    $need = @('Az.Accounts','Az.Storage')
    foreach ($m in $need) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            if (-not $ForceInstall) { throw "Required module '$m' is missing. Re-run with -ForceInstallModules." }
            Write-InfoColor ("Installing module: {0} (CurrentUser)..." -f $m) Yellow
            Install-Module -Name $m -Scope CurrentUser -Force -AllowClobber -Repository PSGallery -ErrorAction Stop | Out-Null
        }
    }

    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.Storage  -ErrorAction Stop

    if ($ForceInstall) {
        foreach ($m in $need) {
            try {
                Write-InfoColor ("Updating module (if needed): {0} (CurrentUser)..." -f $m) Yellow
                Update-Module -Name $m -Scope CurrentUser -ErrorAction SilentlyContinue | Out-Null
            } catch { }
        }
    }
}

function Ensure-AzLogin {
    param([Parameter(Mandatory)][string]$TenantId)

    try {
        $ctx = Get-AzContext -ErrorAction SilentlyContinue
        if ($ctx -and $ctx.Tenant -and ([string]$ctx.Tenant.Id -eq $TenantId)) { return }
    } catch { }

    Write-InfoColor "Azure login required. A Microsoft sign-in window/browser should appear..." Yellow

    try {
        Connect-AzAccount -Tenant $TenantId -ErrorAction Stop | Out-Null
        return
    } catch {
        Write-Audit ("Connect-AzAccount normal failed: {0}" -f $_.Exception.Message) 'WARN'
    }

    Write-InfoColor "Falling back to DEVICE authentication (tenant policy/session may require this)..." Yellow
    Connect-AzAccount -Tenant $TenantId -UseDeviceAuthentication -ErrorAction Stop | Out-Null
}

function Get-AzureAdStorageContext {
    param([Parameter(Mandatory)][string]$StorageAccountName)

    $ctxNow = Get-AzContext -ErrorAction SilentlyContinue
    $tenantNow = ''
    try { $tenantNow = [string]$ctxNow.Tenant.Id } catch { }

    if ($script:AzureStorageContext -and
        $script:AzureStorageContextAccount -eq $StorageAccountName -and
        $script:AzureStorageContextTenant -eq $tenantNow) {
        return $script:AzureStorageContext
    }

    try {
        $script:AzureStorageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount -ErrorAction Stop
        $script:AzureStorageContextAccount = $StorageAccountName
        $script:AzureStorageContextTenant  = $tenantNow
        return $script:AzureStorageContext
    } catch {
        $script:AzureStorageContext = $null
        $script:AzureStorageContextAccount = $null
        $script:AzureStorageContextTenant = $null
        throw ("Failed to create Azure Storage context via connected account (RBAC). Ensure RBAC is assigned and Az modules are current. Underlying: {0}" -f $_.Exception.Message)
    }
}

function Reset-AzureLoginCache {
    Write-Host ""
    Write-InfoColor "Resetting Azure login context for this user..." Yellow

    try { Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null } catch { }
    try { Clear-AzContext -Force -Scope Process -ErrorAction SilentlyContinue | Out-Null } catch { }
    try { Clear-AzContext -Force -Scope CurrentUser -ErrorAction SilentlyContinue | Out-Null } catch { }
    try { Clear-AzDefault -ErrorAction SilentlyContinue | Out-Null } catch { }

    $script:AzureStorageContext = $null
    $script:AzureStorageContextAccount = $null
    $script:AzureStorageContextTenant = $null

    Write-Audit "Azure RBAC: Disconnect/Clear context executed." 'WARN'

    $azureHome = Join-Path $HOME ".Azure"
    if (Test-Path -LiteralPath $azureHome -PathType Container) {
        Write-Host ""
        $yn = Read-Host ("Also delete local token cache folder '{0}'? (Y/N)" -f $azureHome)
        if ($yn -match '^[Yy]$') {
            try {
                Remove-Item -LiteralPath $azureHome -Recurse -Force -ErrorAction Stop
                Write-InfoColor ("Deleted {0}" -f ${azureHome}) Green
                Write-Audit ("Deleted Azure cache folder: {0}" -f $azureHome) 'WARN'
            } catch {
                Write-InfoColor ("Failed to delete {0}: {1}" -f ${azureHome}, $_.Exception.Message) Red
                Write-Audit ("Failed to delete Azure cache folder: {0}" -f $_.Exception.Message) 'ERROR'
            }
        }
    }

    Write-Host ""
    Read-Host "Press Enter to continue" | Out-Null
}

# =====================================================================
# PARSING / LIST / CACHE
# =====================================================================
function Parse-NameParts {
    param([Parameter(Mandatory)][string]$BlobName)

    $file = Split-Path $BlobName -Leaf
    $base = [IO.Path]::GetFileNameWithoutExtension($file)

    $tail = $base
    $u = $base.LastIndexOf('_')
    if ($u -ge 0 -and $u -lt ($base.Length - 1)) { $tail = $base.Substring($u + 1) }

    $company = ""
    $ticket  = ""
    $sender  = ""

    $mTicket = [regex]::Match($tail, '(?:^|[_\- ])t-([^\.]+)')
    if ($mTicket.Success) { $ticket = $mTicket.Groups[1].Value.Trim() }

    $parts = @()
    foreach ($p in ($tail -split '-')) {
        $v = ($p + "").Trim()
        if (-not [string]::IsNullOrWhiteSpace($v)) { $parts += $v }
    }

    $ticketIdx = -1

    if ([string]::IsNullOrWhiteSpace($ticket)) {
        for ($i = 0; $i -lt $parts.Count; $i++) {
            if ($parts[$i] -match '^\d{4,}$') { $ticketIdx = $i; $ticket = $parts[$i]; break }
        }
    } else {
        for ($i = 0; $i -lt $parts.Count; $i++) {
            if ($parts[$i] -eq $ticket) { $ticketIdx = $i; break }
        }
    }

    if ($ticketIdx -ge 0) {
        if ($ticketIdx -gt 0) { $company = ($parts[0..($ticketIdx-1)] -join ' ') }
        if ($ticketIdx -lt ($parts.Count - 1)) { $sender = ($parts[($ticketIdx+1)..($parts.Count-1)] -join ' ') }
    } else {
        $company = $tail
        $ticket  = ""
        $sender  = ""
    }

    $company = ($company -replace '[_]+',' ' -replace '\s+',' ').Trim()
    $ticket  = ($ticket + "").Trim()
    $sender  = ($sender -replace '[_]+',' ' -replace '\s+',' ').Trim()

    return [pscustomobject]@{ Company=$company; Ticket=$ticket; Sender=$sender; File=$file }
}

function Invoke-GetAzStorageBlobLimited {
    param(
        [Parameter(Mandatory)][string]$Container,
        [Parameter(Mandatory)]$Context,
        [int]$MaxCountDesired
    )

    $cmd = Get-Command Get-AzStorageBlob -ErrorAction Stop
    $hasMaxCount = $false
    try { $hasMaxCount = $cmd.Parameters.ContainsKey('MaxCount') } catch { $hasMaxCount = $false }

    if ($hasMaxCount -and $MaxCountDesired -gt 0) {
        return @(Get-AzStorageBlob -Container $Container -Context $Context -MaxCount $MaxCountDesired -ErrorAction Stop)
    }

    return @(Get-AzStorageBlob -Container $Container -Context $Context -ErrorAction Stop)
}

function Try-GetBlobListPropsQuick {
    param([Parameter(Mandatory)]$Blob)

    $lm = $null
    $len = 0

    try { if ($Blob.ICloudBlob -and $Blob.ICloudBlob.Properties) { $len = [int64]$Blob.ICloudBlob.Properties.Length } } catch { }
    try {
        if ($Blob.ICloudBlob -and $Blob.ICloudBlob.Properties -and $Blob.ICloudBlob.Properties.LastModified) {
            $lm = $Blob.ICloudBlob.Properties.LastModified
        }
    } catch { }

    if ($null -eq $lm) {
        try { $lm = $Blob.LastModified } catch { $lm = [datetime]::UtcNow }
    }
    if ($len -le 0) {
        try { $len = [int64]$Blob.Length } catch { $len = 0 }
    }

    return [pscustomobject]@{ Length=$len; LastModified=$lm }
}

function Try-ListAzureRBAC {
    param(
        [Parameter(Mandatory)][string]$StorageAccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [int]$MaxResults = 20
    )

    $ctx = Get-AzureAdStorageContext -StorageAccountName $StorageAccountName
    $want = [Math]::Max(100, ($MaxResults * 3))
    $blobs = Invoke-GetAzStorageBlobLimited -Container $ContainerName -Context $ctx -MaxCountDesired $want

    $results = @()
    foreach ($b in $blobs) {
        $name = [string]$b.Name
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        $p   = Try-GetBlobListPropsQuick -Blob $b
        $len = [int64]$p.Length
        $lm  = $p.LastModified

        $parsed = Parse-NameParts -BlobName $name

        $results += [pscustomobject]@{
            Name         = $name
            Company      = $parsed.Company
            Ticket       = $parsed.Ticket
            Sender       = $parsed.Sender
            SizeBytes    = $len
            SizeMB       = [math]::Round($len / 1MB, 1)
            LastModified = $lm
        }
    }

    return @(($results | Sort-Object LastModified -Descending | Select-Object -First $MaxResults))
}

function Download-AzureBlobRBAC {
    param(
        [Parameter(Mandatory)][string]$StorageAccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [Parameter(Mandatory)][string]$BlobName,
        [Parameter(Mandatory)][string]$DownloadRoot
    )

    Ensure-Folder $DownloadRoot
    $ctx = Get-AzureAdStorageContext -StorageAccountName $StorageAccountName

    $safeName  = (Split-Path $BlobName -Leaf) -replace '[^\w\.\-]','_'
    $localPath = Join-Path $DownloadRoot $safeName

    Write-InfoColor ("Downloading to: {0}" -f $localPath) Cyan
    Get-AzStorageBlobContent -Container $ContainerName -Blob $BlobName -Context $ctx -Destination $localPath -Force -ErrorAction Stop | Out-Null
    Write-InfoColor "Download complete." Green

    return $localPath
}

function Get-ListCachePaths {
    param(
        [string]$StorageAccount = $AzureStorageAccount,
        [string]$Container = $AzureContainer
    )

    $root = Get-PreferredCollectedInfoRoot
    if (-not $root) { $root = $Global:CollectedInfoRoot }
    Ensure-Folder $root

    $safeAccount = (($StorageAccount + '') -replace '[^\w\-\.]','_')
    $safeContainer = (($Container + '') -replace '[^\w\-\.]','_')
    $suffix = "{0}__{1}" -f $safeAccount, $safeContainer

    return [pscustomobject]@{
        Data = Join-Path $root ("secure-log-browser-cache_{0}.bin" -f $suffix)
        Meta = Join-Path $root ("secure-log-browser-cache_{0}.meta.json" -f $suffix)
    }
}

function Save-EncryptedListCache {
    param(
        [Parameter(Mandatory)]$Items,
        [Parameter(Mandatory)][string]$StorageAccount,
        [Parameter(Mandatory)][string]$Container,
        [Parameter(Mandatory)][int]$WindowSuperset
    )

    try {
        $paths = Get-ListCachePaths -StorageAccount $StorageAccount -Container $Container

        $payload = [pscustomobject]@{
            CreatedUtc     = [datetime]::UtcNow.ToString('o')
            StorageAccount = $StorageAccount
            Container      = $Container
            WindowSuperset = $WindowSuperset
            Items          = @($Items)
        }

        $json  = $payload | ConvertTo-Json -Depth 8
        $bytes = [Text.Encoding]::UTF8.GetBytes($json)
        $entropy = [Text.Encoding]::UTF8.GetBytes($Global:CS_ListCacheEntropy)

        $enc = [System.Security.Cryptography.ProtectedData]::Protect(
            $bytes,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )

        [IO.File]::WriteAllBytes($paths.Data, $enc)

        $meta = [pscustomobject]@{
            CreatedUtc     = $payload.CreatedUtc
            StorageAccount = $StorageAccount
            Container      = $Container
            WindowSuperset = $WindowSuperset
            Count          = @($Items).Count
        }

        $meta | ConvertTo-Json -Depth 4 | Out-File -FilePath $paths.Meta -Encoding UTF8 -Force
        Write-Audit ("Encrypted list cache saved: {0}" -f $paths.Data)
    } catch {
        Write-Audit ("Encrypted list cache save failed: {0}" -f $_.Exception.Message) 'WARN'
    }
}

function Try-LoadEncryptedListCache {
    param(
        [Parameter(Mandatory)][string]$StorageAccount,
        [Parameter(Mandatory)][string]$Container,
        [int]$MaxAgeSeconds = 300
    )

    $paths = Get-ListCachePaths -StorageAccount $StorageAccount -Container $Container
    if (-not (Test-Path -LiteralPath $paths.Data -PathType Leaf)) { return $null }

    try {
        $entropy = [Text.Encoding]::UTF8.GetBytes($Global:CS_ListCacheEntropy)
        $enc = [IO.File]::ReadAllBytes($paths.Data)

        $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $enc,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )

        $json = [Text.Encoding]::UTF8.GetString($bytes)
        $obj  = $json | ConvertFrom-Json
        if ($null -eq $obj) { return $null }
        if ([string]$obj.StorageAccount -ne $StorageAccount) { return $null }
        if ([string]$obj.Container -ne $Container) { return $null }

        $createdUtc = [datetime]::Parse([string]$obj.CreatedUtc).ToUniversalTime()
        $ageSec = ([datetime]::UtcNow - $createdUtc).TotalSeconds
        if ($ageSec -gt $MaxAgeSeconds) { return $null }

        return [pscustomobject]@{
            Items          = @($obj.Items)
            CreatedUtc     = $createdUtc
            WindowSuperset = [int]$obj.WindowSuperset
        }
    } catch {
        Write-Audit ("Encrypted list cache load failed: {0}" -f $_.Exception.Message) 'WARN'
        return $null
    }
}

function Remove-IfExists {
    param([Parameter(Mandatory)][string]$LiteralPath)

    try {
        if (Test-Path -LiteralPath $LiteralPath) {
            Remove-Item -LiteralPath $LiteralPath -Recurse -Force -ErrorAction SilentlyContinue
        }
    } catch { }
}

function Clear-BlobSessionState {
    param(
        [string]$StorageAccount = $AzureStorageAccount,
        [string]$Container = $AzureContainer,
        [switch]$IncludeLegacy,
        [switch]$IncludeManagedCopy
    )

    try {
        $script:AzureStorageContext = $null
        $script:AzureStorageContextAccount = $null
        $script:AzureStorageContextTenant = $null
        $script:LastRefreshLocal = $null
        $script:NextRefreshLocal = $null
        $script:LastLoadUsedCache = $false

        $script:CurrentFilterRaw = ""
        $script:CurrentFilterTerms = @()

        $paths = Get-ListCachePaths -StorageAccount $StorageAccount -Container $Container

        Remove-IfExists -LiteralPath $paths.Data
        Remove-IfExists -LiteralPath $paths.Meta

        if ($IncludeLegacy) {
            $roots = @()
            $roots += $Global:CollectedInfoRoot

            $uRoot = Get-UserCollectedInfoRoot
            if ($uRoot) { $roots += $uRoot }

            foreach ($root in ($roots | Select-Object -Unique)) {
                if (-not [string]::IsNullOrWhiteSpace($root) -and (Test-Path -LiteralPath $root -PathType Container)) {
                    Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue | ForEach-Object {
                        if ($_.Name -like 'secure-log-browser-cache*') {
                            Remove-IfExists -LiteralPath $_.FullName
                        }
                    }

                    Remove-IfExists -LiteralPath (Join-Path $root 'CS-secure-log-browser-selfupdate.json')
                }
            }
        }

        if ($IncludeManagedCopy) {
            Remove-IfExists -LiteralPath $script:VV_AppRoot
            Remove-IfExists -LiteralPath $script:VV_WorkRoot
        }

        Write-Audit ("Cleared blob session state for {0}/{1}. Legacy={2} Managed={3}" -f $StorageAccount, $Container, [bool]$IncludeLegacy, [bool]$IncludeManagedCopy)
        Write-InfoColor "Full local cache/state cleared. Next load will come directly from Azure." Green
    } catch {
        Write-Audit ("Failed clearing blob session state: {0}" -f $_.Exception.Message) 'WARN'
        Write-InfoColor ("Failed clearing blob cache/state: {0}" -f $_.Exception.Message) Red
    }
}

function Get-RecentItems {
    param(
        [Parameter(Mandatory)][string]$StorageAccount,
        [Parameter(Mandatory)][string]$Container,
        [int]$VisibleWindowSize = 20,
        [switch]$BypassCache
    )

    $superset = 100
    $script:LastLoadUsedCache = $false

    if (-not $BypassCache) {
        $cache = Try-LoadEncryptedListCache -StorageAccount $StorageAccount -Container $Container -MaxAgeSeconds $Global:CS_ListCacheTtlSeconds
        if ($cache -and $cache.Items) {
            $script:LastLoadUsedCache = $true
            $localRef = Convert-ToTimeZone -UtcOrUnknown $cache.CreatedUtc -Tzi ([System.TimeZoneInfo]::Local)
            Write-InfoColor "Loading source: CACHE" Yellow
            return [pscustomobject]@{
                Items          = @($cache.Items | Select-Object -First $VisibleWindowSize)
                AllCachedItems = @($cache.Items)
                RefreshedLocal = $localRef
                Source         = 'CACHE'
            }
        }
    }

    Write-InfoColor "Loading source: AZURE" Yellow
    Write-InfoColor ("Loading recent secure bundles from Azure (RBAC): {0}/{1} ..." -f $StorageAccount, $Container) Cyan
    $allItems = @(Try-ListAzureRBAC -StorageAccountName $StorageAccount -ContainerName $Container -MaxResults $superset)
    Save-EncryptedListCache -Items $allItems -StorageAccount $StorageAccount -Container $Container -WindowSuperset $superset

    $nowLocal = Get-Date
    return [pscustomobject]@{
        Items          = @($allItems | Select-Object -First $VisibleWindowSize)
        AllCachedItems = @($allItems)
        RefreshedLocal = $nowLocal
        Source         = 'AZURE'
    }
}

# =====================================================================
# CSB DECRYPT
# =====================================================================
function Ensure-ZipAssemblies {
  try { [void][System.IO.Compression.ZipArchiveMode]::Create } catch {
    foreach($asm in 'System.IO.Compression','System.IO.Compression.FileSystem'){
      try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
    try { [void][System.IO.Compression.ZipArchiveMode]::Create }
    catch { throw "Required .NET compression types are unavailable. Install .NET Framework 4.5+." }
  }
}
function Join-Bytes([byte[]]$a,[byte[]]$b){
  $out = New-Object byte[] ($a.Length + $b.Length)
  [Array]::Copy($a,0,$out,0,$a.Length)
  [Array]::Copy($b,0,$out,$a.Length,$b.Length)
  return $out
}
function BytesEqual([byte[]]$a,[byte[]]$b){
  if ($a.Length -ne $b.Length) { return $false }
  $diff = 0
  for($i=0;$i -lt $a.Length;$i++){ $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

function ASN-ExpectTag([byte[]]$buf, [int]$idx, [byte]$tag) { if ($idx -ge $buf.Length) { throw "ASN.1 read past end" }; if ($buf[$idx] -ne $tag) { throw "ASN.1 tag mismatch" }; return ($idx+1) }
function ASN-ReadLen([byte[]]$buf, [int]$idx) { if ($idx -ge $buf.Length) { throw "ASN.1 length read past end" }; $b=[int]$buf[$idx]; $idx++; if($b -lt 0x80){ return @{Len=$b;Idx=$idx} }; $n=$b-0x80; if($n -lt 1 -or $n -gt 4){ throw "Unsupported ASN.1 length" }; $val=0; for($k=0;$k -lt $n;$k++){ $val=(($val -shl 8) -bor [int]$buf[$idx]); $idx++ }; return @{Len=$val;Idx=$idx} }
function ASN-ReadSeq([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x30; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 SEQUENCE overrun" }; @{Start=$idx;End=($idx+$len);Idx=$idx} }
function ASN-ReadInt([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x02; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 INTEGER overrun" }; $val=$buf[$idx..($idx+$len-1)]; $idx+=$len; if($val.Length -gt 1 -and $val[0]-eq 0x00){ $val=$val[1..($val.Length-1)] }; @{Val=([byte[]]$val);Idx=$idx} }
function ASN-ReadOctets([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x04; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OCTET STRING overrun" }; @{Val=([byte[]]$buf[$idx..($idx+$len-1)]);Idx=($idx+$len)} }
function ASN-ReadOid([byte[]]$buf, [int]$idx) { $idx=ASN-ExpectTag $buf $idx 0x06; $lr=ASN-ReadLen $buf $idx; $len=$lr.Len; $idx=$lr.Idx; if($idx+$len -gt $buf.Length){ throw "ASN.1 OID overrun" }; $data=$buf[$idx..($idx+$len-1)]; $idx+=$len; $first=[int]$data[0]; $a=[int]([math]::Floor($first/40)); $b=$first%40; $oidParts=@($a,$b); $val=0; for($i=1;$i -lt $data.Length;$i++){ $val=($val -shl 7) -bor ($data[$i] -band 0x7F); if(($data[$i] -band 0x80)-eq 0){ $oidParts+=$val; $val=0 } }; @{Oid=($oidParts -join '.');Idx=$idx} }
function IntFromBytes([byte[]]$b){ $v=0; foreach($x in $b){ $v=(($v -shl 8) -bor $x) }; $v }
function PemToBytes([string]$pem, [string]$header, [string]$footer){ $i1=$pem.IndexOf($header); $i2=$pem.IndexOf($footer); if($i1 -lt 0 -or $i2 -lt 0){ throw "PEM missing header/footer" }; $b64=$pem.Substring($i1+$header.Length,$i2-($i1+$header.Length)) -replace '\s',''; [Convert]::FromBase64String($b64) }

function PBKDF2-Derive([string]$password, [byte[]]$salt, [int]$iters, [int]$keyLen, [string]$prf){
  if ($prf -eq 'SHA1') {
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters)
    try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
  }
  if ($prf -eq 'SHA256') {
    try {
      $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iters, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
      try { return $k.GetBytes($keyLen) } finally { $k.Dispose() }
    } catch {
      $pwd = [Text.Encoding]::UTF8.GetBytes($password)
      $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$pwd)
      try {
        $hLen = 32
        $blocks = [int][math]::Ceiling($keyLen / $hLen)
        $dk = New-Object byte[] ($blocks * $hLen)
        for ($i=1; $i -le $blocks; $i++){
          $intBlock = [byte[]]@(
            ($i -shr 24) -band 0xFF,
            ($i -shr 16) -band 0xFF,
            ($i -shr 8)  -band 0xFF,
            $i -band 0xFF
          )
          $u = $hmac.ComputeHash( (Join-Bytes $salt $intBlock) )
          $t = [byte[]]$u.Clone()
          for ($j=2; $j -le $iters; $j++){
            $u = $hmac.ComputeHash($u)
            for ($kidx=0; $kidx -lt $hLen; $kidx++){ $t[$kidx] = $t[$kidx] -bxor $u[$kidx] }
          }
          [Array]::Copy($t, 0, $dk, ($i-1)*$hLen, $hLen)
        }
        $out = New-Object byte[] $keyLen
        [Array]::Copy($dk, 0, $out, 0, $keyLen)
        return $out
      } finally { $hmac.Dispose() }
    }
  }
  throw "Unsupported PBKDF2 PRF: $prf"
}

function Decrypt-Pkcs8EncryptedPrivateKey([string]$pem, [string]$password){
  $der = PemToBytes $pem '-----BEGIN ENCRYPTED PRIVATE KEY-----' '-----END ENCRYPTED PRIVATE KEY-----'
  $top = ASN-ReadSeq $der 0
  $idx = $top.Idx
  $alg = ASN-ReadSeq $der $idx
  $idx = $alg.End
  $algOid = ASN-ReadOid $der $alg.Idx
  if ($algOid.Oid -ne '1.2.840.113549.1.5.13') { throw "Unsupported encryption algorithm OID (expected PBES2)" }
  $pbes2 = ASN-ReadSeq $der $algOid.Idx
  $kdfAlg = ASN-ReadSeq $der $pbes2.Idx
  $encAlgPos = $kdfAlg.End
  $kdfOid = ASN-ReadOid $der $kdfAlg.Idx
  if ($kdfOid.Oid -ne '1.2.840.113549.1.5.12') { throw "Unsupported KDF OID (expected PBKDF2)" }
  $pbkdf2Seq = ASN-ReadSeq $der $kdfOid.Idx
  $saltOct   = ASN-ReadOctets $der $pbkdf2Seq.Idx
  $iterInt   = ASN-ReadInt    $der $saltOct.Idx
  $scanIdx   = $iterInt.Idx
  $klenMaybe = $null
  $prfOid    = '1.2.840.113549.2.7'
  if ($scanIdx -lt $pbkdf2Seq.End) {
    if ($der[$scanIdx] -eq 0x02) { $klenMaybe = ASN-ReadInt $der $scanIdx; $scanIdx = $klenMaybe.Idx }
    if ($scanIdx -lt $pbkdf2Seq.End -and $der[$scanIdx] -eq 0x30) {
      $prfSeq = ASN-ReadSeq $der $scanIdx
      $prfRead = ASN-ReadOid $der $prfSeq.Idx
      $prfOid = $prfRead.Oid
    }
  }
  $encAlg = ASN-ReadSeq $der $encAlgPos
  $encOid = ASN-ReadOid $der $encAlg.Idx
  $ivOct  = ASN-ReadOctets $der $encOid.Idx
  $encOctet = ASN-ReadOctets $der $idx
  $cipherPrivKey = $encOctet.Val
  $prf = if ($prfOid -eq '1.2.840.113549.2.7') { 'SHA1' } elseif ($prfOid -eq '1.2.840.113549.2.9') { 'SHA256' } else { throw "Unsupported PRF OID: $prfOid" }
  $aesBits = switch ($encOid.Oid) {
    '2.16.840.1.101.3.4.1.42' { 256 }
    '2.16.840.1.101.3.4.1.22' { 192 }
    '2.16.840.1.101.3.4.1.2'  { 128 }
    default { throw "Unsupported encryption OID (expected AES-CBC)" }
  }
  $keyLen = if ($klenMaybe) { IntFromBytes $klenMaybe.Val } else { $aesBits / 8 }
  $iters  = [int](IntFromBytes $iterInt.Val)
  if ($iters -le 0) { throw "Bad PBKDF2 iteration count" }
  $key = PBKDF2-Derive $password $saltOct.Val $iters $keyLen $prf
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = $aesBits
    $aes.BlockSize = 128
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $key
    $aes.IV  = $ivOct.Val
    $ms = New-Object IO.MemoryStream
    try {
      $cs = New-Object System.Security.Cryptography.CryptoStream($ms, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try { $cs.Write($cipherPrivKey,0,$cipherPrivKey.Length); $cs.FlushFinalBlock() } finally { $cs.Dispose() }
      $pkcs8 = $ms.ToArray()
    } finally { $ms.Dispose() }
  } finally { $aes.Dispose() }
  $pki = ASN-ReadSeq $pkcs8 0
  $i2 = $pki.Idx
  $ver  = ASN-ReadInt $pkcs8 $i2; $i2 = $ver.Idx
  $alg2 = ASN-ReadSeq $pkcs8 $i2
  $oid2 = ASN-ReadOid $pkcs8 $alg2.Idx
  if ($oid2.Oid -ne '1.2.840.113549.1.1.1') { throw "PrivateKey algorithm not RSA" }
  $i2 = $alg2.End
  $ok = ASN-ReadOctets $pkcs8 $i2
  $rk = $ok.Val
  $rseq = ASN-ReadSeq $rk 0; $ri = $rseq.Idx
  $v    = ASN-ReadInt $rk $ri; $ri = $v.Idx
  $n    = ASN-ReadInt $rk $ri; $ri = $n.Idx
  $e    = ASN-ReadInt $rk $ri; $ri = $e.Idx
  $d    = ASN-ReadInt $rk $ri; $ri = $d.Idx
  $p    = ASN-ReadInt $rk $ri; $ri = $p.Idx
  $q    = ASN-ReadInt $rk $ri; $ri = $q.Idx
  $dp   = ASN-ReadInt $rk $ri; $ri = $dp.Idx
  $dq   = ASN-ReadInt $rk $ri; $ri = $dq.Idx
  $iq   = ASN-ReadInt $rk $ri; $ri = $iq.Idx
  $rp = New-Object System.Security.Cryptography.RSAParameters
  $rp.Modulus  = [byte[]]$n.Val
  $rp.Exponent = [byte[]]$e.Val
  $rp.D        = [byte[]]$d.Val
  $rp.P        = [byte[]]$p.Val
  $rp.Q        = [byte[]]$q.Val
  $rp.DP       = [byte[]]$dp.Val
  $rp.DQ       = [byte[]]$dq.Val
  $rp.InverseQ = [byte[]]$iq.Val
  try {
    $rsa = New-Object System.Security.Cryptography.RSACng
    $rsa.ImportParameters($rp)
    return $rsa
  } catch {
    $fallback = [System.Security.Cryptography.RSA]::Create()
    $fallback.ImportParameters($rp)
    return $fallback
  }
}

function Read-CSB([string]$path){
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -lt 4+1+1+2+32) { throw "File too small to be a CSB bundle." }
  $magic = [Text.Encoding]::ASCII.GetString($bytes,0,4)
  if ($magic -ne 'CSB1') { throw "Bad magic '$magic' (expected CSB1)" }
  $ver   = $bytes[4]
  if ($ver -ne 1) { throw "Unsupported CSB version $ver" }
  $flags = $bytes[5]
  $wlen  = (([int]$bytes[6] -shl 8) -bor ([int]$bytes[7]))
  $hdrLenNoTag = 8 + $wlen
  if ($bytes.Length -lt $hdrLenNoTag + 32) { throw "Truncated CSB header." }
  $wrapped = New-Object byte[] $wlen
  [Array]::Copy($bytes,8,$wrapped,0,$wlen)
  $tag = New-Object byte[] 32
  [Array]::Copy($bytes, $bytes.Length-32, $tag, 0, 32)
  $cipherLen = $bytes.Length - $hdrLenNoTag - 32
  if ($cipherLen -le 0) { throw "No ciphertext present in CSB." }
  $cipher = New-Object byte[] $cipherLen
  [Array]::Copy($bytes, $hdrLenNoTag, $cipher, 0, $cipherLen)
  $headerNoTag = New-Object byte[] $hdrLenNoTag
  [Array]::Copy($bytes, 0, $headerNoTag, 0, $hdrLenNoTag)
  return [pscustomobject]@{
    Version      = $ver
    Flags        = $flags
    Wrapped      = $wrapped
    Ciphertext   = $cipher
    Tag          = $tag
    HeaderNoTag  = $headerNoTag
  }
}

function Unwrap-Secret {
  param(
    [Parameter(Mandatory)][byte[]]$Wrapped,
    [Parameter(Mandatory)][int]$Flags,
    [Parameter(Mandatory)][System.Security.Cryptography.RSA]$Rsa
  )
  $isCsp = ($Rsa -is [System.Security.Cryptography.RSACryptoServiceProvider])
  $order = @()
  if (($Flags -band 0x02) -ne 0) { $order += 'OaepSHA256' }
  if (($Flags -band 0x04) -ne 0) { $order += 'OaepSHA1' }
  if ($order.Count -eq 0) { $order = @('OaepSHA256','OaepSHA1') }
  $order += 'Pkcs1'
  foreach($pad in $order){
    try {
      switch ($pad) {
        'OaepSHA256' {
          if ($isCsp) { throw "RSACryptoServiceProvider does not support OAEP-SHA256 in .NET Framework; skipping." }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        }
        'OaepSHA1' {
          if ($isCsp) { return ([System.Security.Cryptography.RSACryptoServiceProvider]$Rsa).Decrypt($Wrapped, $true) }
          return $Rsa.Decrypt($Wrapped, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA1)
        }
        'Pkcs1' {
          $priv = $Rsa.ExportParameters($true)
          $keySizeBits = $priv.Modulus.Length * 8
          $cspParams = New-Object System.Security.Cryptography.CspParameters
          $cspParams.ProviderType = 24
          $csp = New-Object System.Security.Cryptography.RSACryptoServiceProvider($keySizeBits, $cspParams)
          try {
            $csp.PersistKeyInCsp = $false
            $csp.ImportParameters($priv)
            return $csp.Decrypt($Wrapped, $false)
          } finally {
            try { $csp.Clear() } catch {}
            try { $csp.Dispose() } catch {}
          }
        }
      }
    } catch {
      Write-Audit ("RSA unwrap failed with {0}: {1}" -f $pad, $_.Exception.Message) 'WARN'
    }
  }
  throw "Unable to unwrap AES/HMAC/IV secret with available paddings."
}

function Decrypt-CSB-InPlace {
  param([string]$CsbPath,[string]$Passphrase)
  if (-not (Test-Path -LiteralPath $CsbPath -PathType Leaf)) { throw "CSB not found: $CsbPath" }
  if ([string]::IsNullOrWhiteSpace($Passphrase)) { throw "Passphrase is blank; cannot decrypt." }
  if ([string]::IsNullOrWhiteSpace($Global:CS_EncryptedPrivateKeyPem)) { throw "Encrypted private key PEM not set in script." }
  $outDir = Split-Path -Path $CsbPath -Parent
  Ensure-ZipAssemblies
  $csb = Read-CSB -path $CsbPath
  $rsaPriv = Decrypt-Pkcs8EncryptedPrivateKey -pem $Global:CS_EncryptedPrivateKeyPem -password $Passphrase
  $secret = Unwrap-Secret -Wrapped $csb.Wrapped -Flags $csb.Flags -Rsa $rsaPriv
  if ($secret.Length -lt 80) { throw "Unwrapped secret too short ($($secret.Length)); expected 80." }
  $aesKey = New-Object byte[] 32; [Array]::Copy($secret, 0,  $aesKey, 0, 32)
  $macKey = New-Object byte[] 32; [Array]::Copy($secret, 32, $macKey, 0, 32)
  $iv     = New-Object byte[] 16; [Array]::Copy($secret, 64, $iv, 0, 16)
  $hmac = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList (,$macKey)
  try {
    $combined = New-Object byte[] ($csb.HeaderNoTag.Length + $csb.Ciphertext.Length)
    [Array]::Copy($csb.HeaderNoTag,0,$combined,0,$csb.HeaderNoTag.Length)
    [Array]::Copy($csb.Ciphertext,0,$combined,$csb.HeaderNoTag.Length,$csb.Ciphertext.Length)
    $calcTag = $hmac.ComputeHash($combined)
  } finally { $hmac.Dispose() }
  if (-not (BytesEqual $calcTag $csb.Tag)) { throw "HMAC authentication failed." }
  $aes = [System.Security.Cryptography.Aes]::Create()
  try {
    $aes.KeySize = 256
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $aesKey
    $aes.IV  = $iv
    $msOut = New-Object IO.MemoryStream
    try {
      $cs2 = New-Object System.Security.Cryptography.CryptoStream($msOut, $aes.CreateDecryptor(), [System.Security.Cryptography.CryptoStreamMode]::Write)
      try { $cs2.Write($csb.Ciphertext,0,$csb.Ciphertext.Length); $cs2.FlushFinalBlock() } finally { $cs2.Dispose() }
      $zipBytes = $msOut.ToArray()
    } finally { $msOut.Dispose() }
  } finally { $aes.Dispose() }
  $baseName = [IO.Path]::GetFileNameWithoutExtension($CsbPath)
  $outZip = Join-Path $outDir ($baseName + ".zip")
  [IO.File]::WriteAllBytes($outZip, $zipBytes)
  $extractDir = Join-Path $outDir $baseName
  if (Test-Path -LiteralPath $extractDir) {
    try { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction Stop }
    catch { $extractDir = $extractDir + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') }
  }
  [System.IO.Compression.ZipFile]::ExtractToDirectory($outZip, $extractDir)
  [pscustomobject]@{ ZipPath = $outZip; ExtractPath = $extractDir }
}

function Open-Folder([string]$Path) {
    try { if (Test-Path -LiteralPath $Path) { Start-Process explorer.exe -ArgumentList "`"$Path`"" | Out-Null } } catch { }
}

# =====================================================================
# SEARCH / UI
# =====================================================================
function Normalize-SearchTerms {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return @() }
    $terms = @()
    foreach ($t in ($Text -split '\s+')) {
        $v = ($t + "").Trim()
        if (-not [string]::IsNullOrWhiteSpace($v)) { $terms += $v }
    }
    return $terms
}

function Item-MatchesTerms {
    param(
        [Parameter(Mandatory)]$Item,
        [Parameter(Mandatory)][string[]]$Terms
    )

    if ($null -eq $Terms -or $Terms.Length -eq 0) { return $true }

    $hay = ("{0} {1} {2} {3}" -f $Item.Company, $Item.Ticket, $Item.Sender, $Item.Name).ToLowerInvariant()

    foreach ($term in $Terms) {
        $needle = ($term + "").ToLowerInvariant()
        if ($hay.IndexOf($needle) -lt 0) { return $false }
    }
    return $true
}

function Write-ColumnHeadings {
    $wCompany = 20
    $wTicket  = 10
    $wSender  = 12
    $wMB      = 6
    $wET      = 30

    Write-Host "      " -NoNewline

    Write-Host ("{0,-$wCompany}" -f "Company") -NoNewline -ForegroundColor Cyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wTicket}"  -f "Ticket")  -NoNewline -ForegroundColor Cyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wSender}"  -f "Sender")  -NoNewline -ForegroundColor Cyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,$wMB}"       -f "MB")      -NoNewline -ForegroundColor Cyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wET}"      -f "Upload Stamp (ET)") -NoNewline -ForegroundColor Cyan
    Write-Host "  " -NoNewline
    Write-Host ("Upload Stamp (IST)") -ForegroundColor Cyan

    Write-Host "      " -NoNewline
    Write-Host ("{0,-$wCompany}" -f ("-" * ("Company".Length))) -NoNewline -ForegroundColor DarkCyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wTicket}"  -f ("-" * ("Ticket".Length)))  -NoNewline -ForegroundColor DarkCyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wSender}"  -f ("-" * ("Sender".Length)))  -NoNewline -ForegroundColor DarkCyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,$wMB}"       -f ("-" * ("MB".Length)))      -NoNewline -ForegroundColor DarkCyan
    Write-Host "  " -NoNewline
    Write-Host ("{0,-$wET}"      -f ("-" * ("Upload Stamp (ET)".Length))) -NoNewline -ForegroundColor DarkCyan
    Write-Host "  " -NoNewline
    Write-Host ("-" * ("Upload Stamp (IST)".Length)) -ForegroundColor DarkCyan
}

function Read-MenuSelectionWithAutoRefresh {
    param(
        [Parameter(Mandatory)][datetime]$RefreshDueLocal,
        [string]$Prompt = "Selection"
    )

    Write-Host ("{0}: " -f $Prompt) -NoNewline

    $buffer = New-Object System.Text.StringBuilder
    $useRaw = $true
    try {
        $null = $Host.UI.RawUI.KeyAvailable
    } catch {
        $useRaw = $false
    }

    if (-not $useRaw) {
        $remaining = [math]::Ceiling(($RefreshDueLocal - (Get-Date)).TotalSeconds)
        if ($remaining -le 0) { Write-Host ""; return "__AUTO_REFRESH__" }
        $val = Read-Host
        return $val
    }

    while ($true) {
        if ((Get-Date) -ge $RefreshDueLocal) {
            Write-Host ""
            return "__AUTO_REFRESH__"
        }

        try {
            if ($Host.UI.RawUI.KeyAvailable) {
                $key = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

                if ($key.VirtualKeyCode -eq 13) {
                    Write-Host ""
                    return $buffer.ToString()
                }

                if ($key.VirtualKeyCode -eq 8) {
                    if ($buffer.Length -gt 0) {
                        $buffer.Remove($buffer.Length - 1, 1) | Out-Null
                        Write-Host "`b `b" -NoNewline
                    }
                    continue
                }

                if ($key.VirtualKeyCode -eq 27) {
                    while ($buffer.Length -gt 0) {
                        $buffer.Remove($buffer.Length - 1, 1) | Out-Null
                        Write-Host "`b `b" -NoNewline
                    }
                    continue
                }

                $ch = [string]$key.Character
                if (-not [string]::IsNullOrEmpty($ch) -and [int][char]$ch[0] -ge 32) {
                    [void]$buffer.Append($ch)
                    Write-Host $ch -NoNewline
                }
            } else {
                Start-Sleep -Milliseconds 200
            }
        } catch {
            Write-Host ""
            return "__AUTO_REFRESH__"
        }
    }
}

function Show-MenuTable {
    param(
        $AllItems,
        [string]$StorageAccount,
        [string]$Container,
        [string]$TenantId,
        [string]$DownloadRoot
    )

    $commandsLine = "  [Idx] Download    [S] Search    [C] Clear Filter    [N] Toggle Notifications    [W] Toggle Window (20/100)    [R] Refresh    [L] FULL Clear + Reload    [X] Reset Azure Login Cache    [Q] Quit"
    Set-ConsoleWidthToFitCommands -CommandsLine $commandsLine -ExtraChars 5

    while ($true) {
        Clear-Host
        Write-InfoColor ("Running script: {0}" -f $PSCommandPath) DarkYellow
        Write-InfoColor ("Storage: {0}   Container: {1}   Tenant: {2}" -f $StorageAccount, $Container, $TenantId) Yellow
        Write-InfoColor ("Window: last {0} uploads" -f $script:WindowSize) DarkGray
        if ($script:LastRefreshLocal) {
            Write-InfoColor ("Last Refreshed: {0}" -f (Format-LocalRefreshStamp -Dt $script:LastRefreshLocal)) DarkGray
        }
        if ($script:NextRefreshLocal) {
            Write-InfoColor ("Next Auto Refresh: {0}" -f (Format-LocalRefreshStamp -Dt $script:NextRefreshLocal)) DarkGray
        }
        Write-InfoColor ("Notifications: {0}" -f ($(if ($script:NotificationsEnabled) { 'ON' } else { 'OFF' }))) DarkGray
        Write-InfoColor ("Self-update: {0}" -f ($(if ($EnableSelfUpdate) { 'ON' } else { 'OFF' }))) DarkGray

        if (-not [string]::IsNullOrWhiteSpace($script:CurrentFilterRaw)) {
            Write-InfoColor ("Active Filter: '{0}'" -f $script:CurrentFilterRaw) Cyan
        } else {
            Write-InfoColor "Active Filter: (none)" DarkGray
        }

        Write-Host ""
        Write-ColumnHeadings

        $all = Force-Array $AllItems

        $displayItems = @()
        if ($script:CurrentFilterTerms -and $script:CurrentFilterTerms.Length -gt 0) {
            foreach ($it in $all) {
                if (Item-MatchesTerms -Item $it -Terms $script:CurrentFilterTerms) { $displayItems += $it }
            }
        } else {
            $displayItems = $all
        }

        $displayCount = Count-Items $displayItems

        if ($displayCount -eq 0) {
            Write-InfoColor "No items match the current filter." Red
        } else {
            $idx = 1
            foreach ($item in $displayItems) {
                $company = Trunc $item.Company 20
                $ticket  = Trunc $item.Ticket 12
                $sender  = Trunc $item.Sender 12
                $stampEt  = Format-UploadStampET  -UtcOrUnknown $item.LastModified
                $stampIst = Format-UploadStampIST -UtcOrUnknown $item.LastModified

                $line = "{0,4}  {1,-20}  {2,-10}  {3,-12}  {4,6:N1}  {5,-30}  {6}" -f `
                        $idx, $company, $ticket, $sender, $item.SizeMB, $stampEt, $stampIst
                Write-Host $line
                $idx++
            }
        }

        Write-Host ""
        Write-Host "Commands:"
        Write-Host $commandsLine
        $input = Read-MenuSelectionWithAutoRefresh -RefreshDueLocal $script:NextRefreshLocal -Prompt "Selection"

        if ($input -eq "__AUTO_REFRESH__") {
            Write-Audit "Auto refresh triggered."
            return "REFRESH"
        }

        if ($input -match '^[Qq]$') { return "QUIT" }
        if ($input -match '^[Rr]$') { return "REFRESH" }

        if ($input -match '^[Ll]$') {
            Clear-BlobSessionState -StorageAccount $StorageAccount -Container $Container -IncludeLegacy -IncludeManagedCopy
            Start-Sleep -Seconds 1
            return "HARD_REFRESH"
        }

        if ($input -match '^[Ww]$') {
            if ($script:WindowSize -eq 20) { $script:WindowSize = 100 } else { $script:WindowSize = 20 }
            return "REFRESH"
        }

        if ($input -match '^[Nn]$') {
            Set-NotificationsEnabled -Enabled:(-not $script:NotificationsEnabled)
            Write-InfoColor ("Notifications now: {0}" -f ($(if ($script:NotificationsEnabled) { 'ON' } else { 'OFF' }))) Green
            Start-Sleep -Seconds 1
            continue
        }

        if ($input -match '^[Xx]$') {
            Reset-AzureLoginCache
            return "REFRESH"
        }

        if ($input -match '^[Ss]$') {
            $script:CurrentFilterRaw = Read-Host "Enter search terms (space-separated). Blank = none"
            $script:CurrentFilterTerms = Normalize-SearchTerms -Text $script:CurrentFilterRaw
            continue
        }

        if ($input -match '^[Cc]$') {
            $script:CurrentFilterRaw = ""
            $script:CurrentFilterTerms = @()
            continue
        }

        if ($input -match '^\d+$') {
            $num = [int]$input
            if ($num -lt 1 -or $num -gt $displayCount) {
                Write-InfoColor "Selection out of range." Red
                Start-Sleep -Seconds 1
                continue
            }

            $arr = Force-Array $displayItems
            $chosen = $arr[$num - 1]

            $downloaded = Download-AzureBlobRBAC -StorageAccountName $StorageAccount -ContainerName $Container -BlobName $chosen.Name -DownloadRoot $DownloadRoot
            Write-Audit ("Downloaded: {0}" -f $downloaded)

            if ($downloaded -and $downloaded.ToLower().EndsWith(".csb")) {
                Write-Host ""
                $yn = Read-Host "Decrypt this downloaded bundle now? (Y/N)"
                if ($yn -match '^[Yy]$') {
                    try {
                        Write-InfoColor "Decrypting .csb into the same download folder..." Yellow
                        $res = Decrypt-CSB-InPlace -CsbPath $downloaded -Passphrase $Global:CS_EncryptPassphrase
                        Write-InfoColor ("Decrypted ZIP : {0}" -f $res.ZipPath) Green
                        Write-InfoColor ("Extracted to  : {0}" -f $res.ExtractPath) Green
                        Write-Audit ("Decrypted: {0} -> {1}" -f $downloaded, $res.ExtractPath)
                        Open-Folder -Path $res.ExtractPath
                    } catch {
                        Write-InfoColor ("Decryption failed: {0}" -f $_.Exception.Message) Red
                        Write-Audit ("Decryption failed: {0}" -f $_.Exception.Message) 'ERROR'
                    }
                }
            }

            Write-Host ""
            Read-Host "Press Enter to return to the list" | Out-Null
            continue
        }

        Write-InfoColor "Unrecognized input." Red
        Start-Sleep -Seconds 1
    }
}

# =====================================================================
# MAIN
# =====================================================================
try {
    Ensure-Folder $Global:CollectedInfoRoot
    Write-Audit ("RUN START CS-secure-log-browser v3.5 (RBAC, window={0})" -f $script:WindowSize)
    Write-Audit ("Running script path: {0}" -f $PSCommandPath)

    Initialize-NotificationPreference
    Prompt-Passphrase
    Ensure-AzModules -ForceInstall:$ForceInstallModules
    Ensure-AzLogin -TenantId $AzureTenantId

    while ($true) {
        $useBypassCache = $false

        $load = Get-RecentItems -StorageAccount $AzureStorageAccount -Container $AzureContainer -VisibleWindowSize $script:WindowSize -BypassCache:$useBypassCache
        $items = Force-Array $load.Items
        $script:LastRefreshLocal = $load.RefreshedLocal
        $script:NextRefreshLocal = $script:LastRefreshLocal.AddMinutes($Global:CS_AutoRefreshMinutes)

        if (-not $script:LastLoadUsedCache) {
            Process-NewItemNotification -Items $items
        } else {
            Process-NewItemNotification -Items $items -SuppressPopup
        }

        if ($ExportOnly) {
            $outFile = Join-Path $Global:CollectedInfoRoot ("secure-log-browser-list_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            $items | ConvertTo-Json -Depth 8 | Out-File -FilePath $outFile -Encoding UTF8
            Write-InfoColor "ExportOnly: wrote list to:" Green
            Write-Host $outFile
            Write-Audit ("ExportOnly wrote {0}" -f $outFile)
            exit 0
        }

        if ((Count-Items $items) -eq 0) {
            Write-InfoColor "No items found." Yellow
            Write-Audit "No items found."
            exit 0
        }

        $result = Show-MenuTable -AllItems $items -StorageAccount $AzureStorageAccount -Container $AzureContainer -TenantId $AzureTenantId -DownloadRoot $DownloadRoot

        if ($result -eq "REFRESH" -or $result -eq "HARD_REFRESH") {
            if ($result -eq "HARD_REFRESH") {
                Clear-BlobSessionState -StorageAccount $AzureStorageAccount -Container $AzureContainer -IncludeLegacy -IncludeManagedCopy
            }

            Ensure-AzLogin -TenantId $AzureTenantId

            $load = Get-RecentItems -StorageAccount $AzureStorageAccount -Container $AzureContainer -VisibleWindowSize $script:WindowSize -BypassCache:$true
            $items = Force-Array $load.Items
            $script:LastRefreshLocal = $load.RefreshedLocal
            $script:NextRefreshLocal = $script:LastRefreshLocal.AddMinutes($Global:CS_AutoRefreshMinutes)

            Process-NewItemNotification -Items $items

            if ((Count-Items $items) -eq 0) {
                Write-InfoColor "No items found." Yellow
                Write-Audit "No items found after refresh."
                exit 0
            }

            continue
        }

        break
    }

    Write-Audit "RUN SUCCESS"
    exit 0
}
catch {
    Write-Audit $_.Exception.Message 'ERROR'
    Write-Error ("ERROR: {0}" -f $_.Exception.Message)
    exit 2
}